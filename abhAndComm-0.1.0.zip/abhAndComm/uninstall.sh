#!/usr/bin/env bash
#
# bbh bundle — uninstaller.
#
# Removes ONLY entries this bundle installed:
#   * a symlink whose target resolves inside the bundle root, or
#   * a copied directory carrying the .bbh-installed marker this installer wrote.
# A directory (or file) the installer did not create is left untouched, always.
# After removing an entry, the newest <name>.bak.<timestamp> backup is restored.

set -euo pipefail

MARKER_NAME=".bbh-installed"

SELF="${BASH_SOURCE[0]}"
while [ -L "$SELF" ]; do
    _link="$(readlink "$SELF")"
    case "$_link" in
        /*) SELF="$_link" ;;
        *) SELF="$(dirname "$SELF")/$_link" ;;
    esac
done
BUNDLE_ROOT="$(cd -- "$(dirname -- "$SELF")" && pwd -P)"

if [ -t 1 ] && [ -z "${NO_COLOR:-}" ]; then
    C_RESET=$'\033[0m'; C_BOLD=$'\033[1m'
    C_OK=$'\033[32m'; C_WARN=$'\033[33m'; C_ERR=$'\033[31m'
else
    C_RESET=''; C_BOLD=''; C_OK=''; C_WARN=''; C_ERR=''
fi

info() { printf '%s\n' "$*"; }
warn() { printf '%sWARN:%s %s\n' "$C_WARN" "$C_RESET" "$*" >&2; }
err()  { printf '%sERROR:%s %s\n' "$C_ERR" "$C_RESET" "$*" >&2; }
die()  { err "$*"; exit 2; }
hr()   { printf '%s\n' "------------------------------------------------------------------------"; }

usage() {
    cat <<'EOF'
bbh bundle uninstaller — remove only the skills this bundle installed.

Usage:
  ./uninstall.sh [options]

Options:
  --dest DIR        Skill root to clean (default: $DSH_HOME/skills, else ~/.dsh/skills).
  --scope user      Same resolution as install.sh (default).
  --scope project   Use $PWD/.agents/skills.
  --dry-run         Print what would be removed; change nothing.
  -h, --help        This help.

What is removed: a symlink pointing inside this bundle, or a copied directory with the
.bbh-installed marker naming this bundle. Everything else — including the upstream
packs' symlinks — is left in place. <name>.bak.<timestamp> backups are restored.
EOF
}

DEST=""
SCOPE="user"
DRY_RUN=0

while [ "$#" -gt 0 ]; do
    case "$1" in
        --dest)
            [ "$#" -ge 2 ] || die "--dest requires a value"
            DEST="$2"; shift 2 ;;
        --dest=*)
            DEST="${1#*=}"; shift ;;
        --scope)
            [ "$#" -ge 2 ] || die "--scope requires a value"
            SCOPE="$2"; shift 2 ;;
        --scope=*)
            SCOPE="${1#*=}"; shift ;;
        --dry-run)
            DRY_RUN=1; shift ;;
        -h|--help)
            usage; exit 0 ;;
        *)
            die "unknown option: $1 (try --help)" ;;
    esac
done

case "$SCOPE" in
    user|project) ;;
    *) die "--scope must be 'user' or 'project' (got: $SCOPE)" ;;
esac
if [ -n "$DEST" ] && [ "$SCOPE" != "user" ]; then
    die "--dest and --scope are mutually exclusive; --dest already names the exact root"
fi
if [ -z "$DEST" ] && [ "$SCOPE" = "project" ]; then
    DEST="$PWD/.agents/skills"
fi
DSH_HOME_DIR="${DSH_HOME:-$HOME/.dsh}"
[ -n "$DEST" ] || DEST="$DSH_HOME_DIR/skills"

normalize_path() {
    if command -v realpath >/dev/null 2>&1; then
        realpath -m -- "$1" 2>/dev/null && return 0
    fi
    case "$1" in
        /*) printf '%s\n' "$1" ;;
        *)  printf '%s\n' "$PWD/$1" ;;
    esac
}

path_is_inside() {
    local p r
    p="$(normalize_path "$1")"
    r="$(normalize_path "$2")"
    [ "$p" = "$r" ] && return 0
    case "$p" in "$r"/*) return 0 ;; esac
    return 1
}

marker_field() {
    local dir="$1" key="$2"
    [ -f "$dir/$MARKER_NAME" ] || return 1
    sed -n "s/^${key}=//p" "$dir/$MARKER_NAME" 2>/dev/null | head -n 1
}

# 0 = this entry was installed by this bundle
owned_by_bundle() {
    local target="$1" raw resolved bundle
    if [ -L "$target" ]; then
        raw="$(readlink -- "$target")"
        case "$raw" in
            /*) resolved="$raw" ;;
            *)  resolved="$(dirname -- "$target")/$raw" ;;
        esac
        path_is_inside "$resolved" "$BUNDLE_ROOT"
        return $?
    fi
    if [ -d "$target" ]; then
        bundle="$(marker_field "$target" bundle || true)"
        [ -n "$bundle" ] && [ "$(normalize_path "$bundle")" = "$(normalize_path "$BUNDLE_ROOT")" ]
        return $?
    fi
    return 1
}

newest_backup() { # name -> prints newest <name>.bak.<stamp> path
    local name="$1" candidate="" best="" entry stamp
    [ -d "$DEST" ] || return 1
    for entry in "$DEST/$name".bak.*; do
        [ -e "$entry" ] || [ -L "$entry" ] || continue
        stamp="${entry##*.bak.}"
        if [ -z "$best" ] || [ "$stamp" \> "$best" ]; then
            best="$stamp"; candidate="$entry"
        fi
    done
    [ -n "$candidate" ] || return 1
    printf '%s\n' "$candidate"
}

REMOVED=0
RESTORED=0
KEPT=0
FAILED=0
TABLE_LINES=()
RESTORE_LINES=()

info "bbh bundle uninstaller"
info "  bundle      : $BUNDLE_ROOT"
info "  destination : $DEST"
[ "$DRY_RUN" -eq 1 ] && info "  dry-run     : yes — nothing will be removed"
hr

if [ ! -d "$DEST" ]; then
    warn "destination does not exist: $DEST — nothing to do"
    exit 0
fi
if [ ! -w "$DEST" ]; then
    err "destination is not writable: $DEST"
    err "  re-run with --dest DIR naming the root you installed into; this script never uses sudo."
    exit 2
fi

for target in "$DEST"/*; do
    [ -e "$target" ] || [ -L "$target" ] || continue
    name="$(basename -- "$target")"
    case "$name" in
        .*) continue ;;
        *.bak.*) continue ;;   # handled only as restore candidates
    esac

    if ! owned_by_bundle "$target"; then
        KEPT=$((KEPT + 1))
        continue
    fi

    detail="copied directory (marker)"
    if [ -L "$target" ]; then
        detail="symlink -> $(readlink -- "$target")"
    fi

    if [ "$DRY_RUN" -eq 1 ]; then
        REMOVED=$((REMOVED + 1))
        TABLE_LINES+=("$(printf 'would remove  %-28s %s' "$name" "$detail")")
    else
        if rm -rf -- "$target" 2>/dev/null; then
            REMOVED=$((REMOVED + 1))
            TABLE_LINES+=("$(printf 'removed       %-28s %s' "$name" "$detail")")
        else
            FAILED=$((FAILED + 1))
            TABLE_LINES+=("$(printf 'failed        %-28s could not remove' "$name")")
            continue
        fi
    fi

    if backup="$(newest_backup "$name")"; then
        if [ "$DRY_RUN" -eq 1 ]; then
            RESTORED=$((RESTORED + 1))
            RESTORE_LINES+=("$(printf 'would restore %-28s %s -> %s' "$name" "$(basename -- "$backup")" "$name")")
        elif mv -- "$backup" "$DEST/$name" 2>/dev/null; then
            RESTORED=$((RESTORED + 1))
            RESTORE_LINES+=("$(printf 'restored      %-28s %s -> %s' "$name" "$(basename -- "$backup")" "$name")")
        else
            FAILED=$((FAILED + 1))
            RESTORE_LINES+=("$(printf 'failed        %-28s could not restore %s' "$name" "$(basename -- "$backup")")")
        fi
    fi
done

hr
printf '%s%-13s %-28s %s%s\n' "$C_BOLD" "RESULT" "SKILL" "DETAIL" "$C_RESET"
hr
if [ "${#TABLE_LINES[@]}" -gt 0 ]; then
    printf '%s\n' ${TABLE_LINES[@]+"${TABLE_LINES[@]}"}
fi
if [ "${#RESTORE_LINES[@]}" -gt 0 ]; then
    printf '%s\n' ${RESTORE_LINES[@]+"${RESTORE_LINES[@]}"}
fi
if [ "${#TABLE_LINES[@]}" -eq 0 ] && [ "${#RESTORE_LINES[@]}" -eq 0 ]; then
    info "  (no entries belonging to this bundle were found)"
fi
hr
printf '%sremoved | restored | kept (untouched) | failed%s\n' "$C_BOLD" "$C_RESET"
printf '%7d | %8d | %16d | %6d\n' "$REMOVED" "$RESTORED" "$KEPT" "$FAILED"
info ""
info "kept (untouched): $KEPT entr(ies) in $DEST do not belong to this bundle and were left alone."

if [ "$FAILED" -gt 0 ]; then
    err "completed with $FAILED failure(s)"
    exit 1
fi
if [ "$DRY_RUN" -eq 1 ]; then
    info "dry-run complete — nothing was removed"
else
    info "Uninstall complete. Other skill roots (e.g. ~/.agents/skills) were not touched."
fi
exit 0
