# Bug-Bounty Attack-Class Coverage Matrix

**24 classes** — machine-readable companion: [`bounty-coverage-matrix.json`](bounty-coverage-matrix.json).

Derived from transilienceai/communitytools `skills/coordination/reference/coverage-matrix.json` (v2026-07-11, `95fdc128af4c`), adapted for this web/API bug-bounty bundle. `tools/cells_build.py` evaluates each class's `applies_when` predicate against a scope's flag set to produce the applicable-cell work-list; `tools/coverage_gate.py` joins that list against real on-disk evidence.

## What changed from upstream

- **Dropped 15 `MAS-*` mobile classes** (MASVS-2023). See `meta.dropped_classes` in the JSON for the full list and the reason.
- **Every `technique_ref` re-pointed** at the vendored tree (`vendor/upstream-skills/...`) and asserted to exist on disk after the copy.
- **Two new per-class fields:** `bounty_tier` (`high` | `medium` | `low`) and `needs_chain` (boolean).
- `applies_when` grammar, the 18-name `agent_flags` vocabulary and the 7-name `derived_flags` vocabulary are **byte-identical to upstream**.

### Bounty tier split

| tier | classes | meaning |
|---|---|---|
| `high` | 11 | pays standalone on a typical HackerOne/Bugcrowd-style program |
| `medium` | 5 | pays when the impact is demonstrated; often triaged down or duplicate-heavy |
| `low` | 8 | mostly N/A or informational; value appears only through a chain |

`needs_chain` is `true` for **11 of 24** classes — these are the classes the chain stage should expect to combine with another bug before they are worth reporting.

### Scope split

| scope | keyed by | classes |
|---|---|---|
| `unit` | `unit_id` | 12 |
| `host` | `listener` | 6 |
| `asset` | `asset_tag` | 6 |

### Genuine-negative requirement (`negative_kind`)

| negative_kind | classes | what closes the cell as a covered negative |
|---|---|---|
| `active_probe` | 20 | a non-agent tool-log corroborator (the probe actually ran) |
| `reachability` | 1 | ≥ `min_vantages` distinct **verified** vantage regions |
| `none` | 3 | a corroborated probe, no extra requirement |

### `applies_when` predicate grammar

The applies_when grammar is byte-identical to upstream and is the ONLY grammar tools/cells_build.py needs to implement. Exactly three forms exist; an object carries exactly one of these keys.

| form | meaning | classes using it |
|---|---|---|
| `{"always": true}` | applicable to every scope of its scope kind | 1 |
| `{"any_flag": [flag, ...]}` | applicable iff at least one listed flag is set | 23 |
| `{"all_flags": [flag, ...]}` | applicable iff every listed flag is set | 0 |

> all_flags is supported by the grammar but is used by ZERO classes after the MAS-* drop (every upstream all_flags predicate was mobile-only). tools/cells_build.py must still implement it so a future class can use it.

### Dropped classes

15 upstream `MASVS-2023` classes were removed:

`MAS-STORAGE-LOCAL`, `MAS-CRYPTO-WEAK`, `MAS-PLATFORM-IPC`, `MAS-PLATFORM-WEBVIEW`, `MAS-STORAGE-LOGS`, `MAS-CRYPTO-KEYMGMT`, `MAS-AUTH-LOCAL`, `MAS-NETWORK-CLEARTEXT`, `MAS-NETWORK-PINNING`, `MAS-PLATFORM-SCREEN`, `MAS-CODE-DEPENDENCY`, `MAS-CODE-SECRETS`, `MAS-RESILIENCE-ROOT`, `MAS-RESILIENCE-INTEGRITY`, `MAS-PRIVACY-DATA`

Mobile app-bundle classes are unreachable in this bundle: every MAS-* predicate requires the code-derived mobile_app flag, and cells_build.py only derives mobile_app for a recon/inventory/mobile-surface.json that this web/API pipeline never produces. Keeping them would add 15 permanently-inapplicable rows to every coverage ledger and would make the hard-100% coverage gate's denominator lie about what was in scope.

## Classes

`applies_when` is shown in the compact predicate-DSL form; see the JSON for the exact object. `tier` and `chain` are the bounty-pipeline fields.

| class_id | taxonomy | what it is | applies_when (trigger) | tier | chain | technique_ref |
|---|---|---|---|---|---|---|
| `API1-BOLA` | API-2023 | Broken Object Level Authorization (cross-tenant object access) | `{"any_flag": ["object_by_id"]}` | **high** | — | [`vendor/upstream-skills/api-security/reference/scenarios/rest/owasp-bola-bopla.md`](../vendor/upstream-skills/api-security/reference/scenarios/rest/owasp-bola-bopla.md) |
| `API3-BOPLA` | API-2023 | Broken Object Property Level Auth / mass-assignment | `{"any_flag": ["json_body"]}` | **high** | — | [`vendor/upstream-skills/api-security/reference/scenarios/rest/mass-assignment.md`](../vendor/upstream-skills/api-security/reference/scenarios/rest/mass-assignment.md) |
| `API5-BFLA` | API-2023 | Broken Function Level Authorization (role/verb) | `{"any_flag": ["role_verb_gated"]}` | **high** | — | [`vendor/upstream-skills/web-app-logic/SKILL.md`](../vendor/upstream-skills/web-app-logic/SKILL.md) |
| `API6-BUSINESS` | API-2023 | Unrestricted access to sensitive business flows | `{"any_flag": ["sensitive_flow"]}` | **high** | — | [`vendor/upstream-skills/web-app-logic/SKILL.md`](../vendor/upstream-skills/web-app-logic/SKILL.md) |
| `API7-SSRF` | API-2023 | Server-Side Request Forgery (incl. stored connector/webhook URL) | `{"any_flag": ["server_fetched_url"]}` | **high** | — | [`vendor/upstream-skills/server-side/SKILL.md`](../vendor/upstream-skills/server-side/SKILL.md) |
| `API10-CONSUMPTION` | API-2023 | Unsafe consumption of 3rd-party APIs | `{"any_flag": ["consumes_upstream"]}` | **low** | yes | [`vendor/upstream-skills/api-security/reference/scenarios/rest/api-recon-and-discovery.md`](../vendor/upstream-skills/api-security/reference/scenarios/rest/api-recon-and-discovery.md) |
| `WEB-A03-INJECTION` | Web-2021 | Injection (SQLi/NoSQLi/cmd/SSTI/XXE) | `{"any_flag": ["input_sink"]}` | **high** | — | [`vendor/upstream-skills/injection/SKILL.md`](../vendor/upstream-skills/injection/SKILL.md) |
| `WEB-A04-DESIGN` | Web-2021 | Insecure design / logic flaw | `{"any_flag": ["workflow"]}` | **high** | — | [`vendor/upstream-skills/web-app-logic/SKILL.md`](../vendor/upstream-skills/web-app-logic/SKILL.md) |
| `WEB-A08-INTEGRITY` | Web-2021 | Software/data integrity (insecure deserialization / CI) | `{"any_flag": ["deser_or_ci"]}` | **high** | — | [`vendor/upstream-skills/server-side/reference/insecure-deserialization-resources.md`](../vendor/upstream-skills/server-side/reference/insecure-deserialization-resources.md) |
| `XC-WEBHOOK-ORACLE` | Cross-cut | Unauthenticated webhook/ingress state oracle | `{"any_flag": ["inbound_webhook"]}` | **medium** | yes | [`vendor/upstream-skills/api-security/reference/scenarios/rest/unauthenticated-webhook-oracle.md`](../vendor/upstream-skills/api-security/reference/scenarios/rest/unauthenticated-webhook-oracle.md) |
| `XC-EXISTENCE-ORACLE` | Cross-cut | Unauth existence/enumeration oracle (via error-ordering) | `{"any_flag": ["id_keyed_unauth"]}` | **low** | yes | [`vendor/upstream-skills/api-security/reference/scenarios/rest/unauth-existence-oracle.md`](../vendor/upstream-skills/api-security/reference/scenarios/rest/unauth-existence-oracle.md) |
| `XC-STORED-XSS` | Cross-cut | Stored/reflected/DOM XSS | `{"any_flag": ["stored_field"]}` | **high** | — | [`vendor/upstream-skills/client-side/SKILL.md`](../vendor/upstream-skills/client-side/SKILL.md) |
| `WEB-A06-COMPONENTS` | Web-2021 | Vulnerable & outdated components | `{"any_flag": ["version_fingerprinted"]}` | **medium** | — | [`vendor/upstream-skills/cve-poc-generator/SKILL.md`](../vendor/upstream-skills/cve-poc-generator/SKILL.md) |
| `XC-CORS` | Cross-cut | CORS misconfiguration (reflected origin / null / credentials) | `{"any_flag": ["http_listener"]}` | **medium** | yes | [`vendor/upstream-skills/api-security/reference/scenarios/rest/cors-misconfiguration.md`](../vendor/upstream-skills/api-security/reference/scenarios/rest/cors-misconfiguration.md) |
| `XC-TRANSPORT-DOWNGRADE` | Cross-cut | HTTPS->HTTP redirect downgrade / missing HSTS | `{"any_flag": ["http_listener"]}` | **low** | yes | [`vendor/upstream-skills/api-security/reference/scenarios/rest/https-downgrade-redirect-hsts.md`](../vendor/upstream-skills/api-security/reference/scenarios/rest/https-downgrade-redirect-hsts.md) |
| `XC-VERBOSE-ERRORS` | Cross-cut | Verbose errors (stack/schema/framework disclosure) | `{"any_flag": ["http_listener"]}` | **low** | yes | [`vendor/upstream-skills/api-security/reference/scenarios/rest/verbose-error-schema-disclosure.md`](../vendor/upstream-skills/api-security/reference/scenarios/rest/verbose-error-schema-disclosure.md) |
| `XC-SECURITY-HEADERS` | Cross-cut | Security headers (per web origin) | `{"any_flag": ["http_listener"]}` | **low** | yes | [`vendor/upstream-skills/api-security/reference/scenarios/rest/https-downgrade-redirect-hsts.md`](../vendor/upstream-skills/api-security/reference/scenarios/rest/https-downgrade-redirect-hsts.md) |
| `XC-TLS-POSTURE` | Cross-cut | TLS posture (weak ciphers/protocols) via sslscan | `{"any_flag": ["tls_listener"]}` | **low** | yes | [`vendor/upstream-skills/api-security/reference/scenarios/rest/https-downgrade-redirect-hsts.md`](../vendor/upstream-skills/api-security/reference/scenarios/rest/https-downgrade-redirect-hsts.md) |
| `API4-RESOURCE` | API-2023 | Unrestricted Resource Consumption (rate/limit) | `{"any_flag": ["has_api"]}` | **low** | yes | [`vendor/upstream-skills/api-security/reference/scenarios/rest/api-recon-and-discovery.md`](../vendor/upstream-skills/api-security/reference/scenarios/rest/api-recon-and-discovery.md) |
| `API2-BROKEN-AUTH` | API-2023 | Broken Authentication | `{"any_flag": ["auth_surface"]}` | **high** | — | [`vendor/upstream-skills/authentication/SKILL.md`](../vendor/upstream-skills/authentication/SKILL.md) |
| `API8-MISCONFIG` | API-2023 | Security misconfiguration | `{"always": true}` | **medium** | — | [`vendor/upstream-skills/web-app-logic/SKILL.md`](../vendor/upstream-skills/web-app-logic/SKILL.md) |
| `API9-INVENTORY` | API-2023 | Improper inventory (shadow/old versions, public docs/swagger) | `{"any_flag": ["has_api"]}` | **low** | yes | [`vendor/upstream-skills/api-security/reference/scenarios/rest/exposed-documentation.md`](../vendor/upstream-skills/api-security/reference/scenarios/rest/exposed-documentation.md) |
| `XC-SUBDOMAIN-ORIGIN` | Cross-cut | Subdomain/origin exposure (CDN bypass, exposed admin/mgmt panels) | `{"any_flag": ["is_apex"]}` | **medium** | yes | [`vendor/upstream-skills/reconnaissance/reference/scenarios/subdomain-enumeration.md`](../vendor/upstream-skills/reconnaissance/reference/scenarios/subdomain-enumeration.md) |
| `XC-SECRET-EXPOSURE` | Cross-cut | Secret/key exposure in JS bundles, docs, git | `{"any_flag": ["serves_js", "static_js_or_repo"]}` | **high** | — | [`vendor/upstream-skills/osint/SKILL.md`](../vendor/upstream-skills/osint/SKILL.md) |

### Why each tier

| class_id | tier | chain | rationale |
|---|---|---|---|
| `API1-BOLA` | high | — | The single highest-paid API class on H1/Bugcrowd; cross-tenant object reads and writes are accepted on their own. |
| `API3-BOPLA` | high | — | Mass assignment that sets a privileged property (role, tenant, verified, price) is a self-contained privilege escalation. |
| `API5-BFLA` | high | — | Reaching an admin/role-gated function with a lower-privilege token pays standalone; verb tampering is a routine variant. |
| `API6-BUSINESS` | high | — | Business-logic abuse (coupon stacking, negative quantity, refund loops) is reliably paid when a concrete loss is demonstrated. |
| `API7-SSRF` | high | — | SSRF with demonstrated impact (cloud metadata, internal service read, credential capture) is high; DNS-only SSRF is the weak variant and is handled by the chain stage. |
| `API10-CONSUMPTION` | low | yes | Unsafe third-party API consumption is rarely accepted without a second bug showing what the attacker actually gains. |
| `WEB-A03-INJECTION` | high | — | SQLi, command injection and SSTI remain top-paying; XXE/NoSQLi pay when data or RCE is shown. |
| `WEB-A04-DESIGN` | high | — | Insecure design / logic flaws pay well because they are unfixable by a WAF and usually unique to the target. |
| `WEB-A08-INTEGRITY` | high | — | Insecure deserialization reaching RCE is a critical standalone; CI/CD injection that yields secrets or code exec pays the same. |
| `XC-WEBHOOK-ORACLE` | medium | yes | An unauthenticated webhook/ingress state oracle is usually Low alone; it becomes Medium/High once chained to a state change or a data leak. |
| `XC-EXISTENCE-ORACLE` | low | yes | Enumeration/existence oracles are almost always triaged informational unless chained to an account-takeover or mass-enumeration impact. |
| `XC-STORED-XSS` | high | — | Stored XSS pays standalone (session/ATO on admin review, wormable spread). The class is gated on stored_field, so the primary case is the stored variant. |
| `WEB-A06-COMPONENTS` | medium | — | Outdated components only pay when a reachable, pre-auth or auth-bypassing CVE is confirmed active - not on a version banner alone. |
| `XC-CORS` | medium | yes | Reflected-origin + ACAC:true against a credentialed sensitive endpoint pays Medium/High; the wildcard or Bearer-only variant is normally rejected standalone (see severity-calibration.md). |
| `XC-TRANSPORT-DOWNGRADE` | low | yes | Missing HSTS / HTTP redirect downgrade is a hardening finding; it only pays chained to a MITM or cookie-theft primitive. |
| `XC-VERBOSE-ERRORS` | low | yes | Stack traces and schema disclosure are informational alone; they pay when the disclosed material unlocks a real bug. |
| `XC-SECURITY-HEADERS` | low | yes | Missing security headers are on most programs' N/A list; value only appears when a header gap enables an actual attack (clickjacking on a state-changing page, CSP bypass). |
| `XC-TLS-POSTURE` | low | yes | Weak ciphers/protocols are a posture finding; standalone they are N/A almost everywhere and only matter chained to interception. |
| `API4-RESOURCE` | low | yes | Rate-limit and resource-consumption reports are usually closed as informational or DoS-out-of-scope; they pay only with a demonstrated business impact beyond 'I can send many requests'. |
| `API2-BROKEN-AUTH` | high | — | Auth bypass, JWT confusion, OAuth misbinding and 2FA bypass are high-severity standalone classes. |
| `API8-MISCONFIG` | medium | — | Broad catch-all: exposed debug/admin surfaces and permissive defaults pay at Medium; generic hardening gaps inside it do not. |
| `API9-INVENTORY` | low | yes | Exposed Swagger/OpenAPI is informational on its own; shadow or deprecated API versions pay when they lack the current version's authorization. |
| `XC-SUBDOMAIN-ORIGIN` | medium | yes | An exposed origin/admin panel is a Medium when it defeats the WAF or reaches an unauthenticated console; a bare origin IP is usually informational without a second bug. |
| `XC-SECRET-EXPOSURE` | high | — | Live cloud keys, API tokens or session secrets in JS bundles, docs or git history pay standalone and are routinely High/Critical. |

### Applicability flags

`applies_when` predicates are evaluated by code against these vocabularies. They are byte-identical to upstream and **must not be renamed**.

**Agent-set flags (18)** — written only by `tools/surface_build.py`, each with its evidence line:

`object_by_id`, `json_body`, `role_verb_gated`, `sensitive_flow`, `server_fetched_url`, `input_sink`, `workflow`, `deser_or_ci`, `inbound_webhook`, `id_keyed_unauth`, `stored_field`, `auth_surface`, `consumes_upstream`, `static_js_or_repo`, `local_store`, `crypto_use`, `exported_component`, `webview`

**Code-derived flags (7)** — recomputed by `tools/cells_build.py` from the unit's shape; an agent may never write these:

`http_listener`, `tls_listener`, `version_fingerprinted`, `has_api`, `is_apex`, `serves_js`, `mobile_app`

> Four agent flags (`local_store`, `crypto_use`, `exported_component`, `webview`) and one derived flag (`mobile_app`) are retained for vocabulary parity but are referenced by no class in this catalogue, because the only classes that used them were the dropped `MAS-*` set.

### technique_ref substitutions

| class_id | upstream ref (not vendored) | bundle ref | reason |
|---|---|---|---|
| `WEB-A06-COMPONENTS` | `skills/source-code-scanning/SKILL.md` | `vendor/upstream-skills/cve-poc-generator/SKILL.md` | upstream ref was skills/source-code-scanning/SKILL.md, which is not vendored; cve-poc-generator is the vendored skill that covers the version/CVE -> advisory -> PoC step this host-scope class needs |
| `XC-TLS-POSTURE` | `skills/cryptography/SKILL.md` | `vendor/upstream-skills/api-security/reference/scenarios/rest/https-downgrade-redirect-hsts.md` | upstream ref was skills/cryptography/SKILL.md, which is not vendored (out of scope for web/API); the vendored transport scenario names itself the companion of XC-TLS-POSTURE and documents the sslscan/testssl.sh route |

### OWASP Top 10 2021 accounting

Every OWASP Top 10 2021 category is accounted for: either >=1 class carries it in owasp_refs, or it is listed in not_assessed with a reason. validate_catalog.py fails if any A01-A10 is neither. This is what lets a coverage claim cite OWASP without inventing duplicate classes.

- **A09:2021** — Security Logging and Monitoring Failures — not observable from the client side: whether events are logged, retained and alerted on is a property of infrastructure the test does not see. Assess it in a configuration/posture review, not a black-box or grey-box application test, and state the exclusion in the report rather than implying coverage.
