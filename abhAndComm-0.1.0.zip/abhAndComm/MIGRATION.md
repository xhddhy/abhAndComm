# bbh 迁移手册（MIGRATION）

> 适用版本：`0.1.0`（见 `VERSION`）
> 读者：需要把这套 bundle 装到另一台 DSH 上、或把它从一台机器搬到另一台机器的操作者。
> 约定：正文中文，代码 / 路径 / 命令 / 标识符保持英文。

---

## 0. 三分钟迁移（TL;DR）

在**源机**打包（不要带 `_upstream/`、`runs/`）：

```bash
tar --exclude='_upstream' --exclude='runs' --exclude='__pycache__' --exclude='.git' \
    -czf bbh-0.1.0.tar.gz -C /me/ai/dsh/bounty abhAndComm
```

在**目标机**解开并安装：

```bash
mkdir -p /opt/bbh && tar -xzf bbh-0.1.0.tar.gz -C /opt/bbh
cd /opt/bbh/abhAndComm
chmod -R a+rX .              # bundle 里若有 600 权限的文件，先放开读权限
python3 tools/context_guard.py   # 必须 OK，否则先 --fix（见「工作区指令注入」）
./install.sh                     # 默认 user scope（$DSH_HOME/skills）+ vendor skills
ls -l "${DSH_HOME:-$HOME/.dsh}/skills" | grep bbh
```

然后**新开一个 DSH 会话**，在会话技能表里确认能看到 `bbh` / `bbh-*`。
卸载用 `./uninstall.sh --dest "${DSH_HOME:-$HOME/.dsh}/skills"`。

---

## 1. 这套东西是什么、装在 DSH 的哪一层

**skills 是文件系统发现，不是 npm 插件。** DSH 的 `skill-filesystem` provider 扫描若干
*skill root*，在每个 root 的**顶层**识别两种形状：

- 目录 bundle：`<root>/<name>/SKILL.md`
- 扁平文件：`<root>/<name>.md`

嵌套的 `**/SKILL.md`（例如 `skills/foo/references/SKILL.md`）**故意不会被发现**。
`SKILL.md` 的 YAML frontmatter 必须同时有 `name` 和 `description`，否则整个技能被静默跳过
（只在日志里 warning，模型侧看不到任何 per-skill 诊断）。

root 的扫描优先级（数字越小越优先，同名技能取优先级最高者）：

| rank | source | 路径 |
|---|---|---|
| 100 | project-dsh | `<projectRoot>/.dsh/skills` |
| 200 | project-agents | `<projectRoot>/.agents/skills` |
| 300 | custom | DSH 配置里的 `customSkillDirs` |
| 400 | user-dsh | `$DSH_HOME/skills`（未设置则为 `~/.dsh/skills`） |
| 500 | user-agents | `~/.agents/skills`（`$DSH_AGENTS_HOME`） |

`projectRoot` = **会话工作目录的最近一个含 `.git` 的祖先目录**；如果一路到 `/` 都没有 `.git`，
则 project root 就是工作目录本身。

结论：**安装 = 把目录放进某个 root（或 symlink 过去）；迁移 = 拷目录 + 重跑 `install.sh`。**
没有 npm install、没有数据库、没有构建步骤，也没有需要改写的 DSH 配置文件。

bundle 组成：

| 路径 | 作用 | 是不是 skill |
|---|---|---|
| `skills/bbh-*` | 本 bundle 自己的技能（重写版流水线） | 是（会被安装） |
| `vendor/upstream-skills/` | 两个上游包的技能副本，**仅当目标机没有同名技能时**才安装 | 是（条件安装） |
| `contracts/` `tools/` `workflows/` `catalog/` | schema、CLI 工具、工作流、覆盖矩阵等支持文件 | 否 |
| `install.sh` / `uninstall.sh` | 安装 / 卸载 | — |
| `tools/sync-upstream.sh` | 重新拉取 `_upstream/` 并清理注入面 | — |
| `tools/context_guard.py` | 扫描指令注入面（见「工作区指令注入」） | — |
| `VERSION` | 语义版本 + 上游 revision | — |

skill root 有 watcher：新增 / 删除 / 改 frontmatter 会在下一个 step 刷新技能表，通常**不需要重启
DSH**；不确定时新开一个会话最稳。

---

## 2. 两种安装位置：user-scope 与 project-scope

| | user scope | project scope |
|---|---|---|
| 路径 | `$DSH_HOME/skills`（回退 `~/.dsh/skills`） | `<project>/.agents/skills` |
| 对应 rank | 400 | 200（优先级更高） |
| 命令 | `./install.sh`（默认） | `./install.sh --scope project`（用 `$PWD/.agents/skills`） |
| 可见范围 | 该用户在这台机器上的**所有** DSH 会话 | 只有 project root 之下的会话 |
| 适合 | 个人长期使用、跨多个项目、迁移最省事 | skills 要跟项目一起版本化 / 团队共享 / 与其它项目隔离 |
| 依赖 | 无 | **必须有 `.git`**，否则 DSH 不认为那是 project root |

**为什么 project-scope 依赖 `.git`：** DSH 用「最近一个含 `.git` 的祖先」定位 project root。
如果 `<project>` 里没有 `.git`，project root 会退化成**会话的工作目录本身**——你从
`<project>/tools/` 启动会话，root 就是 `<project>/tools/`，于是 `<project>/.agents/skills`
根本不在扫描范围内，skill 看起来「装了但不存在」。

project-scope 的另一个副作用：skills 从此和 agent 读取指令的目录树重叠，任何放在项目里的
`AGENTS.md` / `CLAUDE.md` 都会随会话一起加载，暴露面更大——详见
[工作区指令注入](#工作区指令注入)。

第三种选择：`./install.sh --dest /opt/skills` 装到任意目录，再在 DSH 配置里用
`customSkillDirs`（rank 300）把它接进来。`install.sh` 只**打印**可粘贴的 YAML 片段，
**从不修改**任何 DSH 配置文件：

```yaml
# ~/.dsh/profiles/<profile>/cordis.patch.yml
- name: '@deepseek-ai/dsh-skill-filesystem'
  config:
    customSkillDirs:
      - /opt/bbh/abhAndComm/skills
```

---

## 3. 迁移到另一台 DSH 的完整步骤

### 步骤 0 — 目标机前置

- DSH 可运行；清楚这台机器的 `$DSH_HOME`（未设置即 `~/.dsh`）。
- `python3 >= 3.10`（`install.sh` 会硬校验并拒绝低版本）。
- `git`（仅当要在目标机跑 `tools/sync-upstream.sh` 时需要）。
- 目标用户对 skill root 有写权限；本 bundle **绝不使用 sudo**。

### 步骤 1 — 拷目录（两种方式选一）

**方式 A：rsync（推荐，增量、可重复）**

```bash
rsync -a --delete \
  --exclude '_upstream/' --exclude 'runs/' --exclude '__pycache__/' --exclude '.git/' \
  /me/ai/dsh/bounty/abhAndComm/ newhost:/opt/bbh/abhAndComm/
```

`-a` 保留符号链接 / 权限 / 时间戳；`--delete` 让目标与源一致（被 exclude 的目录不受影响）。
跨用户拷贝后如果目标用户不是 owner，执行一次 `chmod -R a+rX /opt/bbh/abhAndComm`。

**方式 B：tar（目标机没有 rsync 时）**

```bash
# 源机
tar --exclude='_upstream' --exclude='runs' --exclude='__pycache__' --exclude='.git' \
    -czf bbh-0.1.0.tar.gz -C /me/ai/dsh/bounty abhAndComm
# 传输
scp bbh-0.1.0.tar.gz newhost:/tmp/
# 目标机
ssh newhost 'mkdir -p /opt/bbh && tar -xzf /tmp/bbh-0.1.0.tar.gz -C /opt/bbh && chmod -R a+rX /opt/bbh/abhAndComm'
```

### 步骤 2 — 预检 + 安装

```bash
cd /opt/bbh/abhAndComm

python3 tools/context_guard.py            # 必须 OK；有 findings 先 python3 tools/context_guard.py --fix
./install.sh --dry-run                    # 先看清单：装哪些、跳过哪些、为什么跳过
./install.sh                              # user scope，symlink + vendor（默认）
# 其他常用形态：
./install.sh --scope project              # 装到 $PWD/.agents/skills（该目录要有 .git）
./install.sh --dest /opt/skills --copy    # bundle 会被移动/删除，或目标在不同文件系统
./install.sh --no-vendor                  # 目标机已有两个上游包
```

`install.sh` 的行为要点：

- 幂等：重复执行不改变任何东西，summary 与第一次一致。
- 已有同名条目：**跳过并说明原因**（保护上游 pack，避免遮蔽）；`--force` 才会先备份成
  `<name>.bak.<timestamp>` 再替换。
- symlink 优先；检测到跨文件系统会自动降级为 `--copy` 并警告。
- 安装后逐个校验 `test -f <dest>/<name>/SKILL.md`（跟随 symlink）与 frontmatter 的
  `name` / `description`，最后打印 `installed | skipped (exists) | failed` 表。

### 步骤 3 — 验证 skill 出现在会话技能表

```bash
ls -l "${DSH_HOME:-$HOME/.dsh}/skills" | grep -E 'bbh|->'
readlink -f "${DSH_HOME:-$HOME/.dsh}/skills/bbh"      # 应指向 bundle 的 skills/bbh
python3 tools/context_guard.py                        # 再次确认工作区干净
```

然后在 DSH 里**新开一个会话**（或推进到下一个 step），确认技能表里出现 `bbh` / `bbh-*`；
project-scope 安装时，确认会话的工作目录在该 project root 之下。
如果技能带 `disable-model-invocation: true`，它**不会**出现在模型技能表，但 `/name` 仍然可用。

### 步骤 4 — 跑一次自检

```bash
python3 tools/bbh_scope.py --help
python3 tools/schema_check.py --help
python3 tools/cvss_recompute.py --vector 'CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:H/A:N' --json
./install.sh --dry-run                    # 第二次执行，summary 应与第一次相同（幂等证明）
tools/sync-upstream.sh --check            # 上游是否移动（只读，不改任何文件）
./uninstall.sh --dest "${DSH_HOME:-$HOME/.dsh}/skills" --dry-run
```

具体 CLI 以 `tools/README.md` 为准（它冻结了阶段之间的接口契约）。

---

## 4. 迁移后必须重新确认的外部依赖

先跑一次汇总检查：

```bash
python3 -V
python3 -c 'import jsonschema, requests; print("optional deps ok")'
for t in httpx katana gau ffuf jq git; do printf '%-8s %s\n' "$t" "$(command -v $t || echo MISSING)"; done
```

| 依赖 | 用在哪 | 缺失的后果 |
|---|---|---|
| `python3 >= 3.10` | 所有 `tools/*.py` | **硬失败**：`install.sh` 直接拒绝安装 |
| `jsonschema` | `schema_check.py`、contracts 校验 | 阶段边界的 schema 校验降级为人工检查，**安装不被阻塞**（`install.sh` 标为 OPTIONAL） |
| `requests` | `nvd_lookup.py`、在线抓取 | NVD / 在线查询降级；有 `--cache-dir` 冻结快照时仍可复现，否则该步跳过 |
| `pyyaml` | 读 YAML 的工具 | 相关工具降级，不影响安装 |
| `httpx`（ProjectDiscovery **CLI**） | executor 阶段的存活确认 | 降级为 `python3 -c 'import requests'` / `curl` 手工确认。注意重名陷阱：`python3 -c "import httpx"` 成功**不代表** CLI 存在，要用 `command -v httpx` |
| `katana` | 爬虫 / 端点发现 | 降级到 `gau` + wayback + JS 解析，覆盖面变薄 |
| `gau` | 历史 URL / 参数 | URL 面收窄 → queue 的 lead 变少；流程不失败，只是覆盖变薄 |
| `ffuf` | 目录 / 内容爆破 | admin、config 路径发现降级为手工或自带字典脚本 |
| `jq` | shell 流水线便利 | 对 Python 工具**没有影响**（工具只用标准库 + `jsonschema` / `requests` / `pyyaml`） |
| `nuclei` / `subfinder` | — | **不是依赖**：子域枚举与 nuclei 在本 bundle 中被永久移除（见第 7 节） |

一句话：除了 `python3`，其它都只会让某个阶段**降级**（结果更薄 / 人工补），不会让流水线崩掉。
安装阶段把 `jsonschema` 和 `requests` 作为 OPTIONAL 报告，正是这个原因。

---

## 5. 不要迁移 `_upstream/` 和 `runs/`；`--no-vendor` 什么时候用

**`_upstream/`（约 35 MB 的第三方 checkout）不要拷**：

1. 它不是 skill root，DSH 不会从那里发现技能；目标机上真正需要的是 `vendor/` 和 `skills/`。
2. 它带着两个上游仓库的完整 git 历史与工作树，拷过去只会让「上游 revision」在不同机器上漂移；
   目标机需要时用 `tools/sync-upstream.sh` 现拉（`VERSION` 记录了当前 revision）。
3. 它历史上含 `AGENTS.md` / `CLAUDE.md` / `OPENCODE.md` 等**指令注入文件**，见下节。

**`runs/` 不要拷**：那是真实 engagement 的运行数据（scope、queue、证据、报告，可能含客户信息与
凭据）。它必须按项目单独管理与脱敏，不应该跟着工具包到处走；体积大且每次运行都会重建。

**`--no-vendor` 的适用场景**：目标机**已经安装了这两个上游包**（例如 `~/.agents/skills` 下已有
58 个指向 pack 的 symlink）时使用。`vendor/` 是「目标机什么都没有」时的兜底；即使不加
`--no-vendor`，`install.sh` 也会检测同名技能并打印 `skipped (exists)`，所以它主要是让 summary
更干净、避免「到底装了谁」的歧义。

### 工作区指令注入

**机制。** DSH 会把 **project root 到工作目录之间**的 `AGENTS.md` / `CLAUDE.md` 链作为
workspace instructions 注入 agent 上下文；`AGENTS.local.md` / `CLAUDE.local.md` 是叠加层。
因此：**把任何第三方仓库 clone / 解压到工作区里，就等于把它的指令注入到正在运行的 agent 里。**
`hooks.json`、`.claude/settings.json` 更危险——它们可以被 harness 的 hook bridge **执行命令**；
嵌套的 `.agents/skills`、`.dsh/skills`、`.claude/skills` 则会**遮蔽**同名技能。

**这不是理论。** 本 bundle 开发期间：一个内容只有 `poison` 的测试文件 `CLAUDE.local.md` 被放在
`_upstream/` 下，harness 真的把它作为
`Additional instructions from: abhAndComm/_upstream/abh/CLAUDE.local.md` 加载进了正在运行的 agent；
随后一次 `tools/sync-upstream.sh`（内部 `git reset --hard`）又把上游仓库里的 `AGENTS.md` /
`CLAUDE.md` **恢复**出来，同样被再次注入。所以「清理一次」是不够的：**每次同步之后都必须重新清理。**

**工具。** `tools/context_guard.py` 扫描整个 bundle，检测四类形状：

| 类别 | 例子 | 为什么危险 |
|---|---|---|
| instruction files | `AGENTS.md`、`AGENTS.local.md`、`CLAUDE.md`、`CLAUDE.local.md`、`OPENCODE.md`、`GEMINI.md` | 被当作 agent 指令加载 |
| hook configs | `hooks.json`、`.claude/settings.json`、`.claude/settings.local.json`、`.claude/hooks.json` | 其中带 `hooks` 或 `mcpServers` 键的会**执行命令**（惰性配置不误报） |
| shadow skill roots | bundle 内的 `.agents/skills`、`.dsh/skills`、`.claude/skills` | 同名技能遮蔽真正安装的技能 |
| broken instruction symlinks | 名字是指令文件、但目标已失效的符号链接 | `find -type f` 看不见它们，第一轮清理漏掉的就是这种 |

```bash
python3 tools/context_guard.py                  # 报告，exit 1 = 有 blocking finding
python3 tools/context_guard.py --json           # 机器可读
python3 tools/context_guard.py --fix            # 就地删除（含断链）
python3 tools/context_guard.py --prune-upstream # 兼容模式：顺带清掉 _upstream/ 里的惰性脚手架
python3 tools/context_guard.py --root DIR       # 扫描指定目录（默认 bundle 根）
```

**两个脚本如何使用它：**

- `install.sh` 在链接任何 skill **之前**跑 `python3 tools/context_guard.py --quiet`；发现即打印完整
  报告并**拒绝安装**（exit 3）。唯一的逃生门是 `--allow-instruction-files`，它会打印醒目的
  WARN，并在 summary 里再次提醒「bundle 内的指令文件未经清理」。
- `tools/sync-upstream.sh` 在每次 fetch/`reset --hard` 之后，先跑内置的快速 strip（遍历**整个
  bundle 根**，不只 `_upstream/`），再跑 `context_guard.py --prune-upstream` 并把它当作权威：
  如果 pruned 之后仍有 finding，脚本 **exit 非零**。`--strip-only` 可以只做清理、不碰 git，
  适合手工往 `vendor/` 拷东西之后跑一次。

**为什么 `--scope project` 更危险：** project-scope 把 skills 装进 `<project>/.agents/skills`，
也就是 agent 读取工作区指令的**同一棵目录树**。此后项目里任何 `AGENTS.md` / `CLAUDE.md`——包括
别人 clone 进来的第三方目录里的——都会随会话被加载。user-scope（`$DSH_HOME/skills`）把数据和
指令面分开，是更安全的默认值。

---

## 6. 排错

### 6.1 skill 完全没出现

```bash
R="${DSH_HOME:-$HOME/.dsh}/skills"      # 或 <project>/.agents/skills
ls -l "$R" | head
readlink -f "$R/bbh/SKILL.md"           # symlink 是否指到真实文件？
test -f "$R/bbh/SKILL.md" && echo present
```

- 路径错了最常见：`install.sh` 用的 `$DSH_HOME` 与你 shell 里的可能不同（例如 DSH 由 systemd
  启动、`DSH_HOME` 只在它的环境里）。对比 `./install.sh --dry-run` 打印的 destination。
- project-scope：确认会话 cwd 在 project root（含 `.git` 的最近祖先）之下。
- 目录 bundle 里必须有 **`SKILL.md`**（大写、顶层）；`skills/bbh/README.md` 不算。

### 6.2 斜杠命令缺失（`/bbh` 不存在）

- 斜杠命令来自技能本身（`user-invocable`，默认允许），**不是**上游 pack 的 `commands/*.md`。
  本 bundle 从不安装上游的 commands / agents / hooks，所以别期望那些命令出现。
- 检查技能名：`/bbh` 存在的前提是 `skills/bbh/`（或 frontmatter `name: bbh`）已安装。
  只有 `bbh-*` 时，就用 `/bbh-scope` 这样的名字。
- frontmatter 里 `user-invocable: false` 会让它从人类可见命令里消失（模型仍可能可用）。

### 6.3 `SKILL.md` frontmatter 被拒（拼写问题）

DSH 的规则（被拒 = 整个技能被静默丢弃，只在日志中 warning）：

```yaml
---
name: bbh-scope            # 必填；必须匹配 ^[a-z0-9]+(-[a-z0-9]+)*$，不能有大写/下划线/空格
description: ...           # 必填，非空
whenToUse: ...             # 可选
disable-model-invocation: true   # 可选；布尔，接受 true/false/yes/no/on/off/1/0（大小写不敏感）
user-invocable: false            # 可选；同上
---
```

常见错误：`disableModelInvocation:`（驼峰）、`modelInvocable:`、`userInvocable:` —— 这些**旧键名
会直接报错并丢弃技能**，必须用连字符形式；布尔写成 `True`/`yes` 之外的拼写（如 `enable`）也会
被拒。`install.sh` 安装后会逐个校验 `name` / `description` 是否存在、`name` 是否符合正则，
不符合就计入 `failed`。

### 6.4 多个 root 出现同名 skill

按第 1 节的 rank 取**最小**者：`100 <project>/.dsh/skills` > `200 <project>/.agents/skills`
> `300 customSkillDirs` > `400 $DSH_HOME/skills` > `500 ~/.agents/skills`。
这意味着往 `$DSH_HOME/skills` 装一个与 `~/.agents/skills` 同名的技能，会**遮蔽**后者。
本 bundle 的 vendor 安装逻辑正是为此设计：只要任何 root 已提供同名技能，就不再安装 vendor 副本
（install summary 里的 `skipped (exists)` 会写明是哪个 root 提供的）。要看全部来源：

```bash
for r in "$PWD/.dsh/skills" "$PWD/.agents/skills" "${DSH_HOME:-$HOME/.dsh}/skills" "$HOME/.agents/skills"; do
  [ -d "$r" ] && find "$r" -maxdepth 2 -name SKILL.md | sed "s|^|$r: |"
done
```

### 6.5 「我装了但模型看不见」的检查顺序

1. **文件在不在**：`test -f <root>/<name>/SKILL.md`，symlink 用 `readlink -f` 确认目标存在。
2. **frontmatter 合不合法**：见 6.3（`name` 正则、`description` 非空、布尔拼写）。
3. **root 对不对**：`install.sh` 的 destination 与 DSH 实际扫描的 `$DSH_HOME` 是否是同一个。
4. **project root 对不对**：project-scope 时，会话 cwd 是否在含 `.git` 的祖先之下。
5. **有没有被遮蔽**：同名技能在更高 rank 的 root 里是否存在（见 6.4）。
6. **是不是模型不可见**：`disable-model-invocation: true` 的技能只对人类可见（`/name`）。
7. **目录层级**：是不是放在了 root 的**顶层**（嵌套 `**/SKILL.md` 不被发现）。
8. **刷新时机**：watcher 会在下一个 step 刷新技能表；仍不确定就新开一个会话。
9. **工作区干不干净**：`python3 tools/context_guard.py`；如果安装时用了
   `--allow-instruction-files`，先把它清掉再排别的问题。

### 6.6 `install.sh` 拒绝安装

```
ERROR: context_guard.py found instruction-injection surface in this bundle:
ERROR: REFUSING to install a bundle that can steer the operator's agent.
```

按提示处理：`python3 tools/context_guard.py --fix`（或手工删除报告里的路径），再重跑。
只有在你明确知道风险时才用 `--allow-instruction-files` 覆盖。

---

## 7. 本 bundle 与两个上游包的关系

上游：

- `abh` = <https://github.com/Awarexone/Agentic-Bug-Hunter>
- `comm` = <https://github.com/transilienceai/communitytools>
- 当前 revision 记录在 `VERSION`，checkout 在 `_upstream/`（参考用，不参与 skill 发现）。

**vendored（原样拷贝，条件安装）**：`vendor/upstream-skills/` 下的上游技能副本——包括
`api-security`、`argus`、`attack-path-stitcher`、`authentication`、`bb-methodology`、`client-side`、
`coordination`、`cve-poc-generator`、`graphql-audit`、`injection`、`osint`、`patt-fetcher`、
`reconnaissance`、`risk-prioritiser`、`security-arsenal`、`server-side`、`triage-validation`、
`web2-vuln-classes`、`web-app-logic`（以目录为准）。
它们**只在目标机没有同名技能时**才装：已有的上游 pack 永远优先，不会重复安装、不会遮蔽。

**rewritten（本 bundle 自己的实现）**：`skills/bbh-*` 与 `tools/*.py`、`contracts/*.json`、
`workflows/`。核心差异：

- `surface_build.py` 是翻译层：把 ABH 的分类桶翻译成 communitytools 的 `surface/v2` flag 词汇，
  让 39 类目录的谓词能跑；derived flag 由 `cells_build.py` 自己算，agent 无法伪造。
- `coverage_gate.py` 是硬闸门：`applicability/cells.json`（代码产生）里的每个 cell 都必须有真实
  结果，没有软指标；把代码判定适用的 cell 直接标 N/A 视为伪造，直接 FAIL。
- queue **没有 kill list**：所有信号都变成 lead，最低档是 P3（排在 P1/P2 之后），不存在“淘汰”。

**永久移除（不是开关，没有 flag 可以打开）**：

- **子域枚举**与 **nuclei**：本 bundle 只处理 program 已经告诉你的资产；没有
  `--with-subdomains` 之类的逃生门。真需要发现能力，请作为独立的、显式定范围的阶段另外加。
- 上游的 **slash commands / agents / hooks**（`commands/*.md`、`agents/`、`hooks/`、
  `.claude/settings.json` 等）一律不安装；上游的 `CLAUDE.md` / `AGENTS.md` 会被
  `tools/context_guard.py` 与 `tools/sync-upstream.sh` 清理（见「工作区指令注入」）。

**上游 checkout 的日常维护**：

```bash
tools/sync-upstream.sh            # fetch + reset --hard origin/HEAD，然后 strip + context guard
tools/sync-upstream.sh --check    # 只读：上游是否移动
tools/sync-upstream.sh --strip-only   # 不动 git，只清理指令注入面
```

同步完成后 `vendor/` 与 `catalog/` 相对 `_upstream/` **就过期了**；脚本会提醒，但**故意不自动
重新生成**——重新生成是一次需要人 review 的变更：重新生成后要对比 diff、更新 `VERSION` 里的
上游 revision，并重跑 `install.sh`。
