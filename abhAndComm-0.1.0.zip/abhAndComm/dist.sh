#!/usr/bin/env bash
# Build the shippable zip of this bundle.
#
# WHY A SCRIPT AND NOT A HAND-TYPED zip COMMAND
# ---------------------------------------------
# The exclusion list is not cosmetic — two of the exclusions are load-bearing:
#
#   _upstream/   is a 37 MB read-only build snapshot that carries upstream's agent-instruction
#                files (AGENTS.md / CLAUDE.md / *.local.md) and command-hook configs. Shipping it
#                would ship exactly the instruction-injection surface that tools/context_guard.py
#                exists to catch. MIGRATION.md tells the operator to leave it behind; this script
#                makes that automatic instead of a thing to remember.
#   .cache/      holds mermaid.js (~3.5 MB) and render intermediates. It is a BUILD dependency
#                for re-rendering docs/diagrams; the rendered SVG/PNG are already committed.
#
# So the packaging rule lives in one place, is reviewable, and cannot drift from the docs.
#
# Usage:  bash dist.sh [--out DIR] [--name NAME] [--keep-staging]
# Exit:   0 built, 1 zip failed, 2 missing tools / missing required content.
set -euo pipefail

BUNDLE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$BUNDLE"

OUT="$BUNDLE/dist"
NAME=""
KEEP=0
while [[ $# -gt 0 ]]; do
  case "$1" in
    --out)  OUT="$2"; shift 2 ;;
    --name) NAME="$2"; shift 2 ;;
    --keep-staging) KEEP=1; shift ;;
    -h|--help) sed -n '2,20p' "$0"; exit 0 ;;
    *) echo "dist.sh: unknown flag $1" >&2; exit 2 ;;
  esac
done

command -v zip >/dev/null || { echo "dist.sh: zip is not installed" >&2; exit 2; }
command -v python3 >/dev/null || { echo "dist.sh: python3 is required" >&2; exit 2; }

VERSION="$(head -1 VERSION 2>/dev/null | tr -d '[:space:]' || echo 0.0.0)"
[[ -n "$VERSION" ]] || VERSION="0.0.0"
NAME="${NAME:-abhAndComm-${VERSION}}"

# --- preflight: refuse to ship a bundle that would poison the operator's agent context --------
if [[ -f tools/context_guard.py ]]; then
  if ! python3 tools/context_guard.py --quiet; then
    echo "dist.sh: REFUSING to package — context_guard found an instruction-injection surface." >&2
    python3 tools/context_guard.py >&2 || true
    echo "  Fix it first:  python3 tools/context_guard.py --prune-upstream" >&2
    exit 2
  fi
fi

# --- preflight: the content that must exist, or the zip is a broken deliverable ---------------
required=(skills workflows contracts tools catalog vendor pipeline examples
          README.md MIGRATION.md VERSION install.sh uninstall.sh)
missing=()
for r in "${required[@]}"; do [[ -e "$r" ]] || missing+=("$r"); done
if [[ ${#missing[@]} -gt 0 ]]; then
  echo "dist.sh: refusing to package — missing required content: ${missing[*]}" >&2
  exit 2
fi

# --- stage: copy what ships, using tar so the exclusion list is one readable expression -------
STAGE="$(mktemp -d "${TMPDIR:-/tmp}/bbh-dist.XXXXXX")"
trap '[[ "$KEEP" == "1" ]] && echo "staging kept: $STAGE" || rm -rf "$STAGE"' EXIT

DEST="$STAGE/abhAndComm"
mkdir -p "$DEST"

# Everything except the build/run output and the upstream snapshot. Listed as excludes rather
# than includes so a new top-level directory ships by default instead of being silently dropped —
# the failure mode of an include-list is a deliverable that is quietly missing a component.
tar -C "$BUNDLE" -cf - \
    --exclude='./_upstream' \
    --exclude='./runs' \
    --exclude='./dist' \
    --exclude='./docs/diagrams/.cache' \
    --exclude='__pycache__' \
    --exclude='*.pyc' \
    --exclude='.DS_Store' \
    --exclude='*.tmp' \
    . | tar -C "$DEST" -xf -

echo "staged $(find "$DEST" -type f | wc -l) file(s), $(du -sh "$DEST" | cut -f1)"

# --- build -----------------------------------------------------------------------------------
mkdir -p "$OUT"
ZIP="$OUT/$NAME.zip"
rm -f "$ZIP"
if ! (cd "$STAGE" && zip -qr9 "$ZIP" abhAndComm); then
  echo "dist.sh: zip failed" >&2; exit 1
fi

# --- verify the archive rather than trusting the exit code ------------------------------------
python3 - "$ZIP" <<'PY'
import sys, zipfile
z = zipfile.ZipFile(sys.argv[1])
names = z.namelist()
bad = z.testzip()
if bad:
    print(f"dist.sh: archive is corrupt at {bad}", file=sys.stderr); sys.exit(1)
must = ["abhAndComm/README.md", "abhAndComm/MIGRATION.md", "abhAndComm/VERSION",
        "abhAndComm/install.sh", "abhAndComm/uninstall.sh", "abhAndComm/tools/README.md",
        "abhAndComm/contracts/README.md", "abhAndComm/skills/bbh/SKILL.md",
        "abhAndComm/docs/diagrams/workflow-overview.png",
        "abhAndComm/examples/run-demo.sh"]
for m in must:
    if m not in names:
        print(f"dist.sh: archive is missing {m}", file=sys.stderr); sys.exit(1)
# The two exclusions that matter, asserted rather than assumed.
leaked = [n for n in names
          if "/_upstream/" in n or n.startswith("abhAndComm/_upstream")
          or "/.cache/" in n or "__pycache__" in n or n.endswith(".pyc")]
if leaked:
    print("dist.sh: archive leaked excluded content:", file=sys.stderr)
    for n in leaked[:10]:
        print("   ", n, file=sys.stderr)
    sys.exit(1)
print(f"verified: {len(names)} entries, no _upstream/, no .cache/, no __pycache__")
PY

SIZE="$(du -h "$ZIP" | cut -f1)"
echo
echo "built: $ZIP  ($SIZE)"
echo
echo "install on the target machine:"
echo "  unzip $(basename "$ZIP") && cd abhAndComm && ./install.sh"
