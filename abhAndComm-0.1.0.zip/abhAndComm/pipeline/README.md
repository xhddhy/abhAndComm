# 流水线设计

这份文档解释**为什么**这样拼，而不是重复每个命令怎么敲（那是 `skills/bbh-*/SKILL.md` 和
`tools/README.md` 的活）。先读这里建立心智模型，再去看具体阶段。

---

## 1. 一句话概括

两个上游项目各自缺一半：

- **ABH** 会**看**——把已知资产分类成桶、排攻击面、建链、过 7 问。但它没有"覆盖"这个概念：
  它的 `/surface` 会给你一个 Kill List，然后就没有账本告诉你哪些桶还没碰。
- **communitytools** 会**记账和保真**——角色契约、surface flags、覆盖矩阵、盲验证。
  但它的入口假设你有一个正规 pentest 的 scope 和预算，不假设你在跟几百个猎人抢同一个 SRC。

合并后的东西：**用 ABH 的眼睛找活，用 comm 的账本保证不糊弄自己，交付物是你能亲手复现的东西。**

---

## 2. 全流程图

**渲染好的图（点开看，不需要任何依赖）：**

| 图 | 看什么 |
|---|---|
| [`docs/diagrams/workflow-overview.png`](../docs/diagrams/workflow-overview.png) | **先看这张** —— 四个阶段群、两个必需卡点、cure 回路。颜色 = 能力来自哪个项目 |
| [`docs/diagrams/workflow-detail.png`](../docs/diagrams/workflow-detail.png) | 每一跳的**交接产物**，解释"阶段之间只通过文件说话" |
| [`docs/diagrams/runtime.png`](../docs/diagrams/runtime.png) | **一个资产内部**：三个文件的记忆契约、INTEGRATE 唯一写者、盲验证硬边界 |

图的真源是同目录的 `.mmd`（mermaid），改完跑 `bash docs/diagrams/render.sh` 重新出图。
下面这份是同一张图的文本版，方便在纯文本环境里读：

```mermaid
graph TD
    A["Stage 0 SCOPE<br/>scope.json<br/>第三方 CNAME / staging / 安全港 检查"]
    B["Stage 1 RECON-LITE<br/>只对已知资产分类<br/>无子域枚举 · 无 nuclei"]
    C1{{"卡点 1<br/>资产 × 漏洞类 分类表<br/>等你确认"}}
    D["Stage 2 QUEUE<br/>只排队不淘汰<br/>P3 = 稍后，不是跳过"]
    E["Stage 3 SLICE / FORK<br/>surface flags + 覆盖矩阵 cells<br/>一资产一 slice"]
    F["Stage 4 COORDINATOR ×N<br/>一资产一个 coordinator<br/>attack-chain / session-memory / experiments"]
    G["Stage 5 EXECUTOR<br/>每批 1-2 个<br/>产出 finding 候选"]
    H["Stage 6 VALIDATE<br/>盲验证 · PoC 真跑 · CVSS 重算<br/>3 个反驳者"]
    I["Stage 6b CURE<br/>只补点名的缺口<br/>不许重新立论"]
    J["Stage 7 CHAIN<br/>A→B→C"]
    K["Stage 8 七问闸<br/>一问不过就停"]
    L["Stage 9 REPRO PACK<br/>复现手册 + PoC 包"]
    C2{{"卡点 2<br/>你手动复现"}}
    C3{{"卡点 3<br/>确认后定稿"}}

    A --> B --> C1 --> D --> E --> F --> G --> H
    H -->|CONFIRMED| J
    H -->|CURE| I --> H
    H -->|REJECTED| FP["false-positives/<br/>标假阳性"]
    J --> K
    K -->|否| I
    K -->|是| L --> C2 --> C3
    FP --> D
```

---

## 3. 阶段契约

每个阶段只通过**磁盘上的一个文件**和**一条命令**跟下一阶段说话。这是刻意的：workflow 脚本
是无状态的导引，agent 上下文用完即弃，**文件才是记忆**。所以任何一步崩了都能从落盘状态续跑。

| 阶段 | 产出 | 契约 | 生产者 | 消费者 |
|---|---|---|---|---|
| 0 SCOPE | `scope.json` | `contracts/scope.schema.json` | `tools/bbh_scope.py init` | 后续全部 |
| 1 RECON-LITE | `classification.json` | `contracts/classification.schema.json` | `/bbh-recon` + `tools/bbh_classify.py` | QUEUE、SURFACE |
| 2 QUEUE | `queue.json` | `contracts/surface-queue.schema.json` | `tools/queue_build.py` | SLICE、闸 |
| 3 SLICE | `assets/<tag>/recon/inventory/surface.json`<br/>`assets/<tag>/applicability/cells.json`<br/>`slices/<tag>.json` | `contracts/surface.v2.schema.json`<br/>`contracts/slice.schema.json` | `tools/surface_build.py`<br/>`tools/cells_build.py`<br/>`tools/slice_build.py` | COORDINATOR |
| 4-5 EXECUTE | `findings/finding-NNN/*` | `contracts/finding.schema.json` | executor | VALIDATE |
| 6 VALIDATE | `artifacts/{validated,false-positives,dropped}/F-NNN.json`<br/>`coverage.json` | `contracts/validation-verdict.schema.json` | **盲** validator | CHAIN、闸 |
| 7 CHAIN | `chains/<F-NNN>.json` | 见 `skills/bbh-chain/` | chain-builder | 七问 |
| 8 七问 | `seven-questions/F-NNN.json` | `contracts/seven-questions.schema.json` | 七问 agent | REPRO |
| 9 REPRO | `repro/F-NNN/RUNBOOK.md`<br/>`repro/F-NNN/<F-NNN>_pack.zip` | `contracts/repro-runbook.schema.json` | `tools/repro_pack.py` | **你** |

---

## 4. 卡点怎么实现的（两个必需 + 一个收尾）

workflow 脚本**不能自己停下来问人**——DSH 的 `workflow` 工具是前台执行的，跑完才返回。
所以卡点做成了"**返回一个信封 + 用 `resume_from` 续跑**"：

1. 跑到卡点，workflow 返回 `{status: "CHECKPOINT_1", artifacts: {...}, question: "..."}` 并结束。
2. 调用它的会话（就是你在 GUI 里对话的那个 agent）把问题转述给你。
3. 你说继续，它会用同一个 `run_dir` 加 `resume_from: "checkpoint-1"` 再调一次 workflow。
4. 第二次运行**从磁盘读回状态**，跳过已完成的阶段，继续往下。

好处是卡点之间可以隔几天，中间机器重启也不丢。代价是每个卡点要跑两次 workflow 调用——
值得，因为你要的是"手动复现"而不是"它说它复现了"。

**但要知道这个"停"是什么性质的停**：它是**你不去续跑**，不是代码把门锁上了。
只有 `checkpoint-2 → finalize` 那一步是代码强制的——不传 `args.human_confirmation`，
workflow 会再返回一次信封而不是定稿。`checkpoint-1` 没有任何确认校验：谁带
`resume_from: "checkpoint-1"` 再调一次就直接过去了。

对半自动用法这是对的（工具是你的，锁是多余的），但它决定了一件事：
**让产出可信的是你手动复现那一步，不是流水线里的闸门。** 所以第 2 个卡点是真正承重的那个。

---

## 5. 六个必须说明的设计决定

### 5.1 子域枚举和 nuclei 是**移除**，不是开关

你明确说了不做。我没有把它做成 `--with-subdomains`，因为留一个开关意味着以后有人会打开它，
然后 `scope.json` 和实际被扫的东西就不是一回事了。资产只来自 scope，这是这个项目的信任根。
要跨资产发现，那是另一个项目、另一个 scope 文档。

`tools/README.md` 的 "Not in this bundle, on purpose" 一节写明了这一点。

### 5.2 flags 是规则推出来的，不是模型聊出来的

`tools/surface_build.py` 用一张可审计的正则表把 ABH 的桶翻译成 comm 的 18 个 agent flag。
为什么不让模型直接打 flag？因为 flag 决定覆盖矩阵要你检查多少东西——**一个能被模型说服的
flag，就是一个能悄悄缩小工作量的 flag**。

所以：

- 每条 flag 都带 `evidence`("`server_fetched_url` <- URL-shaped param: image_url")；
- `--explain` 打印整张映射表，你可以不看代码就质疑某个 flag；
- 7 个**派生 flag**(`http_listener` / `tls_listener` / `version_fingerprinted` / `has_api` /
  `is_apex` / `serves_js` / `mobile_app`)在 `cells_build.py` 里由形状算出，`surface_build.py`
  写了就会被 `--strict-flags` 判失败。一个 unit 不能被"说服"自己不是 HTTP 监听，所以它也不能
  被说服豁免依赖这个事实的漏洞类。

### 5.3 覆盖闸默认不是 100%，但诚实性是无条件的

这是我最需要跟你讲清楚的一处**主动偏离上游**。

communitytools 的覆盖闸是硬 100%：每个适用单元格都要有着落。那对**受雇 pentest** 是对的——
客户按广度付钱，矩阵填满就收工。

**赏金不是那个活。** 你是几百个猎人里的一个，平台按有效漏洞付钱，理性的停止规则是"高价值的
线索都做过了"，不是"每个端点都把 24 个 web 类探一遍"。一个在真实赏金局里永远不可能通过的闸，
只会训练你忽略它——那比没有闸更糟。

所以 `coverage_gate.py` 有两个模式：

| 模式 | 什么时候算 complete |
|---|---|
| `bounty`（默认） | 确实做了活、没有任何声明超出证据、没有 finding 挂在树上没判决、所有 P1 线索到终态。覆盖率**完整报告**但不设闸。 |
| `strict` | 上游契约：`covered == applicable`，没做的单元格直接卡住。给受雇活或用在你真的想填满矩阵的时候。 |

**两个模式下都不放松的**（这才是保真的部分）：

- 适用集由代码从代码拥有的输入算出，**agent 缩不小它**；`--mode` 只改停止规则，不改数字。
- 把代码判定适用的单元格标成 `na` 是**硬造假 FAIL**，不是判断题。
- 声称 `covered` / `covered_negative` 的单元格必须引用**磁盘上真实存在**的证据。
- 声称 `covered` 必须有 `artifacts/validated/` 里真的 `CONFIRMED` 判决。
  声称 `covered_negative` 必须带上该类 `negative_kind` 要求的佐证：`active_probe` 要工具日志，
  `reachability` 要 N 个不同且已验证的观测点。
- 从没进过账本的单元格算**未触碰**，不算 pending。新资产账本是空的，把 49 个适用单元格报成
  "0 untouched" 就是在告诉你反话。
- finding 目录存在但没有判决文件 → 闸失败。**测试不是在你停手时结束，是在 finding 有判决时结束。**

### 5.4 保真验证是真的在跑你的 PoC

`tools/README.md` 里 `bbh-validate` 那节列了它实际做的事。要点：PoC **会被真的执行**（不是读一遍），
坏了会被修复重跑；CVSS 从向量**重算**（向量与档位不符算失败）；CVE 声明打 NVD + KEV 并可用
`--cache-dir` 冻结快照以保证重放可复现；跨身份漏洞(IDOR/BOLA/ATO/提权)必须有 actor 拿到 victim
数据的证据、新会话仍可复现、匿名行为不同；最后 3 个**盲**反驳者必须全部无法反驳。

"盲"是硬边界：validator 拿不到 `attack-chain.md`、拿不到其他 finding、拿不到 coordinator 的推理、
拿不到 executor 的日志。它只看证据。一旦 validator 读了攻链，它的判决就不再独立——这不是风格问题，
是**判决有效性**问题。cure 执行器同理：只拿点名的 `failed_checks` + `missing_evidence`，
**不许重新立论**，这样下一轮盲验证的独立性才保得住。

### 5.5 排队不淘汰具体保住了什么

ABH 的 `/surface` 给你 P1/P2 和一个 Kill List——被 kill 的东西**消失了**，你事后无法区分
"我看过，没东西"和"我根本没看"。这对赏金是致命的，因为：

- 环境变了（新版本上线、WAF 规则改了）以后，被 kill 的线索可能要重看，但记录没了；
- 平台会新收漏洞类（比如某类 GraphQL 问题开始给钱），你没法回头扫自己 kill 掉的清单；
- 你无法诚实回答"这个类我到底碰过没有"。

所以 `queue.json` **没有 kill list，没有 eliminated 状态**。最低档是 `P3`，语义是"在 P1 P2 之后"。
唯一表示"做过且没东西"的状态是 `exhausted`，那是一个**覆盖结果**，不是淘汰。

### 5.6 分资产 = 一个 coordinator，不是一个会话

你说的 "forksession" 在 comm 里叫 `coordinator-loop`，机制是：**每资产一个 coordinator，
状态落在三个文件里**——

- `attack-chain.md`：当前理论，≤50 行，每批重写；
- `session-memory.md`：只追加的持久记忆（拿到的凭证、确认的事实、死路、未结线索、转向历史）；
- `experiments.md`：只追加的账本，`E-NNN` 行。

**INTEGRATE agent 是这三个文件的唯一写者**，所以并行的 executor 不会在账本上打架。
每个 think/execute/integrate agent 都是全新、便宜的上下文，只加载它需要的那点状态。

为什么必须是文件而不是一个长会话：一次 30 批的狩猎塞不进一个上下文窗口。文件是记忆，
agent 是一次性的。这也意味着**崩了能续**——这是"分资产 fork"真正的收益，不是并行度。

---

## 6. 目录地图

```
abhAndComm/
├── skills/bbh-*/          10 个技能 = 你的斜杠命令层（DSH 里 user-invocable 技能就是命令）
├── workflows/             3 个 DSH 内联 workflow 脚本（主编排 + coordinator + 验证）
├── contracts/             9 份 JSON Schema = 阶段间的接口
├── tools/                 工具 + tools/README.md（冻结的 CLI 契约）
├── catalog/               覆盖矩阵类目（赏金向改编版）
├── vendor/upstream-skills/ 自带上游技能，保证目标机没装两个包也能跑
├── pipeline/              本文档
├── examples/              demo fixture，用来干跑验证
├── install.sh / uninstall.sh
├── tools/sync-upstream.sh 拉上游更新（并重新剥离指令污染文件）
└── MIGRATION.md           迁移到另一台 DSH
```

装到 DSH 的哪一层：**纯文件系统技能根**。不是 npm 插件，不是 handler hook。
所以迁移就是拷目录 + 跑 `install.sh`。细节见 `MIGRATION.md`。

---

## 7. 这个组合刻意不做的事

- **不扩面。** 资产只来自 scope。
- **不自动提交。** 7 问过了、复现手册生成了，然后停下等你。没有平台 API 调用。
- **不写正式报告。** 你要的是复现手册和 PoC 包。上游的 H1 Markdown / Transilience PDF 技能还在
  `vendor/upstream-skills/` 里（`report-writing` 不在其中），想接随时接。
- **不做移动端。** 类目里 15 个 MASVS 类被拿掉了：一个 web unit 永远不会带上 `mobile_app` 派生
  flag，所以它们永远不会适用，留着只是噪音。
- **不做爆破和破坏性操作。** `scope.json` 的 `roe` 是强制的，写操作默认只允许自有租户的
  建立-再删除。密码喷洒那套上游工具**没有**进这个 bundle。

---

## 8. 工作区指令注入：一个必须处理的架构级问题

这一节不是理论。**它是这次构建过程中真实发生的。**

### 8.1 通道

DSH 会把**项目根到当前工作目录之间**的 `AGENTS.md` / `CLAUDE.md` 链当作工作区指导加载进
agent 上下文，而 `AGENTS.local.md` / `CLAUDE.local.md` 是**额外叠加**的。内容是作为
**指令**注入的，不是作为数据。

推论很直接：**任何位于这条路径上、叫这些名字的文件，就是一个指令注入原语。**
把任何第三方仓库 clone 进你的工作区，就继承了它里面这些文件说的所有话。

这对本项目尤其要命，因为本项目的整个卖点就是"把两个第三方仓库 clone 下来重写"。

### 8.2 实际发生的两次

**第一次——测试夹具落进了活路径。** 构建期间有个验证剥离逻辑的测试夹具写成了
`_upstream/abh/CLAUDE.local.md`，内容就一个词：`poison`。它被加载了，系统提示里出现了
"Additional instructions from: abhAndComm/_upstream/abh/CLAUDE.local.md"。载荷是良性的
（一个 canary），但**通道被证实是通的**。

**第二次——`git reset --hard` 把删掉的文件复活了。** `sync-upstream.sh` 同步上游时，
git 恢复了被删的 `AGENTS.md` / `CLAUDE.md` / `OPENCODE.md`，它们**再次被注入**进一个正在运行的
agent 上下文。所以剥离**必须在每次同步之后执行**，而且必须**可检查**，不能靠"我记得做过"。

### 8.3 处置：`tools/context_guard.py`

一个可执行的检查，检测四类被"解释"而不仅仅是被"读取"的文件：

| 类别 | 文件 | 为什么危险 |
|---|---|---|
| `instruction_file` | `AGENTS.md` `CLAUDE.md` `AGENTS.local.md` `CLAUDE.local.md` `OPENCODE.md` `GEMINI.md` | 被当作 agent 指令加载 |
| `hook_config` | `hooks.json` `.claude/settings.json` | **会执行命令**。指令文件能误导 agent，钩子配置能跑代码 |
| `shadow_root` | `.agents/skills` `.dsh/skills` `.claude/skills` | 同名技能会**遮蔽**真技能，而技能正文是按需加载的指令 |
| 断链 | 名字匹配但 `Path.exists()` 为假的软链 | `find -type f` **看不见**它们——第一次清理就是这样漏掉一个的 |

它已经在这个 bundle 里抓到 **11 个我手工清理漏掉的真问题**，包括上游 ABH 的
`.claude/settings.json` 和 `hooks/hooks.json`（两个都真的定义了命令钩子），以及 comm 里 6 个
嵌套 `.claude/skills`。

`install.sh` 把它当**硬前置**：发现 blocking 就拒绝安装。`sync-upstream.sh` 每次同步后调
`--prune-upstream` 重新修剪。`--fix` / `--prune-upstream` 可手动清。

```bash
python3 tools/context_guard.py                    # 报告，exit 1 = 有 blocking
python3 tools/context_guard.py --prune-upstream   # 清理（同步后跑）
```

### 8.4 给迁移的提醒

`--scope project` 安装（把技能装到 `<project>/.agents/skills`）会让暴露面**变大**，因为技能
从此和 agent 读取指令的是同一棵树。所以默认装到 `$DSH_HOME/skills`（user scope），
让技能树在工作区之外。

`_upstream/` 是只读参考快照，**不该进迁移包**——它体积大、含有上面这些东西，而且
`vendor/` 已经带了运行时真正需要的部分。

---

## 9. 一次对抗性审查发现并修掉的七个洞

这套东西被外部审过一遍。批評裡關於代碼的斷言我逐條**實測複現**，不採信也不反駁。
七條成立，全部已修，且每條在 `examples/run-demo.sh` 裡有自己的斷言（回歸會抓到復發）。

| # | 洞 | 實測結果 | 修法 |
|---|---|---|---|
| 1 | 七問閘是擺設：`repro_pack` 只比 `verdict == "PASS"` 這個字符串 | 七個答案全 `false` + `verdict:"PASS"` → **包照出** | 真讀那 7 個答案：任一 `pass != true`、或任一問缺失 → 拒發包（exit 1）。schema 不合法更早攔下（exit 2） |
| 2 | 覆蓋閘信任它本該監管的檔案 | 手改 `cells.json` 35→1 → **閘門報 100% 覆蓋** | 閘門自己從 `surface.json` + 類目**重算**適用集，與 `cells.json` 不符即 FAIL 並逐格點名。算不出來 = blocker，不當通過 |
| 3 | `repro_pack` 沒有路徑約束 | `poc.script = ../../../../etc/hostname` → **檔案被拷進交付包** | `poc.script` / `evidence.artifacts[]` / `finding_id` 全部做 containment 檢查，越界即拒（exit 2）；PoC 兄弟檔也只拷仍在 finding 目錄內的真實檔案（擋 symlink 夾帶） |
| 4 | 技能層與編排層沒接上 | 10 個技能**零處**提到 `workflows/` | `/bbh` 新增「Two ways to drive this」章節；10 個技能都指向 `workflows/bbh-hunt.js`；卡點/續跑協議寫進文檔；乾跑有靜態斷言 |
| 5 | 佇列攜帶會靜默降級 | 訊號消失的 lead 被攜帶時 `params`/`evidence` 全丟、重算後 **P1→P2** | 原樣保留 `priority`/`tier`/`params`/`gf_patterns`，並標記 `carried_forward: true`。`--explain` 同時印出「今天重算會得幾分」讓差異可查 |
| 6 | 卡點是軟停，但文檔說得像鎖 | 只有 CP2→finalize 有 `human_confirmation` 校驗；CP1 無校驗 | 文檔改成「兩個必需 + 一個收尾」，並明說**只有第 2 個是代碼強制的** |
| 7 | 通配符命中但未驗 CNAME 卻讀起來像「已驗證」 | 無 `--dns-cache` 時 `assets.acme.com` 判 in scope 且無任何提示 | 判決理由明寫「CNAME 未驗證」並說明通配符不等於所有權；新增 `--require-cname` 讓未驗證的通配符命中變成 exit 2 |

**有一條批評沒有複現**：它說 apex 資產下 `www.acme.com` 會被判 in-scope。實測是
`UNCLEAR`（apex 不覆蓋子域，這是刻意的）。那個構造只在**通配符** scope 下成立，
也就是上表第 7 條。

**教訓**：漏洞 1、2、3 是同一類——**閘門信任了一個它本來該檢查的檔案**。
`cells.json`、七問 JSON、`finding.json` 都是 agent 寫的落盤產物，把它們讀回來當作既成事實，
閘門就只是個記錄器。现在這三處都是**重算或驗證**，不是**讀取**。
