---
name: bbh-repro
description: The deliverable stage — author the manual reproduction runbook (bbh/repro/v1) and build the executable PoC pack with repro_pack.py. Covers the RUNBOOK.md requirements (install steps first, then numbered copy-pasteable commands each with expected output, negative control, gotchas), the pack/ layout, and the CONFIRMED+PASS precondition that makes the tool refuse bad inputs. Use after the 7-Question Gate passes.
whenToUse: After bbh-seven returns PASS. This is the last agent stage; checkpoint 2 is a human running the runbook by hand.
---

# bbh-repro — Stage 9, the deliverable

**Input:** `<slice>/findings/finding-<NNN>/` + `<slice>/artifacts/validated/F-<NNN>.json` +
`<slice>/seven-questions/F-<NNN>.json`.
**Output:** `<run>/repro/F-<NNN>/RUNBOOK.md`, `<run>/repro/F-<NNN>/pack/`,
`<run>/repro/F-<NNN>/pack.zip`.
**Tool:** `tools/repro_pack.py` ★.

> The runbook is the **primary deliverable**: a human, on a clean machine, with no agent, follows
> it top to bottom and reproduces the bug. Stage 6 already proved the PoC runs; this stage makes
> that proof transferable to someone else. **Nothing here may say "as described above" or
> "similarly".** Every command is copy-pasteable and every command states what the operator sees.

> **Orchestrated path:** `workflows/bbh-hunt.js` runs this stage as part of the full pipeline
> and stops at the checkpoints. This skill is the manual path and the reference for what the
> stage does; both write the same artifacts. See `/bbh` § "Two ways to drive this".

## 1. Author the runbook source

Write `<finding-dir>/repro.json` conforming to `contracts/repro-runbook.schema.json`
(`bbh/repro/v1`). `repro_pack.py` renders `RUNBOOK.md` from it.

Authoring rules that the schema enforces:

| Field | Requirement |
|---|---|
| `environment.tools[]` | **Every** external tool the runbook invokes, with `name` + a copy-pasteable `install` command, plus `version` ("any" only if genuinely version-insensitive), `verify`, and `why` |
| `environment.os` / `.network` | What it was verified on (e.g. "Debian 12 / Python 3.11"); reachability (internet / VPN / allowlisted source IP) |
| `environment.credentials[]` | `role`, `how_to_obtain`, `env_var` — **never a secret value** |
| `setup[]` | Numbered prep: extract the pack, export env vars. Install commands live here, **first** |
| `reproduce[]` | **Step 1 must be the smallest request that shows a difference.** Do **not** start with reconnaissance |
| `verify.success_criteria` | Required. The exact observable that means the bug reproduced |
| `verify.negative_control` | The command to run when it does **not** reproduce, and what that prints |
| `verify.expected_excerpt` | The literal response excerpt, redacted consistently |
| `verify.false_positive_traps[]` | How an operator could fool themselves here |
| `cleanup[]` | **Mandatory** for any step that created state — leaving test data violates the RoE |
| `gotchas[]` | Non-obvious conditions learned while validating |
| `time_estimate_min` | Honest end-to-end time for a competent operator on a clean box |
| `validation_provenance` | `verdict_ref`, `seven_q_ref`, `last_verified`, `verified_by` |

Every step object is `{step, cmd, expected, on_failure, note, safety}`; `cmd` is **one**
copy-pasteable command (multi-line shell allowed, chained unrelated actions not), and `safety` is
set whenever the step writes state and says how `cleanup` undoes it.

**False-positive traps are not optional garnish.** The best ones come straight out of validation:
"a 200 on the victim id is also returned for a non-existent id — check the body, not the status."

### Worked example (excerpt)

```json
{
  "schema": "bbh/repro/v1",
  "finding_id": "F-001",
  "asset_tag": "api.acme.com",
  "title": "BOLA in GET /v2/users/{id}",
  "severity": "high",
  "cvss_vector": "CVSS:3.1/AV:N/AC:L/PR:L/UI:N/S:U/C:H/I:N/A:N",
  "cvss_score": 6.5,
  "one_line_summary": "Any authenticated user can read any other tenant's profile by changing the id.",
  "time_estimate_min": 15,
  "environment": {
    "os": "Debian 12 / Python 3.11",
    "network": "internet; api.acme.com reachable directly",
    "tools": [
      { "name": "curl", "version": "8.x", "install": "apt-get install -y curl",
        "verify": "curl --version", "why": "step 1 is a single HTTP request" }
    ],
    "python_packages": ["requests"],
    "credentials": [
      { "role": "attacker_user", "how_to_obtain": "register a free account on app.acme.com",
        "env_var": "ACME_USER_A" },
      { "role": "victim_user", "how_to_obtain": "second free account, separate tenant",
        "env_var": "ACME_USER_B" }
    ]
  },
  "setup": [
    { "step": 1, "title": "Unpack the PoC pack", "cmd": "unzip pack.zip && cd pack",
      "expected": "poc/, evidence/, env/, verify.sh" },
    { "step": 2, "title": "Install the environment", "cmd": "bash env/install.sh",
      "expected": "curl and the python packages installed; last line OK",
      "on_failure": "check network access and the OS matches environment.os" },
    { "step": 3, "title": "Export the two tokens", "cmd": "export ACME_USER_A=... ACME_USER_B=...",
      "expected": "no output; echo ${ACME_USER_A:?} prints a token" }
  ],
  "reproduce": [
    { "step": 1, "title": "Baseline: read your own profile",
      "cmd": "curl -sS -H \"Authorization: Bearer $ACME_USER_A\" https://api.acme.com/v2/users/me",
      "expected": "200 with your own email and tenant",
      "on_failure": "the token is wrong or the account is not provisioned" },
    { "step": 2, "title": "Swap in the victim's id",
      "cmd": "curl -sS -H \"Authorization: Bearer $ACME_USER_A\" https://api.acme.com/v2/users/4711",
      "expected": "200 whose body contains victim@example.com and tenant T2",
      "note": "this is the bug: user_a's token, user_b's data" }
  ],
  "verify": {
    "success_criteria": "step 2 returns the victim's email and tenant while authenticated as user_a",
    "expected_excerpt": "\"email\":\"victim@example.com\"",
    "negative_control": "curl ... /v2/users/999999999 -> 404 NOT_FOUND (so a 200 with a body is meaningful)",
    "false_positive_traps": [
      "a 200 alone is not the bug — read the body",
      "the id must belong to another tenant or the API 404s before the auth check"
    ]
  },
  "cleanup": [
    { "step": 1, "title": "Delete the test accounts", "cmd": "curl -X DELETE ...",
      "expected": "204" }
  ],
  "gotchas": ["ids are tenant-scoped in the URI but not in the query filter"]
}
```

## 2. Build the pack

```bash
python3 tools/repro_pack.py \
    --finding-dir runs/acme-2026-09/assets/api.acme.com/findings/finding-001 \
    --verdict     runs/acme-2026-09/assets/api.acme.com/artifacts/validated/F-001.json \
    --seven-q     runs/acme-2026-09/assets/api.acme.com/seven-questions/F-001.json \
    --out         runs/acme-2026-09/repro/F-001
```

**It refuses to build** when the Stage 6 verdict is not `CONFIRMED` or the Stage 8 verdict is not
`PASS` — exit `1`, with the reason on stdout. That refusal is the point: a runbook is a claim that
the bug is real *and* submittable, and the tool will not let you assert it without both verdicts.
If it refuses, go back to `bbh-validate` or `bbh-seven`; do not hand-build the pack.

> `--finding-dir` must contain the `bbh/repro/v1` source from §1. `tools/README.md` does not name
> the source filename it looks for — write `repro.json` and confirm with
> `python3 tools/repro_pack.py --help` if the build cannot find it. Do not invent a flag.

### Output layout

```
runs/<engagement>/repro/F-001/
├── RUNBOOK.md          # rendered from bbh/repro/v1
├── pack/
│   ├── poc/            # the runnable script(s), e.g. exploit.py
│   ├── evidence/       # raw request/response, redacted consistently
│   ├── env/
│   │   ├── install.sh          # derived from environment.tools
│   │   └── requirements.txt    # derived from environment.python_packages
│   └── verify.sh       # runs the whole runbook non-interactively, PASS/FAIL per step
└── pack.zip            # zip of pack/, next to the runbook
```

`RUNBOOK.md` is rendered with:

- **every command in a fenced block** — no inline prose commands;
- the **install section first**;
- a **`TROUBLESHOOTING`** section built from `gotchas` + each step's `on_failure`.

`verify.sh` is the machine-readable twin of the runbook: it runs the runbook unattended and prints
`PASS`/`FAIL` per step. Run it yourself before handing over — a runbook whose `verify.sh` fails is
not a deliverable.

```bash
cd runs/acme-2026-09/repro/F-001 && bash pack/verify.sh
python3 tools/schema_check.py --kind repro runs/acme-2026-09/repro/F-001/repro.json
# `--kind <k>` resolves to contracts/<k>.schema.json; `--kind all --run-dir <run>` also works.
```

## 3. CHECKPOINT 2 — manual reproduction (human)

A human, on a box that is not the agent's, follows `RUNBOOK.md` using only what it says. Success
criteria: `title` → `setup` → `reproduce` → `verify.success_criteria` all land, and the
`negative_control` prints what the runbook says it prints.

Record the outcome with `validation_provenance.verified_by` (`human`) and `last_verified`
(ISO timestamp), then rebuild the pack so `RUNBOOK.md` carries the human verification.

Signs the runbook is not ready: the operator has to ask a question; a step's `expected` is vague;
a command assumes a file the pack does not ship; the negative control was skipped.

## 4. Done when

- [ ] `repro.json` validates against `contracts/repro-runbook.schema.json`.
- [ ] `repro_pack.py` exits `0` — meaning both verdicts were `CONFIRMED` and `PASS`.
- [ ] `RUNBOOK.md`, `pack/`, and `pack.zip` exist at `<run>/repro/F-<NNN>/`.
- [ ] Every command in `RUNBOOK.md` is in a fenced block; install section is first.
- [ ] `TROUBLESHOOTING` exists and covers every `gotchas` entry and every step's `on_failure`.
- [ ] `reproduce[0]` is the smallest differentiating request — no reconnaissance step.
- [ ] `verify.negative_control` and `false_positive_traps` are populated.
- [ ] `cleanup[]` covers every step that created state.
- [ ] `pack/verify.sh` runs end to end and prints PASS for every step.
- [ ] No secret value appears anywhere in `pack/` or `RUNBOOK.md`.
- [ ] A human completed checkpoint 2 and `validation_provenance` records it.

## Reference (do not duplicate)

- Contract: `contracts/repro-runbook.schema.json`.
- CLI: `tools/README.md` § Stage 9.
