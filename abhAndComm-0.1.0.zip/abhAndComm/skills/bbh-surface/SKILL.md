---
name: bbh-surface
description: Build the attack-surface queue (bbh/queue/v1) from classification.json and per-asset coverage cells — the stage that ranks everything and eliminates nothing. Explains the 0-100 priority arithmetic, the P1/P2/P3 bands, --explain, and why P3 means "later" rather than "skip". Use after bbh-recon, and re-run after bbh-slice to fold coverage cells in.
whenToUse: After recon-lite produces classification.json and checkpoint 1 clears the asset list; re-run after cells_build.py so coverage-cell leads appear alongside bucket leads.
---

# bbh-surface — Stage 2, the queue

> ## ⚠️ THIS STAGE QUEUES EVERYTHING AND ELIMINATES NOTHING
>
> **There is no kill list. There is no "skip" status. Nothing is ever removed.**
>
> Every input signal becomes a lead. The lowest band is **`P3`, which means "after P1 and P2"** —
> it does **not** mean "skip", "dead", or "not a target". A lead whose signal was weak still has
> `status: "queued"` and stays visible in `queue.json` forever.
>
> This is the deliberate difference from ABH's `/surface`, which printed a "Kill List (skip)".
> Here, `exhausted` is the *only* status that means "worked and produced nothing" — and even then
> the lead stays in the file. That is what makes **"looked at and found nothing"** distinguishable
> from **"never looked at"**, which is the whole point of the artifact.

**Input:** `runs/<engagement>/classification.json` (+ `runs/<engagement>/assets/` once slice has run).
**Output:** `runs/<engagement>/queue.json` (`bbh/queue/v1`, `contracts/surface-queue.schema.json`).
**Tool:** `tools/queue_build.py`.

> **Orchestrated path:** `workflows/bbh-hunt.js` runs this stage as part of the full pipeline
> and stops at the checkpoints. This skill is the manual path and the reference for what the
> stage does; both write the same artifacts. See `/bbh` § "Two ways to drive this".

## 1. Build (pass A — bucket leads)

```bash
ENG=acme-2026-09; RUN=runs/$ENG

python3 tools/queue_build.py \
    --classification "$RUN/classification.json" \
    --cells-dir      "$RUN/assets" \
    --out            "$RUN/queue.json"
```

`--cells-dir` points at the per-asset tree root. On a fresh run Stage 3 has not written
`applicability/cells.json` yet, so this pass contributes **no** coverage-cell leads — the queue is
built from ABH buckets. That is expected, not a failure.

## 2. Re-build (pass B — coverage-cell leads)

After `bbh-slice` has run `cells_build.py`, run the **same command again**:

```bash
python3 tools/queue_build.py \
    --classification "$RUN/classification.json" \
    --cells-dir      "$RUN/assets" \
    --out            "$RUN/queue.json"
```

Re-running over the same classification is **idempotent and preserves each lead's `status`** — so
`investigating` / `candidate` / `exhausted` survive, `touched_by` is not lost, and
`lead_id` stays stable. New coverage-cell leads appear; existing ones are not renumbered or reset.
This is the intended two-pass flow, not a workaround.

## 3. What a lead is

| Field | Meaning |
|---|---|
| `lead_id` | `L-` + 6 hex, e.g. `L-DDC554` — a deterministic hash of `asset_tag|class_id|address|bucket`, so it is **stable across re-runs**. Reference it in notes and commits. |
| `asset_tag` / `asset_id` | Which asset owns the lead |
| `unit_id` | Set when the lead came from a coverage cell; `null` for bucket-only leads |
| `class_id` | Catalogue class (e.g. `API1-BOLA`) when known; `null` for a raw signal |
| `address` | The unit address the lead targets |
| `bucket` | Originating ABH bucket when not cell-derived |
| `priority` | Integer `0`–`100` |
| `tier` | `P1` / `P2` / `P3` — presentation band only |
| `rationale` | One line naming the signal that produced the lead |
| `source` | `coverage-cell`, `abh-bucket`, `js-secret`, `auth-path`, `admin-path`, `param`, `cloud`, `takeover`, `port`, `memory-pattern` |
| `status` | `queued` · `investigating` · `candidate` · `reported` · **`exhausted`** |
| `touched_by` | The `EXPERIMENT_ID` that worked this lead |

`status` semantics, precisely:

| Status | Set when | Coverage effect |
|---|---|---|
| `queued` | default — nobody has looked | not covered |
| `investigating` | an executor is on it | not covered |
| `candidate` | a finding was written for it | not covered until validated |
| `reported` | verdict `CONFIRMED` and 7-questions `PASS` | covered |
| `exhausted` | worked, produced nothing | covered **as a corroborated negative** |

Nothing moves a lead out of the file. `exhausted` is a *result*, and `coverage_gate.py` requires a
corroborator for it: "we tested and found nothing" is a **covered negative**, never a rejection.

## 4. The priority arithmetic

Priority is a **0–100 integer from an additive score** over the signals attached to the lead.
The weights belong to `queue_build.py`, not to this document — **read them from the tool**:

```bash
python3 tools/queue_build.py \
    --classification "$RUN/classification.json" \
    --cells-dir      "$RUN/assets" \
    --out            "$RUN/queue.json" \
    --explain
```

`--explain` prints the **per-lead arithmetic**: which signals fired and what each contributed.
That output is authoritative. Do not hard-code weights into a prompt, a report, or this skill —
if the tool's weights change, a copied table silently lies.

Audit checklist for `--explain` output:

- [ ] Every lead in `queue.json` appears in the explanation.
- [ ] The listed contributions sum to the printed `priority`.
- [ ] `tier` is consistent with the score across the whole file (one band boundary, applied uniformly).
- [ ] A lead whose score you disagree with still has a `rationale` and a `source` — you may
      *re-rank by hand* by moving `status`, but you may not delete the lead.

**Bands.** `P1` = work first · `P2` = next · `P3` = later. Bands are a reading order, not a
filter. If the run finishes `P1` and `P2`, `P3` is what is left to do — and it is still there to
do because nothing deleted it.

## 5. Working the queue

```bash
# The list, with statuses
python3 tools/lead_board.py --run-dir "$RUN" show

# The next unclaimed lead for one asset
python3 tools/lead_board.py --run-dir "$RUN" next --asset api.acme.com

# Claim it before you start — this is the audit link, not bookkeeping theatre
python3 tools/lead_board.py --run-dir "$RUN" touch --lead "$LEAD_ID" \
    --status investigating --experiment E-004
```

`lead_board.py` is the cross-asset view of `queue.json` + each slice's `experiments.md`. Statuses
written here **survive a re-run of `queue_build.py`** — which is why the re-run in §2 is safe.

**Discipline:** an executor that starts work without `touch --status investigating` breaks the
`touched_by` link, and a later re-run can no longer tell the lead was touched. Claim first.

## 6. Done when

- [ ] `queue.json` validates against `contracts/surface-queue.schema.json`.
- [ ] `lead_count` equals `len(leads)`; every lead has a `rationale` and a `source`.
- [ ] Every asset in `classification.json` contributed at least one lead (or is in
      `negative_findings[]`).
- [ ] `--explain` output accounts for every lead's score.
- [ ] **Zero** leads have been deleted, and no `tier` was used to drop one.
- [ ] Pass B has been run after slice, so `source: "coverage-cell"` leads exist.

## Reference (do not duplicate)

- Contract: `contracts/surface-queue.schema.json`.
- CLI: `tools/README.md` § Stage 2.
- Upstream `/surface` output format, for contrast with the kill-list it used to print:
  `vendor/upstream-commands/abh/surface.md` (ABH command; not vendored).
