---
name: bbh
description: Main entry point for the bbh bug-bounty pipeline — runs scope, known-asset recon-lite, queue, per-asset slices, executor batches, blind validation, chaining, the ABH 7-Question Gate and the manual reproduction pack, with two required human checkpoints (asset confirmation, manual reproduction) and an optional finalize step. Includes the routing table to every bbh-* skill and the artifact map. Use this first, when starting an engagement or when unsure which bbh stage comes next.
whenToUse: Type this first for any bbh engagement. It is the one to read when you do not yet know which stage you are in, or when a human needs to know where to intervene.
---

# bbh — the pipeline

This bundle ships **no native DSH plugin**: the `bbh-*` skills *are* the slash-command layer. Each
one is a focused operator playbook; this skill is the map.

**Repo root:** `/me/ai/dsh/bounty/abhAndComm/`. All commands below run from there.
**Run directory:** `runs/<engagement>/` — `<engagement>` is the slug in `scope.json`, e.g. `acme-2026-09`.
**Input:** a program scope page / H1-Bugcrowd handle, plus a human for the two required checkpoints.
**Output:** the whole `runs/<engagement>/` tree — the per-stage artifacts are listed in the routing
table and the artifact map below, and each stage skill states its own exact input and output.

## Two ways to drive this — pick one before you start

| | **Workflow** (orchestrated) | **Manual CLI** (this skill's quickstart) |
|---|---|---|
| What runs | `workflows/bbh-hunt.js` fans out coordinators, executors, validators and the gate/cure loop for you | you run one `tools/*.py` per stage and drive the agents yourself |
| Use it when | you want the full loop, coverage tracking, and the cure cycle automated | you want to drive one stage, debug, re-run a single step, or work one asset by hand |
| Checkpoints | returns a `CHECKPOINT_n` envelope and stops; you resume with `resume_from` | you simply stop and continue when ready |
| Cost | many agents per asset — bound it with `args.max_experiments` / `args.only_assets` | whatever you spawn yourself |

**Neither is "the real one".** They write the same artifacts in the same places, so you can start
manually and hand the same `run_dir` to the workflow later, or resume a workflow run by hand.

### Driving the workflow

A DSH workflow script is an **inline body**, not a file the tool loads by name. So the call is:
read the file, pass its contents as `script`, and pass the identity as `meta`:

```
workflow({
  script: <contents of workflows/bbh-hunt.js>,
  meta:   { name: "bbh-hunt", description: "bug-bounty pipeline" },
  args:   { scope_file: "runs/acme-2026-09/scope.json", run_dir: "runs/acme-2026-09" }
})
```

`args` for `bbh-hunt.js`: `scope_file` | `scope`, `run_dir`, `resume_from`, `human_confirmation`,
`max_experiments` (default 30), `max_cure_cycles` (3), `parallel_assets` (3), `only_assets`,
`votes` (3), `nvd_cache_dir`, `kev_snapshot`, `dry_run`.

### The checkpoint / resume protocol

A workflow **cannot pause and ask**. So a checkpoint is implemented as *returning an envelope and
ending the run*:

1. The run reaches a checkpoint and returns `{status: "CHECKPOINT_1", artifacts: {...}, question: "..."}`.
2. The calling session shows you the question. **This is the stop** — nothing continues on its own.
3. You answer, and the caller re-invokes the same script with the same `args.run_dir` plus
   `resume_from: "checkpoint-1"`. The new run reads state off disk and continues.

Because the state is on disk, the gap between steps can be days and the machine can reboot in
between. The resume tokens are listed in `workflows/README.md`.

**What the stop actually is:** it is *you not re-invoking*. Only the checkpoint-2 → finalize
transition is gated in code — without `args.human_confirmation` the run returns the envelope again
instead of finalizing. Checkpoint 1 is not code-gated: anyone who calls `resume_from: "checkpoint-1"`
proceeds. That is fine for a semi-automatic tool you drive, and it is why **checkpoint 2 (you
reproducing the runbook by hand) is the one that actually protects the output.**

## Quickstart (manual CLI)

```bash
cd /me/ai/dsh/bounty/abhAndComm
ENG=acme-2026-09; RUN=runs/$ENG; mkdir -p "$RUN"

# 1. scope
python3 tools/bbh_scope.py init --engagement $ENG --platform hackerone --program acme \
    --asset 'web:acme.com:apex' --asset 'wildcard:*.acme.com' --out $RUN/scope.json
python3 tools/schema_check.py --kind scope $RUN/scope.json

# 2. recon-lite (known assets only — no subdomain enum, no nuclei)
python3 tools/bbh_classify.py --recon-dir recon/acme.com --scope $RUN/scope.json \
    --out $RUN/classification.json

# --- CHECKPOINT 1: a human confirms the asset list ---

# 3. queue (queues everything, eliminates nothing)
python3 tools/queue_build.py --classification $RUN/classification.json \
    --cells-dir $RUN/assets --out $RUN/queue.json

# 4. slice (one self-contained work order per asset)
python3 tools/surface_build.py --classification $RUN/classification.json \
    --scope $RUN/scope.json --assets-dir $RUN/assets --explain
for d in $RUN/assets/*/; do
  python3 tools/cells_build.py --asset-dir "$d" --catalog catalog/bounty-coverage-matrix.json
done
python3 tools/slice_build.py --run-dir $RUN --scope $RUN/scope.json
python3 tools/queue_build.py --classification $RUN/classification.json \
    --cells-dir $RUN/assets --out $RUN/queue.json   # pass B: folds coverage cells in

# 5..9  work each slice: execute -> validate -> chain -> 7 questions -> repro pack
python3 tools/coverage_gate.py --run-dir $RUN
```

## The flow

```mermaid
flowchart TD
    S["scope"] --> R["recon-lite<br/>known assets only"]
    R --> C1{{"CHECKPOINT 1<br/>human confirms asset list"}}
    C1 --> Q["queue<br/>queues everything, eliminates nothing"]
    Q --> SL["slice / fork<br/>one slice per asset"]
    SL --> CO["per-asset coordinator"]
    CO --> EX["executor<br/>1-2 per batch"]
    EX --> VA["validate<br/>blind, x3 refuters"]
    VA -->|CONFIRMED| CH["chain<br/>A to B to C"]
    VA -->|"fail: cure"| CU1["cure executor<br/>named gaps only"]
    CU1 -->|"re-validate"| VA
    CH --> SQ["7 questions"]
    SQ -->|PASS| RP["repro pack<br/>RUNBOOK.md + pack/"]
    SQ -->|"fail: cure"| CU2["cure loop<br/>failing question named"]
    CU2 -->|"re-run all 7"| SQ
    RP --> C2{{"CHECKPOINT 2<br/>human runs the runbook by hand"}}
    C2 --> C3{{"CHECKPOINT 3<br/>finalize and submit"}}
```

Read it as: **`scope → recon-lite → [CHECKPOINT 1] → queue → slice/fork → per-asset coordinator →
executor → validate → (fail: cure → re-validate) → chain → 7 questions → (fail: cure) → repro pack
→ [CHECKPOINT 2 manual repro] → [CHECKPOINT 3 finalize]`**.

## The human checkpoints — two that matter, one that is just bookkeeping

The pipeline is autonomous between checkpoints. **Two of them are required**; the third is a
finalize step the code happens to model as a checkpoint.

| # | Required? | When | What the human does | Gate to pass |
|---|---|---|---|---|
| **1** | **yes** | After `classification.json` validates, **before** the queue is built | Read `scope.json` and `classification.json`. Confirm every asset is really in scope, that staging/dev and third-party CNAMEs are excluded, that the safe-harbor status is understood, and that nothing discovered-but-unlisted got promoted into `assets[]`. | `bbh_scope.py check` returns the expected code for one in-scope, one excluded and one third-party URL; no asset is `unclear` |
| **2** | **yes** | After `repro_pack.py` exits 0, **before** finalizing | Run `RUNBOOK.md` by hand on a clean box, from `setup` through `verify`, including the negative control. The agent's own machine does not count. | `verify.success_criteria` is observed; `negative_control` prints what the runbook says; `pack/verify.sh` prints PASS for every step |
| **3** | optional | After checkpoint 2 | Finalize: record `validation_provenance.verified_by: "human"` and `last_verified`, rebuild the pack, run the coverage gate, decide what is submitted. | `coverage_gate.py --run-dir` exit 0; every submitted finding has a `CONFIRMED` verdict, a `PASS` 7-question record and a human-verified runbook |

Checkpoint 1 is the cheap one and the one people skip: after it, every downstream artifact inherits
the asset list, and a wrong host that reaches the queue has already cost crawl traffic and possibly
a ban. Checkpoint 2 is the honest one: it is the difference between "the agent says it reproduced"
and "a person reproduced it".

**Only checkpoint 2 is enforced in code.** `workflows/bbh-hunt.js` refuses to finalize without
`args.human_confirmation`, but checkpoint 1 is a plain stop — a caller that re-invokes with
`resume_from: "checkpoint-1"` proceeds without any approval being checked. Treat 1 as a discipline
you keep, not a lock the tool holds. Checkpoint 3 can be skipped entirely by resuming with
`resume_from: "checkpoint-3"`.

## Routing table

| Stage | Skill | Run it when | Output artifact |
|---|---|---|---|
| 0 | **`/bbh-scope`** | Anytime before traffic; whenever a new URL appears | `runs/<eng>/scope.json` |
| 1 | **`/bbh-recon`** | After scope; when scope gains assets | `runs/<eng>/classification.json` |
| 2 | **`/bbh-surface`** | After checkpoint 1; re-run after slice | `runs/<eng>/queue.json` |
| 3 | **`/bbh-slice`** | After the queue exists, before spawning anyone | `assets/<tag>/recon/inventory/surface.json`, `assets/<tag>/applicability/cells.json`, `slices/<tag>.json` |
| 5 | **`/bbh-execute`** | Inside a slice, per batch | `assets/<tag>/findings/finding-NNN/` + the three tracking files |
| 6 | **`/bbh-validate`** | The instant a candidate is materialized; fresh after each cure | `assets/<tag>/artifacts/{validated,false-positives,dropped}/F-NNN.json` |
| 7 | **`/bbh-chain`** | After `CONFIRMED`, before the 7 questions | new candidate findings + `attack-chain.md` `## Chains` |
| 8 | **`/bbh-seven`** | After the chain stage | `assets/<tag>/seven-questions/F-NNN.json` |
| 9 | **`/bbh-repro`** | After the gate returns `PASS` | `repro/F-NNN/{RUNBOOK.md,pack/,pack.zip}` |
| — | **`/bbh`** (this) | Start of an engagement; when lost | the map |

Each stage's skill states its own inputs, outputs and done-conditions. Load only the stage you are
in — these are playbooks, not a novel.

**Stage 4 (the per-asset coordinator) has no `bbh-*` skill of its own.** It is the role that owns
one slice: it reads `slices/<asset_tag>.json`, writes the three tracking files, runs the batch
cadence, and spawns executors and validators. `/bbh-execute` documents that role's working
contract; the coordinator's own boundaries are in the vendored
`vendor/upstream-skills/coordination/reference/{role-matrix,spawning-recipes}.md`. Numbering follows
`contracts/*.schema.json` ("Stage 5 EXECUTOR output", "Stage 6 output", "Stage 8 output",
"Stage 9 output"), which is why 4 and 5 are close together and there is no stage for 4 here.

## Artifact map

```
runs/<engagement>/
├── scope.json                                  bbh/scope/v1            stage 0
├── recon/<target>/                             input tree to classify  stage 1
├── classification.json                         bbh/classification/v1   stage 1
├── queue.json                                  bbh/queue/v1            stage 2 (+ re-run after 3)
├── slices/<asset_tag>.json                     bbh/slice/v1            stage 3
├── assets/<asset_tag>/
│   ├── recon/inventory/surface.json            surface/v2              stage 3
│   ├── applicability/cells.json                code-generated          stage 3
│   ├── coverage.json                           executor-maintained
│   ├── attack-chain.md   experiments.md   session-memory.md           stage 5
│   ├── findings/finding-NNN/                   bbh/finding/v1          stage 5
│   ├── artifacts/validated/F-NNN.json          bbh/verdict/v1          stage 6
│   ├── artifacts/false-positives/F-NNN.json    bbh/verdict/v1          stage 6
│   ├── artifacts/dropped/F-NNN.json            bbh/verdict/v1          stage 6
│   ├── seven-questions/F-NNN.json              bbh/7q/v1               stage 8
│   └── reports/coverage-matrix.json            coverage_gate.py        every gate run
└── repro/F-NNN/{RUNBOOK.md,pack/,pack.zip}     bbh/repro/v1            stage 9
```

Validate at every stage boundary — a stage whose output does not validate has not completed:

```bash
python3 tools/schema_check.py --kind all --run-dir runs/acme-2026-09
# --kind <k> resolves to contracts/<k>.schema.json (scope, classification, slice,
# surface-queue, surface.v2, finding, verdict, seven-questions, repro).
# --kind all is the one form tools/README.md shows explicitly — prefer it at boundaries.
```

## Invariants

Five properties hold across the whole pipeline. If one breaks, the run is not trustworthy.

1. **Nothing is eliminated.** The queue ranks; it never deletes. `P3` means "later". The only
   terminal lead status is `exhausted`, and it stays in the file as a covered negative.
2. **Applicability is code-produced.** `cells_build.py` computes the 7 derived flags; an agent may
   not write them, so an agent cannot shrink the set of classes it is expected to test.
3. **Executors claim, validators decide.** A candidate finding is a claim; only a blind validator
   writes `CONFIRMED`. The executor cannot write to `validated/`.
4. **Blindness is preserved across cure rounds.** Validators never read the theory, the chain, or
   executor logs, and are re-spawned fresh every round. Cure executors get only the named gaps and
   must not re-theorize.
5. **Scope is checked mechanically, every time.** `bbh_scope.py check` — exit 1 out of scope,
   exit 2 unclear (third party / staging / no safe harbor). Never a judgement call.

## Reference material

Two reference shelves exist, and they are not the same set:

| Where | What lives there |
|---|---|
| `vendor/upstream-skills/<skill>/…` | The **vendored skills**, normalised for this bundle: from communitytools — `triage-validation/SKILL.md` (the 7-Question Gate), `coordination/SKILL.md` + `coordination/reference/{role-matrix,VALIDATION,spawning-recipes,bookkeeping,executor-role,coverage-matrix}.md`, `security-arsenal/`, `web2-vuln-classes/`, `api-security/`, and the rest; and from ABH — `bb-methodology/`, `argus/`, `graphql-audit/`, `web2-recon/`. `vendor/normalisation-changelog.json` has the exact list |
| `vendor/upstream-commands/abh/…` | ABH's **slash-command playbooks**: `{scope,recon,hunt,surface,chain,validate}.md`. These are procedures, not skills, so they are not on the skill shelf — but they ARE vendored, and they are where the A→B signal table and the time-box rules live |

Everything the pipeline needs is vendored. `_upstream/` is a read-only build-time snapshot and is
**deliberately excluded from the migration bundle** (it is large and carries upstream's
agent-instruction files), so no skill may point into it. If you find a reference that does, that is
a bug — fix it to a `vendor/` path.

**Frozen contract:** `tools/README.md` is the only authority on CLI flags, and `contracts/*.schema.json`
on artifact shape. If a command you need is not in `tools/README.md`, it does not exist — add a
stage or do it by hand, but do not invent a flag.
