---
name: bbh-scope
description: Turn a bug-bounty program's scope page, HackerOne/Bugcrowd handle, or raw asset list into a validated runs/<engagement>/scope.json (bbh/scope/v1). Handles wildcard vs apex interpretation, path exclusions, third-party CNAME and staging/dev detection, and the safe-harbor check. Use as the first stage of the bbh pipeline, or any time you need to prove an asset is in scope before sending it traffic.
whenToUse: Use before any request is sent to a target, and again whenever a new URL surfaces that is not already in scope.json. Produces the artifact every later stage refuses to work without.
---

# bbh-scope — Stage 0 intake

**Output:** `runs/<engagement>/scope.json` (`bbh/scope/v1`, `contracts/scope.schema.json`).
**Input:** the program's scope page (H1/Bugcrowd/Intigriti/YesWeHack/Immunefi), or a raw asset list.
**Downstream:** every later stage reads `scope_ref` and **refuses assets absent here**.

> Rule: no artifact from this stage = no traffic. `bbh_scope.py check` is the only authority on
> whether a URL may be touched. A human's memory of the scope page is not.

> **Orchestrated path:** `workflows/bbh-hunt.js` runs this stage as part of the full pipeline
> and stops at the checkpoints. This skill is the manual path and the reference for what the
> stage does; both write the same artifacts. See `/bbh` § "Two ways to drive this".

## 0. Run directory

```bash
ENG=acme-2026-09
RUN=runs/$ENG
mkdir -p "$RUN"
```

All paths in this skill are relative to the repo root (`/me/ai/dsh/bounty/abhAndComm/`) unless
absolute. `asset_tag` = the host (or `host:port`) that keys every downstream directory.

## 1. Extract the scope page into the three lists

Read the program page and write down **verbatim**:

| List | Goes into | Notes |
|---|---|---|
| In-scope assets (domains, wildcards, APIs, mobile bundles, IPs/CIDRs, repos) | `--asset` | One flag per asset |
| Out-of-scope hosts/patterns | `--exclude` | Hosts only; paths go in `path_exclusions` |
| Rewards / accepted bug classes | your notes | Feeds `bbh-seven` Q2; **not** stored in scope.json |

`KIND` must be one of the schema's enum:
`web` · `api` · `mobile` · `ip` · `cidr` · `source_repo` · `wildcard`.

```bash
python3 tools/bbh_scope.py init \
    --engagement acme-2026-09 --platform hackerone --program acme \
    --asset 'web:acme.com:apex' \
    --asset 'wildcard:*.acme.com' \
    --asset 'api:api.acme.com' \
    --asset 'mobile:com.acme.app' \
    --exclude staging.acme.com \
    --out runs/acme-2026-09/scope.json
```

- `--asset KIND:VALUE[:apex]`. The literal `:apex` suffix is how `is_apex` (a **derived** surface
  flag) ever becomes true — set it on the registrable apex only.
- `--exclude` accepts a host/pattern; `out_of_scope[]` is matched by `check`, and a discovered
  asset matching it is dropped at slice time, never queued.
- Repeat `--asset` / `--exclude` once per entry. Add `--help` if the installed build differs —
  never invent a flag; `tools/README.md` is the frozen contract.

## 2. Fill the fields the CLI does not prompt for

Open `runs/<engagement>/scope.json` and complete, per `contracts/scope.schema.json`:

| Field | What to write | Why it matters |
|---|---|---|
| `assets[].asset_id` | Stable `a1`, `a2`, … | Referenced by every downstream artifact |
| `assets[].path_exclusions` | Globs, e.g. `/admin/*`, `/help/*` | `check` applies these on every URL |
| `assets[].notes` | "wildcard covers sub-subdomains" etc. | Ambiguity you resolved, recorded |
| `safe_harbor` | `true` **only** if the program publishes the clause | Absence is treated as false and downgrades rate/aggressiveness |
| `roe.rate_limit_rps` | Default `5`; lower if no safe harbor | Enforced by the executor |
| `roe.max_requests_per_asset` | Default `20000` | Budget the coordinator tracks |
| `creds_env` | Env-var **names** only, e.g. `ACME_USER_A` | **Never a secret value** |

## 3. Interpretation rules (the part that gets people banned)

**Wildcards are narrower than they look.**

| Scope pattern | Covers | Does NOT cover |
|---|---|---|
| `*.acme.com` | `api.acme.com`, `app.acme.com` | `acme.com` itself |
| `acme.com` | `acme.com` only | `api.acme.com` |
| `*.acme.com` + `acme.com` | both | `a.api.acme.com` (depends on the program — ask) |

If the program lists only explicit production hosts, a wildcard does **not** grant you the rest.

**Third-party CNAME → unclear, never in scope.** A host inside the wildcard that points at
Zendesk/Freshdesk/Salesforce/Intercom/HubSpot or any other SaaS is not owned by the program.

```bash
dig +short api.acme.com CNAME
# CNAME to *.zendesk.com etc. -> third party: do NOT test without written confirmation
whois acme.com | grep -iE "registrant|admin|tech|org"      # ownership corroboration
```

**Staging / dev / test / qa → unclear unless explicitly listed.**

```
staging.acme.com  dev.acme.com  qa.acme.com  test.acme.com  uat.acme.com
```
Check whether the scope says `*.acme.com` *or* names production hosts only.

**Safe harbor.** Look for "we will not pursue legal action against researchers who…". If it is
absent, set `safe_harbor: false`, drop `rate_limit_rps`, and stay strictly inside the documented
scope. Do not test third-party services, and do not test anything requiring a write.

## 4. Verify before you leave this stage

```bash
# Every asset and a representative URL for each — expect exit 0 for in-scope:
python3 tools/bbh_scope.py check --scope runs/acme-2026-09/scope.json \
    --url https://api.acme.com/v2/users/1

# A known-excluded host and a known third party — expect exit 1 and exit 2 respectively:
python3 tools/bbh_scope.py check --scope runs/acme-2026-09/scope.json \
    --url https://staging.acme.com/
python3 tools/bbh_scope.py check --scope runs/acme-2026-09/scope.json \
    --url https://acme.zendesk.com/

python3 tools/schema_check.py --kind scope runs/acme-2026-09/scope.json
# `--kind` takes one of a CLOSED set that does NOT map mechanically onto filenames:
# scope, classification, surface, queue, slice, finding, verdict, seven-questions, repro.
# Note especially that the queue's contract file is `surface-queue.schema.json` while its
# kind is `queue`. `python3 tools/schema_check.py --list-kinds` is authoritative.
# `--kind all --run-dir <run>` also works.
```

**Exit-code contract** (branch on these, never on the printed prose):
`0` in scope · `1` out of scope · `2` **unclear** — third party, staging, or no safe harbor.
An `unclear` is a *stop*, not a judgement call: get written program confirmation or drop the asset.

## 5. Done when

- [ ] `scope.json` exists and validates against `contracts/scope.schema.json`.
- [ ] Every asset has a stable `asset_id`; the apex carries `:apex`.
- [ ] `out_of_scope[]` and per-asset `path_exclusions[]` are populated.
- [ ] `safe_harbor` is `true` only with a quoted clause; `roe` reflects it.
- [ ] `check` returns the expected code for one in-scope, one excluded, one third-party URL.
- [ ] Every unclear asset is either resolved in writing or **removed** from `assets[]`.

## Reference (do not duplicate)

- Upstream scope methodology incl. the Vienna `/advuew/*` example, wildcard interpretation and
  the third-party-CNAME check: `vendor/upstream-commands/abh/scope.md` (ABH command; not vendored).
- Frozen CLI: `tools/README.md` § Stage 0. Schema: `contracts/scope.schema.json`.
