---
name: bbh-validate
description: The fidelity gate — a blind validator re-runs the PoC and repairs it, recomputes CVSS from the vector, checks CVE claims against NVD+CISA KEV, stats every evidence path on disk, requires cross-identity proof for IDOR/BOLA/ATO, and requires 3 blind refuters to fail to refute before CONFIRMED. Covers the CONFIRMED/REJECTED/CURE/DROPPED routing and the strict cure contract. Use on every candidate finding before it is counted as coverage.
whenToUse: Interleaved — the moment a candidate finding is materialized, before the next hunt batch. Re-spawn a fresh validator after every cure round.
---

# bbh-validate — Stage 6, the fidelity gate

**Input:** a candidate at `<slice>/findings/finding-<NNN>/` (`finding.json`, `poc/`, `evidence/`).
**Output:** `<slice>/artifacts/validated|false-positives|dropped/F-<NNN>.json`
(`bbh/verdict/v1`, `contracts/validation-verdict.schema.json`).
**Tools:** `tools/cvss_recompute.py`, `tools/nvd_lookup.py`, `tools/schema_check.py`.

> **Orchestrated path:** `workflows/bbh-hunt.js` runs this stage as part of the full pipeline
> and stops at the checkpoints. This skill is the manual path and the reference for what the
> stage does; both write the same artifacts. See `/bbh` § "Two ways to drive this".

## Does this keep findings honest? Yes — and here is the mechanism

A validator is an agent that has **never read** `attack-chain.md`, the coordinator's theory, or the
executor's logs. It sees the finding directory and nothing else, and it is **re-spawned fresh every
cure round** so the blindness holds across the whole loop. Honesty is then enforced by seven
mechanical facts, not by good intentions:

| # | Mechanism | What it stops |
|---|---|---|
| 1 | **The PoC is actually re-run and repaired.** It must execute, emit `expected_output`, and do so identically on ≥3 runs. | PoCs that never ran, or ran once and were pasted |
| 2 | **CVSS is recomputed from the vector** by `cvss_recompute.py`; a vector/band mismatch is a failed check. | Inflated or under-sold severity labels |
| 3 | **CVE claims hit NVD + KEV** via `nvd_lookup.py`; NVD, KEV and vendor advisory must agree. | Version-only "Critical" claims and invented CVEs |
| 4 | **Every evidence path is checked on disk.** A named artifact that is absent, or empty, fails. | Findings whose "screenshots" are a filename in JSON |
| 5 | **Cross-identity proof is mandatory for IDOR/BOLA/ATO/privesc**: actor reaches victim's data, a fresh session still works, anonymous differs. | "IDOR" on your own account; a 200 with no data delta |
| 6 | **3 blind refuters must fail to refute.** Confirmation requires `refuters.count >= 3` and `refuters.refuted == 0`. | Confirmations that survive only because nobody argued |
| 7 | **A check with no recorded raw output is a failed check.** Each check carries `cmd` + output. | Verdicts written from memory |

The verdict is written **only** by the validator. The executor cannot route its own finding.

## 1. Checks to run

Every check records `pass`, `detail`, `cmd`, and the raw output that decided it.

| Check | Passes when | Fails when |
|---|---|---|
| `scope_in_scope` | `bbh_scope.py check` on the finding's endpoint returns exit 0 **now** | exit 1 or 2 |
| `poc_runs` | the PoC executes and emits `expected_output` | it errors, or the token is absent |
| `poc_deterministic` | ≥3 runs, identical **decisive** output | any run differs |
| `negative_control` | the control did **not** print the success token | control prints the token → the signal is noise |
| `impact_real` | real data or a real state change appears in the evidence | a status code with no body |
| `cross_identity` | **required** for IDOR/BOLA/ATO/privesc: actor → victim data, fresh session repro, anon differs | blank identity block, or actor == victim |
| `cvss_recomputed` | recomputed score matches the claimed band | any mismatch |
| `cve_truth` | **when a CVE is claimed:** NVD + KEV + vendor advisory agree | disagreement, or no advisory |
| `not_known_duplicate` | not in disclosed reports / changelog / docs | documented behaviour |
| `evidence_complete` | every `evidence.artifacts[]` and `poc.script` exists on disk, non-empty | missing or empty file |

```bash
# scope — re-check NOW, not from the executor's notes
python3 tools/bbh_scope.py check --scope runs/acme-2026-09/scope.json \
    --url https://api.acme.com/v2/users/4711

# CVSS — recompute from the vector, never trust the claim
python3 tools/cvss_recompute.py --vector 'CVSS:3.1/AV:N/AC:L/PR:L/UI:N/S:U/C:H/I:N/A:N' --json

# CVE claims — freeze the snapshot so a replayed verdict is reproducible
python3 tools/nvd_lookup.py CVE-2024-1234 --json \
    --cache-dir runs/acme-2026-09/artifacts/nvd-cache

# evidence on disk — every path named in the finding
python3 - <<'PY'
import json,os
d=os.path.dirname("runs/acme-2026-09/assets/api.acme.com/findings/finding-001/finding.json")
f=json.load(open(os.path.join(d,"finding.json")))
for p in [f["poc"]["script"], *f["evidence"].get("artifacts",[])]:
    fp=os.path.join(d,p); print(p, os.path.exists(fp) and os.path.getsize(fp)>0)
PY
```

Then validate the verdict itself:

```bash
python3 tools/schema_check.py --kind verdict \
    runs/acme-2026-09/assets/api.acme.com/artifacts/validated/F-001.json
```

## 2. Adversarial quorum

Before writing a verdict, spawn **3 refuters that each try to destroy the finding**, blind to the
coordinator's theory. They must be genuinely adversarial — commission them to refute, not to
review:

- Is the "victim" identity actually the attacker's own resource under a different id?
- Does the endpoint return the same body for a **non-existent** id (so the 200 means nothing)?
- Is the data genuinely sensitive, or is it public by design?
- Does the PoC depend on an unstated precondition the executor had but didn't record?
- Is the CVSS C/I/A justified by the *demonstrated* step, or by a hypothesised end state?
- Is the "bug" the documented behaviour of that API version?

`refuters.refuted` counts the refuters that **succeeded**. One successful refutation blocks
`CONFIRMED` — the verdict becomes `CURE` (gaps named) or `REJECTED` (majority refuted).
Record `refutation_args[]` verbatim; they are the most valuable artifact this stage produces.

## 3. The four verdicts

| Verdict | Meaning | Written to | Counts as coverage? |
|---|---|---|---|
| `CONFIRMED` | all checks pass, 0 successful refutations, ≥3 refuters | `artifacts/validated/F-001.json` | **yes** |
| `REJECTED` | adversarially refuted — a false positive | `artifacts/false-positives/F-001.json` | **no** — cell stays `pending` |
| `CURE` | real but under-evidenced / a named gap | back to the executor | not yet |
| `DROPPED` | real bug but out of scope / not submittable here; or still uncured after `MAX_CURE_ROUNDS` | `artifacts/dropped/F-001.json` | **no** |

`REJECTED` is the false-positive record the pipeline asks for — it is a **result, not a failure**.
`DROPPED` is neither reported nor counted as covered.

**Coverage follows the verdict.** A cell flips to covered only on `CONFIRMED`, a justified N/A, or
a corroborated negative. A cell whose only candidates were rejected stays `pending`, so the search
continues — that edge is the whole reason validation runs interleaved rather than at the end.

## 4. The strict cure contract

`CURE` hands the executor **exactly two lists** and nothing else:

```json
{
  "failed_checks": ["negative_control", "cross_identity"],
  "missing_evidence": ["evidence/two-identity-comparison.txt"]
}
```

The cure executor:

- closes **exactly** those named gaps — writes the named files, repairs and re-runs the PoC,
  fixes the CVSS vector;
- may **not re-theorize**, may not add a new class, may not widen the claim to make the gap
  disappear;
- may **not** read `attack-chain.md`, the coordinator's theory, other findings, or the refuters'
  reasoning.

Then a **fresh blind validator** re-validates from disk. Re-validating with the same validator
would leak the cure executor's explanation into the gate and void the independence.

Track `cure_cycles`. **`>= 3` escalates to the coordinator** — three failed cures on one candidate
usually means the claim is wrong, not the evidence.

## 5. Writing the verdict

```json
{
  "schema": "bbh/verdict/v1",
  "finding_id": "F-001",
  "asset_tag": "api.acme.com",
  "verdict": "CURE",
  "checks": {
    "scope_in_scope": { "pass": true,  "cmd": "python3 tools/bbh_scope.py check ...", "detail": "exit 0" },
    "poc_runs":       { "pass": true,  "cmd": "python3 poc/exploit.py", "detail": "printed victim_user_b_email" },
    "poc_deterministic": { "pass": true, "detail": "3/3 identical decisive output" },
    "negative_control":  { "pass": false, "cmd": "python3 poc/exploit.py --own-id", "detail": "control also printed the token" },
    "cross_identity":    { "pass": false, "detail": "actor == victim; no user_b evidence" },
    "cvss_recomputed":   { "pass": true,  "detail": "6.5 medium matches vector" }
  },
  "failed_checks": ["negative_control", "cross_identity"],
  "missing_evidence": ["evidence/two-identity-comparison.txt"],
  "refuters": { "count": 3, "refuted": 1, "refutation_args": ["the owned-id request also returns 200 with a body"] },
  "cvss": { "vector": "CVSS:3.1/AV:N/AC:L/PR:L/UI:N/S:U/C:H/I:N/A:N",
            "claim_score": 6.5, "recomputed_score": 6.5, "recomputed_band": "medium",
            "nvd_score": null, "kev_listed": null },
  "reason": "PoC works but the negative control is not negative and no second identity was demonstrated.",
  "cure_cycles": 0
}
```

## 6. Done when

- [ ] A verdict exists for **every** candidate — none left `status: candidate` with no verdict.
- [ ] Every check has `cmd` + raw output recorded; no check passed on prose alone.
- [ ] `CONFIRMED` verdicts have `refuters.count >= 3` and `refuters.refuted == 0`.
- [ ] `CVE` claims have a frozen NVD/KEV snapshot under `artifacts/nvd-cache/`.
- [ ] Every `failed_checks`/`missing_evidence` entry was handed to a cure executor verbatim.
- [ ] Findings verdicts validate via `schema_check.py --kind verdict`.
- [ ] No coverage cell was flipped to covered by a `REJECTED` or `DROPPED` verdict.

## Reference (do not duplicate)

- Contract: `contracts/validation-verdict.schema.json`.
- CLI: `tools/README.md` § Stage 6.
- Full upstream validation procedure (checks, proof-of-validation layout, templates):
  `vendor/upstream-skills/coordination/reference/VALIDATION.md`
  (raw fallback `vendor/upstream-skills/coordination/reference/VALIDATION.md`).
- Role boundary (what a blind validator may read):
  `vendor/upstream-skills/coordination/reference/role-matrix.md`.
