---
name: bbh-slice
description: Group classified surfaces per asset, translate ABH buckets into surface/v2 flags, generate the code-produced coverage cells, and emit one self-contained slice (bbh/slice/v1) per asset. Explains the 18 agent-settable flags vs the 7 code-derived flags and why an agent must never write a derived flag. Use after the queue exists and before spawning any executor.
whenToUse: After bbh-surface pass A, and again whenever classification.json changes. Produces the fork unit — one slice per asset — that every coordinator and executor works from.
---

# bbh-slice — Stage 3, the translation layer and the fork unit

**Input:** `runs/<engagement>/classification.json`, `runs/<engagement>/scope.json`, `runs/<engagement>/queue.json`.
**Outputs:** `<run>/assets/<asset_tag>/recon/inventory/surface.json` (`surface/v2`),
`<run>/assets/<asset_tag>/applicability/cells.json`, `<run>/slices/<asset_tag>.json` (`bbh/slice/v1`).
**Tools:** `tools/surface_build.py` ★, `tools/cells_build.py` ★, `tools/slice_build.py`,
`tools/coverage_gate.py` ★.

> **One slice = one asset = one coordinator session.** A slice is the complete, self-contained
> work order: the receiving coordinator must **never need to read another slice's directory**.
> `output_dir` is an absolute path and is that coordinator's entire write boundary.

> **Orchestrated path:** `workflows/bbh-hunt.js` runs this stage as part of the full pipeline
> and stops at the checkpoints. This skill is the manual path and the reference for what the
> stage does; both write the same artifacts. See `/bbh` § "Two ways to drive this".

## 1. surface.json — buckets → `surface/v2` flags

```bash
ENG=acme-2026-09; RUN=runs/$ENG

python3 tools/surface_build.py \
    --classification "$RUN/classification.json" \
    --scope          "$RUN/scope.json" \
    --assets-dir     "$RUN/assets" \
    --explain
# -> $RUN/assets/api.acme.com/recon/inventory/surface.json
```

This is the single most important tool in the bundle: it turns ABH's classification buckets into
the communitytools `surface/v2` flag vocabulary so the catalogue's `applies_when` predicates can
run. It obeys five rules — verify each one on the output:

| # | Rule | How to check |
|---|---|---|
| 1 | **Only the 18 agent flags** may appear in `units[].flags` | diff the flag set against the list below |
| 2 | **Every flag carries its evidence** — one `"<flag> <- <why>"` line per flag in `units[].evidence` | `jq '.units[].evidence'` |
| 3 | `unit_id` assigned in **stable sorted-address order** (`u-0001`, `u-0002`, …) and **never renumbered** on a re-run over a superset — a new address appends | re-run and diff — existing ids unchanged |
| 4 | `equiv_group` set when two units are the same logical target (`/v1/x` and `/v2/x`, or trailing-slash variants) | `jq '[.units[]\|select(.equiv_group)]'` |
| 5 | Scope-excluded assets are **skipped with a printed reason**, never silently | read stdout |

`--explain` prints the **full mapping table** (bucket → flag → why) so a human can audit a flag
without reading source. Keep that output with the run; it is the provenance of every claim the
catalogue will later make about applicability.

### The vocabulary: 18 agent flags vs 7 derived flags

**The 18 flags an agent (or `surface_build.py`) MAY set** — from
`contracts/surface.v2.schema.json`, `units[].flags` enum:

| Group | Flags |
|---|---|
| Object / access shape | `object_by_id` · `id_keyed_unauth` · `role_verb_gated` · `auth_surface` |
| Data handling | `json_body` · `stored_field` · `local_store` · `input_sink` |
| Server-side reach | `server_fetched_url` · `consumes_upstream` · `inbound_webhook` |
| Logic / flow | `sensitive_flow` · `workflow` · `deser_or_ci` |
| Code / client | `static_js_or_repo` · `crypto_use` · `exported_component` · `webview` |

**The 7 flags an agent MAY NOT set** — computed by `cells_build.py` from the unit's shape:

| Derived flag | Computed from |
|---|---|
| `http_listener` | a listener exists on the unit's host:port over HTTP |
| `tls_listener` | the same, over TLS |
| `version_fingerprinted` | `classification.version` is actually observed, not guessed |
| `has_api` | a unit of type `endpoint` or `service` is present |
| `is_apex` | `scope.json` marks the asset apex (the `:apex` suffix) |
| `serves_js` | a `page` unit or a `.js` address is present |
| `mobile_app` | the asset is a mobile bundle, enumerated from `recon/inventory/mobile-surface.json` |

### Why an agent may not set a derived flag

`cells_build.py` **filters out any derived flag written into `units[].flags` and warns.** This is
not style. The set of applicable classes is **code-produced and un-fabricatable — an agent cannot
shrink it.** If a derived flag were agent-settable, a coordinator under time pressure could clear
`http_listener` or `has_api` and make whole class families silently inapplicable, and the coverage
gate would report "complete" over untested surface. The derived flags are the integrity property
of the whole pipeline: **shape decides applicability, not the agent's opinion of the target.**
An agent may only *close* cells with evidence, never remove them.

## 2. cells.json — the code-produced applicable set

```bash
python3 tools/cells_build.py \
    --asset-dir "$RUN/assets/api.acme.com" \
    --catalog   catalog/bounty-coverage-matrix.json
# -> $RUN/assets/api.acme.com/applicability/cells.json
```

One cell per matching scope key, per class whose `applies_when` predicate is true against the unit
/ listener / asset flag sets:

| `scope` | Cells produced |
|---|---|
| `unit` | one per matching surface unit |
| `host` | one per distinct listener (`host:port`) |
| `asset` | one per asset |

The catalogue is the 39-class matrix. Its class ids and predicates are the authority — read them,
never restate them:

- Human-readable: `vendor/upstream-skills/coordination/reference/coverage-matrix.md`
- Machine-readable source of truth: `vendor/upstream-skills/coordination/reference/coverage-matrix.json`
  (39 classes). Pristine upstream original: `vendor/upstream-skills/coordination/reference/coverage-matrix.{md,json}`
- Class playbooks for executors: whatever `slice.class_playbooks` resolved (see §3).

**If `catalog/bounty-coverage-matrix.json` is missing, stop** — `cells_build.py` cannot run and no
downstream artifact is trustworthy. Copy `vendor/upstream-skills/coordination/reference/coverage-matrix.json`
to `catalog/bounty-coverage-matrix.json`; do not hand-write a substitute and do not skip the stage.

## 3. slice.json — one self-contained work order per asset

```bash
python3 tools/slice_build.py --run-dir "$RUN" --scope "$RUN/scope.json"
# -> $RUN/slices/<asset_tag>.json   (one per asset)
```

| Field | Contract |
|---|---|
| `slice_id` | `s-<asset_tag-slug>` |
| `output_dir` | **ABSOLUTE** path to `<run>/assets/<asset_tag>/` — the coordinator's write boundary, nothing outside it |
| `scope_ref` | absolute path to `scope.json` for the in-scope re-check |
| `surface_flags` | mirrored from `surface.json` for convenience; **`surface.json` remains authoritative** |
| `applicable_cells[]` | code-generated. The coordinator **MAY NOT shrink this list** — it may only close cells with evidence |
| `cell_count` | `len(applicable_cells)` |
| `leads[]` | this asset's queued leads, highest priority first |
| `class_playbooks` | `class_id → [concrete reference-file paths]`. Resolved here so executors get **exact paths, never a whole `SKILL.md`** |
| `creds_env` / `roe` | copied from scope; the executor's operating limits |
| `gate` | `complete` · `applicable` · `covered` · `ratio`. `complete=false` may be worked but cannot be reported complete |

## 4. The coverage gate (run it at the boundary)

```bash
python3 tools/coverage_gate.py --asset-dir "$RUN/assets/api.acme.com"
python3 tools/coverage_gate.py --run-dir   "$RUN"
python3 tools/coverage_gate.py --run-dir   "$RUN" --mode strict
# exit 0 = complete, 1 = incomplete (per-cell detail on stdout), 2 = inputs unreadable
```

Joins the code-produced `applicability/cells.json` against the on-disk evidence in `coverage.json`
and the `artifacts/validated|false-positives|dropped/` trees. Writes
`<asset-dir|run-dir>/reports/coverage-matrix.json` on **every** run, pass or fail.

**Two completion modes — and the default is deliberately not 100%.**

| mode | complete when |
|---|---|
| `bounty` **(default)** | something was actually worked, no claim exceeds its evidence, no finding sits in the tree without a verdict, and every **`P1`** lead reached a terminal status. The coverage ratio and the untouched backlog are **reported in full** but do not gate. |
| `strict` | the upstream contract: `covered == applicable`; untouched cells block. Use for contracted work or when you deliberately want the full matrix. |

Upstream gates a contracted pentest at a hard 100% of applicable cells. A bug bounty is not that
engagement: the rational stopping rule is "the highest-value leads are worked", not "every endpoint
probed for all 24 web classes". A gate that can never pass is a gate the operator learns to ignore.
**Use `bounty` for a normal run; reach for `strict` when breadth is the deliverable.**

Rules that hold in **both** modes — this is the part that cannot be relaxed:

- The applicable set is **code-produced** by `cells_build.py` from code-owned inputs. An agent
  **cannot shrink it**, and `--mode` changes only the stopping rule, **never the numbers**.
- A cell marked `na` whose predicate the catalogue evaluates **true** is a **hard fabrication FAIL**,
  not a judgement call.
- Every cell claiming `covered` or `covered_negative` must cite evidence that **exists on disk**.
- A cell claiming `covered` must be backed by a real **`CONFIRMED` verdict** in
  `artifacts/validated/`. A `covered_negative` must carry the corroborator its class's
  `negative_kind` requires — a tool-log reference for `active_probe`, N distinct verified vantage
  regions for `reachability`.
- A ledger row for a cell that is **not applicable** is a dangling row and **fails** the gate.
- A finding directory with **no verdict artifact fails** the gate. Testing is not finished when the
  tester stops; it is finished when the finding has a verdict.

A cell never entered in the ledger counts as **untouched**, not as pending: on a fresh asset the
ledger is empty, and reporting "0 untouched" against 49 applicable cells would tell the operator
the opposite of the truth. `--run-dir` additionally cross-checks every `P1` lead in `queue.json`
so a whole asset cannot be quietly skipped.

## 5. Done when

- [ ] `surface.json` validates as `surface/v2`; no derived flag appears in any `units[].flags`.
- [ ] Every flag has a matching `"<flag> <- <why>"` line in the same unit's `evidence`.
- [ ] `cells.json` exists for every asset and matches the catalogue count for its flag set.
- [ ] `slices/<asset_tag>.json` validates against `contracts/slice.schema.json`, with `output_dir` absolute.
- [ ] Every `class_id` in `applicable_cells` has a non-empty `class_playbooks` entry.
- [ ] `coverage_gate.py` runs and its report is on disk (exit 1 is expected before work starts —
      on a fresh asset the ledger is empty and every cell is `untouched`).
- [ ] `queue_build.py` re-run (bbh-surface §2) so coverage-cell leads are in `queue.json`.

## Reference (do not duplicate)

- Contracts: `contracts/surface.v2.schema.json`, `contracts/slice.schema.json`.
- CLI: `tools/README.md` § Stage 3 and § Stage 3 gate (mode semantics, both-modes rules).
- 39-class catalogue: see §2 for the vendor paths.
