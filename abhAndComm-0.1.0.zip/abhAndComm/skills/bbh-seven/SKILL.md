---
name: bbh-seven
description: The ABH 7-Question Gate — run on every CONFIRMED finding after the chain stage to decide whether it is worth submitting to THIS program. All seven questions with their kill conditions, the never-submit list, the conditionally-valid-with-chain table, and the rule that a failed question returns to the cure loop named rather than dying silently. Use before writing any report.
whenToUse: After bbh-validate returns CONFIRMED and after bbh-chain has had its pass. Never before — validation asks "is this real?", these questions ask "is this worth submitting here?".
---

# bbh-seven — Stage 8, the 7-Question Gate

**Input:** `CONFIRMED` findings + their chains; `scope.json` (Q3, and Q2's accepted-impact list).
**Output:** `<slice>/seven-questions/F-<NNN>.json` (`bbh/7q/v1`, `contracts/seven-questions.schema.json`).
**Then:** `PASS` → `bbh-repro`. `CURE` → cure loop, then re-run **all seven**. `KILL` → recorded, never silent.

> ## One wrong answer stops the finding — but **stops** means *routes*, not *deletes*
>
> Validation asks **"is this real?"**. The 7 questions ask **"is this worth submitting to THIS
> program?"** They are different gates and both must be passed.
>
> A failed question **returns to the cure loop with the failing question named**, exactly like a
> failed check in Stage 6 — `verdict: "CURE"`, `killed_by: "q6_impact_proven"`. `KILL` is reserved
> for questions a cure cannot fix (out of scope, documented behaviour, an admin precondition, a
> never-submit class with no chain), and even then the record is written with its reason. **Nothing
> is ever dropped quietly.**

> **Orchestrated path:** `workflows/bbh-hunt.js` runs this stage as part of the full pipeline
> and stops at the checkpoints. This skill is the manual path and the reference for what the
> stage does; both write the same artifacts. See `/bbh` § "Two ways to drive this".

## The 7 questions

Answer **in order**. One failure stops the pass.

### Q1 — Can an attacker use this RIGHT NOW, step by step? (`q1_demonstrable_right_now`)

Write all five lines. The schema requires them as separate fields:

```
1. Setup:   I need [own account / another user's ID / no account]
2. Request: [exact method, URL, headers, body — copy-paste ready]
3. Result:  I can [read / modify / delete] [exact data shown]
4. Impact:  the real-world consequence is [ATO / PII read / money stolen]
5. Cost:    Time: [X min], Capital: [$0 / $X]
```
**KILL/CURE if you cannot write line 2 as a real HTTP request** — e.g. it reads
"I need to look at the code more". That is a cure (go get the request) or a kill (there is no bug).

### Q2 — Is the impact on the program's accepted list? (`q2_impact_accepted`)
Read the program page's "Vulnerability Types" and "Out of Scope". If your bug maps to a listed
exclusion → **KILL**. If it maps to nothing listed, and the program is silent → `CURE` (get
clarification) or downgrade.

### Q3 — Is the root cause in an in-scope asset? (`q3_asset_in_scope`)
Exact host in scope, production, not third-party. Re-check mechanically:
```bash
python3 tools/bbh_scope.py check --scope runs/<eng>/scope.json --url <finding-url>
# exit 0 = in scope | 1 = out of scope (KILL) | 2 = unclear (STOP, not a judgement call)
```
Staging/dev and third-party services are **KILL**, however good the bug.

### Q4 — Does it need privileged access an attacker can't get? (`q4_no_privileged_access_needed`)
- "Admin can do X" → **KILL** (on ~99% of programs).
- "A regular user can do X that only an admin should" → **PASS**.
- Requires physical access / an MFA device → usually KILL.
- Requires a compromised victim account → questionable, low severity at best.

### Q5 — Is this already known or accepted behaviour? (`q5_not_known_behavior`)
Search disclosed reports (endpoint + class), GitHub issues, the changelog, and the API/design docs.
**Acknowledged or documented-as-intended → KILL.**

### Q6 — Can you prove impact beyond "technically possible"? (`q6_impact_proven`)
| Class | Proves it | Does **not** prove it |
|---|---|---|
| XSS | actual cookie/session exfil, or a real state change | `alert(1)` / `alert(document.domain)` |
| SSRF | an internal service body | a DNS callback |
| SQLi | rows from a real table | an error message |
| IDOR | the other user's private data | a 200 status code |

If you can only show "technically possible" → **DOWNGRADE**, do not kill. Set `downgrade_to`.
A downgrade is `CURE`: fix the severity and the CVSS vector, then re-run all seven.

### Q7 — Is this a known-invalid bug class? (`q7_not_never_submit`)
Check the never-submit list below. On it **without a confirmed chain → KILL**. With a confirmed
chain → PASS, and you **must** populate `q7.chain_used` with the chain that makes it valid.
A `chain_used` naming an unconfirmed or unvalidated link fails the pass.

## Never-submit list

Submitting these destroys your validity ratio.

```
Missing CSP / HSTS / security headers        Missing SPF / DKIM / DMARC
GraphQL introspection alone (no auth bypass, no IDOR demonstrated)
Banner / version disclosure without a working CVE exploit
Clickjacking on non-sensitive pages (no sensitive-action PoC)
Tabnabbing                                    CSV injection (no code execution shown)
CORS wildcard (*) without credential-exfil PoC
Logout CSRF                                   Self-XSS (only exploits your own account)
Open redirect alone (no ATO / OAuth-theft chain)
OAuth client_secret in a mobile app (known, expected)
SSRF DNS callback only (no internal service access or data)
Host header injection alone (no password-reset poisoning PoC)
Rate limit on non-critical forms (search, contact, login behind Cloudflare)
Session not invalidated on logout            Concurrent sessions
Internal IP in an error message              Mixed content
SSL weak ciphers                             Missing HttpOnly / Secure flags alone
Broken external links                        Autocomplete on password fields
Pre-account-takeover (usually — very specific conditions required)
```

## Conditionally valid — the chain is required

Build the chain first, prove it end to end, **then** report.

| Standalone finding | Chain required | Valid result |
|---|---|---|
| Open redirect | + OAuth `redirect_uri` → auth code theft | ATO (Critical) |
| Clickjacking | + sensitive action + working PoC | Medium |
| CORS wildcard | + credentialed request exfils user PII | High |
| CSRF | + sensitive action (transfer funds, change email, delete account) | High |
| Rate limit bypass | + OTP/reset-token brute force succeeds | Medium/High |
| SSRF DNS-only | + internal service access + data returned | Medium |
| Host header injection | + password reset email uses the injected host | High |
| Prompt injection | + reads another user's data (IDOR) | High |
| S3 bucket listing | + JS bundles contain API keys or OAuth secrets | Medium/High |
| Self-XSS | + CSRF triggers it on the victim unknowingly | Medium |
| Subdomain takeover | + OAuth `redirect_uri` registered at that subdomain | Critical |
| GraphQL introspection | + auth bypass mutation, or IDOR on `node()` | High |

## The four pre-submission gates (run after all seven pass)

| Gate | Question | Blocking check |
|---|---|---|
| 0 — Reality (30 s) | Real, in scope, reproducible from scratch, evidence in hand? | confirmed with real HTTP requests, not code reading |
| 1 — Impact (2 min) | What does the attacker walk away with? Is there a real victim? | more than "sees non-sensitive data"; no unlikely preconditions |
| 2 — Dedup (5 min) | Hacktivity + GitHub issues + 5 most recent disclosed reports + changelog | not a known issue |
| 3 — Report quality (10 min) | Title `[Class] in [Endpoint] allows [actor] to [impact]`; copy-pasteable request; CVSS computed; 1–2 sentence fix | **never** "could potentially" / "may allow" |

## Writing the result

```json
{
  "schema": "bbh/7q/v1",
  "finding_id": "F-001",
  "asset_tag": "api.acme.com",
  "cycle": 1,
  "answers": {
    "q1_demonstrable_right_now": {
      "pass": true,
      "setup": "own account user_a plus victim id 4711",
      "request": "GET /v2/users/4711 HTTP/1.1 ... Authorization: Bearer <user_a>",
      "result": "reads victim's email, phone, billing address",
      "impact": "cross-tenant PII disclosure for any user id",
      "cost": "Time: 5 minutes, Capital: $0"
    },
    "q2_impact_accepted":        { "pass": true, "detail": "PII disclosure is on the accepted list" },
    "q3_asset_in_scope":         { "pass": true, "detail": "bbh_scope.py check exit 0 on api.acme.com" },
    "q4_no_privileged_access_needed": { "pass": true, "detail": "a plain authenticated user suffices" },
    "q5_not_known_behavior":     { "pass": true, "detail": "no disclosed report, not in changelog or API docs" },
    "q6_impact_proven":          { "pass": true, "detail": "victim's real PII in the response body" },
    "q7_not_never_submit":       { "pass": true, "detail": "not on the list", "chain_used": null }
  },
  "verdict": "PASS",
  "killed_by": null,
  "kill_reason": null,
  "downgrade_to": null
}
```

## Done when

- [ ] Every `CONFIRMED` finding has a `seven-questions/F-<NNN>.json`.
- [ ] **All seven** questions are answered — no blanks. A blank is a failure, not a maybe.
- [ ] Q1 carries all five lines as separate fields.
- [ ] Every `verdict: "CURE"` names `killed_by` and a concrete `kill_reason`, and was routed to the
      cure loop.
- [ ] Every `verdict: "KILL"` records the question and the reason — no silent drops.
- [ ] Every Q7 pass on a never-submit class has a non-null `chain_used` pointing at validated findings.
- [ ] `downgrade_to` is set wherever Q6 passed only at a lower severity, and the CVSS vector was
      updated to match via `tools/cvss_recompute.py`.
- [ ] The four pre-submission gates were run after the seven passed.
- [ ] `cycle` reflects the number of the pass (`1` first, `2` after one cure round).

## Reference (do not duplicate)

- Contract: `contracts/seven-questions.schema.json`.
- Full upstream gate incl. the common-N/A kill-signal table and the CVSS 3.1 quick reference:
  `vendor/upstream-skills/triage-validation/SKILL.md` (vendored ABH skill).
- Upstream `/validate` four-gate checklist: `vendor/upstream-commands/abh/validate.md` (not vendored).
