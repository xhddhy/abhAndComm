---
name: bbh-recon
description: Recon-LITE over assets the program already told you about — classifies a known-asset recon tree into runs/<engagement>/classification.json (bbh/classification/v1) across the five buckets (api_endpoints/auth_paths, interesting_params, js_secrets/admin_paths) plus optional cloud/takeover/ports. Does NO subdomain enumeration and runs NO nuclei. Use to populate the recon tree from scope.json, then to bucket it.
whenToUse: Immediately after bbh-scope, and whenever scope.json gains new assets. Also use to re-classify after adding crawl data without redoing the whole pipeline.
---

# bbh-recon — Stage 1, known assets only

> ## ⛔ THIS STAGE DOES NOT DISCOVER NEW ASSETS
>
> **No subdomain enumeration. No `subfinder` / `amass` / `crt.sh` / Chaos. No `nuclei`.**
> No directory brute-force to find new *hosts*.
>
> The asset list comes from `scope.json` — from the program — and from nowhere else. If a host
> shows up during crawling that is not in `scope.json`, you **do not add it**; you record it and
> `bbh_scope.py check` decides (exit 1 = drop, exit 2 = unclear = stop). This is deliberate: the
> bundle classifies assets the program already told you about. There is no `--with-subdomains`
> escape hatch in `tools/README.md`, and adding discovery back is a separate, explicitly-scoped
> project — not a flag.

**Input:** `runs/<engagement>/scope.json` + a recon tree (`recon/<target>/`).
**Output:** `runs/<engagement>/classification.json` (`bbh/classification/v1`).
**Tool:** `tools/bbh_classify.py` — it **does not scan**. It reads files and buckets them.

> The classifier ignores unknown files rather than erroring: a partially-populated recon tree is
> valid. Populate the buckets you can; an empty bucket is a coverage fact, not a failure.

> **Orchestrated path:** `workflows/bbh-hunt.js` runs this stage as part of the full pipeline
> and stops at the checkpoints. This skill is the manual path and the reference for what the
> stage does; both write the same artifacts. See `/bbh` § "Two ways to drive this".

## 1. Build the asset list from scope — never from DNS

```bash
ENG=acme-2026-09; RUN=runs/$ENG; TGT=acme.com
RECON=recon/$TGT            # canonical tree location (frozen example uses this path)
mkdir -p $RECON/{live,urls,candidates,params,js,admin}

python3 - <<'PY' > /tmp/targets.txt
import json
s = json.load(open("runs/acme-2026-09/scope.json"))
print("\n".join(a["value"] for a in s["assets"] if a["kind"] in ("web","api","wildcard")))
PY
# scope.json IS the host list. Do not run subfinder over it.
```

Every URL harvested below is scope-filtered **before** it enters the tree:

```bash
SCOPE=$RUN/scope.json
while read -r u; do
  python3 tools/bbh_scope.py check --scope "$SCOPE" --url "$u" >/dev/null 2>&1 || continue
  echo "$u"
done < /tmp/all-urls-raw.txt > $RECON/urls/all.txt
```

## 2. Populate the tree (crawl known hosts only)

| Tree file the classifier reads | Produced by | Bucket it feeds |
|---|---|---|
| `live/urls.txt` | `httpx` over the scope host list | (asset metadata) |
| `urls/all.txt` | `katana` + `waybackurls` + `gau`, scope-filtered | source for all greps |
| `candidates/{xss,ssrf,idor,sqli,redirect,lfi}.txt` | `gf <pattern>` over `urls/all.txt` | `interesting_params` |
| `api-endpoints.txt` | grep for `/api/`, `/v1/`, `/graphql`, `/rest/` | `api_endpoints` |
| `params/*.txt` | `arjun` / `x8` per high-value endpoint | `interesting_params` |
| `js/endpoints.txt` | LinkFinder | `api_endpoints` |
| `js/secrets.txt` | SecretFinder | `js_secrets` |
| `config-exposure.txt` | `.git/`, `.env`, `swagger.json`, `.DS_Store` probes | `admin_paths` / `js_secrets` |
| `admin/*.txt` | grep `admin\|internal\|debug\|management\|console` + `ffuf` | `admin_paths` |
| `ports/*.txt` | `nmap` — **only for `ip`/`cidr` assets** | optional `ports` |

```bash
# live hosts: resolve the scope list, do NOT enumerate
cat /tmp/targets.txt | httpx -silent -tech-detect -status-code -title -o $RECON/live/urls.txt

# crawl + history, scoped
cat $RECON/live/urls.txt | awk '{print $1}' | katana -d 3 -jc -kf all -silent | anew /tmp/all-urls-raw.txt
echo $TGT | waybackurls | anew /tmp/all-urls-raw.txt
gau $TGT --subs | anew /tmp/all-urls-raw.txt      # scope-filter the output (see §1)

# gf classification -> candidates/
for p in xss ssrf idor sqli redirect lfi; do
  cat $RECON/urls/all.txt | gf $p > $RECON/candidates/$p.txt
done

# api endpoints (E2a)
cat $RECON/urls/all.txt | grep -E "/api/|/v1/|/v2/|/v3/|/graphql|/rest/|/gql" | anew $RECON/api-endpoints.txt

# auth paths (E2b)
cat $RECON/urls/all.txt | grep -E "/oauth|/login|/auth|/sso|/saml|/oidc|/callback|/token" | anew $RECON/admin/auth.txt

# admin / debug paths (E4b)
cat $RECON/urls/all.txt | grep -E "/admin|/internal|/debug|/test|/management|/console" | anew $RECON/admin/paths.txt

# params (E3) — arjun against high-value endpoints, one file per endpoint
arjun -u https://api.$TGT/v2/users -m GET > $RECON/params/api-users.txt
```

`ffuf` and LinkFinder/SecretFinder invocations are the upstream ones — the full pipeline reference
is `vendor/upstream-skills/web2-recon/SKILL.md` (ABH skill; not vendored). **Do not copy it here**,
and skip its subdomain-enumeration and nuclei steps when you use it.

**Rate discipline:** honour `roe.rate_limit_rps` from `scope.json` (default 5). If
`safe_harbor: false`, halve it and serialise.

## 3. The five buckets (+ three optional)

`bbh_classify.py` emits `bbh/classification/v1`; bucket names are frozen by the schema.

| Bucket | Required key | Populated from | Feeds class families |
|---|---|---|---|
| `api_endpoints` (E2a) | `url` (+`method`,`evidence`,`source`) | crawl grep, LinkFinder | BOLA/BOPLA, injection, GraphQL, mass-assignment |
| `auth_paths` (E2b) | `url` (+`kind` enum) | auth grep, login/SSO/OIDC/SAML flows | broken auth, OAuth/OIDC, session, MFA |
| `interesting_params` (E3) | `url`, `params[]` | `gf` candidates, `arjun`, `x8` | XSS, SSRF, SQLi, open redirect, LFI |
| `js_secrets` (E4a) | `url`, `kind` enum | SecretFinder, JS grep | secret exposure, consumption, integrity |
| `admin_paths` (E4b) | `url` | admin grep, `ffuf`, config exposure | BFLA, misconfig, verbose errors |
| `cloud` *(optional)* | `provider`, `identifier` | bucket listings, origin-IP discovery | cloud misconfig |
| `takeover` *(optional)* | `host`, `cname` | `dig +short <host> CNAME` | subdomain origin/ takeover |
| `ports` *(optional)* | `port` | `nmap` — **IP/CIDR assets only** | host-scope coverage cells |

Hard rules from the schema:

- **Every entry cites its provenance** (`evidence` / `source`), e.g. `source: "gf:idor"`.
- **`js_secrets.value_redacted` is first-4 + last-4 chars only.** Never write a live secret to disk.
- `auth_paths[].kind` must be one of the schema enum; use `unknown` rather than guessing.
- `takeover[]` is **recorded, never claimed** without written authorization.
- `ports[]` only for assets the program exposes as `ip`/`cidr`.

## 4. Classify and verify

```bash
python3 tools/bbh_classify.py \
    --recon-dir "$RECON" \
    --scope "$RUN/scope.json" \
    --out "$RUN/classification.json"

python3 tools/schema_check.py --kind classification "$RUN/classification.json"
# `--kind <k>` resolves to contracts/<k>.schema.json; `--kind all --run-dir <run>` also works.
```

Success prints a single `OK:` line. Exit codes: `0` success, `1` a real negative result,
`2` bad input/unreadable. A non-empty `negative_findings[]` is a **result**, not an error — it is
what lets the queue distinguish "not looked at" from "looked at, empty".

## 5. Done when

- [ ] `classification.json` validates against `contracts/classification.schema.json`.
- [ ] Every asset in `scope.json` appears in `assets[]` **or** in `negative_findings[]`.
- [ ] Every bucket entry carries `evidence`/`source`; no uncited entry.
- [ ] No secret is stored unredacted.
- [ ] The recon tree contains **no** file produced by subdomain enumeration or nuclei.
- [ ] Anything discovered but not in `scope.json` was checked with `bbh_scope.py check` and dropped
      or escalated as unclear — it was never appended to `assets[]`.

## Reference (do not duplicate)

- Bucket semantics: `contracts/classification.schema.json`.
- CLI: `tools/README.md` § Stage 1.
- Full crawl/JS/fuzz recipes: `vendor/upstream-skills/web2-recon/SKILL.md` (ABH skill; not vendored).
  Skip its subdomain-enumeration and nuclei sections — they are out of scope here.
