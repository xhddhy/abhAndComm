---
name: bbh-execute
description: The executor role — ABH's /hunt equivalent inside a bbh slice. Covers the per-asset batch cadence (think 3 hypotheses, spawn 1-2 executors, integrate, validate), the attack-chain.md/session-memory.md/experiments.md three-file contract, the executor's escalation ladder, and the rule that an executor files a CANDIDATE finding and never a verdict. Use when running or coordinating hunt batches inside one asset slice.
whenToUse: Once a slice exists and a coordinator is working it. Load before spawning executors and before writing any finding.json.
---

# bbh-execute — the executor role

**Input:** one slice, `runs/<engagement>/slices/<asset_tag>.json`, and the files under its
absolute `output_dir`.
**Output:** candidate findings at `<slice>/findings/finding-<NNN>/`, updated
`<slice>/experiments.md`, `<slice>/attack-chain.md`, `<slice>/session-memory.md`.
**Contract:** `contracts/finding.schema.json` (`bbh/finding/v1`).

> ## The executor writes a **candidate**, never a verdict
>
> `<slice>/findings/finding-001/finding.json` is a **CLAIM**. It becomes real only when
> `bbh-validate` returns `CONFIRMED`. The executor **may not write** to
> `<slice>/artifacts/validated/`, `.../false-positives/`, or `.../dropped/` — those belong to the
> blind validator alone. Writing your own verdict is the single fastest way to make the whole
> pipeline dishonest, and it is also self-defeating: the validator is blind to your theory and
> will re-run the PoC from scratch.

> **Orchestrated path:** `workflows/bbh-hunt.js` runs this stage as part of the full pipeline
> and stops at the checkpoints. This skill is the manual path and the reference for what the
> stage does; both write the same artifacts. See `/bbh` § "Two ways to drive this".

## 1. The batch cadence

```
THINK  → write 3 hypotheses (>=1 [wildcard]) into attack-chain.md; pick 1-2
EXECUTE→ spawn 1-2 executors, each with an EXPERIMENT_ID and a claimed lead
INTEGRATE → materialize each candidate as finding-NNN/ ; update chain + memory
VALIDATE  → hand it to bbh-validate (blind, fresh, interleaved) — NOT at the end
LOOP   → max 30 experiments; batch review at experiments 5, 15, 25
```

**1–2 executors per batch.** Not three, not five. Recon may use more; exploitation may not. A
batch is not finished until every candidate it produced has been integrated **and** sent to
validation — do not stack batches and validate at the end. Interleaved validation is what keeps
coverage honest (`coverage-by-VALID`: a class flips to covered only on a `VALID` finding, a
justified N/A, or a genuine negative — a rejected candidate leaves the cell `pending`).

```bash
# Claim the lead BEFORE the batch — this is the audit link
python3 tools/lead_board.py --run-dir runs/acme-2026-09 touch \
    --lead "$LEAD_ID" --status investigating --experiment E-004
```

**Stop conditions.** 30 experiments, or three consecutive `[wildcard]` hypotheses with no new
observation, or two batches with no progress → escalate to the coordinator rather than widening
the batch. Do not fix "nothing found" by spawning more agents.

## 2. The three-file contract

Three files, three different jobs. Mixing them is why hunts lose their history.

| File | Nature | Cap | Written by |
|---|---|---|---|
| `attack-chain.md` | **Current theory.** Living; pruned every batch | **50 lines** | Coordinator |
| `experiments.md` | **Append-only ledger.** Never rewritten, never pruned | unbounded | Executors append; coordinator owns rows |
| `session-memory.md` | **Durable facts.** Survives theory churn | ~80 lines | Whoever learns the fact |

### `attack-chain.md`

```markdown
## Services
- <port> <service> <version>

## Surface
- <endpoint or interface> — <observation>

## Theory (this batch)
1. <hypothesis A> — <reasoning>
2. <hypothesis B> — <reasoning>
3. [wildcard] <hypothesis C> — <reasoning>
Chosen: <which one and why>

## Tested (cumulative, terse)
- <experiment id> <technique> → <result one-liner>

## Next
- <single concrete next step>
```

Three hypotheses **every** batch. Record the two you did not pick — they are the backlog, and a
hypothesis that is never written down cannot be revisited. Prune resolved `Tested` items to
one-liners; the 50-line cap is what keeps the file readable at batch 20.

### `experiments.md`

```markdown
| ID | Batch | Goal | Technique | Target | Hypothesis | Result | Goal_attempts | Notes |
|----|-------|------|-----------|--------|------------|--------|---------------|-------|
```

- `ID` — `E-NNN`, monotonically increasing.
- `Goal` — the **conceptual** goal, not the technique. Three different techniques chasing "auth as
  the reporting service" are **one** goal and three strikes against it.
- `Result` — `success` / `partial` / `fail` / `pending`.
- `Goal_attempts` — running count of `fail` rows **for this goal**. `>= 3` on any goal → escalate;
  the approach is stuck, not the technique.
- **Dedup rule:** skip a row only if *Goal, Technique, Target and the meaningful parameters* all
  match a prior row. Different technique → new row, even for the same goal.
- Append **before terminating — even on failure.** A negative that is not in the ledger is
  indistinguishable from work that never happened, and the coverage gate will keep the cell open.

### `session-memory.md`

The facts that are not theory and not an experiment — the things a fresh batch must know on line 1:

```markdown
## Identities
- user_a: env ACME_USER_A — low-priv, tenant T1
- user_b: env ACME_USER_B — low-priv, tenant T2 (the victim side)

## Confirmed live
- https://api.acme.com/v2/users/{id} — 200 with valid bearer; 401 without
- https://api.acme.com/graphql — introspection ON (2026-09-10)

## Dead ends (do not re-test without a new signal)
- /admin/* — WAF 403 for all encodings (E-002..E-006)
- legacy /v1 — 410 Gone since 2026-08

## Quirks
- numeric ids must be same-tenant or the API 404s *before* the auth check
```

Never write a secret value here — env-var **names** only, matching `scope.creds_env`. Never write
a theory here either; if it is a hypothesis it belongs in `attack-chain.md`, and if it was tested it
belongs in `experiments.md`.

## 3. The executor's escalation ladder

Escalate **fully** before reporting a negative. A failure at step 1 is not a negative result.

1. **Quickstart payloads** — the basic technique attempt.
2. **Encoding variants** — URL, double-URL, unicode, hex, base64 wrapping.
3. **Filter bypass** — case toggling, comment nesting, alternate keywords, whitespace alternatives.
4. **Cheat-sheet payloads** — the full technique catalogue from the class playbook.
5. **PATT** — the payload library the slice handed you.

Then: **reproduce 3× with the working payload**, capture the PoC, capture the evidence.

## 4. Filing a candidate finding

Write `<slice>/findings/finding-001/`:

```
finding-001/
├── finding.json          # bbh/finding/v1
├── poc/exploit.py        # runnable; finding.poc.script names it
└── evidence/
    ├── raw-response.txt  # verbatim
    └── screenshot.png    # when there is a browser surface
```

Minimum viable `finding.json` (full contract in `contracts/finding.schema.json`):

```json
{
  "schema": "bbh/finding/v1",
  "finding_id": "F-001",
  "experiment_id": "E-004",
  "asset_tag": "api.acme.com",
  "class_id": "API1-BOLA",
  "cell_key": "api.acme.com|u-0007|API1-BOLA",
  "title": "BOLA in GET /v2/users/{id} allows any authenticated user to read another tenant's profile",
  "severity_claim": "high",
  "endpoint": "https://api.acme.com/v2/users/4711",
  "method": "GET",
  "impact": "Attacker reads victim's email, phone and billing address. Real data, real victim.",
  "cvss_vector": "CVSS:3.1/AV:N/AC:L/PR:L/UI:N/S:U/C:H/I:N/A:N",
  "evidence": {
    "request": "GET /v2/users/4711 HTTP/1.1\nHost: api.acme.com\nAuthorization: Bearer <user_a>",
    "response": "{\"id\":4711,\"email\":\"victim@example.com\", ...}",
    "status_code": 200,
    "artifacts": ["evidence/raw-response.txt"],
    "identity": { "actor": "user_a", "victim": "user_b", "anonymous": false }
  },
  "poc": {
    "script": "poc/exploit.py",
    "cmd": "python3 poc/exploit.py",
    "dependencies": ["requests"],
    "expected_output": "victim_user_b_email",
    "negative_control": "prints NO-ACCESS when run with user_a's own id",
    "runs": 3,
    "deterministic": true
  },
  "chain_hints": ["PUT /v2/users/{id} likely shares the same missing check"],
  "status": "candidate"
}
```

Rules that the validator will enforce, so satisfy them at authoring time:

- `class_id` **must be in the slice's `applicable_cells`** — a finding cannot invent a cell.
- `evidence.identity` must populate **both** `actor` and `victim` for IDOR/BOLA/ATO/privesc.
  Blank identity answers fail automatically.
- `poc.expected_output` must name the **decisive token**, and `negative_control` must state what
  the same PoC prints when the bug is absent. A PoC with no negative control is not reproducible.
- `runs >= 3` and `deterministic: true` — the validator re-runs it.
- **CVSS self-check before filing:**
  ```bash
  python3 tools/cvss_recompute.py --vector 'CVSS:3.1/AV:N/AC:L/PR:L/UI:N/S:U/C:H/I:N/A:N' --json
  # compare .score/.band against severity_claim; fix the vector or the claim, then file
  ```
  A vector that disagrees with the claimed band is a validation failure, not a rounding note.
- `impact` names **real data or a real action**. Never "could potentially".

## 5. Reporting a negative

No finding → write `<slice>/logs/mission-<ID>.md`: objective, what was tried (technique → result),
observations, and what would unblock. Append the `experiments.md` row and increment
`Goal_attempts`. "We tested and found nothing" is a **covered negative** and needs a corroborator —
the mission log plus the tool output is that corroborator.

## 6. Done when

- [ ] Every batch has 3 hypotheses in `attack-chain.md`, ≥1 `[wildcard]`, and a recorded choice.
- [ ] Every executor batch was 1–2 executors, each with a claimed lead and an `EXPERIMENT_ID`.
- [ ] Every candidate is filed under `findings/` and has been handed to `bbh-validate`.
- [ ] Every terminated experiment has a row in `experiments.md`, appended even on failure.
- [ ] `session-memory.md` holds identities, confirmed-live endpoints, dead ends, quirks — no secrets.
- [ ] Nothing was written to `artifacts/validated|false-positives|dropped/`.
- [ ] Findings reproduce 3×, have a negative control, and their CVSS vector matches the claim.

## Reference (do not duplicate)

- Finding contract: `contracts/finding.schema.json`.
- Upstream hunt methodology: `vendor/upstream-commands/abh/hunt.md` (ABH command; not vendored).
- Executor role, escalation ladder, log discipline:
  `vendor/upstream-skills/coordination/reference/executor-role.md`.
- Spawn patterns (1–2 per batch, EXPERIMENT_ID injection):
  `vendor/upstream-skills/coordination/reference/spawning-recipes.md`.
- Ledger mechanics: `vendor/upstream-skills/coordination/reference/bookkeeping.md`.
