#!/usr/bin/env bash
# Render the diagrams in this directory to SVG + PNG.
#
# WHY A SCRIPT RATHER THAN HAND-DRAWN IMAGES
# ------------------------------------------
# The .mmd sources are the truth; the images are build output. Keeping them in one place with a
# reproducible renderer means the pictures cannot quietly drift from the pipeline they describe —
# edit the .mmd, re-run this, and the committed images follow. The same mermaid sources are also
# embedded in `pipeline/README.md` and `skills/bbh/SKILL.md`, so a reader can diff prose against
# picture.
#
# mermaid.js is a BUILD dependency, deliberately not vendored: it is ~3.5 MB, it would more than
# double this bundle, and it is only needed when someone re-renders. It is cached under
# `.cache/` (git-ignored) and fetched once. The rendered `.svg`/`.png` ARE committed, so the
# images are available offline.
#
# Usage:  bash docs/diagrams/render.sh [name ...]     # default: every *.mmd here
# Exit:   0 all rendered, 1 a render failed, 2 no chromium / no sources.
set -euo pipefail

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$HERE"

CACHE="$HERE/.cache"
MERMAID="$CACHE/mermaid.min.js"
MERMAID_URL="https://cdn.jsdelivr.net/npm/mermaid@11/dist/mermaid.min.js"

CHROME="$(command -v chromium || command -v chromium-browser || command -v google-chrome || true)"
if [[ -z "$CHROME" ]]; then
  echo "render.sh: no chromium/chrome found — cannot render. Install one, or read the .mmd sources." >&2
  exit 2
fi

if [[ $# -gt 0 ]]; then
  SOURCES=("$@")
else
  shopt -s nullglob
  SOURCES=(*.mmd)
fi
[[ ${#SOURCES[@]} -gt 0 ]] || { echo "render.sh: no .mmd sources" >&2; exit 2; }

# --- fetch mermaid once ------------------------------------------------------
mkdir -p "$CACHE"
if [[ ! -s "$MERMAID" ]]; then
  echo "fetching mermaid.js (one time, cached in .cache/) …"
  if ! curl -sSL --max-time 60 -o "$MERMAID.tmp" "$MERMAID_URL"; then
    echo "render.sh: could not download $MERMAID_URL" >&2
    echo "  The rendered .svg/.png in this directory are committed, so you only need this" >&2
    echo "  step if the diagrams changed." >&2
    rm -f "$MERMAID.tmp"; exit 1
  fi
  mv "$MERMAID.tmp" "$MERMAID"
fi

# --- render ------------------------------------------------------------------
# A generous window; the PNG is trimmed afterwards, so overshooting costs nothing but pixels.
fail=0

for src in "${SOURCES[@]}"; do
  name="$(basename "$src" .mmd)"
  printf '%-16s ' "$name"

  html="$CACHE/$name.html"
  cat > "$html" <<HTML
<!doctype html><html><head><meta charset="utf-8">
<style>
  body { margin:0; padding:24px; background:#ffffff;
         font-family: -apple-system, "Noto Sans CJK SC", "Noto Sans SC", "PingFang SC",
                      "Microsoft YaHei", "Segoe UI", sans-serif; }
  .mermaid { background:#ffffff; }
</style></head>
<body><pre class="mermaid">
$(cat "$src")
</pre>
<script src="mermaid.min.js"></script>
<script>
  mermaid.initialize({
    startOnLoad: true,
    theme: 'base',
    themeVariables: {
      fontFamily: '-apple-system, "Noto Sans CJK SC", "Noto Sans SC", "PingFang SC", "Microsoft YaHei", sans-serif',
      fontSize: '15px',
      lineColor: '#5f6368',
      primaryTextColor: '#202124'
    },
    flowchart: { htmlLabels: true, curve: 'basis', nodeSpacing: 42, rankSpacing: 60, useMaxWidth: false },
    securityLevel: 'loose'
  });
  window.__done = false;
  mermaid.run().then(() => { window.__done = true; });
</script></body></html>
HTML

  # SVG straight out of the DOM — vector, editable, and what the README embeds. This runs FIRST
  # because it also tells us how big the drawing actually is.
  "$CHROME" --headless --no-sandbox --disable-gpu --virtual-time-budget=12000 \
        --window-size=3200,4000 --dump-dom "file://$html" > "$CACHE/$name.dom.html" 2>/dev/null || true
  natural="$(python3 - "$CACHE/$name.dom.html" "$name.svg" <<'PY'
import re, sys
dom = open(sys.argv[1], encoding='utf-8', errors='replace').read()
m = re.search(r'(<svg\b.*?</svg>)', dom, re.S)
if not m:
    print("0 0"); print("no <svg> in DOM", file=sys.stderr); sys.exit(0)
svg = m.group(1)
if not svg.lstrip().startswith('<?xml'):
    svg = '<?xml version="1.0" encoding="UTF-8"?>\n' + svg
open(sys.argv[2], 'w', encoding='utf-8').write(svg)
w = re.search(r'<svg[^>]*\swidth="([0-9.]+)', svg)
h = re.search(r'<svg[^>]*\sheight="([0-9.]+)', svg)
print(f"{w.group(1) if w else 2000} {h.group(1) if h else 1200}")
PY
)"
  read -r NAT_W NAT_H <<<"$natural"
  [[ "$NAT_W" == "0" ]] && { echo "FAIL (no <svg> in DOM — mermaid error?)"; fail=1; continue; }

  # Size the window to the DRAWING, not to a guess. A window narrower than the diagram silently
  # crops the PNG — the SVG still looks fine, so only the raster gives it away, and only if you
  # compare dimensions. Padding covers the body margin in the wrapper HTML.
  PAD=80
  WIN_W="$(python3 -c "import math;print(math.ceil($NAT_W)+$PAD)")"
  WIN_H="$(python3 -c "import math;print(math.ceil($NAT_H)+$PAD)")"

  # SCALE: the SVG is the crisp artifact and scales losslessly; the PNG is a convenience preview.
  # 1 is the honest default for a 4-5k-px-wide drawing (2x would produce a ~10k-px, multi-MB file).
  png="$CACHE/$name.png"
  if ! "$CHROME" --headless --no-sandbox --disable-gpu --hide-scrollbars \
        --force-device-scale-factor="${SCALE:-1}" --window-size="$WIN_W,$WIN_H" \
        --virtual-time-budget=12000 \
        --screenshot="$png" "file://$html" >/dev/null 2>&1; then
    echo "FAIL (chromium screenshot)"; fail=1; continue
  fi

  # Trim the generous window down to the drawing plus a margin. Without this every PNG carries
  # thousands of pixels of white and the diagram looks lost in the frame.
  python3 - "$png" <<'PY'
import sys
from PIL import Image, ImageChops
p = sys.argv[1]
im = Image.open(p).convert('RGB')
bg = Image.new('RGB', im.size, (255, 255, 255))
bbox = ImageChops.difference(im, bg).getbbox()
if bbox:
    m = 40
    box = (max(0, bbox[0]-m), max(0, bbox[1]-m),
           min(im.width, bbox[2]+m), min(im.height, bbox[3]+m))
    im = im.crop(box)
im.save(p)
print(f"{im.width}x{im.height}", end=' ')
PY
  # The trimmed PNG starts life in the cache; the committed artifact belongs next to its .mmd.
  mv -f "$png" "$HERE/$name.png"
  echo "-> $name.svg + $name.png"
done

echo
if [[ "$fail" == "0" ]]; then
  echo "render.sh: ${#SOURCES[@]} diagram(s) rendered into $HERE"
else
  echo "render.sh: at least one diagram failed" >&2
fi
exit "$fail"
