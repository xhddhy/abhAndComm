# docs/diagrams — 流水线图

三张图，一份渲染脚本。`.mmd` 是**真源**，`.svg` / `.png` 是构建产物——改了 `.mmd` 重跑一次，
图就跟着走，不会跟它描述的流水线悄悄脱节。

| 图 | 看什么 | 尺寸 |
|---|---|---|
| `workflow-overview` | **先看这张。** 四个阶段群（看 → 切 → 打 → 交）、三个卡点、cure 回路、覆盖闸。颜色 = 能力来自哪个项目 | 1770×2467 |
| `workflow-detail` | 同上，但**每一跳都标注了落盘的交接产物**——这张解释"阶段之间只通过文件说话" | 4832×890 |
| `runtime` | **一个资产内部到底发生什么**：三个文件的记忆契约、INTEGRATE 是唯一写者、盲验证的硬边界、cure 只拿点名缺口 | 3258×1234 |

## 渲染

```bash
bash docs/diagrams/render.sh                  # 全部
bash docs/diagrams/render.sh runtime.mmd      # 单张
SCALE=2 bash docs/diagrams/render.sh          # 高清（文件会大很多）
```

需要 `chromium`（或 `google-chrome`）、`python3` 带 `PIL`、以及**首次**渲染时的网络
（下载 mermaid.js 到 `.cache/`）。之后离线可渲染。

`mermaid.min.js` 约 3.5 MB，**故意不 vendor**：它会让这个 4.3 MB 的包体积翻倍，而它只在
重新渲染时才需要。渲染好的 `.svg` / `.png` 是提交进仓库的，所以看图不需要任何依赖。

## 两个坑，脚本已经替你踩了

**1. 窗口必须按图的实际尺寸开，不能猜。** 猜小了 chromium 会**静默横向裁掉** PNG——SVG 看起来
完全正常，只有对比尺寸才发现。脚本先用 `--dump-dom` 取出 SVG 的自然宽高，再据此开窗。
本目录第一版就栽在这儿：workflow 图自然宽 4832px，而窗口只给了 2600 CSS px，PNG 少了将近一半。

**2. 别用 `node --check` 之类的方式校验 mermaid。** 也用不着——脚本会检查 DOM 里有没有
mermaid 的真实错误文本节点。（注意：SVG 里**永远**有一个 `error-icon` 的 CSS 类名，那是
mermaid 恒定输出的样式表，`grep error` 会给你假阳性。）

## 想改图

`.mmd` 就是普通 mermaid，直接用编辑器改。两点约定：

- **颜色编码是信息，不是装饰**：蓝 = ABH 的能力，绿 = communitytools 的能力，黄 = 本次新写的
  胶水，紫 = 人工卡点。加节点时给它 `:::abh` / `:::comm` / `:::glue` / `:::hum` / `:::bad` / `:::out`。
- **节点文字用 `<br/>` 断行，控制在 4 行以内**。图宽是被文字撑起来的，多写一行整张图就宽一截。

改完重跑 `render.sh`，把新的 `.svg` + `.png` 一起提交。
