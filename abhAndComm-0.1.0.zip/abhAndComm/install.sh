#!/usr/bin/env bash
#
# bbh bundle — installer for DSH skill roots.
#
# DSH discovers skills on the filesystem, not through npm: a skill is
# <root>/<name>/SKILL.md (or <root>/<name>.md) at the TOP LEVEL of a scanned root.
# Roots, in precedence order:
#
#   100  <projectRoot>/.dsh/skills      (project-dsh)
#   200  <projectRoot>/.agents/skills   (project-agents)
#   300  customSkillDirs (DSH config)   (custom)
#   400  $DSH_HOME/skills               (user-dsh)
#   500  ~/.agents/skills               (user-agents)
#
# So installing = putting a directory bundle (or a symlink to one) into one of those
# roots. This script never edits a DSH config file; if a cordis.patch.yml exists it
# prints the equivalent customSkillDirs snippet for you to paste.
#
# Writes only inside the destination skill root (and, for --force backups, that same
# root). Never uses sudo.

set -euo pipefail

VERSION_FILE_NAME="VERSION"
MARKER_NAME=".bbh-installed"
TS_COMPACT="$(date +%Y%m%d-%H%M%S)"
TS_ISO="$(date -u +%Y-%m-%dT%H:%M:%SZ)"

SELF="${BASH_SOURCE[0]}"
while [ -L "$SELF" ]; do
    _link="$(readlink "$SELF")"
    case "$_link" in
        /*) SELF="$_link" ;;
        *) SELF="$(dirname "$SELF")/$_link" ;;
    esac
done
BUNDLE_ROOT="$(cd -- "$(dirname -- "$SELF")" && pwd -P)"
UNINSTALL_SH="$BUNDLE_ROOT/uninstall.sh"
SKILLS_SRC="$BUNDLE_ROOT/skills"
VENDOR_SRC="$BUNDLE_ROOT/vendor/upstream-skills"

# ---------------------------------------------------------------- output helpers
if [ -t 1 ] && [ -z "${NO_COLOR:-}" ]; then
    C_RESET=$'\033[0m'; C_BOLD=$'\033[1m'; C_DIM=$'\033[2m'
    C_OK=$'\033[32m'; C_WARN=$'\033[33m'; C_ERR=$'\033[31m'; C_INFO=$'\033[36m'
else
    C_RESET=''; C_BOLD=''; C_DIM=''; C_OK=''; C_WARN=''; C_ERR=''; C_INFO=''
fi

info() { printf '%s\n' "$*"; }
ok()   { printf '%s%s%s\n' "$C_OK" "$*" "$C_RESET"; }
warn() { printf '%sWARN:%s %s\n' "$C_WARN" "$C_RESET" "$*" >&2; }
err()  { printf '%sERROR:%s %s\n' "$C_ERR" "$C_RESET" "$*" >&2; }
die()  { err "$*"; exit 2; }
hr()   { printf '%s\n' "------------------------------------------------------------------------"; }

# ---------------------------------------------------------------- usage
usage() {
    cat <<'EOF'
bbh bundle installer — install the bundle's skills into a DSH skill root.

Usage:
  ./install.sh [options]

Options:
  --dest DIR        Explicit skill root (overrides --scope).
  --scope user      Install into $DSH_HOME/skills (default: $DSH_HOME or ~/.dsh).
  --scope project   Install into $PWD/.agents/skills (needs .git for DSH to treat
                    that directory as the project root).
  --with-vendor     Also install vendor/upstream-skills/* (default).
  --no-vendor       Skip vendor skills — use when the target machine already has
                    the two upstream packs installed.
  --copy            Copy instead of symlink. Required when the destination is on
                    another filesystem or the bundle will be deleted/moved later.
  --force           Replace a conflicting destination entry, backing it up first to
                    <name>.bak.<timestamp>.
  --dry-run         Print what would happen; change nothing.
  --uninstall       Run uninstall.sh with the same destination resolution.
  --allow-instruction-files
                    Override the context-guard preflight. By default the installer
                    REFUSES to install when the bundle carries files the harness
                    would load as agent instructions, or hook configs that execute.
                    This flag is loud on purpose and should almost never be used.
  -h, --help        This help.

Workspace instruction injection: DSH loads the AGENTS.md / CLAUDE.md (and
*.local.md) chain found between the project root and the working directory as agent
instructions, so a third-party checkout inside the workspace is an injection vector.
tools/context_guard.py detects those files plus hook configs, shadow skill roots and
broken instruction symlinks; install.sh runs it as a hard preflight.

Precedence reminder (DSH scans top to bottom; the highest-priority root wins):
  100 <project>/.dsh/skills    200 <project>/.agents/skills   300 customSkillDirs
  400 $DSH_HOME/skills         500 ~/.agents/skills

Examples:
  ./install.sh                                   # user scope, symlinks, + vendor
  ./install.sh --scope project                   # into ./.agents/skills
  ./install.sh --dest /opt/skills --copy         # portable copy install
  ./install.sh --no-vendor                       # bundle skills only
  ./install.sh --dry-run
  ./install.sh --uninstall --dest /opt/skills
EOF
}

# ---------------------------------------------------------------- argument parsing
DEST=""
SCOPE="user"
WITH_VENDOR=1
COPY_MODE=0
FORCE=0
DRY_RUN=0
ALLOW_INSTRUCTION_FILES=0

while [ "$#" -gt 0 ]; do
    case "$1" in
        --dest)
            [ "$#" -ge 2 ] || die "--dest requires a value"
            DEST="$2"; shift 2 ;;
        --dest=*)
            DEST="${1#*=}"; shift ;;
        --scope)
            [ "$#" -ge 2 ] || die "--scope requires a value"
            SCOPE="$2"; shift 2 ;;
        --scope=*)
            SCOPE="${1#*=}"; shift ;;
        --with-vendor|--vendor)
            WITH_VENDOR=1; shift ;;
        --no-vendor)
            WITH_VENDOR=0; shift ;;
        --copy)
            COPY_MODE=1; shift ;;
        --force)
            FORCE=1; shift ;;
        --dry-run)
            DRY_RUN=1; shift ;;
        --allow-instruction-files)
            ALLOW_INSTRUCTION_FILES=1; shift ;;
        --uninstall)
            shift
            [ -x "$UNINSTALL_SH" ] || die "--uninstall: $UNINSTALL_SH is missing or not executable"
            exec "$UNINSTALL_SH" "$@" ;;
        -h|--help)
            usage; exit 0 ;;
        *)
            die "unknown option: $1 (try --help)" ;;
    esac
done

case "$SCOPE" in
    user|project) ;;
    *) die "--scope must be 'user' or 'project' (got: $SCOPE)" ;;
esac
if [ -n "$DEST" ] && [ "$SCOPE" != "user" ]; then
    die "--dest and --scope are mutually exclusive; --dest already names the exact root"
fi
# A bare "--scope user" is the default; only an explicit --scope project changes it.
if [ -z "$DEST" ] && [ "$SCOPE" = "project" ]; then
    DEST="$PWD/.agents/skills"
fi

# ---------------------------------------------------------------- DSH home resolution
DSH_HOME_DIR="${DSH_HOME:-$HOME/.dsh}"
if [ -z "$DEST" ]; then
    DEST="$DSH_HOME_DIR/skills"
fi

BBH_VERSION="unknown"
if [ -r "$BUNDLE_ROOT/$VERSION_FILE_NAME" ]; then
    BBH_VERSION="$(head -n 1 "$BUNDLE_ROOT/$VERSION_FILE_NAME" 2>/dev/null | tr -d '\r' || true)"
    [ -n "$BBH_VERSION" ] || BBH_VERSION="unknown"
fi

# ---------------------------------------------------------------- path helpers
normalize_path() { # best-effort canonical absolute path, works for missing paths
    if command -v realpath >/dev/null 2>&1; then
        realpath -m -- "$1" 2>/dev/null && return 0
    fi
    case "$1" in
        /*) printf '%s\n' "$1" ;;
        *)  printf '%s\n' "$PWD/$1" ;;
    esac
}

path_is_inside() { # path root -> 0 when path == root or is under root
    local p="$1" r="$2"
    p="$(normalize_path "$p")"
    r="$(normalize_path "$r")"
    [ "$p" = "$r" ] && return 0
    case "$p" in "$r"/*) return 0 ;; esac
    return 1
}

device_of() { # nearest existing ancestor's device id
    local p="$1"
    while [ ! -e "$p" ] && [ "$p" != "/" ]; do p="$(dirname "$p")"; done
    stat -c %d "$p" 2>/dev/null || echo "?"
}

nearest_existing_dir() {
    local p="$1"
    while [ ! -d "$p" ] && [ "$p" != "/" ]; do p="$(dirname "$p")"; done
    printf '%s\n' "$p"
}

# ---------------------------------------------------------------- output buffers
TABLE_LINES=()
INSTALLED=0
SKIPPED=0
FAILED=0
SKIP_NOTES=()
DESIRED_NAMES=()   # names that ended in the desired state (ours), for the summary

record() { TABLE_LINES+=("$1"); }

# ---------------------------------------------------------------- skill discovery
list_skill_names() { # root -> skill names at its top level (dir bundles + flat files)
    local root="$1" entry base
    [ -d "$root" ] || return 0
    for entry in "$root"/*; do
        [ -e "$entry" ] || [ -L "$entry" ] || continue
        base="$(basename -- "$entry")"
        case "$base" in .*) continue ;; esac   # skips .system / markers / backups
        if [ -d "$entry" ] && [ -f "$entry/SKILL.md" ]; then
            printf '%s\n' "$base"
        elif [ -f "$entry" ] && [ "${base##*.}" = "md" ]; then
            printf '%s\n' "${base%.md}"
        fi
    done
}

skill_source_path() { # root name -> prints path to the bundle dir / flat file
    local root="$1" name="$2"
    if [ -f "$root/$name/SKILL.md" ]; then printf '%s\n' "$root/$name"; return 0; fi
    if [ -f "$root/$name.md" ]; then printf '%s\n' "$root/$name.md"; return 0; fi
    return 1
}

marker_field() { # dir key -> value from .bbh-installed
    local dir="$1" key="$2"
    [ -f "$dir/$MARKER_NAME" ] || return 1
    sed -n "s/^${key}=//p" "$dir/$MARKER_NAME" 2>/dev/null | head -n 1
}

# An entry is "ours" when it is a symlink resolving inside this bundle, or a copied
# directory whose .bbh-installed marker names this bundle. Anything else is foreign
# and is never touched without --force.
is_ours() {
    local target="$1" raw resolved bundle
    if [ -L "$target" ]; then
        raw="$(readlink -- "$target")"
        case "$raw" in
            /*) resolved="$raw" ;;
            *)  resolved="$(dirname -- "$target")/$raw" ;;
        esac
        path_is_inside "$resolved" "$BUNDLE_ROOT"
        return $?
    fi
    if [ -d "$target" ]; then
        bundle="$(marker_field "$target" bundle || true)"
        [ -n "$bundle" ] && [ "$(normalize_path "$bundle")" = "$(normalize_path "$BUNDLE_ROOT")" ]
        return $?
    fi
    return 1
}

frontmatter_problem() { # file -> prints the reason DSH would ignore it; empty = ok
    awk '
        { sub(/\r$/, "") }
        NR == 1 {
            if ($0 !~ /^---[[:space:]]*$/) { reason = "no YAML frontmatter (line 1 must be ---)"; exit }
            inside = 1
            next
        }
        inside && /^---[[:space:]]*$/ { closed = 1; exit }
        inside && /^name:/ {
            has_name = 1
            v = $0
            sub(/^name:[[:space:]]*/, "", v)
            gsub(/^["'"'"']+/, "", v)
            gsub(/["'"'"']+[[:space:]]*$/, "", v)
            gsub(/[[:space:]]+$/, "", v)
            name = v
        }
        inside && /^description:/ { has_desc = 1 }
        END {
            if (reason != "") { print reason; exit }
            if (NR == 0) { print "empty file"; exit }
            if (!has_name) { print "frontmatter has no name: key"; exit }
            if (!has_desc) { print "frontmatter has no description: key"; exit }
            if (name == "") { print "frontmatter name: is empty"; exit }
            if (name !~ /^[a-z0-9]+(-[a-z0-9]+)*$/) {
                print "invalid skill name \"" name "\" (DSH requires ^[a-z0-9]+(-[a-z0-9]+)*$)"
                exit
            }
        }
    ' "$1"
}

# ---------------------------------------------------------------- pre-flight
preflight() {
    local errs=0

    for d in skills contracts tools; do
        if [ ! -d "$BUNDLE_ROOT/$d" ]; then
            err "missing required bundle directory: $BUNDLE_ROOT/$d"
            errs=$((errs + 1))
        fi
    done
    [ "$errs" -eq 0 ] || die "this is not a complete bbh bundle (expected skills/, contracts/, tools/)"

    if ! command -v python3 >/dev/null 2>&1; then
        die "python3 not found on PATH (the tools require python3 >= 3.10)"
    fi
    local pyver pyok
    pyver="$(python3 -c 'import sys; print("%d.%d.%d" % sys.version_info[:3])' 2>/dev/null || echo "?")"
    pyok="$(python3 -c 'import sys; print(1 if sys.version_info >= (3, 10) else 0)' 2>/dev/null || echo 0)"
    if [ "$pyok" != "1" ]; then
        die "python3 >= 3.10 required, found python3 $pyver"
    fi

    info "Pre-flight"
    info "  bundle      : $BUNDLE_ROOT (version $BBH_VERSION)"
    info "  python3     : $pyver  (ok, >= 3.10)"

    local mod
    for mod in jsonschema requests; do
        if python3 -c "import $mod" >/dev/null 2>&1; then
            info "  optional    : $mod importable"
        else
            warn "optional python module '$mod' is NOT importable — schema/NVD tools degrade, install is not blocked"
        fi
    done
    if python3 -c 'import yaml' >/dev/null 2>&1; then
        info "  optional    : pyyaml importable"
    else
        warn "optional python module 'pyyaml' is NOT importable — YAML-reading tools degrade"
    fi
    info "  contracts   : $(find "$BUNDLE_ROOT/contracts" -maxdepth 1 -name '*.json' 2>/dev/null | wc -l | tr -d ' ') schema file(s)"
    info "  tools       : $(find "$BUNDLE_ROOT/tools" -maxdepth 1 -name '*.py' 2>/dev/null | wc -l | tr -d ' ') python tool(s)"

    context_guard_preflight
    hr
}

# The bundle lives inside an agent workspace and carries copies of third-party repos.
# Any AGENTS.md / CLAUDE.md chain between the project root and the working directory is
# injected into a live agent's context as instructions; a hook config executes. Refuse
# to install a bundle that carries either. tools/context_guard.py is the authority.
context_guard_preflight() {
    local guard="$BUNDLE_ROOT/tools/context_guard.py"

    if [ -f "$guard" ]; then
        if python3 "$guard" --quiet >/dev/null 2>&1; then
            info "  guard       : clean (no instruction files, command hooks, shadow skill roots)"
            return 0
        fi
        if [ "$ALLOW_INSTRUCTION_FILES" -eq 1 ]; then
            warn "--allow-instruction-files: installing despite context-guard findings"
            warn "  the bundle can inject instructions into any agent that works inside it"
            python3 "$guard" || true
            return 0
        fi
        err "context_guard.py found instruction-injection surface in this bundle:"
        python3 "$guard" || true
        err "REFUSING to install a bundle that can steer the operator's agent."
        err "  fix it:   python3 tools/context_guard.py --fix"
        err "  or override (loud, not recommended): ./install.sh --allow-instruction-files"
        exit 3
    fi

    # Fallback when the guard is missing: sweep the whole bundle for the instruction
    # shapes. _upstream/ is included — a synced checkout resurrects them every time.
    local hits=() f
    while IFS= read -r -d '' f; do hits+=("${f#"$BUNDLE_ROOT"/}"); done < <(
        find "$BUNDLE_ROOT" -name .git -prune -o -type f \
            \( -name 'AGENTS.md' -o -name 'AGENTS.local.md' -o -name 'CLAUDE.md' \
               -o -name 'CLAUDE.local.md' -o -name 'OPENCODE.md' -o -name 'GEMINI.md' \) \
            -print0 2>/dev/null
    )
    if [ "${#hits[@]}" -eq 0 ]; then
        info "  guard       : tools/context_guard.py missing; built-in sweep clean"
        return 0
    fi
    if [ "$ALLOW_INSTRUCTION_FILES" -eq 1 ]; then
        warn "--allow-instruction-files: ${#hits[@]} instruction file(s) present in the bundle"
        for f in "${hits[@]}"; do warn "  $f"; done
        return 0
    fi
    err "instruction files found in the bundle (the harness loads these as agent instructions):"
    for f in "${hits[@]}"; do err "  $f"; done
    err "REFUSING to install. Delete them, or override with --allow-instruction-files."
    exit 3
}

check_destination_writable() {
    local probe
    probe="$(nearest_existing_dir "$DEST")"
    if [ ! -w "$probe" ]; then
        err "destination is not writable: $DEST"
        err "  (nearest existing directory '$probe' is not writable by $(id -un))"
        err "  re-run with --dest DIR pointing at a writable skill root; this script never uses sudo."
        exit 2
    fi
}

# ---------------------------------------------------------------- root search (vendor dedupe)
SEARCH_ROOTS=()

collect_search_roots() {
    # project roots, using the same rule DSH uses: nearest ancestor with .git,
    # else the current working directory.
    local probe="$PWD" project_root=""
    while [ -n "$probe" ] && [ "$probe" != "/" ]; do
        if [ -d "$probe/.git" ]; then project_root="$probe"; break; fi
        probe="$(dirname "$probe")"
    done
    [ -n "$project_root" ] || project_root="$PWD"

    add_root() {
        local r="$1" existing
        [ -n "$r" ] || return 0
        r="$(normalize_path "$r")"
        for existing in ${SEARCH_ROOTS[@]+"${SEARCH_ROOTS[@]}"}; do
            [ "$existing" = "$r" ] && return 0
        done
        SEARCH_ROOTS+=("$r")
    }

    if [ "$SCOPE" = "project" ]; then
        add_root "$PWD/.dsh/skills"
    fi
    add_root "$project_root/.dsh/skills"
    add_root "$project_root/.agents/skills"

    # customSkillDirs, best effort: read-only parse of cordis.patch.yml, never edited.
    local patch line dir
    for patch in "$DSH_HOME_DIR"/profiles/*/cordis.patch.yml; do
        [ -f "$patch" ] || continue
        while IFS= read -r line; do
            case "$line" in
                *-*/*) dir="$(printf '%s' "$line" | sed -n 's/^[[:space:]]*-[[:space:]]*//p' | tr -d '"'"'"'')" ;;
                *) continue ;;
            esac
            case "$dir" in
                /*|~*) [ -n "$dir" ] && add_root "${dir/#\~/$HOME}" ;;
            esac
        done < <(awk '/customSkillDirs:/{f=1;next} f&&/^[[:space:]]*-/{print;next} f&&!/^[[:space:]]*$/{f=0}' "$patch" 2>/dev/null)
    done

    add_root "$DEST"
    add_root "$DSH_HOME_DIR/skills"
    add_root "${DSH_AGENTS_HOME:-$HOME/.agents}/skills"
}

find_provider_root() { # name -> root that already provides it (any scanned root)
    local name="$1" root
    for root in ${SEARCH_ROOTS[@]+"${SEARCH_ROOTS[@]}"}; do
        [ -d "$root" ] || continue
        if [ -d "$root/$name" ] && [ -f "$root/$name/SKILL.md" ]; then
            printf '%s\n' "$root"; return 0
        fi
        if [ -f "$root/$name.md" ]; then
            printf '%s\n' "$root"; return 0
        fi
    done
    return 1
}

# ---------------------------------------------------------------- install one skill
install_one() { # name src kind(own|vendor)
    local name="$1" src="$2" kind="$3"
    local target="$DEST/$name"
    local is_dir_src=0
    local force_note=""
    [ -d "$src" ] && is_dir_src=1

    if [ -e "$target" ] || [ -L "$target" ]; then
        if is_ours "$target"; then
            # Already the desired entry: idempotent, counts as installed, zero changes.
            INSTALLED=$((INSTALLED + 1))
            DESIRED_NAMES+=("$name")
            record "$(printf 'installed  %-28s already installed (ours, unchanged)' "$name")"
            return 0
        fi
        if [ "$FORCE" -eq 1 ]; then
            local backup="$DEST/$name.bak.$TS_COMPACT"
            if [ "$DRY_RUN" -eq 1 ]; then
                force_note="--force: would back up foreign entry -> $(basename "$backup"); "
            else
                if mv -- "$target" "$backup" 2>/dev/null; then
                    force_note="--force: replaced foreign entry (backup: $(basename "$backup")); "
                else
                    FAILED=$((FAILED + 1))
                    record "$(printf 'failed     %-28s cannot back up existing entry' "$name")"
                    return 1
                fi
            fi
        else
            SKIPPED=$((SKIPPED + 1))
            SKIP_NOTES+=("$name exists in the destination and was not installed by this bundle")
            record "$(printf 'skipped    %-28s destination entry exists (not ours); use --force to replace' "$name")"
            return 0
        fi
    fi

    if [ "$DRY_RUN" -eq 1 ]; then
        INSTALLED=$((INSTALLED + 1))
        DESIRED_NAMES+=("$name")
        if [ "$COPY_MODE" -eq 1 ]; then
            record "$(printf 'installed  %-28s %swould copy  %s (dry-run)' "$name" "$force_note" "$src")"
        else
            record "$(printf 'installed  %-28s %swould link  %s (dry-run)' "$name" "$force_note" "$src")"
        fi
        return 0
    fi

    if [ "$COPY_MODE" -eq 1 ]; then
        if ! cp -a -- "$src" "$target" 2>/dev/null; then
            FAILED=$((FAILED + 1))
            record "$(printf 'failed     %-28s copy failed: %s' "$name" "$src")"
            return 1
        fi
        if [ "$is_dir_src" -eq 1 ]; then
            {
                printf 'mode=copy\n'
                printf 'bundle=%s\n' "$BUNDLE_ROOT"
                printf 'source=%s\n' "$src"
                printf 'skill=%s\n' "$name"
                printf 'kind=%s\n' "$kind"
                printf 'version=%s\n' "$BBH_VERSION"
                printf 'installed_at=%s\n' "$TS_ISO"
            } > "$target/$MARKER_NAME"
        fi
        INSTALLED=$((INSTALLED + 1))
        DESIRED_NAMES+=("$name")
        record "$(printf 'installed  %-28s %scopied  %s' "$name" "$force_note" "$src")"
        return 0
    fi

    if ln -s -- "$src" "$target" 2>/dev/null; then
        INSTALLED=$((INSTALLED + 1))
        DESIRED_NAMES+=("$name")
        record "$(printf 'installed  %-28s %ssymlink -> %s' "$name" "$force_note" "$src")"
        return 0
    fi

    # symlink not supported here (rare) — fall back to a copy rather than fail
    warn "symlink creation failed for '$name'; falling back to --copy"
    if cp -a -- "$src" "$target" 2>/dev/null; then
        if [ "$is_dir_src" -eq 1 ]; then
            {
                printf 'mode=copy\n'
                printf 'bundle=%s\n' "$BUNDLE_ROOT"
                printf 'source=%s\n' "$src"
                printf 'skill=%s\n' "$name"
                printf 'kind=%s\n' "$kind"
                printf 'version=%s\n' "$BBH_VERSION"
                printf 'installed_at=%s\n' "$TS_ISO"
            } > "$target/$MARKER_NAME"
        fi
        INSTALLED=$((INSTALLED + 1))
        DESIRED_NAMES+=("$name")
        record "$(printf 'installed  %-28s %scopied  %s (symlink fallback)' "$name" "$force_note" "$src")"
        return 0
    fi

    FAILED=$((FAILED + 1))
    record "$(printf 'failed     %-28s install failed: %s' "$name" "$src")"
    return 1
}

verify_one() { # name -> prints problem text (empty = ok)
    local name="$1" target="$DEST/$name" skill_md
    if [ -d "$target" ]; then
        skill_md="$target/SKILL.md"
    elif [ -f "$target" ]; then
        skill_md="$target"          # flat <name>.md install
    else
        printf '%s\n' "destination entry missing: $target"
        return 0
    fi
    if [ ! -f "$skill_md" ]; then
        printf '%s\n' "SKILL.md missing under $target"
        return 0
    fi
    frontmatter_problem "$skill_md"
}

# ---------------------------------------------------------------- main
main() {
    preflight

    [ -d "$SKILLS_SRC" ] || die "missing $SKILLS_SRC"

    info "Plan"
    info "  destination : $DEST"
    info "  scope       : $SCOPE$([ "$SCOPE" = project ] && echo "  (project root: nearest ancestor with .git, else \$PWD)")"
    info "  mode        : $([ "$COPY_MODE" -eq 1 ] && echo copy || echo symlink) (vendor: $([ "$WITH_VENDOR" -eq 1 ] && echo on || echo off), force: $([ "$FORCE" -eq 1 ] && echo on || echo off))"
    [ "$DRY_RUN" -eq 1 ] && info "  dry-run     : yes — nothing will be written"
    hr

    check_destination_writable

    collect_search_roots

    # --- discover skills -----------------------------------------------------
    declare -A SEEN=()
    local OWN_NAMES=() VENDOR_NAMES=()
    local entry name

    for entry in "$SKILLS_SRC"/*; do
        [ -e "$entry" ] || continue
        name="$(basename -- "$entry")"
        case "$name" in .*|SKILL.md) continue ;; esac
        if [ -d "$entry" ] && [ -f "$entry/SKILL.md" ]; then
            :
        elif [ -f "$entry" ] && [ "${name##*.}" = "md" ]; then
            name="${name%.md}"
        else
            continue
        fi
        [ -n "${SEEN[$name]:-}" ] && continue
        SEEN[$name]=1
        OWN_NAMES+=("$name")
    done

    if [ "$WITH_VENDOR" -eq 1 ]; then
        for entry in "$VENDOR_SRC"/*; do
            [ -e "$entry" ] || continue
            name="$(basename -- "$entry")"
            case "$name" in .*|SKILL.md) continue ;; esac
            if [ -d "$entry" ] && [ -f "$entry/SKILL.md" ]; then
                :
            elif [ -f "$entry" ] && [ "${name##*.}" = "md" ]; then
                name="${name%.md}"
            else
                continue
            fi
            [ -n "${SEEN[$name]:-}" ] && continue
            SEEN[$name]=1
            VENDOR_NAMES+=("$name")
        done
    fi

    local total=$(( ${#OWN_NAMES[@]} + ${#VENDOR_NAMES[@]} ))
    if [ "$total" -eq 0 ]; then
        err "nothing to install: no SKILL.md bundles found under $SKILLS_SRC"
        [ "$WITH_VENDOR" -eq 1 ] && err "and none under $VENDOR_SRC"
        exit 2
    fi
    info "Discovered $total skill(s): ${#OWN_NAMES[@]} bundle + ${#VENDOR_NAMES[@]} vendor"

    # --- destination root ----------------------------------------------------
    if [ "$DRY_RUN" -eq 0 ]; then
        if ! mkdir -p -- "$DEST" 2>/dev/null; then
            err "cannot create destination: $DEST"
            err "  re-run with --dest DIR naming a writable skill root (no sudo is used)."
            exit 2
        fi
    fi

    # symlink -> cross-filesystem guard
    if [ "$COPY_MODE" -eq 0 ] && [ "$DRY_RUN" -eq 0 ]; then
        local ddev sdev
        ddev="$(device_of "$DEST")"
        sdev="$(device_of "$SKILLS_SRC")"
        if [ "$ddev" != "$sdev" ]; then
            warn "destination is on a different filesystem (device $ddev vs $sdev) — symlinks would break; using --copy"
            COPY_MODE=1
        fi
    fi

    # --- install own skills --------------------------------------------------
    local src
    if [ "${#OWN_NAMES[@]}" -gt 0 ]; then
        info ""
        info "Bundle skills"
        for name in ${OWN_NAMES[@]+"${OWN_NAMES[@]}"}; do
            if ! src="$(skill_source_path "$SKILLS_SRC" "$name")"; then
                FAILED=$((FAILED + 1))
                record "$(printf 'failed     %-28s source disappeared' "$name")"
                continue
            fi
            install_one "$name" "$src" own || true
        done
    fi

    # --- install vendor skills (only when the name is not already provided) --
    if [ "${#VENDOR_NAMES[@]}" -gt 0 ]; then
        info ""
        info "Vendor skills (installed only when no other root provides the name)"
        for name in ${VENDOR_NAMES[@]+"${VENDOR_NAMES[@]}"}; do
            local provider
            provider="$(find_provider_root "$name" || true)"
            if [ -n "$provider" ]; then
                if [ "$(normalize_path "$provider")" = "$(normalize_path "$DEST")" ] && is_ours "$DEST/$name"; then
                    : # ours already; fall through to install_one's idempotent path
                else
                    SKIPPED=$((SKIPPED + 1))
                    SKIP_NOTES+=("$name is already provided by $provider (vendor copy not installed)")
                    record "$(printf 'skipped    %-28s already provided by %s' "$name" "$provider")"
                    continue
                fi
            fi
            if ! src="$(skill_source_path "$VENDOR_SRC" "$name")"; then
                FAILED=$((FAILED + 1))
                record "$(printf 'failed     %-28s vendor source disappeared' "$name")"
                continue
            fi
            install_one "$name" "$src" vendor || true
        done
    fi

    # --- verify --------------------------------------------------------------
    info ""
    info "Verify"
    local verify_failed=() problem=""
    for name in ${DESIRED_NAMES[@]+"${DESIRED_NAMES[@]}"}; do
        if [ "$DRY_RUN" -eq 1 ]; then
            info "  $name: would verify test -f $DEST/$name/SKILL.md + frontmatter (dry-run)"
            continue
        fi
        if problem="$(verify_one "$name")" && [ -z "$problem" ]; then
            info "  ${C_OK}ok${C_RESET}   $name: SKILL.md present, frontmatter has name + description"
        else
            verify_failed+=("$name")
            FAILED=$((FAILED + 1))
            record "$(printf 'failed     %-28s verification: %s' "$name" "${problem:-SKILL.md missing or frontmatter invalid}")"
            err "  verify failed for $name: ${problem:-SKILL.md missing or frontmatter invalid}"
        fi
    done

    # --- table ---------------------------------------------------------------
    info ""
    hr
    printf '%s%-11s %-28s %s%s\n' "$C_BOLD" "RESULT" "SKILL" "DETAIL" "$C_RESET"
    hr
    if [ "${#TABLE_LINES[@]}" -gt 0 ]; then
        printf '%s\n' ${TABLE_LINES[@]+"${TABLE_LINES[@]}"}
    fi
    hr
    printf '%sinstalled | skipped (exists) | failed%s\n' "$C_BOLD" "$C_RESET"
    printf '%8d | %16d | %6d\n' "$INSTALLED" "$SKIPPED" "$FAILED"

    # --- summary -------------------------------------------------------------
    info ""
    hr
    info "${C_BOLD}Summary${C_RESET}"
    info "  destination : $DEST"
    info "  installed   : $INSTALLED (already-present entries owned by this bundle count as installed)"
    info "  skipped     : $SKIPPED"
    info "  failed      : $FAILED"
    if [ "${#SKIP_NOTES[@]}" -gt 0 ]; then
        local n
        for n in ${SKIP_NOTES[@]+"${SKIP_NOTES[@]}"}; do info "    - $n"; done
    fi

    # entry point: /bbh when present, else the bbh-* skill, else the first install
    local entry_skill=""
    for name in ${DESIRED_NAMES[@]+"${DESIRED_NAMES[@]}"}; do
        case "$name" in bbh) entry_skill="bbh"; break ;; esac
    done
    if [ -z "$entry_skill" ]; then
        for name in ${DESIRED_NAMES[@]+"${DESIRED_NAMES[@]}"}; do
            case "$name" in bbh-*) entry_skill="$name"; break ;; esac
        done
    fi
    [ -n "$entry_skill" ] || entry_skill="${DESIRED_NAMES[0]:-<skill>}"

    info ""
    if [ "$entry_skill" = "bbh" ]; then
        info "  ${C_BOLD}Run the pipeline:${C_RESET}  /bbh        (or load the \`bbh\` skill from the session skill list)"
    else
        info "  ${C_BOLD}Run the pipeline:${C_RESET}  /${entry_skill}   (or load the \`${entry_skill}\` skill from the session skill list)"
    fi
    info "  ${C_BOLD}Uninstall:${C_RESET}         $UNINSTALL_SH --dest \"$DEST\""

    # ---- operator tools -----------------------------------------------------
    info ""
    info "  ${C_BOLD}工具自检（可随时手动运行）${C_RESET}"
    info "    python3 tools/context_guard.py          # 检查指令注入面：instruction files /"
    info "                                            #   hook configs / shadow skill roots / 断链"
    info "    python3 tools/context_guard.py --fix    # 就地清理（放弃安装前请先跑这个）"
    info "    tools/sync-upstream.sh --check          # 上游是否已移动（只读，不改任何文件）"
    if [ "$ALLOW_INSTRUCTION_FILES" -eq 1 ]; then
        info "    ${C_WARN}注意：本次使用了 --allow-instruction-files，bundle 内的指令文件未经清理。${C_RESET}"
    fi

    # ---- workspace instruction injection ------------------------------------
    info ""
    info "  ${C_BOLD}工作区指令注入${C_RESET}"
    info "    DSH 会把 project root → 工作目录之间的 AGENTS.md / CLAUDE.md（含 .local.md）当作"
    info "    agent 指令加载；把第三方仓库/pack 放进工作区就等于引入指令注入面。本 bundle 已剥离"
    info "    这些文件，且 install.sh 在链接前先跑 context_guard.py，发现即拒绝安装"
    info "    （除非 --allow-instruction-files）。sync-upstream.sh 每次同步后重新清理，因为"
    info "    git reset --hard 会把上游的 AGENTS.md / CLAUDE.md 恢复回来。"
    info "    --scope project（<project>/.agents/skills）把 skills 放进 agent 读取指令的同一棵树，"
    info "    暴露面更大。详见 MIGRATION.md 的「工作区指令注入」。"

    # customSkillDirs alternative — printed, never applied to any config file.
    local patch="" p
    for p in "$DSH_HOME_DIR"/profiles/*/cordis.patch.yml; do
        [ -f "$p" ] && patch="$p" && break
    done
    if [ -n "$patch" ]; then
        info ""
        info "  ${C_BOLD}Alternative to symlinking:${C_RESET} a customSkillDirs entry (rank 300) in $patch"
        info "  This installer never edits DSH config. Paste this yourself:"
        info ""
        info "    - name: '@deepseek-ai/dsh-skill-filesystem'"
        info "      config:"
        info "        customSkillDirs:"
        info "          - $SKILLS_SRC"
        info ""
    fi

    if [ "$FAILED" -gt 0 ]; then
        err "completed with $FAILED failure(s)"
        exit 1
    fi
    [ "$DRY_RUN" -eq 1 ] && ok "dry-run complete — nothing was written"
    exit 0
}

main "$@"
