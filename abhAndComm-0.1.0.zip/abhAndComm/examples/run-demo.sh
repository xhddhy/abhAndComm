#!/usr/bin/env bash
# End-to-end smoke test for the abhAndComm pipeline.
#
# WHY THIS EXISTS
# ---------------
# Every stage of this pipeline is a file plus a command, and the interesting failures are
# interface failures: a stage that writes a field the next stage does not read, a flag the
# catalogue does not know, a cell the gate cannot score. None of those show up from reading
# the code. So this script drives the whole chain over a synthetic-but-realistic target and
# asserts the invariants that matter.
#
# It deliberately does NOT touch the network and does NOT need a real target: stage 1 is fed
# a hand-written recon tree shaped exactly like upstream Agentic-Bug-Hunter's output.
#
#   ./examples/run-demo.sh            # run everything, print PASS/FAIL per check
#   ./examples/run-demo.sh --keep     # leave the temp run dir for inspection
set -euo pipefail

BUNDLE="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$BUNDLE"

KEEP=0
[[ "${1:-}" == "--keep" ]] && KEEP=1

WORK="$(mktemp -d "${TMPDIR:-/tmp}/bbh-demo.XXXXXX")"
cleanup() { [[ "$KEEP" == "1" ]] && { echo; echo "run dir kept at: $WORK"; } || rm -rf "$WORK"; }
trap cleanup EXIT

RUN="$WORK/runs/demo-2026-09"
RECON="$WORK/recon/demo.test"
mkdir -p "$RUN" "$RECON"/{live,urls,candidates,js,admin,ports}

PASS=0; FAIL=0
ok()   { printf '  \033[32mPASS\033[0m  %s\n' "$1"; PASS=$((PASS+1)); }
bad()  { printf '  \033[31mFAIL\033[0m  %s\n' "$1"; FAIL=$((FAIL+1)); }
step() { printf '\n\033[1m%s\033[0m\n' "$1"; }
# check <description> <expected-exit> <cmd...>
check() {
  local desc="$1" want="$2"; shift 2
  local out rc
  out="$("$@" 2>&1)" && rc=0 || rc=$?
  if [[ "$rc" == "$want" ]]; then ok "$desc (exit $rc)"
  else bad "$desc — wanted exit $want, got $rc"; printf '%s\n' "$out" | sed 's/^/        /' | head -12; fi
}

# ---------------------------------------------------------------------------
step "0. build the synthetic recon tree (upstream ABH output shape)"
# ---------------------------------------------------------------------------
# httpx shape: URL [status] [title] [tech,tech] [content-length] [server]
cat > "$RECON/live/urls.txt" <<'EOF'
https://api.demo.test [200] [Demo API] [Express,PostgreSQL,Stripe] [12] [nginx/1.24.0]
https://www.demo.test [200] [Demo] [Next.js,React] [40] [cloudflare]
https://api.demo.test:8443 [200] [Demo Admin] [Express] [12] [nginx/1.24.0]
EOF

cat > "$RECON/urls/all.txt" <<'EOF'
https://api.demo.test/v1/users/1042
https://api.demo.test/v1/users/1042/profile
https://api.demo.test/v2/orders/8f14e45f-ceea-467a-9c1e-1b7c1d4e2a90
https://api.demo.test/v1/invoices/7781
https://api.demo.test/graphql
https://api.demo.test/oauth/authorize
https://api.demo.test/v1/session/refresh
https://api.demo.test/password/reset
https://api.demo.test/v1/reports/export?report_id=91&format=csv
https://api.demo.test/v1/avatar?image_url=https%3A%2F%2Fcdn.demo.test%2Fa.png&user=1042
https://api.demo.test/v1/search?q=test&role=user&callback=cb
https://api.demo.test/v1/checkout?step=3&coupon=SAVE10&cart=17
https://api.demo.test/v1/comments?post_id=5&body=hello
https://www.demo.test/api/contact
https://www.demo.test/search?q=x&next=/dashboard
https://api.demo.test/actuator/env
https://api.demo.test/.git/config
EOF

printf 'https://api.demo.test/v1/search?q=test&role=user&callback=cb\nhttps://api.demo.test/v1/comments?post_id=5&body=hello\n' > "$RECON/candidates/xss.txt"
printf 'https://api.demo.test/v1/avatar?image_url=https%%3A%%2F%%2Fcdn.demo.test%%2Fa.png&user=1042\n' > "$RECON/candidates/ssrf.txt"
printf 'https://api.demo.test/v1/reports/export?report_id=91&format=csv\n' > "$RECON/candidates/idor.txt"

printf '%s\n' \
  https://api.demo.test/v1/users/1042 \
  https://api.demo.test/v1/users/1042/profile \
  https://api.demo.test/v2/orders/8f14e45f-ceea-467a-9c1e-1b7c1d4e2a90 \
  https://api.demo.test/graphql > "$RECON/api-endpoints.txt"

printf 'https://cdn.demo.test/static/js/app.7f3a.js:0:api_key:pk_live_51H8xQ2eZvKYlo2C9f2c\n' \
  > "$RECON/js/secrets.txt"
printf 'https://api.demo.test/v1/internal/reports\nhttps://internal-admin.demo.test/api\n' \
  > "$RECON/js/endpoints.txt"

printf 'https://api.demo.test/.git/config [200]\n' > "$RECON/config-exposure.txt"
printf 'https://api.demo.test/actuator/env [401]\n' > "$RECON/admin/panels.txt"
cat > "$RECON/ports/nmap.txt" <<'EOF'
Starting Nmap 7.94 ( https://nmap.org )
Nmap scan report for api.demo.test (203.0.113.10)
PORT     STATE SERVICE  VERSION
8443/tcp open  ssl/http nginx 1.24.0
EOF
ok "recon tree written to $RECON"

# ---------------------------------------------------------------------------
step "1. scope"
# ---------------------------------------------------------------------------
check "scope init" 0 python3 tools/bbh_scope.py init \
  --engagement demo-2026-09 --platform hackerone --program demo \
  --asset 'web:demo.test:apex' --asset 'wildcard:*.demo.test' \
  --asset 'api:api.demo.test' --asset 'web:www.demo.test' \
  --exclude staging.demo.test --out "$RUN/scope.json"
check "scope schema validates" 0 python3 tools/schema_check.py --kind scope "$RUN/scope.json"
check "in-scope URL accepted" 0 python3 tools/bbh_scope.py check \
  --scope "$RUN/scope.json" --url https://api.demo.test/v1/users/1
check "out-of-scope URL rejected" 1 python3 tools/bbh_scope.py check \
  --scope "$RUN/scope.json" --url https://evil.example.net/x
# An explicitly excluded host is unambiguously out of scope (exit 1)...
check "explicitly excluded host rejected" 1 python3 tools/bbh_scope.py check \
  --scope "$RUN/scope.json" --url https://staging.demo.test/x
# ...a staging-looking host that the wildcard covers but the program never listed is
# UNCLEAR (exit 2), not allowed...
check "unlisted qa host is UNCLEAR" 2 python3 tools/bbh_scope.py check \
  --scope "$RUN/scope.json" --url https://qa.demo.test/x
# ...and a wildcard-only match with NO published safe-harbor clause is ALSO unclear,
# because a wildcard is an authorisation for the asset class, not a blanket legal cover.
# This is the single most consequential default in the whole bundle, so it is asserted
# both ways: absent safe harbor -> unclear, present safe harbor -> in scope.
check "wildcard match without safe harbor is UNCLEAR" 2 python3 tools/bbh_scope.py check \
  --scope "$RUN/scope.json" --url https://shop.demo.test/cart

check "scope init (safe harbor variant)" 0 python3 tools/bbh_scope.py init \
  --engagement demo-sh-2026-09 --platform hackerone --program demo --safe-harbor \
  --asset 'wildcard:*.demo.test' --out "$WORK/scope-sh.json"
check "wildcard match WITH safe harbor is in scope" 0 python3 tools/bbh_scope.py check \
  --scope "$WORK/scope-sh.json" --url https://shop.demo.test/cart
# A wildcard match is not evidence of OWNERSHIP. Without a CNAME record the tool cannot tell a
# first-party subdomain from one delegated to a third party, so the default verdict carries a
# warning and --require-cname escalates the unverified case to unclear. Asserted both ways.
sw_out="$(python3 tools/bbh_scope.py check --scope "$WORK/scope-sh.json" \
  --url https://shop.demo.test/cart 2>&1 || true)"
if grep -q "CNAME was NOT verified" <<<"$sw_out"; then
  ok "unverified wildcard match states the caveat instead of reading as verified"
else
  bad "unverified wildcard match did not warn about the unverified CNAME"
fi
check "--require-cname escalates an unverified wildcard to UNCLEAR" 2 python3 tools/bbh_scope.py \
  check --scope "$WORK/scope-sh.json" --url https://shop.demo.test/cart --require-cname

# ---------------------------------------------------------------------------
step "2. recon-lite classification (known assets only)"
# ---------------------------------------------------------------------------
check "classify" 0 python3 tools/bbh_classify.py \
  --recon-dir "$RECON" --scope "$RUN/scope.json" --out "$RUN/classification.json"
check "classification schema validates" 0 python3 tools/schema_check.py \
  --kind classification "$RUN/classification.json"

python3 - "$RUN/classification.json" <<'PY'
import json, sys
d = json.load(open(sys.argv[1]))
buckets = {}
for a in d["assets"]:
    for k, v in (a.get("buckets") or {}).items():
        buckets[k] = buckets.get(k, 0) + len(v)
print("      buckets:", ", ".join(f"{k}={v}" for k, v in sorted(buckets.items())))
assert d["assets"], "no assets classified"
PY
ok "classification carries assets and buckets"

# ---------------------------------------------------------------------------
step "3. surface translation + coverage cells"
# ---------------------------------------------------------------------------
check "surface_build (strict flags)" 0 python3 tools/surface_build.py \
  --classification "$RUN/classification.json" --scope "$RUN/scope.json" \
  --assets-dir "$RUN/assets" --strict-flags

for d in "$RUN"/assets/*/; do
  check "cells_build $(basename "$d")" 0 python3 tools/cells_build.py --asset-dir "$d"
done

python3 - "$RUN" <<'PY'
import glob, json, os, sys
run = sys.argv[1]
AGENT = {"object_by_id","json_body","role_verb_gated","sensitive_flow","server_fetched_url",
         "input_sink","workflow","deser_or_ci","inbound_webhook","id_keyed_unauth","stored_field",
         "auth_surface","consumes_upstream","static_js_or_repo","local_store","crypto_use",
         "exported_component","webview"}
DERIVED = {"http_listener","tls_listener","version_fingerprinted","has_api","is_apex","serves_js","mobile_app"}
total_cells = 0
for sp in sorted(glob.glob(f"{run}/assets/*/recon/inventory/surface.json")):
    s = json.load(open(sp))
    assert s["schema"] == "surface/v2", sp
    for u in s["units"]:
        illegal = set(u["flags"]) & DERIVED
        assert not illegal, f"{sp}: derived flag(s) written by surface_build: {illegal}"
        unknown = set(u["flags"]) - AGENT
        assert not unknown, f"{sp}: unknown flag(s): {unknown}"
    for cp in sorted(glob.glob(f"{run}/assets/*/applicability/cells.json")):
        total_cells += json.load(open(cp))["counts"]["total"]
print(f"      derived flags never written by surface_build; {total_cells} cells enumerated")
assert total_cells > 0, "no cells enumerated"
PY
ok "no derived/unknown flags leaked; cells > 0"

# ---------------------------------------------------------------------------
step "4. coverage gate — honest by construction"
# ---------------------------------------------------------------------------
check "empty ledger reports INCOMPLETE" 1 python3 tools/coverage_gate.py \
  --asset-dir "$(echo "$RUN"/assets/*/ | awk '{print $1}')"

# Fabricate a N/A on a code-applicable cell and confirm the gate refuses it.
ASSET="$(echo "$RUN"/assets/*/ | awk '{print $1}')"
python3 - "$ASSET" <<'PY'
import json, sys
d = sys.argv[1].rstrip("/")
cells = json.load(open(f"{d}/applicability/cells.json"))
rows = [{"cell_key": cells["cells"][0]["cell_key"], "status": "na", "reason": "looks fine"}]
json.dump({"schema": "bbh/coverage/v1", "asset_tag": cells["asset_tag"], "cells": rows},
          open(f"{d}/coverage.json", "w"), indent=1)
PY
check "fabricated N/A is refused" 1 python3 tools/coverage_gate.py --asset-dir "$ASSET"
# NOTE: capture first, then grep. `cmd | grep -q` under `set -o pipefail` reports a FAIL
# even on a match, because grep -q exits as soon as it matches, closes the pipe, and the
# writer dies on EPIPE — which pipefail then propagates as the pipeline's status.
gate_json="$(python3 tools/coverage_gate.py --asset-dir "$ASSET" --json 2>/dev/null || true)"
if grep -q '"fabrications": 1' <<<"$gate_json"; then
  ok "gate counts exactly 1 fabrication"
else
  bad "gate did not report the fabrication"
fi
check "strict mode also refuses" 1 python3 tools/coverage_gate.py --asset-dir "$ASSET" --mode strict

# The central claim of this design is "the applicable set is code-produced, so an agent cannot
# shrink it". That is only true if the gate RE-DERIVES the set instead of reading it back. So:
# shrink cells.json by hand and confirm the gate refuses to score against it.
cp "$ASSET/applicability/cells.json" "$WORK/cells.bak"
python3 - "$ASSET" <<'PY'
import json, sys
p = f"{sys.argv[1].rstrip('/')}/applicability/cells.json"
d = json.load(open(p))
before = len(d["cells"])
d["cells"] = d["cells"][:1]
json.dump(d, open(p, "w"), indent=1)
print(f"      tampered cells.json: {before} -> {len(d['cells'])} cell(s)")
PY
check "hand-shrunk work list is refused" 1 python3 tools/coverage_gate.py --asset-dir "$ASSET"
# Read the per-asset detail from the report, not from --json (which prints the run-level
# summary and deliberately does not carry the per-asset flags).
python3 - "$ASSET" <<'PY'
import json, sys
p = f"{sys.argv[1].rstrip('/')}/reports/coverage-matrix.json"
d = json.load(open(p))
a = d["assets"][0]
assert a["worklist_verified"] is False, "gate scored a work list it could not verify"
assert "disagrees with the catalogue" in a["worklist_detail"], a["worklist_detail"]
assert d["summary"]["complete"] is False, "tampered work list still reported complete"
print(f"      report says worklist_verified=false and complete=false")
PY
ok "gate records the unverified work list in its report"

# The work-list blocker must also survive --json, or a scripted consumer that only reads the
# summary would see complete:false with no reason attached.
gj="$(python3 tools/coverage_gate.py --asset-dir "$ASSET" --json 2>/dev/null || true)"
if grep -q '"complete": false' <<<"$gj"; then
  ok "run summary reports not-complete for the tampered work list"
else
  bad "run summary did not report the tampered work list as not-complete"
fi
cp "$WORK/cells.bak" "$ASSET/applicability/cells.json"

# ...and the honest path must still pass, or the new blocker would be a false positive that
# makes the gate useless in the other direction.
python3 - "$ASSET" <<'PY'
import json, os, sys
a = sys.argv[1].rstrip("/")
cells = json.load(open(f"{a}/applicability/cells.json"))["cells"]
os.makedirs(f"{a}/evidence", exist_ok=True)
open(f"{a}/evidence/probe.txt", "w").write("tool log: probe output\n")
json.dump({"schema": "bbh/coverage/v1", "asset_tag": cells[0]["asset_tag"],
           "cells": [{"cell_key": c["cell_key"], "status": "covered_negative",
                      "corroborator": "tools/probe.py --cell " + c["class_id"],
                      "vantages": ["us-east", "eu-west"],
                      "evidence": ["evidence/probe.txt"]} for c in cells]},
          open(f"{a}/coverage.json", "w"), indent=1)
print(f"      wrote a full {len(cells)}-cell ledger")
PY
check "verified work list + full coverage passes (bounty mode)" 0 \
  python3 tools/coverage_gate.py --asset-dir "$ASSET"
check "verified work list + full coverage passes (strict mode)" 0 \
  python3 tools/coverage_gate.py --asset-dir "$ASSET" --mode strict
rm -f "$ASSET/coverage.json"

# ---------------------------------------------------------------------------
step "5. queue and slice (skipped cleanly if not built yet)"
# ---------------------------------------------------------------------------
if [[ -f tools/queue_build.py ]]; then
  check "queue_build" 0 python3 tools/queue_build.py \
    --classification "$RUN/classification.json" --cells-dir "$RUN/assets" \
    --out "$RUN/queue.json"
  python3 - "$RUN/queue.json" <<'PY'
import json, re, sys
q = json.load(open(sys.argv[1]))
leads = q["leads"]
assert leads, "queue is empty"
killed = [l for l in leads if (l.get("status") or "") in ("killed", "eliminated", "skipped")]
assert not killed, f"queue eliminated {len(killed)} lead(s) — it must never eliminate"
# Every lead must be actionable. A lead whose address is "u-0011" passes every structural
# check and is still useless to the person holding the keyboard, so the invariant asserted
# here is about the ADDRESS, not about unit_id: unit_id is meaningful only for unit-scope
# cells (host-scope keys on host:port, asset-scope on the asset tag), but EVERY cell lead
# must resolve to something you can point a request at.
cells = [l for l in leads if l.get("source") == "coverage-cell"]
assert cells, "no coverage-cell leads: the cells were not folded in"
unit_id_leads = 0
for l in cells:
    addr = str(l.get("address") or "")
    assert addr, f"{l['lead_id']}: coverage-cell lead has no address at all"
    assert not re.fullmatch(r"u-\d+", addr), \
        f"{l['lead_id']}: address is a bare unit id, not an address: {addr!r}"
    if l.get("unit_id"):
        unit_id_leads += 1
        assert re.fullmatch(r"u-\d+", str(l["unit_id"])), \
            f"{l['lead_id']}: unit_id is not a unit id: {l['unit_id']!r}"
assert unit_id_leads > 0, "no unit-scope cell carried a unit_id: address resolution is broken"
tiers = {}
for l in leads:
    tiers[l.get("tier")] = tiers.get(l.get("tier"), 0) + 1
print(f"      {len(leads)} lead(s), tiers: {tiers}, zero eliminated")
PY
  ok "queue eliminates nothing"
else
  echo "  SKIP  queue_build.py not present"
fi

if [[ -f tools/slice_build.py ]]; then
  check "slice_build" 0 python3 tools/slice_build.py --run-dir "$RUN" --scope "$RUN/scope.json"
  python3 - "$RUN" <<'PY'
import glob, json, os, sys
run = sys.argv[1]
slices = sorted(glob.glob(f"{run}/slices/*.json"))
assert slices, "no slices produced"
for sp in slices:
    s = json.load(open(sp))
    assert os.path.isabs(s["output_dir"]), f"{sp}: output_dir must be absolute"
    for refs in (s.get("class_playbooks") or {}).values():
        for r in refs:
            assert not os.path.isdir(r), f"{sp}: class_playbooks must name files, not dirs: {r}"
print(f"      {len(slices)} slice(s), output_dir absolute, playbooks are files")
PY
  ok "slices are self-contained work orders"
else
  echo "  SKIP  slice_build.py not present"
fi

# Re-classification must never quietly demote work that is still owed. A lead whose signal
# disappears from a later classification is carried forward with the priority and tier it was
# scored with WHEN THE SIGNAL EXISTED — re-scoring the reduced evidence would drop a P1 to a P2,
# and in bounty mode "every P1 reached a terminal status" is the completion condition, so a
# demotion silently removes the lead from the set of things still owed.
if [[ -f tools/queue_build.py && -f "$RUN/queue.json" ]]; then
  python3 - "$RUN" <<'PY'
import json, sys
run = sys.argv[1]
q = json.load(open(f"{run}/queue.json"))
p1 = [l for l in q["leads"] if l["tier"] == "P1"]
assert p1, "no P1 lead to track"
watch = p1[0]
json.dump({"schema": "bbh/classification/v1", "target": "demo.test",
           "assets": [{"asset_id": "a9", "asset_tag": "nothing.demo.test", "buckets": {}}]},
          open(f"{run}/shrunk.json", "w"), indent=1)
open(f"{run}/.watch", "w").write(watch["lead_id"])
print(f"      tracking {watch['lead_id']} ({watch['class_id']}) at P={watch['priority']}/{watch['tier']}")
PY
  python3 tools/queue_build.py --classification "$RUN/shrunk.json" \
    --prior-queue "$RUN/queue.json" --out "$RUN/queue-shrunk.json" >/dev/null 2>&1 || true
  python3 - "$RUN" <<'PY'
import json, sys
run = sys.argv[1]
lid = open(f"{run}/.watch").read().strip()
before = {l["lead_id"]: l for l in json.load(open(f"{run}/queue.json"))["leads"]}[lid]
after = {l["lead_id"]: l for l in json.load(open(f"{run}/queue-shrunk.json"))["leads"]}.get(lid)
assert after, f"{lid} vanished from the queue when its signal left the classification"
assert after["priority"] == before["priority"], \
    f"carried lead was silently re-scored: {before['priority']} -> {after['priority']}"
assert after["tier"] == before["tier"], \
    f"carried lead was silently demoted: {before['tier']} -> {after['tier']}"
assert after.get("params") == before.get("params"), "carried lead lost its params"
assert after.get("carried_forward") is True, "carried lead is not flagged as carried"
print(f"      {lid} kept P={after['priority']}/{after['tier']} and its params, flagged carried_forward")
PY
  ok "a carried-forward lead keeps its priority and tier"
else
  echo "  SKIP  queue carry-forward check (no queue.json)"
fi

# ---------------------------------------------------------------------------
step "6. lead board — what to work next, and what was already worked"
# ---------------------------------------------------------------------------
if [[ -f tools/lead_board.py && -f "$RUN/queue.json" ]]; then
  check "lead_board show" 0 python3 tools/lead_board.py --run-dir "$RUN" show
  check "lead_board show --json (trailing position)" 0 python3 tools/lead_board.py \
    --run-dir "$RUN" show --json
  check "lead_board next" 0 python3 tools/lead_board.py --run-dir "$RUN" next

  LEAD_ID="$(python3 tools/lead_board.py --run-dir "$RUN" next --json 2>/dev/null \
    | python3 -c 'import json,sys; print(json.load(sys.stdin)["lead"]["lead_id"])' 2>/dev/null || true)"
  if [[ -n "$LEAD_ID" ]]; then
    check "lead_board touch" 0 python3 tools/lead_board.py --run-dir "$RUN" \
      touch --lead "$LEAD_ID" --status investigating --experiment E-001
    # The queue must survive a rebuild with its status intact — this is the round trip that
    # makes the board usable across sessions rather than a one-shot report.
    python3 tools/queue_build.py --classification "$RUN/classification.json" \
      --cells-dir "$RUN/assets" --prior-queue "$RUN/queue.json" \
      --out "$RUN/queue.json" >/dev/null 2>&1
    python3 - "$RUN/queue.json" "$LEAD_ID" <<'PY'
import json, sys
q = json.load(open(sys.argv[1])); lid = sys.argv[2]
row = next((l for l in q["leads"] if l["lead_id"] == lid), None)
assert row, f"lead {lid} vanished across a queue rebuild — leads must never be lost"
assert row["status"] == "investigating", f"status reset to {row['status']!r} by a rebuild"
assert row["touched_by"] == "E-001", "touched_by was not preserved"
print(f"      {lid} kept status={row['status']} touched_by={row['touched_by']} across a rebuild")
PY
    ok "lead status survives a queue rebuild"
  else
    bad "could not read a lead id from the board"
  fi
else
  echo "  SKIP  lead_board.py or queue.json not present"
fi

# ---------------------------------------------------------------------------
step "7. stage 9 — the reproduction pack (the primary deliverable)"
# ---------------------------------------------------------------------------
# Everything up to here produced a verdict. This stage produces the thing the operator
# actually asked for: a runbook they can follow by hand on a clean box, plus a runnable PoC.
if [[ -f tools/repro_pack.py ]]; then
  FD="$RUN/assets/api.demo.test/findings/finding-001"
  mkdir -p "$FD/poc" "$FD/evidence" "$RUN/assets/api.demo.test/artifacts/validated" \
           "$RUN/assets/api.demo.test/seven-questions"
  cat > "$FD/poc/exploit.py" <<'PY'
#!/usr/bin/env python3
"""Minimal PoC fixture: proves the demo harness, not a real target."""
import sys
print("BOLA-CONFIRMED: victim object returned for actor session")
sys.exit(0)
PY
  printf 'actor: user_a\nvictim: user_b\nidentity delta: 200 with victim data\n' \
    > "$FD/evidence/two-identity-comparison.txt"

  # repro_pack.py requires the candidate finding to exist and to conform to
  # contracts/finding.schema.json — it refuses to invent content from a bare verdict.
  cat > "$FD/finding.json" <<'JSON'
{
  "schema": "bbh/finding/v1", "finding_id": "F-001", "experiment_id": "E-004",
  "asset_tag": "api.demo.test", "class_id": "API1-BOLA", "cell_key": "unit|u-0013|API1-BOLA",
  "title": "BOLA in GET /v1/users/{id} exposes another tenant's profile",
  "severity_claim": "medium", "endpoint": "https://api.demo.test/v1/users/1042", "method": "GET",
  "description": "The object id is not bound to the session.",
  "impact": "An authenticated user reads any other tenant's profile, including email and phone.",
  "cvss_vector": "CVSS:3.1/AV:N/AC:L/PR:L/UI:N/S:U/C:H/I:N/A:N",
  "evidence": {
    "request": "GET /v1/users/1042 HTTP/1.1\nHost: api.demo.test\nCookie: session=ACTOR",
    "response": "{\"id\":1042,\"email\":\"victim@example.com\"}",
    "status_code": 200,
    "artifacts": ["evidence/two-identity-comparison.txt"],
    "identity": {"actor": "user_a", "victim": "user_b", "anonymous": false}
  },
  "poc": {
    "script": "poc/exploit.py", "cmd": "python3 poc/exploit.py",
    "dependencies": [], "expected_output": "BOLA-CONFIRMED",
    "negative_control": "run with a random id; expect no BOLA-CONFIRMED line",
    "runs": 3, "deterministic": true
  },
  "chain_hints": [], "status": "confirmed"
}
JSON

  cat > "$RUN/assets/api.demo.test/artifacts/validated/F-001.json" <<'JSON'
{
  "schema": "bbh/verdict/v1", "finding_id": "F-001", "asset_tag": "api.demo.test",
  "verdict": "CONFIRMED",
  "checks": {"scope_in_scope": {"pass": true}, "poc_runs": {"pass": true},
             "cross_identity": {"pass": true}, "cvss_recomputed": {"pass": true}},
  "failed_checks": [], "missing_evidence": [],
  "refuters": {"count": 3, "refuted": 0, "refutation_args": []},
  "cvss": {"vector": "CVSS:3.1/AV:N/AC:L/PR:L/UI:N/S:U/C:H/I:N/A:N", "recomputed_score": 6.5},
  "evidence_package": ["evidence/two-identity-comparison.txt"],
  "reason": "fixture", "cure_cycles": 0
}
JSON
  cat > "$RUN/assets/api.demo.test/seven-questions/F-001.json" <<'JSON'
{
  "schema": "bbh/7q/v1", "finding_id": "F-001", "asset_tag": "api.demo.test", "cycle": 1,
  "answers": {
    "q1_demonstrable_right_now": {"pass": true, "setup": "one own account plus a victim id",
      "request": "GET /v1/users/1042 with the actor cookie", "result": "victim profile JSON",
      "impact": "cross-tenant PII read", "cost": "2 minutes, $0"},
    "q2_impact_accepted": {"pass": true, "detail": "BOLA is in scope"},
    "q3_asset_in_scope": {"pass": true, "detail": "api.demo.test exact match"},
    "q4_no_privileged_access_needed": {"pass": true, "detail": "any authenticated user"},
    "q5_not_known_behavior": {"pass": true, "detail": "not in changelog or disclosed reports"},
    "q6_impact_proven": {"pass": true, "detail": "victim email present in the response body"},
    "q7_not_never_submit": {"pass": true, "detail": "not on the never-submit list"}
  },
  "verdict": "PASS", "killed_by": null, "kill_reason": null, "downgrade_to": null
}
JSON
  cat > "$FD/repro.json" <<'JSON'
{
  "schema": "bbh/repro/v1", "finding_id": "F-001", "asset_tag": "api.demo.test",
  "title": "BOLA in GET /v1/users/{id} exposes another tenant's profile",
  "severity": "medium", "cvss_vector": "CVSS:3.1/AV:N/AC:L/PR:L/UI:N/S:U/C:H/I:N/A:N",
  "cvss_score": 6.5, "one_line_summary": "A user id swap returns another account's profile.",
  "time_estimate_min": 10,
  "environment": {
    "os": "Debian 12 / Python 3.11",
    "network": "internet reachability to api.demo.test",
    "tools": [
      {"name": "curl", "version": "any", "install": "apt-get install -y curl",
       "verify": "curl --version", "why": "issues the raw requests"},
      {"name": "python3", "version": ">=3.10", "install": "apt-get install -y python3",
       "verify": "python3 --version", "why": "runs the PoC script"}
    ],
    "python_packages": [],
    "credentials": [
      {"role": "victim_user", "how_to_obtain": "register a second free account",
       "env_var": "DEMO_VICTIM_ID"}
    ]
  },
  "setup": [
    {"step": 1, "title": "Export the victim id",
     "cmd": "export DEMO_VICTIM_ID=1042", "expected": "no output"}
  ],
  "reproduce": [
    {"step": 1, "title": "Request the victim object as yourself",
     "cmd": "curl -s -H \"Cookie: session=$DEMO_ACTOR_SESSION\" https://api.demo.test/v1/users/$DEMO_VICTIM_ID",
     "expected": "a JSON profile whose email is not yours",
     "on_failure": "a 403 means the fix is deployed, a 404 means the id is wrong"}
  ],
  "verify": {
    "success_criteria": "the response body contains an email address you do not own",
    "expected_excerpt": "\"email\":\"v****@example.com\"",
    "negative_control": "request the same URL with a random id; expect 404, not a profile",
    "false_positive_traps": [
      "a 200 alone proves nothing — check the body, since non-existent ids may also return 200"
    ]
  },
  "poc_files": ["poc/exploit.py"],
  "evidence_files": ["evidence/two-identity-comparison.txt"],
  "gotchas": ["the id must belong to the same tenant or the API 404s before the auth check"]
}
JSON

  check "repro_pack builds" 0 python3 tools/repro_pack.py \
    --finding-dir "$FD" \
    --verdict "$RUN/assets/api.demo.test/artifacts/validated/F-001.json" \
    --seven-q "$RUN/assets/api.demo.test/seven-questions/F-001.json" \
    --out "$RUN/repro/F-001"

  RB="$RUN/repro/F-001/RUNBOOK.md"
  if [[ -f "$RB" ]]; then
    ok "RUNBOOK.md written ($(wc -l < "$RB") lines)"
    python3 - "$RB" "$RUN/repro/F-001" <<'PY'
import os, re, sys, zipfile
rb, out = sys.argv[1], sys.argv[2]
text = open(rb, encoding="utf-8").read()
low = text.lower()

# A runbook is only useful if it is FOLLOWABLE. These checks target the failure mode where
# it renders as prose about the bug instead of instructions for reproducing it. Deliberately
# structural rather than tied to any particular variable name: the renderer derives its own
# credential variable convention, and pinning that here would test the fixture, not the tool.
for heading in ("prerequisites", "setup", "reproduction", "verification", "troubleshooting"):
    assert f"## {heading}" in low, f"RUNBOOK.md has no {heading.upper()} section"
# Tools must come with an install command, or the reader cannot get started on a clean box.
assert "apt-get install" in low or "pip install" in low, "no install command anywhere"
# Credentials must be exported by NAME, never printed as values.
assert re.search(r"export [A-Z_][A-Z0-9_]*=", text), "no credential export line"
assert "never paste a real customer" in low or "never paste" in low, "no credential-safety note"
# The three things that make a reproduction conclusive rather than suggestive.
assert "success criteria" in low, "no success criteria"
assert "negative control" in low, "no negative control"
assert "fool yourself" in low or "false positive" in low, "no false-positive traps listed"

for banned in ("as described above", "as above", "similarly", "repeat for each", "TODO", "TBD",
               "lorem ipsum", "xxx"):
    assert banned not in low, f"RUNBOOK.md contains placeholder prose: {banned!r}"
assert len(re.findall(r"```", text)) >= 6, "commands are not in fenced blocks"

verify = os.path.join(out, "pack", "verify.sh")
assert os.path.isfile(verify), "pack/verify.sh missing"
assert os.access(verify, os.X_OK), "verify.sh is not executable"
zips = [f for f in os.listdir(out) if f.endswith(".zip")]
assert zips, "no pack zip produced"
with zipfile.ZipFile(os.path.join(out, zips[0])) as z:
    names = z.namelist()
    # Entries are prefixed with the pack root ("pack/…"), so match on the path SUFFIX
    # rather than the start of the string.
    def has(want):
        return any(n == want.rstrip("/") or n.endswith("/" + want.rstrip("/"))
                   or ("/" + want) in n for n in names)
    for want in ("poc/", "evidence/", "env/", "verify.sh"):
        assert has(want), f"zip is missing {want}; entries: {names}"
print(f"      followable runbook ({len(text.splitlines())} lines); pack has "
      f"poc/ evidence/ env/ verify.sh; zip={zips[0]} ({len(names)} entries)")
PY
    ok "runbook and pack pass the deliverable checks"

    # verify.sh must actually be runnable shell, not just present.
    bash -n "$RUN/repro/F-001/pack/verify.sh" 2>/dev/null \
      && ok "pack/verify.sh is syntactically valid shell" \
      || bad "pack/verify.sh is not valid shell"
  else
    bad "RUNBOOK.md was not produced"
  fi

  # The gate must refuse to build a pack from an unconfirmed finding. That refusal is the
  # whole reason the deliverable can be trusted.
  python3 - "$RUN" <<'PY'
import json, sys
p = f"{sys.argv[1]}/assets/api.demo.test/artifacts/validated/F-001.json"
d = json.load(open(p)); d["verdict"] = "CURE"; json.dump(d, open(p, "w"), indent=1)
PY
  check "repro_pack refuses a non-CONFIRMED verdict" 1 python3 tools/repro_pack.py \
    --finding-dir "$FD" \
    --verdict "$RUN/assets/api.demo.test/artifacts/validated/F-001.json" \
    --seven-q "$RUN/assets/api.demo.test/seven-questions/F-001.json" \
    --out "$RUN/repro/F-001-refused"

  # restore CONFIRMED so the remaining gate tests exercise the seven-question side
  python3 - "$RUN" <<'PY'
import json, sys
p = f"{sys.argv[1]}/assets/api.demo.test/artifacts/validated/F-001.json"
d = json.load(open(p)); d["verdict"] = "CONFIRMED"; json.dump(d, open(p, "w"), indent=1)
PY
  SQ="$RUN/assets/api.demo.test/seven-questions/F-001.json"
  VD="$RUN/assets/api.demo.test/artifacts/validated/F-001.json"

  # The seven answers ARE the gate. A hand-written verdict:"PASS" over seven failing answers
  # must not produce a pack — otherwise the recorded 7-question JSON has no evidentiary value.
  python3 - "$SQ" <<'PY'
import json, sys
p = sys.argv[1]; d = json.load(open(p))
for k in d["answers"]:
    d["answers"][k] = {"pass": False, "detail": "not actually checked"}
d["verdict"] = "PASS"
json.dump(d, open(p, "w"), indent=1)
PY
  check "repro_pack refuses PASS over seven failing answers" 1 python3 tools/repro_pack.py \
    --finding-dir "$FD" --verdict "$VD" --seven-q "$SQ" --out "$RUN/repro/F-001-7q-fail"

  # An unanswered question is not a pass either.
  python3 - "$SQ" <<'PY'
import json, sys
p = sys.argv[1]; d = json.load(open(p))
d["answers"] = {k: {"pass": True} for k in d["answers"] if k != "q6_impact_proven"}
json.dump(d, open(p, "w"), indent=1)
PY
  # An unanswered question is not a pass. Exit 2 rather than 1 is correct here: the record
  # violates its own schema, so it is malformed input, not a finding that failed the gate —
  # the schema check catches it before the gate logic is even consulted. The gate's own
  # missing-key check is the second line of defence for `--no-validate` runs.
  check "repro_pack refuses a schema-invalid (unanswered question) record" 2 \
    python3 tools/repro_pack.py --finding-dir "$FD" --verdict "$VD" --seven-q "$SQ" \
    --out "$RUN/repro/F-001-7q-missing"
  check "...and still refuses it with --no-validate (gate's own check)" 1 \
    python3 tools/repro_pack.py --finding-dir "$FD" --verdict "$VD" --seven-q "$SQ" \
    --out "$RUN/repro/F-001-7q-missing-nv" --no-validate

  python3 - "$SQ" <<'PY'
import json, sys
p = sys.argv[1]; d = json.load(open(p))
d["answers"]["q6_impact_proven"] = {"pass": True, "detail": "victim field present in the body"}
json.dump(d, open(p, "w"), indent=1)
PY
  check "repro_pack accepts a fully-answered PASS" 0 python3 tools/repro_pack.py \
    --finding-dir "$FD" --verdict "$VD" --seven-q "$SQ" --out "$RUN/repro/F-001-ok"

  # Path containment: finding.json is written by an agent whose input is a live target, so a
  # traversal here is a prompt-injection payload that would copy a local file into the pack
  # the operator hands to the platform.
  cp "$FD/finding.json" "$WORK/finding.bak"
  python3 - "$FD" <<'PY'
import json, sys
p = f"{sys.argv[1]}/finding.json"; d = json.load(open(p))
d["poc"]["script"] = "../../../../../../etc/hostname"
json.dump(d, open(p, "w"), indent=1)
PY
  check "repro_pack refuses a poc.script that escapes the finding dir" 2 \
    python3 tools/repro_pack.py --finding-dir "$FD" --verdict "$VD" --seven-q "$SQ" \
    --out "$RUN/repro/F-001-escape"
  if [[ -z "$(find "$RUN/repro/F-001-escape" -name 'hostname' 2>/dev/null)" ]]; then
    ok "no out-of-tree file reached the pack"
  else
    bad "an out-of-tree file was copied into the pack"
  fi

  python3 - "$FD" <<'PY'
import json, sys
p = f"{sys.argv[1]}/finding.json"; d = json.load(open(p))
d["poc"]["script"] = "poc/exploit.py"
d["finding_id"] = "../../../evil"
json.dump(d, open(p, "w"), indent=1)
PY
  check "repro_pack refuses a finding_id that escapes --out" 2 python3 tools/repro_pack.py \
    --finding-dir "$FD" --verdict "$VD" --seven-q "$SQ" --out "$RUN/repro/F-001-id"
  cp "$WORK/finding.bak" "$FD/finding.json"
else
  echo "  SKIP  repro_pack.py not present"
fi

# ---------------------------------------------------------------------------
step "8. workflow lint — the harness wraps the body, so plain node --check lies"
# ---------------------------------------------------------------------------
if [[ -f tools/workflow_lint.sh ]]; then
  check "workflow_lint" 0 bash tools/workflow_lint.sh
else
  echo "  SKIP  workflow_lint.sh not present"
fi

# The orchestration layer only exists if something points at it. These scripts are launched by
# reading the file and passing its contents to the `workflow` tool, so a skill that never names
# workflows/ means an operator typing /bbh never finds the automated path — the workflow files
# become dead code that looks like a feature.
missing_refs=()
for f in skills/bbh*/SKILL.md; do
  grep -q "workflows/bbh-hunt.js" "$f" || missing_refs+=("$(basename "$(dirname "$f")")")
done
if [[ ${#missing_refs[@]} -eq 0 ]]; then
  ok "all 10 bbh skills point at the orchestrated path"
else
  bad "these skills never mention workflows/bbh-hunt.js: ${missing_refs[*]}"
fi
if grep -q "resume_from" skills/bbh/SKILL.md; then
  ok "/bbh documents the checkpoint/resume protocol"
else
  bad "/bbh does not document how to resume a checkpointed run"
fi
# The workflow cannot pause; the protocol is 'return an envelope and let the caller re-invoke'.
# If the scripts stopped returning envelopes the documented protocol would be a lie.
if grep -q "CHECKPOINT_1" workflows/bbh-hunt.js && grep -q "resume_from" workflows/bbh-hunt.js; then
  ok "bbh-hunt.js implements the checkpoint envelope + resume_from protocol"
else
  bad "bbh-hunt.js no longer implements the checkpoint protocol its skills document"
fi

# ---------------------------------------------------------------------------
step "9. context guard — the bundle must not inject instructions"
# ---------------------------------------------------------------------------
check "context_guard clean" 0 python3 tools/context_guard.py --quiet

# ---------------------------------------------------------------------------
printf '\n\033[1m%s\033[0m\n' "RESULT: $PASS passed, $FAIL failed"
[[ "$FAIL" == "0" ]] || exit 1
