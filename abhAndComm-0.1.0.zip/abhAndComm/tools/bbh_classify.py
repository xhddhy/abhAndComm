#!/usr/bin/env python3
"""Stage 1 RECON-LITE: bucket an upstream Agentic-Bug-Hunter recon tree into
``bbh/classification/v1``.

WHY THIS TOOL EXISTS
--------------------
This bundle deliberately removed ABH's subdomain-enumeration and nuclei phases:
the program already told us which assets are in scope, and scanning for more is
how a "known-asset" engagement turns into an out-of-scope incident. What is left
of the recon tree is still valuable — live URLs, gf candidate lists, parameter
names, JS secret hits, exposed admin paths, open ports — but it is a pile of
text files with no shared vocabulary. Every later stage (queue -> cells -> slice)
needs one machine-readable, evidence-citing classification, and it needs the
hosts the program excluded to be dropped loudly rather than quietly scanned.

So this tool reads files and classifies. It never sends a packet. It does not
know how to enumerate subdomains, and it will not invent an entry for an input
file that was absent — a missing phase must stay visibly missing, so that
"nothing was found" and "nothing was looked at" remain distinguishable
downstream (the ``negative_findings`` list is exactly that distinction).

The bucketing is expressed as the module-level rule tables below rather than as
scattered ``if`` statements, because a rule that cannot be read and argued with
is a rule nobody will audit.

Usage
-----
    python3 tools/bbh_classify.py \
        --recon-dir recon/acme.com \
        --scope runs/acme-2026-09/scope.json \
        --out runs/acme-2026-09/classification.json

Exit codes: 0 = classified, 1 = real negative (recon tree readable but no
in-scope host in it), 2 = bad input (recon dir or scope unreadable).
"""
from __future__ import annotations

import argparse
import fnmatch
import json
import os
import re
import sys
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable, Sequence
from urllib.parse import parse_qsl, urlsplit

try:  # optional dependency: without it we skip the schema self-check, loudly.
    import jsonschema
except ImportError:  # pragma: no cover - exercised on a bare python3
    jsonschema = None

SCHEMA_ID = "bbh/classification/v1"
TOOL = "bbh_classify.py"

# ---------------------------------------------------------------------------
# Bucketing rule tables — THE substance of this tool.
#
# Each rule is (bucket, regex, human reason). A URL is tested against every rule
# in every table; buckets are NOT exclusive, because ``/api/v1/login`` really is
# both an API endpoint and an auth path, and collapsing that would hide one of
# the two leads the queue is supposed to carry.
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class Rule:
    """One auditable path-classification rule."""

    bucket: str
    pattern: str  # regex source, matched against the URL path (and query for some)
    reason: str
    kind: str | None = None  # auth_paths: the schema's ``kind`` enum value
    where: str = "path"  # path | url | host


API_ENDPOINT_RULES: tuple[Rule, ...] = (
    Rule("api_endpoints", r"/api(?:/|$)", "path segment /api/"),
    Rule("api_endpoints", r"/v[0-9]+(?:/|$)", "versioned path /vN/ (or /vN)"),
    Rule("api_endpoints", r"/graphql(?:/|$)", "GraphQL endpoint"),
    Rule("api_endpoints", r"/gql(?:/|$)", "gql alias for GraphQL"),
    Rule("api_endpoints", r"/rest(?:/|$)", "REST path segment"),
    Rule("api_endpoints", r"/rpc(?:/|$)", "RPC endpoint"),
    Rule("api_endpoints", r"\.json(?:$|\?)", ".json document endpoint", where="url"),
    Rule("api_endpoints", r"\.(?:graphql|gql)(?:$|\?)", "GraphQL document", where="url"),
)

# Observing a JSON content-type is a signal independent of the path, so it is a
# predicate rather than a regex; see JSON_CONTENT_TYPE_HINTS.
JSON_CONTENT_TYPE_HINTS: tuple[str, ...] = (
    "application/json",
    "application/problem+json",
    "application/vnd.api+json",
    "json",
)

AUTH_PATH_RULES: tuple[Rule, ...] = (
    Rule("auth_paths", r"/login(?:/|$)", "login endpoint", kind="login"),
    Rule("auth_paths", r"/signin(?:/|$)", "sign-in endpoint", kind="login"),
    Rule("auth_paths", r"/logout(?:/|$)", "logout endpoint", kind="logout"),
    Rule("auth_paths", r"/signup(?:/|$)", "self-service signup", kind="signup"),
    Rule("auth_paths", r"/register(?:/|$)", "registration endpoint", kind="register"),
    Rule("auth_paths", r"/password(?:/|$)", "password handling endpoint", kind="password_reset"),
    Rule("auth_paths", r"/reset(?:/|$)", "reset endpoint (usually password)", kind="password_reset"),
    Rule("auth_paths", r"/forgot(?:/|$)", "forgot-credential endpoint", kind="password_reset"),
    Rule("auth_paths", r"/oauth(?:/|$)", "OAuth endpoint", kind="oauth"),
    Rule("auth_paths", r"/oidc(?:/|$)", "OIDC endpoint", kind="oidc"),
    Rule("auth_paths", r"/saml(?:/|$)", "SAML endpoint", kind="saml"),
    Rule("auth_paths", r"/sso(?:/|$)", "SSO endpoint", kind="sso"),
    Rule("auth_paths", r"/token(?:/|$)", "token endpoint", kind="token"),
    Rule("auth_paths", r"/session(?:/|$)", "session endpoint", kind="session"),
    Rule("auth_paths", r"/mfa(?:/|$)", "MFA endpoint", kind="mfa"),
    Rule("auth_paths", r"/2fa(?:/|$)", "2FA endpoint", kind="mfa"),
    Rule("auth_paths", r"/otp(?:/|$)", "OTP endpoint", kind="mfa"),
    Rule("auth_paths", r"/invite(?:/|$)", "invitation endpoint", kind="invite"),
    Rule("auth_paths", r"/verify(?:/|$)", "verification endpoint", kind="unknown"),
    Rule("auth_paths", r"/activate(?:/|$)", "account activation endpoint", kind="unknown"),
)

ADMIN_PATH_RULES: tuple[Rule, ...] = (
    Rule("admin_paths", r"/admin(?:/|$)", "administration path"),
    Rule("admin_paths", r"/manage(?:/|$)", "management path"),
    Rule("admin_paths", r"/console(?:/|$)", "console path"),
    Rule("admin_paths", r"/internal(?:/|$)", "internal-only path"),
    Rule("admin_paths", r"/debug(?:/|$)", "debug path"),
    Rule("admin_paths", r"/actuator(?:/|$)", "Spring Actuator"),
    Rule("admin_paths", r"/jenkins(?:/|$)", "Jenkins"),
    Rule("admin_paths", r"/grafana(?:/|$)", "Grafana"),
    Rule("admin_paths", r"/kibana(?:/|$)", "Kibana"),
    Rule("admin_paths", r"/phpmyadmin(?:/|$)", "phpMyAdmin"),
    Rule("admin_paths", r"/wp-admin(?:/|$)", "WordPress admin"),
    Rule("admin_paths", r"/server-status(?:/|$)", "Apache server-status"),
    Rule("admin_paths", r"/swagger(?:/|$)", "Swagger UI / API docs"),
    Rule("admin_paths", r"/\.git(?:/|$)", "exposed .git"),
    Rule("admin_paths", r"/\.env(?:$|/|\?)", "exposed .env"),
)

# URL-shape rules used for the host-level ``admin_paths`` sweep over the crawl
# corpus (urls/all.txt, live/urls.txt, dirs output) — kept identical to the
# table above so an auditor reads one list, not two.
ALL_PATH_RULE_TABLES: tuple[tuple[Rule, ...], ...] = (
    API_ENDPOINT_RULES,
    AUTH_PATH_RULES,
    ADMIN_PATH_RULES,
)

# ---------------------------------------------------------------------------
# Input catalogue. Missing files are NORMAL: the upstream pipeline is allowed to
# be partially populated (phases fail, tools are absent). Every input is
# reported with a line count so the operator can see which phase actually ran.
# ``aliases`` covers the two spellings upstream uses across versions.
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class InputSpec:
    label: str
    glob: str
    kind: str
    aliases: tuple[str, ...] = ()
    phase: str = ""
    optional: bool = True


INPUT_SPECS: tuple[InputSpec, ...] = (
    InputSpec("live/urls.txt", "live/urls.txt", "live",
              aliases=("live/httpx_full.txt",), phase="phase 2 http probe"),
    InputSpec("urls/all.txt", "urls/all.txt", "urls", phase="phase 4 url merge"),
    InputSpec("candidates/*.txt", "candidates/*.txt", "candidates", phase="gf candidate lists"),
    InputSpec("api-endpoints.txt", "api-endpoints.txt", "api",
              aliases=("urls/api_endpoints.txt",), phase="phase 4 api filter"),
    InputSpec("params/*.txt", "params/*.txt", "params", phase="phase 7 parameter discovery"),
    InputSpec("js/endpoints.txt", "js/endpoints.txt", "js_endpoints", phase="phase 5 js analysis"),
    InputSpec("js/secrets.txt", "js/secrets.txt", "js_secrets",
              aliases=("js/potential_secrets.txt",), phase="phase 5 js secrets"),
    InputSpec("config-exposure.txt", "config-exposure.txt", "config",
              aliases=("exposure/config_files.txt",), phase="phase 6 exposure sweep"),
    InputSpec("admin/*.txt", "admin/*.txt", "admin", phase="phase 6 admin sweep"),
    InputSpec("ports/*.txt", "ports/*.txt", "ports", phase="phase 3 port scan"),
    InputSpec("cloud/*.txt", "cloud/*.txt", "cloud", phase="cloud recon"),
    InputSpec("takeover/*.txt", "takeover/*.txt", "takeover", phase="takeover scan"),
)

# gf pattern -> the class of parameter signal it implies. Used by the queue for
# scoring AND printed here as evidence, so one table explains both.
GF_PATTERN_HINTS: dict[str, str] = {
    "ssrf": "server_fetched_url",
    "idor": "object_reference",
    "sqli": "injection",
    "lfi": "file_path",
    "redirect": "url_redirect",
    "xss": "html_sink",
}

# params/<stem>.txt -> tool that produced it (the schema's ``source`` field).
PARAM_TOOL_HINTS: tuple[tuple[str, str], ...] = (
    ("arjun", "arjun"),
    ("x8", "x8"),
    ("param_frequency", "crawl:param_frequency"),
    ("unique_params", "crawl:unique_params"),
    ("interesting_params", "crawl:interesting_params"),
)

# ---------------------------------------------------------------------------
# Secret shapes. Order matters: the first matching shape wins, so the specific
# provider formats are listed before the generic assignment patterns.
# ``kind`` is the classification.schema.json enum value.
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class SecretShape:
    name: str
    pattern: str
    kind: str  # api_key | token | credential | endpoint | internal_host | bucket | config | other
    why: str


SECRET_SHAPES: tuple[SecretShape, ...] = (
    SecretShape("aws_access_key_id", r"\bAKIA[0-9A-Z]{16}\b", "credential",
                "AWS access key id shape AKIA + 16 uppercase alphanumerics"),
    SecretShape("aws_secret_assignment", r"(?i)aws[_\-]?secret[_\-]?access[_\-]?key\s*[:=]\s*\S+",
                "credential", "AWS secret access key assignment"),
    SecretShape("google_api_key", r"\bAIza[0-9A-Za-z_\-]{35}\b", "api_key",
                "Google API key shape AIza + 35 chars"),
    SecretShape("slack_token", r"\bxox[abprs]-[0-9A-Za-z\-]{10,}\b", "token",
                "Slack token shape xox?-"),
    SecretShape("github_token", r"\bgh[pousr]_[0-9A-Za-z]{20,}\b", "token",
                "GitHub token shape gh?_"),
    SecretShape("stripe_secret", r"\bsk_live_[0-9A-Za-z]{16,}\b", "credential",
                "Stripe live secret key"),
    SecretShape("stripe_publishable", r"\bpk_live_[0-9A-Za-z]{16,}\b", "api_key",
                "Stripe live publishable key"),
    SecretShape("jwt", r"\beyJ[0-9A-Za-z_\-]{8,}\.[0-9A-Za-z_\-]{8,}\.[0-9A-Za-z_\-]{4,}\b",
                "token", "JWT: base64url header.payload.signature"),
    SecretShape("private_key", r"-----BEGIN [A-Z ]*PRIVATE KEY-----", "credential",
                "PEM private key header"),
    SecretShape("s3_bucket", r"\b[a-z0-9][a-z0-9.\-]{1,61}[a-z0-9]\.s3[.\-][a-z0-9\-]*\.?amazonaws\.com",
                "bucket", "S3 virtual-host bucket URL"),
    SecretShape("s3_uri", r"\bs3://[a-z0-9][a-z0-9.\-/]{1,80}", "bucket", "s3:// bucket URI"),
    SecretShape("gs_uri", r"\bgs://[a-z0-9][a-z0-9.\-/]{1,80}", "bucket", "gs:// bucket URI"),
    SecretShape("credential_assignment",
                r"(?i)\b(?:api[_\-]?key|apikey|api[_\-]?secret|client[_\-]?secret|secret[_\-]?key|"
                r"password|passwd|pwd|private[_\-]?key)\b\s*[:=]\s*[\"']?([^\s\"',;]{6,})",
                "credential", "api_key/password style assignment"),
    SecretShape("token_assignment",
                r"(?i)\b(?:access[_\-]?token|auth[_\-]?token|refresh[_\-]?token|bearer|"
                r"session[_\-]?id|id[_\-]?token|token)\b\s*[:=]\s*[\"']?([^\s\"',;]{6,})",
                "token", "token/session style assignment"),
    SecretShape("internal_host",
                r"\b(?:[a-z0-9\-]+\.)+(?:internal|intranet|corp|local|lan|priv|private|dev|"
                r"staging|stage|test|qa)\b",
                "internal_host", "internal/development hostname suffix"),
    SecretShape("private_ip", r"\b(?:10\.\d{1,3}\.\d{1,3}\.\d{1,3}|192\.168\.\d{1,3}\.\d{1,3}|"
                             r"172\.(?:1[6-9]|2\d|3[01])\.\d{1,3}\.\d{1,3})\b",
                "internal_host", "RFC1918 address leaked in a bundle"),
    SecretShape("config_file", r"(?i)\b[\w./\-]+\.(?:env|ini|conf|config|ya?ml|properties|tfstate|pem|p12|key)\b",
                "config", "config/credential file reference"),
    SecretShape("endpoint_url", r"https?://[A-Za-z0-9._~:\-/%?=&#+@]{4,}", "endpoint",
                "absolute endpoint URL"),
)

# Free-text line prefixes we understand: "<file>:<line>:<kind>:<value>",
# "<file>:<line>: <value>", "<kind>: <value>", "<kind>=<value>".
# NOTE the file token is non-greedy \S+? (not [^\s:]+): bundle URLs contain a
# colon ("https://host/app.js:12:...") and excluding ':' made every real
# "file:line:kind:value" line fall through to the free-text branch.
SECRET_LINE_RE = re.compile(
    r"^(?P<file>\S+?):(?P<line>\d+):(?P<kind>[A-Za-z_][A-Za-z0-9_\-]*):\s*(?P<value>.+)$")
SECRET_FILELINE_RE = re.compile(r"^(?P<file>\S+?):(?P<line>\d+):\s*(?P<rest>.+)$")
SECRET_KV_RE = re.compile(r"^(?P<kind>[A-Za-z_][A-Za-z0-9_\-]*)\s*[:=]\s*(?P<value>.+)$")

# ---------------------------------------------------------------------------
# httpx parsing. ``live/urls.txt`` is written by upstream as the first column of
# httpx output (URL only) and in other revisions as the full httpx line, so both
# are accepted; ``live/httpx_full.txt`` enriches URL-only lines when present.
# httpx CLI shape:  URL [status] [title] [tech,tech] [content-length] [server]
# ---------------------------------------------------------------------------

BRACKET_RE = re.compile(r"\[([^\]]*)\]")
ANSI_RE = re.compile(r"\x1b\[[0-9;]*m")
NMAP_NORMAL_RE = re.compile(
    r"^(?P<port>\d{1,5})/(?P<proto>tcp|udp)\s+(?P<state>open|open\|filtered|filtered|closed)\s+"
    r"(?P<rest>.*)$", re.I)
NMAP_GREP_PORT_RE = re.compile(
    r"(?P<port>\d{1,5})/(?P<state>open|closed|filtered)/(?P<proto>\w+)//"
    r"(?P<svc>[^/]*)//(?P<product>[^/]*)/")
NMAP_SCAN_HOST_RE = re.compile(
    r"^Nmap scan report for (?:(?P<name>\S+)\s+\((?P<ip>[\d.a-fA-F:]+)\)|(?P<ip2>[\d.a-fA-F:]+))\s*$")
NMAP_GREP_HOST_RE = re.compile(r"^Host:\s+(?P<ip>[\d.a-fA-F:]+)\s*\(")
OPEN_PORT_ONLY_RE = re.compile(r"^(?P<port>\d{1,5})/(?P<state>open|closed|filtered)$", re.I)
# Structural nmap lines (headers, host lines, timing) are not port records and
# are not "unparsed data" either — reporting them as skips would bury the real
# skips in noise.
NMAP_BOILERPLATE_RE = re.compile(
    r"^(?:Starting Nmap|Nmap scan report|Nmap done|Host is up|Host seems down|"
    r"PORT\s+STATE|Not shown:|Service detection performed|OS detection performed|"
    r"MAC Address:|Device type:|Running:|Aggressive OS guesses:|Too many fingerprints|"
    r"Warning:|Initiating|Completed|SERVICE\s+STATE)", re.I)
PORT_SERVICE_SPLIT_RE = re.compile(r"^(?P<product>.*?)[\s/]+(?P<version>\d[\w.\-]*)$")
# A version token: 1.2, 1.2.3, 8.9p1, 1.1.1k, 3.6.0-rc1.
VERSION_TOKEN_RE = re.compile(r"\d+\.\d+(?:\.\d+)*(?:[a-zA-Z]\d*)?(?:[-+~][\w.\-]+)?")
PARAM_NAME_RE = re.compile(r"^[A-Za-z_][A-Za-z0-9_.\[\]\-]{0,63}$")
KNOWN_SERVER_NAMES = (
    "nginx", "apache", "httpd", "iis", "microsoft-iis", "tomcat", "jetty", "gunicorn",
    "uvicorn", "openresty", "caddy", "envoy", "traefik", "cloudflare", "lighttpd",
    "kestrel", "werkzeug", "express", "node.js", "php", "litespeed", "haproxy",
)
KNOWN_TECH_NAMES = (
    "react", "vue", "angular", "next.js", "nuxt", "svelte", "jquery", "bootstrap",
    "django", "flask", "fastapi", "rails", "laravel", "spring", "express", "asp.net",
    "wordpress", "drupal", "joomla", "graphql", "typescript", "webpack", "vite",
    "cloudflare", "akamai", "fastly", "amazon cloudfront", "amazon s3", "s3",
    "google analytics", "google tag manager", "sentry", "swagger", "openapi",
)


def _norm_url(raw: str) -> str | None:
    """Normalise a URL-ish token; return None when it is not usable."""
    raw = raw.strip().strip("\"'")
    if not raw:
        return None
    if raw.startswith("//"):
        raw = "https:" + raw
    if not re.match(r"^[a-zA-Z][a-zA-Z0-9+.\-]*://", raw):
        return None
    parts = urlsplit(raw)
    if not parts.netloc:
        return None
    return raw


def _resolve(raw: str, base: str) -> str | None:
    """Resolve a bare path or a relative URL against the recon target base."""
    raw = raw.strip().strip("\"',")
    if not raw or raw.startswith("#"):
        return None
    url = _norm_url(raw)
    if url:
        return url
    if raw.startswith("/"):
        return base.rstrip("/") + raw
    if re.match(r"^[\w.\-]+\.\w{2,}(?:[:/]|$)", raw) and " " not in raw:
        # host[:port]/path without a scheme
        return "https://" + raw
    return None


def asset_tag_for(url: str) -> tuple[str, str]:
    """Return (asset_tag, host). asset_tag keeps a non-default port."""
    parts = urlsplit(url)
    host = (parts.hostname or "").lower().rstrip(".")
    try:
        port = parts.port
    except ValueError:
        port = None
    if not host:
        return url.lower(), host
    if port and port not in (80, 443):
        return f"{host}:{port}", host
    return host, host


def is_tls(url: str) -> bool:
    parts = urlsplit(url)
    try:
        port = parts.port
    except ValueError:
        port = None
    return parts.scheme.lower() == "https" or port in (443, 8443, 9443, 10443)


@dataclass
class LiveRecord:
    """What httpx told us about one URL. version stays None unless observed."""

    url: str
    status_code: int | None = None
    title: str | None = None
    tech: list[str] = field(default_factory=list)
    server: str | None = None
    content_length: str | None = None
    version: str | None = None
    source: str = ""


def _looks_like_server(token: str) -> bool:
    if VERSION_TOKEN_RE.search(token):
        return True
    low = token.strip().lower()
    return any(low == s or low.startswith(s + "/") for s in KNOWN_SERVER_NAMES)


def _looks_like_tech(token: str) -> bool:
    return token.strip().lower() in KNOWN_TECH_NAMES


def parse_httpx_line(line: str, source: str) -> LiveRecord | None:
    """Parse one httpx output line in either CLI, CSV or JSON-lines shape."""
    line = ANSI_RE.sub("", line).strip()
    if not line:
        return None
    if line.startswith("{"):
        try:
            obj = json.loads(line)
        except json.JSONDecodeError:
            return None
        url = obj.get("url") or obj.get("input") or obj.get("final_url")
        if not isinstance(url, str):
            return None
        tech = obj.get("tech") or obj.get("technologies") or []
        if isinstance(tech, str):
            tech = [tech]
        server = obj.get("webserver") or obj.get("server") or obj.get("web_server")
        rec = LiveRecord(
            url=url,
            status_code=obj.get("status_code") or obj.get("status"),
            title=obj.get("title"),
            tech=[str(t) for t in tech if t],
            server=str(server) if server else None,
            content_length=str(obj.get("content_length")) if obj.get("content_length") else None,
            source=source,
        )
        _promote_server(rec)
        rec.version = _version_from(rec.server, rec.tech)
        return rec

    first, _, rest = line.partition(" ")
    url = _norm_url(first)
    if url is None:
        return None
    groups = [g.strip() for g in BRACKET_RE.findall(rest)]
    rec = LiveRecord(url=url, source=source)
    title_seen = False
    for g in groups:
        if not g:
            continue
        if rec.status_code is None and re.fullmatch(r"\d{3}", g):
            rec.status_code = int(g)
            continue
        if re.fullmatch(r"\d[\d,]*", g) and rec.content_length is None and rec.status_code is not None:
            rec.content_length = g
            continue
        if "," in g:
            rec.tech.extend(t.strip() for t in g.split(",") if t.strip())
            continue
        if _looks_like_server(g):
            if rec.server is None:
                rec.server = g
            else:
                rec.tech.append(g)
            continue
        if _looks_like_tech(g):
            rec.tech.append(g)
            continue
        if not title_seen:
            rec.title = g
            title_seen = True
            continue
        rec.tech.append(g)
    _promote_server(rec)
    rec.version = _version_from(rec.server, rec.tech)
    return rec


def _promote_server(rec: LiveRecord) -> None:
    """When httpx did not emit a separate server field, take it from tech.

    ``-tech-detect`` reports nginx/apache/IIS as technologies; upstream often
    runs without ``-web-server``, so the banner is only visible there. Promote
    the first known server name and keep it in ``tech`` too — dropping it would
    lose the fact that the scanner reported it.
    """
    if rec.server:
        return
    for item in rec.tech:
        base = item.strip().lower().split("/")[0]
        if base in KNOWN_SERVER_NAMES:
            rec.server = item.strip()
            return


def _version_from(server: str | None, tech: Sequence[str]) -> str | None:
    """Return a version ONLY when a real version token was observed."""
    for candidate in ([server] if server else []) + list(tech):
        if not candidate:
            continue
        m = VERSION_TOKEN_RE.search(candidate)
        if m:
            return m.group(0)
    return None


# ---------------------------------------------------------------------------
# Scope
# ---------------------------------------------------------------------------


@dataclass
class ScopeMatch:
    asset_id: str
    apex: bool
    how: str
    path_exclusions: tuple[str, ...] = ()


class ScopeIndex:
    """scope.json -> host lookups. A host that matches nothing is out of scope."""

    def __init__(self, doc: dict[str, Any]):
        self.engagement = str(doc.get("engagement") or "")
        self.assets: list[dict[str, Any]] = [a for a in (doc.get("assets") or []) if isinstance(a, dict)]
        self.out_of_scope: list[str] = [str(p) for p in (doc.get("out_of_scope") or [])]
        self.by_value: dict[str, dict[str, Any]] = {}
        self.wildcards: list[tuple[str, dict[str, Any]]] = []
        for a in self.assets:
            value = self._host_of(str(a.get("value") or ""))
            if not value:
                continue
            if value.startswith("*."):
                self.wildcards.append((value[2:].lower(), a))
            else:
                self.by_value.setdefault(value, a)

    @staticmethod
    def _host_of(value: str) -> str:
        value = value.strip().lower()
        if "://" in value:
            value = urlsplit(value).hostname or ""
        return value.rstrip(".").split("/")[0].split(":")[0]

    def excluded(self, host: str) -> str | None:
        host = host.lower().rstrip(".")
        for pat in self.out_of_scope:
            p = self._host_of(pat) or pat.lower()
            if p.startswith("*."):
                if host.endswith("." + p[2:]):
                    return f"matches out_of_scope wildcard {pat!r}"
            elif host == p:
                return f"matches out_of_scope entry {pat!r}"
        return None

    def lookup(self, host: str) -> ScopeMatch | None:
        host = host.lower().rstrip(".")
        a = self.by_value.get(host)
        if a is not None:
            return ScopeMatch(str(a.get("asset_id") or host), bool(a.get("apex")),
                              "exact asset value", tuple(a.get("path_exclusions") or ()))
        for base, a in self.wildcards:
            if host.endswith("." + base):
                return ScopeMatch(str(a.get("asset_id") or host), bool(a.get("apex")),
                                  f"wildcard asset *.{base}", tuple(a.get("path_exclusions") or ()))
        for value, a in self.by_value.items():
            if a.get("apex") and host.endswith("." + value):
                return ScopeMatch(str(a.get("asset_id") or host), True,
                                  f"subdomain of apex asset {value}", tuple(a.get("path_exclusions") or ()))
        return None

    def path_excluded(self, match: ScopeMatch, url: str) -> str | None:
        path = urlsplit(url).path or "/"
        for glob in match.path_exclusions:
            if fnmatch.fnmatch(path, glob) or fnmatch.fnmatch(path, glob.rstrip("*") + "*"):
                return f"path {path} matches asset path_exclusion {glob!r}"
        return None


# ---------------------------------------------------------------------------
# Collector
# ---------------------------------------------------------------------------


class Collector:
    """Accumulates bucket entries and the per-host provenance behind them."""

    def __init__(self, target: str, scope: ScopeIndex | None):
        self.target = target
        self.base = f"https://{target}"
        self.scope = scope
        self.buckets: dict[str, dict[str, dict[str, Any]]] = {}
        self.hosts: dict[str, dict[str, Any]] = {}
        self.dropped: list[str] = []
        self._dropped_seen: set[str] = set()
        self.skipped: list[str] = []
        self.input_report: dict[str, dict[str, Any]] = {}
        self.notes: dict[str, list[str]] = {}

    # -- host bookkeeping ---------------------------------------------------
    def drop(self, reason: str) -> None:
        """Record a scope drop once, so one out-of-scope host is one printed line."""
        if reason in self._dropped_seen:
            return
        self._dropped_seen.add(reason)
        self.dropped.append(reason)

    def note(self, asset_tag: str, text: str) -> None:
        bucket = self.notes.setdefault(asset_tag, [])
        if text not in bucket:
            bucket.append(text)

    def host_meta(self, url: str) -> tuple[str, str] | None:
        """Resolve a URL to (asset_tag, host), applying scope. None = dropped."""
        asset_tag, host = asset_tag_for(url)
        if not host:
            self.skipped.append(f"{url} (no host)")
            return None
        if self.scope is None:
            self.hosts.setdefault(asset_tag, {"asset_id": asset_tag, "apex": False, "match": "no scope.json"})
            return asset_tag, host
        reason = self.scope.excluded(host)
        if reason:
            self.drop(f"host={host} reason=out_of_scope ({reason})")
            return None
        match = self.scope.lookup(host)
        if match is None:
            self.drop(f"host={host} reason=not in scope.json assets")
            return None
        pe = self.scope.path_excluded(match, url)
        if pe:
            self.drop(f"url={url} reason={pe}")
            return None
        self.hosts.setdefault(asset_tag, {"asset_id": match.asset_id, "apex": match.apex,
                                          "match": match.how})
        return asset_tag, host

    def add(self, bucket: str, url: str, entry: dict[str, Any], evidence: str) -> bool:
        got = self.host_meta(url)
        if got is None:
            return False
        asset_tag, _host = got
        entry = dict(entry)
        entry["url"] = url
        entry.setdefault("evidence", evidence)
        slot = self.buckets.setdefault(asset_tag, {}).setdefault(bucket, {})
        if url in slot:
            existing = slot[url]
            for key in ("params",):
                if isinstance(entry.get(key), list):
                    merged = list(existing.get(key) or [])
                    for item in entry[key]:
                        if item not in merged:
                            merged.append(item)
                    existing[key] = merged
            srcs = {s for s in str(existing.get("source") or "").split("+") if s}
            srcs |= {s for s in str(entry.get("source") or "").split("+") if s}
            if srcs:
                existing["source"] = "+".join(sorted(srcs))
            ev = {e for e in str(existing.get("evidence") or "").split("; ") if e}
            ev.add(evidence)
            existing["evidence"] = "; ".join(sorted(ev))
            return False
        slot[url] = entry
        return True


# ---------------------------------------------------------------------------
# Readers
# ---------------------------------------------------------------------------


def read_lines(path: Path) -> list[str]:
    try:
        text = path.read_text(encoding="utf-8", errors="replace")
    except OSError as exc:
        print(f"{TOOL}: WARN cannot read {path}: {exc}", file=sys.stderr)
        return []
    return [ln.rstrip("\n") for ln in text.splitlines()]


def host_from_ports_file(path: Path, lines: Sequence[str], target: str) -> str:
    for ln in lines:
        m = NMAP_SCAN_HOST_RE.match(ln.strip()) or NMAP_GREP_HOST_RE.match(ln.strip())
        if m:
            return (m.groupdict().get("name") or m.groupdict().get("ip")
                    or m.groupdict().get("ip2") or target)
    stem = path.stem
    if re.fullmatch(r"[\d.]+", stem) or "." in stem:
        return stem
    return target


def parse_ports(lines: Sequence[str]) -> tuple[list[dict[str, Any]], list[str]]:
    """Parse nmap normal, greppable, and ``80/open`` shapes. Returns (ports, skips)."""
    ports: list[dict[str, Any]] = []
    skips: list[str] = []
    seen: set[tuple[Any, ...]] = set()

    def emit(port: Any, service: str = "", product: str = "", version: str = "",
             evidence: str = "", state: str = "open") -> None:
        try:
            port_i = int(port)
        except (TypeError, ValueError):
            return
        if state != "open":
            return
        product = product.strip().strip("|")
        version = version.strip()
        if product and not version:
            m = PORT_SERVICE_SPLIT_RE.match(product)
            if m:
                product, version = m.group("product").strip(), m.group("version")
            else:
                # "OpenSSH 8.9p1 Ubuntu 3ubuntu0.4 (Ubuntu Linux; ...)" has no
                # trailing version token; the version is still really observed.
                vm = VERSION_TOKEN_RE.search(product)
                if vm:
                    version = vm.group(0)
        key = (port_i, service.lower(), product.lower(), version)
        if key in seen:
            return
        seen.add(key)
        ports.append({"port": port_i, "service": service.strip().strip("|").lower(),
                      "product": product, "version": version, "evidence": evidence})

    for raw in lines:
        ln = raw.strip()
        if not ln or ln.startswith("#"):
            continue
        m = NMAP_GREP_PORT_RE.search(ln)
        if m:
            emit(m.group("port"), m.group("svc"), m.group("product"), "", "nmap greppable", m.group("state"))
            continue
        m = NMAP_NORMAL_RE.match(ln)
        if m:
            rest = m.group("rest")
            parts = rest.split(None, 1)
            svc = parts[0] if parts else ""
            tail = parts[1] if len(parts) > 1 else ""
            emit(m.group("port"), svc, tail, "", "nmap normal", m.group("state"))
            continue
        m = OPEN_PORT_ONLY_RE.match(ln)
        if m:
            emit(m.group("port"), "", "", "", "open_ports.txt (port only)", m.group("state"))
            continue
        if NMAP_BOILERPLATE_RE.match(ln):
            continue
        skips.append(ln)
    return ports, skips


def redact(value: str) -> str:
    """Contract redaction: first 4 + last 4 chars, never the full secret."""
    value = value.strip().strip("\"'")
    if len(value) < 12:
        return "<redacted>"
    return f"{value[:4]}...{value[-4:]}"


def classify_secret(value: str) -> tuple[str, str]:
    """Return (kind, why) for a secret-shaped value, first matching shape wins."""
    for shape in SECRET_SHAPES:
        m = re.search(shape.pattern, value)
        if not m:
            continue
        # The generic assignment shapes capture only the value; prefer that for
        # the redaction so "api_key=SECRET" does not redact the key name too.
        if m.groups():
            return shape.kind, f"{shape.why} ({shape.name})"
        return shape.kind, f"{shape.why} ({shape.name})"
    return "other", "no known secret shape matched"


def extract_secret_value(value: str) -> str:
    """The substring to redact: the captured group when a shape captures one."""
    for shape in SECRET_SHAPES:
        m = re.search(shape.pattern, value)
        if m:
            return m.group(1) if m.groups() else m.group(0)
    return value


def parse_secret_line(line: str, filename: str, lineno: int) -> tuple[dict[str, Any] | None, str]:
    """Parse one js-secret line. Returns (entry, skip_reason)."""
    raw = ANSI_RE.sub("", line).strip()
    if not raw or raw.startswith("#"):
        return None, "empty or comment"
    url = ""
    kind_hint = ""
    value = raw
    m = SECRET_LINE_RE.match(raw)
    if m:
        url, kind_hint, value = m.group("file"), m.group("kind"), m.group("value")
    else:
        m = SECRET_FILELINE_RE.match(raw)
        if m:
            url, value = m.group("file"), m.group("rest")
        else:
            m = SECRET_KV_RE.match(raw)
            if m and not raw.lower().startswith("http"):
                kind_hint, value = m.group("kind"), m.group("value")
    if not value.strip():
        return None, "no value after prefix"
    kind, why = classify_secret(value)
    if kind_hint:
        why += f"; file-declared kind={kind_hint}"
    secret_value = extract_secret_value(value)
    url_out = url.strip()
    if not url_out or not re.match(r"^[a-zA-Z][\w+.\-]*://", url_out):
        if url_out and ("." in url_out or "/" in url_out):
            url_out = url_out
        else:
            url_out = f"{filename}#L{lineno}"
    context = raw.replace(secret_value, redact(secret_value))
    return ({"url": url_out, "kind": kind, "value_redacted": redact(secret_value),
             "context": context[:300], "evidence": f"{filename}:{lineno} ({why})"}, "")


def parse_cloud_line(line: str) -> tuple[dict[str, Any] | None, str]:
    raw = line.strip().lstrip("-* \t")
    if not raw or raw.startswith("#"):
        return None, "empty or comment"
    provider = "other"
    low = raw.lower()
    if re.search(r"\bs3\b|amazonaws|aws", low):
        provider = "aws"
    elif re.search(r"blob\.core\.windows\.net|azure|\.dfs\.core", low):
        provider = "azure"
    elif re.search(r"storage\.googleapis|gs://|gcp|google cloud", low):
        provider = "gcp"
    elif re.search(r"cloudflare|r2\.cloudflarestorage|workers\.dev", low):
        provider = "cloudflare"
    identifier = ""
    m = re.search(r"\b(?:s3|gs)://([A-Za-z0-9._\-/]+)", raw)
    if m:
        identifier = m.group(1).strip("/").split("/")[0]
    if not identifier:
        m = re.search(r"https?://([A-Za-z0-9._\-]+)", raw)
        if m:
            identifier = m.group(1)
    if not identifier:
        m = re.match(r"^([A-Za-z0-9._\-]{3,})(?:\s|$|[:,])", raw)
        if m:
            identifier = m.group(1)
    if not identifier:
        return None, "no bucket/host identifier on line"
    access = "unknown"
    for word in ("listable", "readable", "denied", "public", "private"):
        if word in low:
            access = {"public": "readable", "private": "denied"}.get(word, word)
            break
    return ({"provider": provider, "identifier": identifier, "access": access,
             "evidence": raw[:200]}, "")


def parse_takeover_line(line: str) -> tuple[dict[str, Any] | None, str]:
    raw = line.strip().lstrip("-* \t")
    if not raw or raw.startswith("#"):
        return None, "empty or comment"
    conf = "unknown"
    low = raw.lower()
    for word, value in (("dangling", "high"), ("unclaimed", "high"), ("nxdomain", "high"),
                        ("404", "medium"), ("no such bucket", "high"), ("probably", "low")):
        if word in low:
            conf = value
            break
    service = ""
    m = re.search(r"\[([^\]]+)\]", raw)
    if m:
        service = m.group(1).strip().lower()
        raw = raw.replace(m.group(0), " ")
    tokens = [t for t in re.split(r"[\s,>]+", raw) if t]
    cname = ""
    for t in tokens:
        t = t.strip("()")
        if "." in t and not t.startswith("http") and t.count(".") >= 1 and re.fullmatch(r"[\w.\-]+", t):
            if re.search(r"\.(?:com|net|org|io|co|dev|cloud|app|ai|me|info|biz|xyz)$", t, re.I) or "." in t:
                cname = t
    if not cname:
        return None, "no CNAME-looking token on line"
    host = ""
    for t in tokens:
        t = t.strip("()")
        if t != cname and re.fullmatch(r"[\w.\-]+", t) and "." in t:
            host = t
            break
    if not host:
        return None, "no host token on line (host and cname must both be present)"
    if host == cname:
        return None, "host and cname are the same token"
    return ({"host": host.lower(), "cname": cname.lower(), "service": service,
             "confidence": conf if conf in ("low", "medium", "high") else "low",
             "evidence": line.strip()[:200]}, "")


def params_from_line(line: str) -> tuple[str | None, list[str]]:
    """Return (url_or_None, parameter names) for a candidate/params line."""
    raw = line.strip()
    if not raw or raw.startswith("#"):
        return None, []
    url = _norm_url(raw)
    if url and "?" in url:
        names = [n for n, _ in parse_qsl(urlsplit(url).query, keep_blank_values=True) if n]
        return url, _dedupe(names)
    if url:
        return url, []
    if "?" in raw and raw.startswith("/"):
        return raw, _dedupe([n for n, _ in parse_qsl(raw.split("?", 1)[1], keep_blank_values=True) if n])
    if "=" in raw and "&" in raw and " " not in raw:
        names = [n for n, _ in parse_qsl(raw, keep_blank_values=True) if n]
        return None, _dedupe(names)
    if PARAM_NAME_RE.match(raw):
        return None, [raw]
    return None, []


def _dedupe(items: Iterable[str]) -> list[str]:
    out: list[str] = []
    for item in items:
        if item and item not in out:
            out.append(item)
    return out


# ---------------------------------------------------------------------------
# Main build
# ---------------------------------------------------------------------------


def build(recon_dir: Path, scope_path: Path | None, target: str) -> dict[str, Any]:
    scope: ScopeIndex | None = None
    if scope_path is not None:
        doc = json.loads(scope_path.read_text(encoding="utf-8"))
        scope = ScopeIndex(doc)
    col = Collector(target, scope)

    # ---- input discovery + per-input reporting ---------------------------
    file_index: dict[str, list[Path]] = {}
    for spec in INPUT_SPECS:
        files: list[Path] = []
        for pattern in (spec.glob,) + spec.aliases:
            found = sorted(p for p in recon_dir.glob(pattern) if p.is_file())
            for p in found:
                if p not in files:
                    files.append(p)
        file_index[spec.label] = files
        total = sum(len(read_lines(p)) for p in files)
        col.input_report[spec.label] = {
            "present": bool(files),
            "files": [str(p.relative_to(recon_dir)) for p in files],
            "lines": total,
            "phase": spec.phase,
        }

    # ---- live/httpx ------------------------------------------------------
    live_records: dict[str, LiveRecord] = {}
    for path in file_index["live/urls.txt"]:
        for line in read_lines(path):
            rec = parse_httpx_line(line, str(path.relative_to(recon_dir)))
            if rec:
                live_records.setdefault(rec.url, rec)
    # Enrich URL-only lines from the full httpx file when the tree has one.
    full = recon_dir / "live" / "httpx_full.txt"
    if full.is_file():
        for line in read_lines(full):
            rec = parse_httpx_line(line, "live/httpx_full.txt")
            if rec and (rec.url not in live_records
                        or (live_records[rec.url].status_code is None and rec.status_code is not None)):
                live_records[rec.url] = rec

    # ---- URL sources -----------------------------------------------------
    url_sources: list[tuple[str, str, str]] = []  # (url, source, file)
    line_status: dict[str, int] = {}
    for kind, label in (("urls", "urls/all.txt"), ("api", "api-endpoints.txt"),
                        ("js_endpoints", "js/endpoints.txt"), ("config", "config-exposure.txt"),
                        ("admin", "admin/*.txt")):
        for path in file_index[label]:
            for line in read_lines(path):
                raw = line.strip()
                if not raw or raw.startswith("#"):
                    continue
                # ffuf/httpx-style trailing "[200]" is a status, not part of the URL.
                m = re.match(r"^(?P<url>\S+)\s*\[(?P<status>\d{3})\]\s*$", raw)
                if m:
                    raw = m.group("url")
                    status_hint = int(m.group("status"))
                else:
                    raw = re.sub(r"\s*\[[^\]]*\]\s*$", "", raw)
                    status_hint = None
                url = _resolve(raw, col.base)
                if url is None:
                    if len(col.skipped) < 500:
                        col.skipped.append(f"{path.relative_to(recon_dir)}: not a URL/path: {raw[:80]!r}")
                    continue
                if status_hint is not None:
                    line_status.setdefault(url, status_hint)
                url_sources.append((url, kind, str(path.relative_to(recon_dir))))

    for path in file_index["live/urls.txt"]:
        for line in read_lines(path):
            rec = parse_httpx_line(line, str(path.relative_to(recon_dir)))
            if rec:
                url_sources.append((rec.url, "live", str(path.relative_to(recon_dir))))

    # Register every observed URL's host first. A host we looked at and found
    # nothing on must still appear (with empty buckets) and be listed in
    # negative_findings — otherwise "not looked at" and "looked at, empty"
    # collapse into the same absence.
    for url, _kind, _src in url_sources:
        col.host_meta(url)

    # ---- path bucketing --------------------------------------------------
    for url, kind, src in url_sources:
        parts = urlsplit(url)
        path = parts.path or "/"
        rec = live_records.get(url)
        for table in ALL_PATH_RULE_TABLES:
            for rule in table:
                target_text = url if rule.where == "url" else path
                if not re.search(rule.pattern, target_text, re.I):
                    continue
                evidence = f"{src}: matched {rule.reason}"
                if rule.bucket == "api_endpoints":
                    col.add("api_endpoints", url, {"method": "GET", "evidence": evidence,
                                                   "source": src}, evidence)
                elif rule.bucket == "auth_paths":
                    col.add("auth_paths", url, {"kind": rule.kind or "unknown", "evidence": evidence},
                            evidence)
                elif rule.bucket == "admin_paths":
                    status = rec.status_code if rec else line_status.get(url)
                    col.add("admin_paths", url, {"status_code": status, "evidence": evidence},
                            evidence)
        if rec and any(h in (t or "").lower() for t in rec.tech for h in JSON_CONTENT_TYPE_HINTS):
            evidence = f"{src}: JSON content-type observed in httpx tech ({', '.join(rec.tech)})"
            col.add("api_endpoints", url, {"method": "GET", "evidence": evidence, "source": src},
                    evidence)

    # ---- interesting params ---------------------------------------------
    for path in file_index["candidates/*.txt"]:
        source = f"gf:{path.stem}"
        for line in read_lines(path):
            url, names = params_from_line(line)
            if not names:
                if line.strip() and len(col.skipped) < 500:
                    col.skipped.append(f"{path.relative_to(recon_dir)}: no parameter names: {line.strip()[:80]!r}")
                continue
            address = url or col.base + "/"
            hint = GF_PATTERN_HINTS.get(path.stem, "")
            evidence = (f"{path.relative_to(recon_dir)}: gf pattern {path.stem}"
                        + (f" ({hint} class)" if hint else ""))
            col.add("interesting_params", address,
                    {"params": names, "method": "GET", "source": source, "evidence": evidence},
                    evidence)
    for path in file_index["params/*.txt"]:
        source = next((tool for stem, tool in PARAM_TOOL_HINTS if stem in path.stem), f"params:{path.stem}")
        for line in read_lines(path):
            url, names = params_from_line(line)
            if not names:
                if line.strip() and len(col.skipped) < 500:
                    col.skipped.append(f"{path.relative_to(recon_dir)}: no parameter names: {line.strip()[:80]!r}")
                continue
            if url is None:
                address = col.base + "/"
                evidence = (f"{path.relative_to(recon_dir)}: bare parameter name "
                            f"(no URL on the line; attached to the recon target)")
                col.note(address, "parameter names had no URL in params/*.txt; attached to the target root")
            else:
                address = url
                evidence = f"{path.relative_to(recon_dir)}: parameterised URL"
            col.add("interesting_params", address,
                    {"params": names, "method": "GET", "source": source, "evidence": evidence},
                    evidence)

    # ---- js secrets ------------------------------------------------------
    for path in file_index["js/secrets.txt"]:
        rel = str(path.relative_to(recon_dir))
        for lineno, line in enumerate(read_lines(path), start=1):
            entry, why = parse_secret_line(line, rel, lineno)
            if entry is None:
                if line.strip() and why != "empty or comment" and len(col.skipped) < 500:
                    col.skipped.append(f"{rel}:{lineno}: secret line skipped ({why})")
                continue
            resolved = _resolve(entry["url"], col.base)
            if resolved is not None:
                got = col.host_meta(resolved)
                if got is None:
                    continue  # scope-dropped, already reported
                entry["url"] = resolved
                asset_tag = got[0]
            else:
                # No bundle URL on the line at all: keep the file:line provenance
                # and attach to the recon target rather than inventing a host.
                asset_tag = target
                col.hosts.setdefault(target, {"asset_id": target, "apex": False,
                                              "match": "js secret line without a bundle URL"})
                col.note(target, f"{rel}:{lineno}: secret line carried no bundle URL; "
                                 f"attached to the recon target")
            slot = col.buckets.setdefault(asset_tag, {}).setdefault("js_secrets", {})
            # Keyed by (url, kind, redacted value): the same secret repeated on
            # three lines is one finding, but three different secrets in one
            # bundle are three findings and must not collapse into one.
            key = f"{entry['url']}|{entry['kind']}|{entry['value_redacted']}"
            if key in slot:
                if len(col.skipped) < 500:
                    col.skipped.append(f"{rel}:{lineno}: duplicate js_secret "
                                       f"({entry['kind']} {entry['value_redacted']}) dropped")
                continue
            slot[key] = entry

    # ---- ports -----------------------------------------------------------
    port_total = 0
    for path in file_index["ports/*.txt"]:
        rel = str(path.relative_to(recon_dir))
        lines = read_lines(path)
        host = host_from_ports_file(path, lines, target)
        ports, skips = parse_ports(lines)
        for ln in skips:
            if ln.strip() and len(col.skipped) < 500:
                col.skipped.append(f"{rel}: unrecognised port line: {ln[:80]!r}")
        if not ports:
            continue
        address = f"https://{host}" if not re.fullmatch(r"[\d.]+", host) else host
        asset_tag, _ = asset_tag_for(address)
        if scope is not None:
            reason = scope.excluded(host)
            if reason:
                col.drop(f"host={host} reason=out_of_scope ({reason}) [ports/{path.name}]")
                continue
            match = scope.lookup(host)
            if match is None:
                col.drop(f"host={host} reason=not in scope.json assets [ports/{path.name}]")
                continue
            col.hosts.setdefault(asset_tag, {"asset_id": match.asset_id, "apex": match.apex,
                                             "match": match.how})
        else:
            col.hosts.setdefault(asset_tag, {"asset_id": asset_tag, "apex": False, "match": "no scope.json"})
        slot = col.buckets.setdefault(asset_tag, {}).setdefault("ports", {})
        for p in ports:
            p = dict(p, evidence=f"{rel}: {p['evidence']}" if p.get("evidence") else rel)
            key = f"port-{p['port']}-{p['service']}-{p['product']}-{p['version']}"
            slot.setdefault(key, p)
            port_total += 1

    # ---- cloud / takeover (only when the input files exist) --------------
    for bucket, label, parser in (("cloud", "cloud/*.txt", parse_cloud_line),
                                  ("takeover", "takeover/*.txt", parse_takeover_line)):
        for path in file_index[label]:
            rel = str(path.relative_to(recon_dir))
            for line in read_lines(path):
                entry, why = parser(line)
                if entry is None:
                    if line.strip() and why != "empty or comment" and len(col.skipped) < 500:
                        col.skipped.append(f"{rel}: {bucket} line skipped ({why})")
                    continue
                address = entry.pop("host", None) or col.base + "/"
                got = col.host_meta(address if "://" in str(address) else f"https://{address}")
                if got is None:
                    continue
                asset_tag = got[0]
                if bucket == "takeover":
                    entry["host"] = address
                entry["evidence"] = f"{rel}: {entry.get('evidence', '')}"
                col.buckets.setdefault(asset_tag, {}).setdefault(bucket, {})[str(entry)] = entry

    # ---- assemble assets -------------------------------------------------
    assets: list[dict[str, Any]] = []
    negative: list[dict[str, Any]] = []
    for asset_tag in sorted(col.hosts):
        meta = col.hosts[asset_tag]
        entry_counts: dict[str, int] = {}
        buckets: dict[str, Any] = {}
        for bucket in ("api_endpoints", "auth_paths", "interesting_params", "js_secrets",
                       "admin_paths", "cloud", "takeover", "ports"):
            items = col.buckets.get(asset_tag, {}).get(bucket)
            if not items:
                continue
            values = list(items.values())
            if bucket == "api_endpoints":
                values.sort(key=lambda e: e["url"])
            elif bucket == "auth_paths":
                values.sort(key=lambda e: e["url"])
            elif bucket == "admin_paths":
                values.sort(key=lambda e: e["url"])
            elif bucket == "interesting_params":
                values.sort(key=lambda e: e["url"])
            elif bucket == "js_secrets":
                values.sort(key=lambda e: (e["url"], e.get("kind", ""),
                                           e.get("value_redacted", "")))
            elif bucket == "ports":
                values.sort(key=lambda e: (e["port"], e.get("service", "")))
            elif bucket in ("cloud", "takeover"):
                values.sort(key=lambda e: json.dumps(e, sort_keys=True))
            buckets[bucket] = values
            entry_counts[bucket] = len(values)
        live_for_host = [r for r in live_records.values() if asset_tag_for(r.url)[0] == asset_tag]
        live_for_host.sort(key=lambda r: (urlsplit(r.url).path not in ("", "/"), r.url))
        server = next((r.server for r in live_for_host if r.server), "")
        tech = _dedupe(t for r in live_for_host for t in r.tech)
        version = next((r.version for r in live_for_host if r.version), None)
        status_code = next((r.status_code for r in live_for_host if r.status_code is not None), None)
        title = next((r.title for r in live_for_host if r.title), None)
        tls = any(is_tls(r.url) for r in live_for_host) or False
        asset = {
            "asset_id": meta["asset_id"],
            "asset_tag": asset_tag,
            "apex": bool(meta["apex"]),
            "server": server,
            "tech": tech,
            "version": version,
            "tls": tls,
            "status_code": status_code,
            "title": title or "",
            "buckets": buckets,
        }
        if col.notes.get(asset_tag):
            asset["notes"] = col.notes[asset_tag]
        assets.append(asset)
        if not buckets:
            negative.append({
                "asset_id": meta["asset_id"],
                "reason": ("host was live/known (scope match: " + str(meta.get("match"))
                           + ") but no classification rule matched any observed URL"),
            })
    doc: dict[str, Any] = {
        "schema": SCHEMA_ID,
        "target": target,
        "engagement": scope.engagement if scope else "",
        "generated_at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "assets": assets,
        "negative_findings": negative,
        "inputs": col.input_report,
        "tool": TOOL,
    }
    doc["dropped"] = col.dropped
    doc["skipped_lines"] = col.skipped
    doc["stats"] = {
        "assets": len(assets),
        "assets_with_signals": sum(1 for a in assets if a["buckets"]),
        "buckets": {b: sum(len(a["buckets"].get(b) or []) for a in assets)
                    for b in ("api_endpoints", "auth_paths", "interesting_params",
                              "js_secrets", "admin_paths", "cloud", "takeover", "ports")},
        "dropped_urls": len(col.dropped),
        "skipped_lines": len(col.skipped),
    }
    return doc


def validate(doc: dict[str, Any]) -> list[str]:
    schema_path = Path(__file__).resolve().parent.parent / "contracts" / "classification.schema.json"
    if jsonschema is None:
        print(f"{TOOL}: WARN jsonschema not importable — output NOT schema-checked", file=sys.stderr)
        return []
    if not schema_path.is_file():
        print(f"{TOOL}: WARN schema {schema_path} not found — output NOT schema-checked", file=sys.stderr)
        return []
    schema = json.loads(schema_path.read_text(encoding="utf-8"))
    validator = jsonschema.Draft202012Validator(schema)
    return [f"{'/'.join(str(p) for p in err.absolute_path)}: {err.message}"
            for err in sorted(validator.iter_errors(doc), key=lambda e: list(e.absolute_path))]


def human_summary(doc: dict[str, Any], out: Path) -> str:
    st = doc["stats"]
    parts = [f"{k}={v}" for k, v in st["buckets"].items() if v]
    return (f"OK: {TOOL} target={doc['target']} assets={st['assets']} "
            f"with_signals={st['assets_with_signals']} "
            f"buckets[{', '.join(parts) if parts else 'none'}] "
            f"negative={len(doc['negative_findings'])} dropped={st['dropped_urls']} "
            f"-> {out}")


def main(argv: Sequence[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        prog=TOOL,
        description="Bucket an upstream ABH recon tree (subdomain+nuclei phases removed) "
                    "into bbh/classification/v1. Reads files; never scans.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=("Example:\n"
                "  python3 tools/bbh_classify.py \\\n"
                "      --recon-dir recon/acme.com \\\n"
                "      --scope runs/acme-2026-09/scope.json \\\n"
                "      --out runs/acme-2026-09/classification.json\n\n"
                "Exit codes: 0 classified, 1 real negative (no in-scope host),\n"
                "            2 bad input (recon dir/scope/out unreadable)."),
    )
    parser.add_argument("--recon-dir", required=True,
                        help="upstream recon/<target>/ tree (absolute or cwd-relative)")
    parser.add_argument("--scope", help="scope.json used to attach asset_id/apex and drop "
                                        "out-of-scope hosts")
    parser.add_argument("--out", required=True, help="classification.json to write")
    parser.add_argument("--target", help="target name (default: basename of --recon-dir)")
    parser.add_argument("--json", action="store_true", help="print a single JSON summary object")
    parser.add_argument("--no-validate", action="store_true",
                        help="skip the jsonschema self-check of the emitted document")
    args = parser.parse_args(argv)

    recon_dir = Path(args.recon_dir).expanduser()
    if not recon_dir.is_dir():
        print(f"{TOOL}: ERROR recon dir does not exist or is not a directory: {recon_dir}",
              file=sys.stderr)
        return 2
    if not os.access(recon_dir, os.R_OK):
        print(f"{TOOL}: ERROR recon dir is not readable: {recon_dir}", file=sys.stderr)
        return 2
    scope_path: Path | None = None
    if args.scope:
        scope_path = Path(args.scope).expanduser()
        if not scope_path.is_file():
            print(f"{TOOL}: ERROR scope file not found: {scope_path}", file=sys.stderr)
            return 2
        try:
            json.loads(scope_path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError) as exc:
            print(f"{TOOL}: ERROR scope file unreadable/invalid JSON: {exc}", file=sys.stderr)
            return 2
    target = args.target or recon_dir.resolve().name
    out = Path(args.out).expanduser()

    try:
        doc = build(recon_dir, scope_path, target)
    except (OSError, json.JSONDecodeError) as exc:
        print(f"{TOOL}: ERROR reading recon tree: {exc}", file=sys.stderr)
        return 2

    try:
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(json.dumps(doc, indent=2, sort_keys=False) + "\n", encoding="utf-8")
    except OSError as exc:
        print(f"{TOOL}: ERROR cannot write {out}: {exc}", file=sys.stderr)
        return 2

    # ---- operator-facing report (never silent) ---------------------------
    # With --json, stdout must be exactly one JSON object, so the human report
    # goes to stderr instead of being dropped.
    emit = (lambda *a: print(*a, file=sys.stderr)) if args.json else print
    emit(f"{TOOL}: inputs under {recon_dir} (missing files are normal — the phase did not run):")
    for label, info in doc["inputs"].items():
        if "present" not in info:
            continue
        state = f"{info['lines']:>6} line(s)" if info["present"] else "MISSING (phase not run)"
        files = ", ".join(info["files"]) if info["files"] else "-"
        emit(f"  INPUT {label:<24} {state:<24} [{files}]")
    for line in doc["dropped"][:200]:
        emit(f"  DROP {line}")
    if len(doc["dropped"]) > 200:
        emit(f"  DROP ... and {len(doc['dropped']) - 200} more (see 'dropped' in the JSON)")
    for line in doc["skipped_lines"][:40]:
        emit(f"  SKIP {line}")
    if len(doc["skipped_lines"]) > 40:
        emit(f"  SKIP ... and {len(doc['skipped_lines']) - 40} more (see 'skipped_lines')")
    for asset in doc["assets"]:
        if not asset["buckets"]:
            emit(f"  NEGATIVE {asset['asset_tag']}: in scope, no rule matched any observed URL")

    if not args.no_validate:
        errors = validate(doc)
        if errors:
            print(f"{TOOL}: ERROR emitted document fails classification.schema.json:", file=sys.stderr)
            for err in errors[:20]:
                print(f"  {err}", file=sys.stderr)
            return 2

    if not doc["assets"]:
        if args.json:
            print(json.dumps({"schema": SCHEMA_ID, "target": target, "assets": 0, "out": str(out),
                              "negative": True, "reason": "no in-scope host found"}, indent=2))
        else:
            print(f"NEGATIVE: {TOOL} found no in-scope host under {recon_dir} "
                  f"(scope={scope_path or 'none'}); wrote empty classification -> {out}")
        return 1

    if args.json:
        print(json.dumps({"schema": SCHEMA_ID, "target": target, "out": str(out),
                          "stats": doc["stats"],
                          "negative_findings": len(doc["negative_findings"])}, indent=2))
    else:
        print(human_summary(doc, out))
    return 0


if __name__ == "__main__":
    sys.exit(main())
