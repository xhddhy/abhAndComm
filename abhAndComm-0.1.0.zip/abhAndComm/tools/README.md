# tools/ — CLI contract

Every stage of the pipeline talks to the next through a **file + one command**. This file is
the frozen interface: the workflows call these exact CLIs, and the skills document them. If you
change a flag, change it here first and grep for the callers.

Conventions, all tools:

- **Python 3.10+**, stdlib plus `jsonschema` / `requests` / `pyyaml` (present in the DSH image).
  No other third-party imports — the bundle must survive a bare `python3`.
- Every tool accepts `--help` and prints a one-line `OK:` summary to stdout on success.
- Exit codes are the contract: `0` success, `1` a real negative result, `2` bad input/unreadable.
  A workflow branches on exit codes, never on parsing prose.
- `--json` (where offered) switches stdout from human text to a single JSON object.
- Tools **never** write outside the paths given on the command line. The coordinator owns
  `<run>/assets/<asset_tag>/`; these tools are the only writers of `recon/inventory/`,
  `applicability/` and `coverage.json` inside it.
- Absolute paths in, absolute paths in artifacts. A slice must never contain a relative path
  that only resolves from the repo root.

---

## Stage 0 — scope

### `bbh_scope.py`

```bash
python3 tools/bbh_scope.py init \
    --engagement acme-2026-09 --platform hackerone --program acme \
    --asset 'web:acme.com:apex' --asset 'api:api.acme.com' \
    --exclude staging.acme.com --out runs/acme-2026-09/scope.json

python3 tools/bbh_scope.py check \
    --scope runs/acme-2026-09/scope.json --url https://api.acme.com/v2/users/1
# exit 0 = in scope, 1 = out of scope, 2 = unclear (third party / staging / no safe harbor)
```

`--asset KIND:VALUE[:apex]`; KIND ∈ scope.schema.json. `check` also applies `out_of_scope`
and every asset's `path_exclusions`. A URL that resolves to a third-party CNAME is **unclear**,
never assumed in scope.

---

## Stage 1 — recon-lite (known assets only)

### `bbh_classify.py`

Consumes the output tree of ABH's recon pipeline **after** the subdomain and nuclei phases have
been removed, and buckets it. It does not scan: it reads files and classifies.

```bash
python3 tools/bbh_classify.py \
    --recon-dir recon/acme.com \
    --scope runs/acme-2026-09/scope.json \
    --out runs/acme-2026-09/classification.json
```

Reads, when present: `live/urls.txt`, `urls/all.txt`, `candidates/{xss,ssrf,idor,sqli,redirect,lfi}.txt`,
`api-endpoints.txt`, `params/*.txt`, `js/endpoints.txt`, `js/secrets.txt`, `config-exposure.txt`,
`admin/*.txt`, and any `ports/*.txt`. Unknown files are ignored, not an error — the recon tree is
allowed to be partially populated.

Emits `bbh/classification/v1` with the buckets `api_endpoints`, `auth_paths`, `interesting_params`,
`js_secrets`, `admin_paths` and optionally `cloud`, `takeover`, `ports`.

---

## Stage 2 — queue (never eliminates)

### `queue_build.py`

```bash
python3 tools/queue_build.py \
    --classification runs/acme-2026-09/classification.json \
    --cells-dir runs/acme-2026-09/assets \
    --out runs/acme-2026-09/queue.json \
    [--explain]
```

Produces `bbh/queue/v1`. **There is no kill list and no eliminated status**: every input signal
becomes a lead, and the lowest band is `P3`, which means "after P1 and P2". Re-running over the same
classification is idempotent and preserves each lead's `status` and `touched_by`.

**Two-pass build, and why the command above is safe on a fresh run.** Stage 2 is listed before
Stage 3, but the coverage cells it folds in do not exist until `cells_build.py` has run. So the
queue is built twice:

- **Pass A** (before slicing): `assets/` does not exist yet. A missing `--cells-dir` is **not an
  error** — the tool prints a `NOTE … building a bucket-only queue (pass A)` and continues. It is
  deliberately not fatal, because failing would push the operator to drop the flag, and then pass B
  would silently never fold the cells in.
- **Pass B** (after `cells_build.py`): the same command again. Coverage-cell leads are added and
  `coverage_seed` is filled from each asset's `applicability/cells.json`. Existing lead ids and
  statuses survive, so pass B is additive by construction.

**Priority** is a 0–100 additive score. The component weights are defined in the module's
`SCORE_*` constants, and `--explain` prints the per-lead arithmetic as a named breakdown — that
output is the authority, not this paragraph, because the weights are meant to be argued with and
retuned. What the components are: the originating bucket's signal strength, the gf-pattern class of
any parameter (an `idor`/`ssrf`/`sqli` hit outranks a generic one), asset criticality (apex or an
`api`-kind asset outranks a static host), the catalogue's `bounty_tier`, and a `needs_chain`
penalty (a class that only pays chained starts lower). Bands: `P1 >= 70`, `P2 >= 40`, else `P3`.

`lead_id` is derived deterministically from `asset_tag|class_id|address|bucket`, so it is **stable
across re-runs** — `lead_board.py touch` depends on that.

---

## Stage 3 — slice per asset

### `surface_build.py` ★ the translation layer

The single most important tool in the bundle: it turns ABH's classification buckets into
communitytools' `surface/v2` flag vocabulary so the 39-class catalogue's predicates can run.

```bash
python3 tools/surface_build.py \
    --classification runs/acme-2026-09/classification.json \
    --scope runs/acme-2026-09/scope.json \
    --assets-dir runs/acme-2026-09/assets \
    --explain
# -> runs/acme-2026-09/assets/api.acme.com/recon/inventory/surface.json
```

Rules it must obey:

1. **Only the 18 agent flags may be written into `units[].flags`.** The 7 derived flags
   (`http_listener`, `tls_listener`, `version_fingerprinted`, `has_api`, `is_apex`, `serves_js`,
   `mobile_app`) are computed by `cells_build.py` from the unit's shape. Writing a derived flag
   from here is a bug, and `cells_build.py` filters it out and warns.
2. **Every flag carries its evidence.** `units[].evidence` holds one `"<flag> <- <why>"` line per
   flag. `--explain` prints the full mapping table so a human can audit a flag without reading code.
3. `unit_id` is assigned in stable sorted-address order (`u-0001`, `u-0002`, …) and is **never
   renumbered** on a re-run over a superset — a new address appends. Coverage ledgers key on it.
4. `equiv_group` is set when two units are the same logical target (`/v1/x` and `/v2/x`, or the
   same path with and without a trailing slash) so a class is not double-counted.
5. Assets excluded by scope are skipped with a printed reason, never silently.

### `cells_build.py` ★

```bash
python3 tools/cells_build.py --asset-dir runs/acme-2026-09/assets/api.acme.com \
    --catalog catalog/bounty-coverage-matrix.json
# -> <asset-dir>/applicability/cells.json
```

Reimplements the upstream enumerator against the bundle's own catalogue: applies each class's
`applies_when` predicate to the unit / listener / asset flag sets, one cell per matching scope
key, and recomputes the 7 derived flags itself. The applicable set is **code-produced and
un-fabricatable** — an agent cannot shrink it. `coverage_gate.py` re-runs this
enumeration independently and refuses a `cells.json` that disagrees with it, so the claim
holds at audit time too, not just at production time.

### `slice_build.py`

```bash
python3 tools/slice_build.py --run-dir runs/acme-2026-09 --scope runs/acme-2026-09/scope.json
# -> runs/acme-2026-09/slices/<asset_tag>.json  (one per asset)
```

Emits `bbh/slice/v1`. Resolves `class_playbooks`: for each `class_id` in the asset's cells, the
concrete reference-file paths the executor should be handed (never a whole `SKILL.md`).

---

## Stage 3 gate — coverage

### `coverage_gate.py` ★

```bash
python3 tools/coverage_gate.py --asset-dir runs/acme-2026-09/assets/api.acme.com
python3 tools/coverage_gate.py --run-dir  runs/acme-2026-09
python3 tools/coverage_gate.py --run-dir  runs/acme-2026-09 --mode strict
# exit 0 = complete, 1 = incomplete (per-cell detail on stdout), 2 = inputs unreadable
```

Joins the code-produced `applicability/cells.json` against the on-disk evidence in
`coverage.json` and the `artifacts/validated|false-positives|dropped/` trees.

**Two completion modes, and the default is deliberately not 100%.**

Upstream communitytools gates a contracted pentest at a hard 100% of applicable cells. That is
correct when someone is paying for breadth and the engagement ends when the matrix fills. Bug
bounty is not that engagement: you are one of many hunters, the program pays per valid finding,
and the rational stopping rule is "the highest-value leads are worked" — not "every endpoint has
been probed for all 24 web classes". A gate that can never pass on a real bounty run is a gate
the operator learns to ignore, which is worse than no gate.

| mode | complete when |
|---|---|
| `bounty` (default) | something was actually worked, no claim exceeds its evidence, no finding sits in the tree without a verdict, and every `P1` lead reached a terminal status. The coverage ratio and the untouched backlog are **reported in full** but do not gate. |
| `strict` | the upstream contract: `covered == applicable`, untouched cells block. Use it for contracted work or when you deliberately want the full matrix. |

Rules that hold in **both** modes — this is the part that cannot be relaxed:

- **The gate re-derives the applicable set itself**, from `recon/inventory/surface.json` + the
  catalogue, and refuses to score a `cells.json` that disagrees with it. This is what makes "an
  agent cannot shrink the work list" true *at audit time* and not merely at production time:
  a gate that reads back the artifact it exists to police is a rubber stamp, and shrinking
  `cells.json` from 35 cells to 1 used to report 100% coverage of a one-cell world. Divergence
  is reported per cell, and a derivation that cannot run at all ("cannot verify") is a blocker
  rather than a pass. `--catalog` overrides the catalogue used for the re-derivation.
- A cell marked `na` whose predicate the catalogue evaluates true is a **hard fabrication FAIL**,
  not a judgement call.
- Every cell claiming `covered` or `covered_negative` must cite evidence that **exists on disk**.
- A cell claiming `covered` must be backed by a real `CONFIRMED` verdict in `artifacts/validated/`.
  A `covered_negative` must carry the corroborator its class's `negative_kind` requires — a
  tool-log reference for `active_probe`, N distinct verified vantage regions for `reachability`.
- A ledger row for a cell that is not applicable is a dangling row and fails the gate.
- A finding directory with no verdict artifact fails the gate. Testing is not finished until the
  finding has a verdict, not until the tester stops.

A cell never entered in the ledger counts as **untouched**, not as pending: on a fresh asset the
ledger is empty, and reporting "0 untouched" against 49 applicable cells would tell the operator
the opposite of the truth. `--run-dir` additionally cross-checks every `P1` lead in `queue.json`
so a whole asset cannot be quietly skipped.

Writes `<asset-dir|run-dir>/reports/coverage-matrix.json` on every run, pass or fail.

---

## Stage 6 — validation support

### `cvss_recompute.py`

```bash
python3 tools/cvss_recompute.py --vector 'CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:H/A:N' --json
# {"score": 9.1, "band": "critical", "vector": "..."}
```

Pure-stdlib CVSS 3.1 base-score arithmetic. The validator recomputes from the vector; a mismatch
between the vector and the claimed band is a failed check, not a rounding note.

### `nvd_lookup.py`

```bash
python3 tools/nvd_lookup.py CVE-2024-1234 --json [--cache-dir runs/<eng>/artifacts/nvd-cache]
```

NVD score/severity/CWE plus CISA KEV membership. `--cache-dir` makes a re-run read a frozen
snapshot instead of the network, which is what makes a replayed verdict reproducible.

### `schema_check.py`

```bash
python3 tools/schema_check.py --kind verdict runs/acme-2026-09/assets/x/artifacts/validated/F-001.json
python3 tools/schema_check.py --kind all --run-dir runs/acme-2026-09
python3 tools/schema_check.py --list-kinds          # the table below, from the tool itself
```

Validates any artifact against `contracts/*.schema.json`. Run at every stage boundary; a stage
whose output does not validate has not completed.

The `--kind` values are a **closed set**, and they do not map mechanically onto the filenames —
the queue's contract file is `surface-queue.schema.json` while its id is `bbh/queue/v1`. Run
`--list-kinds` when in doubt; that output is authoritative.

| `--kind` | contract file | schema `$id` |
|---|---|---|
| `scope` | `contracts/scope.schema.json` | `bbh/scope/v1` |
| `classification` | `contracts/classification.schema.json` | `bbh/classification/v1` |
| `surface` | `contracts/surface.v2.schema.json` | `surface/v2` |
| `queue` | `contracts/surface-queue.schema.json` | `bbh/queue/v1` |
| `slice` | `contracts/slice.schema.json` | `bbh/slice/v1` |
| `finding` | `contracts/finding.schema.json` | `bbh/finding/v1` |
| `verdict` | `contracts/validation-verdict.schema.json` | `bbh/verdict/v1` |
| `seven-questions` | `contracts/seven-questions.schema.json` | `bbh/7q/v1` |
| `repro` | `contracts/repro-runbook.schema.json` | `bbh/repro/v1` |

Accepted aliases: `7q`, `seven_questions`, `sevenquestions` → `seven-questions`; `repro-runbook`,
`runbook` → `repro`; `surface-queue`, `surface-queue-v1` → `queue`; `validation-verdict` →
`verdict`.

`--kind all --run-dir DIR` walks the run and validates every file it recognises, skipping the rest
by name and reporting the skip count. A file that exists but is not valid JSON is an error, not a
skip.

---

## The three-file coordinator state contract

Not a tool, but a frozen interface the coordinator and every executor depend on. All three live in
the slice's `output_dir`, and the INTEGRATE agent is their **sole writer** so parallel executors
never race on them:

| file | job | discipline |
|---|---|---|
| `attack-chain.md` | the current working theory | **rewritten** every batch, hard cap 50 lines |
| `experiments.md` | the append-only ledger of what was tried | one `E-NNN` row per attempt, with its goal and outcome; never edited, only appended |
| `session-memory.md` | durable facts that must outlive the theory | append-only, ~80 lines: identities and credentials (env-var NAMES only), confirmed-live facts, dead ends so they are not retried, environment quirks, confirmed chains |

Three files rather than one because they have three different lifetimes: the theory is rewritten
every batch, the ledger is never rewritten, and the memory outlives both. Upstream communitytools
defines the first two; `session-memory.md` is this bundle's addition, because a bounty run spans
more sessions than a scoped pentest and the dead-ends list is what stops a re-run from repeating
yesterday's failures.

---

## Stage 9 — deliverables

### `repro_pack.py` ★

```bash
python3 tools/repro_pack.py \
    --finding-dir runs/acme-2026-09/assets/api.acme.com/findings/finding-001 \
    --verdict  runs/.../artifacts/validated/F-001.json \
    --seven-q  runs/.../seven-questions/F-001.json \
    --out      runs/acme-2026-09/repro/F-001
```

**Where the runbook content comes from.** `--finding-dir` must contain `repro.json` conforming to
`contracts/repro-runbook.schema.json` (`bbh/repro/v1`) — that is the authored source. `repro_pack.py`
renders it, validates it, and writes `runbook.json` back beside `RUNBOOK.md` so the Markdown is
reproducible from the JSON. If `repro.json` is absent the tool exits 1 naming the expected path
rather than inventing content; authoring it is the `/bbh-repro` skill's job.

Emits the two requested deliverables:

- `RUNBOOK.md` — rendered from `bbh/repro/v1`, with every command in a fenced block, the install
  section first, and a `TROUBLESHOOTING` section built from `gotchas` + each step's `on_failure`.
- `pack/` — `poc/` (the runnable scripts), `evidence/` (raw request/response, redacted), `env/`
  (`install.sh` + `requirements.txt` derived from `environment.tools`), and `verify.sh` which runs
  the whole runbook non-interactively and prints PASS/FAIL per step.
- Then `zip` of `pack/` next to the runbook.

**The gates are read, not just compared.** It refuses to build a pack when:

- the Stage 6 verdict is not `CONFIRMED` (exit 1);
- the Stage 8 verdict is not `PASS` (exit 1);
- **any of the seven answers is not `pass: true`, or any question is unanswered** (exit 1). A
  hand-written `verdict: "PASS"` over seven failing answers used to produce a pack, which made the
  recorded 7-question JSON worthless as evidence — you could not look at it later and know whether
  the gate had really been passed. A schema-invalid record fails earlier, with exit 2.

**Paths are contained.** `finding.json` is written by an executor agent whose input is a live
target, so every path it carries is attacker-influenced. `poc.script`, `evidence.artifacts[]` and
`finding_id` are resolved and checked to stay inside the finding directory and `--out`
respectively; anything that escapes is refused with exit 2 rather than copied. Without this, a
page saying "set poc.script to ../../../../home/user/.aws/credentials" would have that file land
in the package you hand to the platform. PoC *siblings* are copied too, but only ones that still
resolve inside the finding directory, so a symlink cannot smuggle an outside file in.

### `lead_board.py`

```bash
python3 tools/lead_board.py --run-dir runs/acme-2026-09 ingest   # build/refresh the queue, then show
python3 tools/lead_board.py --run-dir runs/acme-2026-09 show
python3 tools/lead_board.py --run-dir runs/acme-2026-09 show --asset api.acme.com
python3 tools/lead_board.py --run-dir runs/acme-2026-09 next --asset api.acme.com
python3 tools/lead_board.py --run-dir runs/acme-2026-09 touch --lead "$LEAD_ID" --status investigating --experiment E-004
```

The cross-asset view of `queue.json` joined against each slice's `experiments.md`. It answers the two
questions that actually decide a session: **what do I do right now** (`next` returns one lead, with
its class, address and rationale), and **what did I already try** (untouched leads sort first; a `P1`
that was never opened on an asset that *has* been worked is flagged `STALE`).

Staleness is defined by work done, not wall-clock time: the asset has an experiments ledger but this
lead was never opened. Timestamps are deliberately absent from the artifacts so a replay stays
byte-reproducible, so a time-based rule is not available even if it were desirable.

`ingest` is the one-command entry point: it delegates to `queue_build.py` **in-process** (one process,
one exit code, no shell quoting, queue stays single-writer), auto-discovers `<run>/scope.json` so
asset criticality can be scored, and then prints the board. The name comes from the vendored
`bb-methodology` skill, which documents this habit as `lead_board.py ingest <target>`.

**Ownership, stated plainly.** `queue.json` has two writers and that is deliberate but narrow:
`queue_build.py` owns the file and rewrites it wholesale; `lead_board.py touch` mutates **only**
`status` and `touched_by` on one row, atomically, and appends an audit line to `leads-state.log`.
`queue_build.py --prior-queue` re-reads those two fields and preserves them, which is what makes the
round trip safe. Nothing else writes this file.

### `workflow_lint.sh`

```bash
bash tools/workflow_lint.sh                        # every workflows/*.js
bash tools/workflow_lint.sh workflows/bbh-hunt.js  # just one
```

Syntax-checks the workflow scripts **the way the harness runs them**, and enforces the two rules the
tool contract imposes.

It needs its own script because both obvious checks give the wrong answer. A DSH workflow script is a
bare JavaScript *body*, not a module: it has top-level `await` and top-level `return`, and the
harness wraps it in an async function before running it. So `node --check file.js` reports "await is
only valid in async functions", and `node --check file.mjs` reports "Illegal return statement". Both
are false alarms whose tempting conclusion — "the scripts are broken" — is wrong; but skipping the
check entirely is worse, because a real typo then surfaces only when the workflow tool refuses to
start, mid-engagement. This script reproduces the harness's wrapping and checks that instead.

It also fails on `export const meta` / `export default` / `import` (meta is a tool *parameter*, not
code) and on `Date.now()` / `new Date()` / `Math.random()` in code (verdicts must be reproducible
across a replay; mentions inside comments are allowed, since the scripts explain the rule).

---

## Not in this bundle, on purpose

- **Subdomain enumeration and nuclei.** Removed by design: this project classifies assets the
  program already told you about. There is no `--with-subdomains` escape hatch; add discovery
  back as a separate, explicitly-scoped stage if you ever want it.
- **Report rendering (HackerOne Markdown, Transilience PDF).** Out of scope for this bundle's
  deliverables. The repo has the upstream skills if you want to bolt them on.
