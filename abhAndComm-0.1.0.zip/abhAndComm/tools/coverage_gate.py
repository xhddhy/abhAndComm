#!/usr/bin/env python3
"""Score an engagement's attack-class coverage against the code-produced cell work list.

WHY THIS TOOL EXISTS
--------------------
"Coverage" is the claim most easily faked in a security report, because the person making
it is the same person who did the work and the same person who benefits from it looking
finished. This tool exists so that claim is computed from disk instead of asserted.

The mechanism: `cells_build.py` already produced the applicable set from code-owned
inputs, so the work list cannot be shrunk after the fact. This tool then joins that
immutable list against two things an agent CANNOT fabricate consistently:

  1. the coverage ledger (`coverage.json`), where every cell must name evidence files;
  2. the filesystem, where those evidence files must actually exist, and where a cell
     claiming `covered` must be backed by a real CONFIRMED verdict in artifacts/validated/.

The decisive rule is the anti-fabrication check: a cell that the catalogue's predicate
selects is applicable BY CONSTRUCTION, so marking it `na` is not a judgement call, it is a
hard FAIL.

TWO COMPLETION MODES, AND WHY THE DEFAULT IS NOT 100%
-----------------------------------------------------
Upstream communitytools gates a contracted pentest at a hard 100% of applicable cells.
That is right when someone is paying for breadth and the engagement ends when the matrix
is full. Bug bounty is not that engagement: you are one of many hunters, the program pays
per valid finding, and the rational stopping rule is "the highest-value leads are worked",
not "every endpoint has been probed for all 24 web classes". Pretending otherwise would
fail the `complete` gate on every real bounty run and train the operator to ignore it.

So:

  --mode bounty  (default)  complete when every asset was actually visited, every P1 lead
                            reached a terminal status, and every CONFIRMED finding has a
                            passing verdict. The coverage ratio and the untouched-cell
                            backlog are REPORTED in full but do not gate.
  --mode strict             the upstream semantics: complete iff covered == applicable,
                            no soft bar.

Both modes share the same anti-fabrication rules and the same evidence-existence checks.
Switching modes changes the stopping rule, never the honesty of the numbers.
"""
from __future__ import annotations

import argparse
import glob
import json
import os
import sys

COVERAGE_SCHEMA = "bbh/coverage/v1"
CELLS_SCHEMA = "bbh/cells/v1"

# What a genuine negative requires, per the catalogue's negative_kind.
NEGATIVE_KINDS = {"active_probe", "reachability", "none"}

COMPLETE_STATUSES = {"covered", "covered_negative"}
TERMINAL_LEAD_STATUSES = {"reported", "exhausted"}
ALLOWED_STATUSES = COMPLETE_STATUSES | {"pending", "na"}


class GateInputError(Exception):
    """Inputs are unreadable. Distinct from 'incomplete': one is a broken setup, the
    other is unfinished work, and conflating them makes a gate failure unactionable."""


def _load(path: str) -> dict:
    try:
        with open(path, encoding="utf-8") as fh:
            return json.load(fh)
    except OSError as exc:
        raise GateInputError(f"cannot read {path}: {exc}") from exc
    except json.JSONDecodeError as exc:
        raise GateInputError(f"{path} is not valid JSON: {exc}") from exc


def load_cells(asset_dir: str) -> dict:
    p = os.path.join(asset_dir, "applicability", "cells.json")
    if not os.path.isfile(p):
        raise GateInputError(
            f"no cells.json under {asset_dir}/applicability/ — run cells_build.py first; "
            "without the code-produced work list there is nothing to score against")
    doc = _load(p)
    if doc.get("schema") != CELLS_SCHEMA:
        raise GateInputError(f"{p}: expected schema {CELLS_SCHEMA}, got {doc.get('schema')!r}")
    return doc


def rederive_cells(asset_dir: str, catalog_hint: str | None) -> tuple[dict[str, dict], list[str]]:
    """Independently recompute the applicable cell set from surface.json + the catalogue.

    WHY THIS TOOL DOES NOT TRUST cells.json
    ---------------------------------------
    The whole claim of this pipeline is "the applicable set is code-produced, so an agent cannot
    shrink it". That claim is only true at the moment cells_build.py runs. Reading the file back
    later and scoring against it makes the gate trust the very artifact it exists to police: edit
    cells.json from 35 cells down to 1 and the gate reports 100% coverage of a one-cell world.

    So the gate re-derives the set here, from the two inputs it can trust — the surface inventory
    and the catalogue — and treats any divergence from cells.json as a blocker. The point is not
    that cells.json is expected to be wrong; it is that a gate which cannot tell the difference
    between "produced by the tool" and "edited by hand" is not a gate.

    Returns ({cell_key: cell}, warnings). Empty dict means the derivation could not run at all,
    which the caller must treat as a blocker rather than as "nothing to check".
    """
    surface = os.path.join(asset_dir, "recon", "inventory", "surface.json")
    if not os.path.isfile(surface):
        return {}, [f"no surface.json at {surface}: cannot re-derive the applicable set"]

    # Loaded by path rather than imported, so this works whatever the caller's cwd is and
    # without requiring tools/ to be an importable package.
    import importlib.util

    cb_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "cells_build.py")
    if not os.path.isfile(cb_path):
        return {}, [f"cells_build.py not found next to this script ({cb_path})"]

    spec = importlib.util.spec_from_file_location("_bbh_cells_build", cb_path)
    if spec is None or spec.loader is None:
        return {}, [f"cannot load {cb_path}"]
    mod = importlib.util.module_from_spec(spec)
    # Register before exec: cells_build imports nothing that needs it, but keeping the module
    # in sys.modules matches how lead_board loads queue_build and avoids surprising a future
    # dataclass/annotation in that file.
    sys.modules[spec.name] = mod
    try:
        spec.loader.exec_module(mod)
        catalog_path = mod.resolve_catalog(catalog_hint)
        catalog = mod.load_catalog(catalog_path)
        asset = mod.load_asset(asset_dir)
        cells, _counts = mod.enumerate_cells(asset, catalog)
    except Exception as exc:  # noqa: BLE001 — any failure here is "cannot verify", not "verified"
        return {}, [f"re-derivation failed: {type(exc).__name__}: {exc}"]
    finally:
        sys.modules.pop(spec.name, None)

    return {c["cell_key"]: c for c in cells}, []


def load_coverage(asset_dir: str) -> dict:
    p = os.path.join(asset_dir, "coverage.json")
    if not os.path.isfile(p):
        # Absent ledger is legitimate for an asset nobody has worked yet. It scores as
        # zero coverage rather than as an error, so the gate can be run early as a
        # progress read without special-casing the first run.
        return {"schema": COVERAGE_SCHEMA, "asset_tag": None, "cells": [], "_absent": True,
                "_path": p}
    doc = _load(p)
    if doc.get("schema") != COVERAGE_SCHEMA:
        raise GateInputError(f"{p}: expected schema {COVERAGE_SCHEMA}, got {doc.get('schema')!r}")
    doc["_path"] = p
    return doc


def load_verdicts(asset_dir: str) -> dict[str, dict]:
    """finding_id -> verdict document, across all terminal verdict buckets."""
    out: dict[str, dict] = {}
    for bucket in ("validated", "false-positives", "dropped"):
        for p in sorted(glob.glob(os.path.join(asset_dir, "artifacts", bucket, "*.json"))):
            try:
                v = _load(p)
            except GateInputError:
                continue
            fid = v.get("finding_id") or os.path.splitext(os.path.basename(p))[0]
            v["_bucket"] = bucket
            v["_path"] = p
            out[fid] = v
    return out


def load_finding_evidence(asset_dir: str) -> dict[str, list[str]]:
    """finding_id -> relative evidence paths that exist on disk."""
    out: dict[str, list[str]] = {}
    for fdir in sorted(glob.glob(os.path.join(asset_dir, "findings", "finding-*"))):
        ev_dir = os.path.join(fdir, "evidence")
        files = []
        if os.path.isdir(ev_dir):
            for root, _dirs, names in os.walk(ev_dir):
                for n in sorted(names):
                    files.append(os.path.relpath(os.path.join(root, n), fdir))
        fid = os.path.basename(fdir).replace("finding-", "F-", 1)
        out[fid] = files
    return out


def artifact_exists(asset_dir: str, ref: str) -> bool:
    """Does an evidence reference resolve to a real file?

    Accepts absolute paths, asset-dir-relative paths, and finding-relative paths, because
    the three appear interchangeably in evidence written by different agents. Rejecting
    two of the three would produce false FAILs that train the operator to ignore the gate.
    """
    if not ref or not isinstance(ref, str):
        return False
    cands = [ref]
    if not os.path.isabs(ref):
        cands.append(os.path.join(asset_dir, ref))
        # A bare filename may live under some finding's evidence/ dir.
        cands.extend(glob.glob(os.path.join(asset_dir, "findings", "*", "evidence", ref)))
        cands.extend(glob.glob(os.path.join(asset_dir, "findings", "*", ref)))
    return any(os.path.isfile(c) for c in cands)


def score_asset(asset_dir: str, mode: str, catalog: str | None = None) -> dict:
    asset_dir = os.path.abspath(asset_dir)
    cells_doc = load_cells(asset_dir)
    cov = load_coverage(asset_dir)
    verdicts = load_verdicts(asset_dir)
    finding_evidence = load_finding_evidence(asset_dir)

    applicable = {c["cell_key"]: c for c in cells_doc.get("cells") or []}

    # Re-derive the work list from surface.json + catalogue and refuse to score a world that
    # does not match. See rederive_cells() for why this is the difference between a gate and a
    # rubber stamp. A derivation that could not run is a blocker too: "cannot verify" must never
    # be reported as "verified".
    derived, derive_notes = rederive_cells(asset_dir, catalog)
    worklist_ok = False
    worklist_detail = ""
    if not derived:
        worklist_detail = ("could not re-derive the applicable set — " + "; ".join(derive_notes)
                           if derive_notes else "could not re-derive the applicable set")
    else:
        shrunk = sorted(set(derived) - set(applicable))
        inflated = sorted(set(applicable) - set(derived))
        if shrunk or inflated:
            parts = []
            if shrunk:
                parts.append(f"{len(shrunk)} applicable cell(s) are MISSING from cells.json "
                             f"(e.g. {', '.join(shrunk[:3])})")
            if inflated:
                parts.append(f"{len(inflated)} cell(s) in cells.json are NOT applicable "
                             f"(e.g. {', '.join(inflated[:3])})")
            worklist_detail = ("cells.json disagrees with the catalogue: " + "; ".join(parts)
                               + " — the work list has been edited or is stale; re-run "
                                 "cells_build.py")
        else:
            worklist_ok = True

    ledger = {}
    for row in cov.get("cells") or []:
        key = row.get("cell_key")
        if not key:
            continue
        if key in ledger:
            # Two rows for one cell means the ledger cannot be trusted to be a ledger.
            raise GateInputError(f"{cov.get('_path')}: duplicate cell_key {key!r}")
        ledger[key] = row

    missing = sorted(set(applicable) - set(ledger))
    dangling = sorted(set(ledger) - set(applicable))
    covered, negative, pending, fabrications = [], [], [], []
    evidence_gaps, verdict_gaps, negative_gaps = [], [], []

    # A cell with no ledger row is NOT "covered" and NOT "pending" — it is untouched.
    # Folding it into the backlog here is deliberate: on a fresh asset the ledger is
    # empty, and reporting "0 untouched" against 49 applicable cells would tell the
    # operator the opposite of the truth.
    pending.extend(missing)

    for key, cell in sorted(applicable.items()):
        row = ledger.get(key)
        if row is None:
            continue
        status = (row.get("status") or "pending").lower()
        if status not in ALLOWED_STATUSES:
            raise GateInputError(f"{cov.get('_path')}: cell {key} has invalid status {status!r}")

        if status == "na":
            # THE hard rule. The predicate selected this cell from flags an agent set,
            # so "not applicable" is a contradiction, not a judgement.
            fabrications.append({
                "cell_key": key, "class_id": cell["class_id"], "scope_key": cell["scope_key"],
                "reason": row.get("reason", ""),
                "why": "the catalogue predicate selects this cell; marking it N/A is a fabrication",
            })
            continue

        if status in COMPLETE_STATUSES:
            refs = [r for r in (row.get("evidence") or []) if r]
            if not refs:
                evidence_gaps.append({"cell_key": key, "why": "no evidence references at all"})
            else:
                bad = [r for r in refs if not artifact_exists(asset_dir, r)]
                if bad:
                    evidence_gaps.append({"cell_key": key, "why": "cited evidence is not on disk",
                                          "missing": bad})

        if status == "covered":
            fid = row.get("finding_id")
            v = verdicts.get(fid) if fid else None
            if not v:
                verdict_gaps.append({"cell_key": key, "finding_id": fid,
                                     "why": "no verdict artifact for the claimed finding"})
            elif v.get("verdict") != "CONFIRMED":
                verdict_gaps.append({"cell_key": key, "finding_id": fid,
                                     "why": f"verdict is {v.get('verdict')}, not CONFIRMED"})
            covered.append(key)

        elif status == "covered_negative":
            kind = cell.get("negative_kind") or "none"
            corr = row.get("corroborator")
            if kind == "active_probe" and not corr:
                negative_gaps.append({"cell_key": key, "negative_kind": kind,
                                      "why": "active_probe negatives need a tool-log corroborator"})
            elif kind == "reachability":
                regions = row.get("vantages") or []
                need = int(cell.get("min_vantages") or 0)
                if len(set(regions)) < max(need, 1):
                    negative_gaps.append({
                        "cell_key": key, "negative_kind": kind,
                        "why": f"reachability negative needs >= {max(need, 1)} distinct "
                               f"verified vantage region(s), got {len(set(regions))}"})
            negative.append(key)

        else:  # pending
            pending.append(key)

    total = len(applicable)
    done = len(covered) + len(negative)
    ratio = (done / total) if total else 1.0

    findings_seen = sorted(finding_evidence.keys())
    confirmed = sorted(f for f, v in verdicts.items() if v.get("verdict") == "CONFIRMED")
    unvalidated_findings = sorted(
        f for f in findings_seen
        if f not in verdicts and finding_evidence.get(f)
    )

    blockers = []
    # This one goes first because everything below it is scored against a work list that may
    # not be the real one. A number computed from a tampered denominator is worse than no
    # number: it reads as a result.
    if not worklist_ok:
        blockers.append(f"work list unverified: {worklist_detail}")
    if fabrications:
        blockers.append(f"{len(fabrications)} cell(s) marked N/A despite being code-applicable")
    if evidence_gaps:
        blockers.append(f"{len(evidence_gaps)} covered cell(s) cite evidence that is not on disk")
    if verdict_gaps:
        blockers.append(f"{len(verdict_gaps)} cell(s) claim coverage without a CONFIRMED verdict")
    if negative_gaps:
        blockers.append(f"{len(negative_gaps)} genuine-negative cell(s) lack a required corroborator")
    if dangling:
        blockers.append(f"{len(dangling)} ledger row(s) reference cells that are not applicable")
    if total == 0:
        blockers.append("no applicable cells: the surface inventory is empty or was not built")

    accounted = not missing
    if mode == "strict":
        # Upstream semantics: the matrix must be full. Untouched cells block.
        complete = (accounted and not blockers and done == total and total > 0)
    else:
        # Bounty semantics: the backlog is reported, never gated. What DOES block is
        # claiming more than you can show (the gaps above), having worked nothing at all,
        # or leaving a finding in the tree without a verdict.
        complete = (not blockers and done > 0 and not unvalidated_findings)

    missing_set = set(missing)
    return {
        "asset_tag": cells_doc.get("asset_tag") or os.path.basename(asset_dir),
        "asset_dir": asset_dir,
        "mode": mode,
        "cells_total": total,
        "cells_covered": len(covered),
        "cells_negative": len(negative),
        # `untouched` is the whole backlog: rows that say pending PLUS cells never
        # entered in the ledger at all. `pending` counts only the former.
        "cells_untouched": len(pending),
        "cells_pending": len([k for k in pending if k not in missing_set]),
        "cells_unaccounted": len(missing),
        "cells_dangling": len(dangling),
        # The re-derivation result is part of the report, not just a blocker string: a
        # consumer that only looks at coverage_ratio still deserves to see that the
        # denominator was unverifiable.
        "worklist_verified": worklist_ok,
        "worklist_detail": worklist_detail,
        "worklist_derived_cells": len(derived),
        "coverage_ratio": round(ratio, 4),
        "complete": complete,
        "fabrications": fabrications,
        "evidence_gaps": evidence_gaps,
        "verdict_gaps": verdict_gaps,
        "negative_gaps": negative_gaps,
        "unaccounted_cells": missing[:50],
        "dangling_cells": dangling[:50],
        "untouched_by_class": _rollup(pending, applicable),
        "untouched_by_tier": _tier_rollup(pending, applicable),
        "findings_seen": findings_seen,
        "findings_confirmed": confirmed,
        "findings_without_verdict": unvalidated_findings,
        "blockers": blockers,
    }


def _rollup(keys: list[str], applicable: dict) -> dict[str, int]:
    out: dict[str, int] = {}
    for k in keys:
        cid = applicable[k]["class_id"]
        out[cid] = out.get(cid, 0) + 1
    return dict(sorted(out.items(), key=lambda kv: (-kv[1], kv[0])))


def _tier_rollup(keys: list[str], applicable: dict) -> dict[str, int]:
    out: dict[str, int] = {}
    for k in keys:
        tier = applicable[k].get("bounty_tier") or "unrated"
        out[tier] = out.get(tier, 0) + 1
    return dict(sorted(out.items()))


def queue_p1_blockers(run_dir: str) -> tuple[list[str], int, int]:
    """In bounty mode, a P1 lead that nobody worked is a real gap. Returns
    (blockers, p1_total, p1_open)."""
    qpath = os.path.join(run_dir, "queue.json")
    if not os.path.isfile(qpath):
        return ([f"no queue.json at {qpath}: cannot verify P1 leads were worked"], 0, 0)
    q = _load(qpath)
    p1 = [l for l in (q.get("leads") or []) if (l.get("tier") or "").upper() == "P1"]
    open_p1 = [l for l in p1 if (l.get("status") or "queued") not in TERMINAL_LEAD_STATUSES]
    blockers = []
    if open_p1:
        blockers.append(f"{len(open_p1)} of {len(p1)} P1 lead(s) never reached a terminal status")
    return blockers, len(p1), len(open_p1)


def discover_assets(run_dir: str) -> list[str]:
    assets = os.path.join(run_dir, "assets")
    if not os.path.isdir(assets):
        return []
    return sorted(
        d for d in glob.glob(os.path.join(assets, "*"))
        if os.path.isfile(os.path.join(d, "applicability", "cells.json"))
    )


def write_report(out_root: str, doc: dict) -> str:
    d = os.path.join(out_root, "reports")
    os.makedirs(d, exist_ok=True)
    p = os.path.join(d, "coverage-matrix.json")
    with open(p, "w", encoding="utf-8") as fh:
        json.dump(doc, fh, indent=1)
        fh.write("\n")
    return p


def print_asset(a: dict) -> None:
    flag = "COMPLETE" if a["complete"] else "INCOMPLETE"
    print(f"  [{flag}] {a['asset_tag']}  "
          f"{a['cells_covered']} covered + {a['cells_negative']} negative / {a['cells_total']} "
          f"applicable = {a['coverage_ratio']:.1%}")
    print(f"      untouched backlog: {a['cells_untouched']} cell(s) "
          f"({a['cells_unaccounted']} never entered in the ledger, "
          f"{a['cells_pending']} recorded as pending)")
    wl = ("verified against the catalogue" if a.get("worklist_verified")
          else f"NOT VERIFIED — {a.get('worklist_detail', '')}")
    print(f"      work list: {wl}")
    for b in a["blockers"]:
        print(f"      BLOCKER: {b}")
    if a["fabrications"]:
        for f in a["fabrications"][:5]:
            print(f"      FABRICATED N/A: {f['class_id']} on {f['scope_key']}")
    if a["evidence_gaps"]:
        for g in a["evidence_gaps"][:5]:
            print(f"      EVIDENCE MISSING: {g['cell_key']} ({g['why']})")
    if a["verdict_gaps"]:
        for g in a["verdict_gaps"][:5]:
            print(f"      NO VERDICT: {g['cell_key']} finding={g['finding_id']}")
    if a["untouched_by_tier"]:
        tiers = ", ".join(f"{k}={v}" for k, v in a["untouched_by_tier"].items())
        print(f"      untouched backlog by tier: {tiers}")


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(
        description="Score attack-class coverage against the code-produced cell work list.",
        epilog="Examples: python3 tools/coverage_gate.py --asset-dir runs/x/assets/api.demo.test"
               " | python3 tools/coverage_gate.py --run-dir runs/x --mode strict")
    g = ap.add_mutually_exclusive_group(required=True)
    g.add_argument("--asset-dir")
    g.add_argument("--run-dir")
    ap.add_argument("--mode", choices=("bounty", "strict"), default="bounty",
                    help="bounty (default) gates on worked P1 leads and validated findings; "
                         "strict gates on 100%% of applicable cells (upstream semantics).")
    ap.add_argument("--catalog",
                    help="coverage catalogue used to re-derive the applicable set; "
                         "defaults to catalog/bounty-coverage-matrix.json")
    ap.add_argument("--json", action="store_true")
    args = ap.parse_args(argv)

    try:
        if args.asset_dir:
            asset_dirs = [os.path.abspath(args.asset_dir)]
            out_root = asset_dirs[0]
        else:
            run_dir = os.path.abspath(args.run_dir)
            asset_dirs = discover_assets(run_dir)
            out_root = run_dir
            if not asset_dirs:
                print(f"error: no asset has an applicability/cells.json under {run_dir}/assets",
                      file=sys.stderr)
                return 2

        assets = [score_asset(d, args.mode, args.catalog) for d in asset_dirs]
    except GateInputError as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 2

    extra_blockers: list[str] = []
    p1_total = p1_open = 0
    if args.run_dir and args.mode == "bounty":
        extra_blockers, p1_total, p1_open = queue_p1_blockers(out_root)
        if extra_blockers:
            # Attribute a queue-level gap to the run, not to one asset.
            assets[0]["blockers"].extend(extra_blockers)
            assets[0]["complete"] = False

    total_cells = sum(a["cells_total"] for a in assets)
    total_done = sum(a["cells_covered"] + a["cells_negative"] for a in assets)
    doc = {
        "schema": "bbh/coverage-matrix/v1",
        "mode": args.mode,
        "scope": "asset" if args.asset_dir else "run",
        "root": out_root,
        "assets": assets,
        "summary": {
            "assets": len(assets),
            "assets_complete": sum(1 for a in assets if a["complete"]),
            "cells_total": total_cells,
            "cells_done": total_done,
            "coverage_ratio": round(total_done / total_cells, 4) if total_cells else 1.0,
            "fabrications": sum(len(a["fabrications"]) for a in assets),
            "evidence_gaps": sum(len(a["evidence_gaps"]) for a in assets),
            "verdict_gaps": sum(len(a["verdict_gaps"]) for a in assets),
            "negative_gaps": sum(len(a["negative_gaps"]) for a in assets),
            "p1_leads": p1_total,
            "p1_leads_open": p1_open,
            "complete": all(a["complete"] for a in assets),
        },
    }
    report_path = write_report(out_root, doc)

    if args.json:
        print(json.dumps(doc["summary"] | {"report": report_path}, indent=1))
    else:
        print(f"COVERAGE GATE ({args.mode} mode) — {out_root}")
        for a in assets:
            print_asset(a)
        s = doc["summary"]
        verdict = "COMPLETE" if s["complete"] else "INCOMPLETE"
        print(f"\n  {verdict}: {s['assets_complete']}/{s['assets']} asset(s) complete, "
              f"{s['cells_done']}/{s['cells_total']} cell(s) covered "
              f"({s['coverage_ratio']:.1%})")
        if args.mode == "bounty":
            print("  note: in bounty mode the untouched backlog is reported, not gated. "
                  "Use --mode strict for the 100% contract.")
        print(f"  report: {report_path}")

    return 0 if doc["summary"]["complete"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
