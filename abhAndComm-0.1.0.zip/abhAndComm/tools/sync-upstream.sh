#!/usr/bin/env bash
#
# bbh bundle — refresh the two upstream checkouts under _upstream/.
#
#   _upstream/abh   https://github.com/Awarexone/Agentic-Bug-Hunter
#   _upstream/comm  https://github.com/transilienceai/communitytools
#
# These checkouts are REFERENCE MATERIAL ONLY: DSH discovers skills from skill roots,
# not from _upstream/. After syncing, this script re-strips the instruction files that
# would otherwise poison agent context — DSH injects any AGENTS.md / CLAUDE.md chain it
# finds between the project root and the working directory, so leaving them under a
# synced checkout loads two conflicting sets of agent instructions.
#
# It deliberately does NOT regenerate vendor/ or catalog/: those are reviewed changes.

set -euo pipefail

SELF="${BASH_SOURCE[0]}"
while [ -L "$SELF" ]; do
    _link="$(readlink "$SELF")"
    case "$_link" in
        /*) SELF="$_link" ;;
        *) SELF="$(dirname "$SELF")/$_link" ;;
    esac
done
TOOLS_DIR="$(cd -- "$(dirname -- "$SELF")" && pwd -P)"
BUNDLE_ROOT="$(cd -- "$TOOLS_DIR/.." && pwd -P)"
UPSTREAM_DIR="$BUNDLE_ROOT/_upstream"

ABH_URL="https://github.com/Awarexone/Agentic-Bug-Hunter"
COMM_URL="https://github.com/transilienceai/communitytools"

POISON_NAMES=(AGENTS.md AGENTS.local.md CLAUDE.md CLAUDE.local.md OPENCODE.md GEMINI.md)
GUARD="$BUNDLE_ROOT/tools/context_guard.py"
GIT_TIMEOUT="${BBH_GIT_TIMEOUT:-180}"

if [ -t 1 ] && [ -z "${NO_COLOR:-}" ]; then
    C_RESET=$'\033[0m'; C_BOLD=$'\033[1m'
    C_OK=$'\033[32m'; C_WARN=$'\033[33m'; C_ERR=$'\033[31m'
else
    C_RESET=''; C_BOLD=''; C_OK=''; C_WARN=''; C_ERR=''
fi

info() { printf '%s\n' "$*"; }
note() { printf '%s\n' "$*" >&2; }   # progress that must not pollute captured stdout
ok()   { printf '%s%s%s\n' "$C_OK" "$*" "$C_RESET"; }
warn() { printf '%sWARN:%s %s\n' "$C_WARN" "$C_RESET" "$*" >&2; }
err()  { printf '%sERROR:%s %s\n' "$C_ERR" "$C_RESET" "$*" >&2; }
die()  { err "$*"; exit 2; }
hr()   { printf '%s\n' "------------------------------------------------------------------------"; }

usage() {
    cat <<EOF
sync-upstream.sh — refresh _upstream/abh and _upstream/comm from GitHub.

Usage:
  tools/sync-upstream.sh [--check] [--strip-only] [--help]

  (no flags)   Fetch (or shallow-clone) both checkouts to the remote default branch,
               then re-strip the instruction files that poison agent context and run
               tools/context_guard.py --prune-upstream.
  --check      Report whether either upstream moved. Changes nothing on disk
               (uses git ls-remote, so not even local refs are updated).
  --strip-only Do not touch git: just re-strip instruction files across the bundle root
               and run the context guard. Useful after copying a pack into vendor/.
  -h, --help   This help.

Sources:
  abh   $ABH_URL
  comm  $COMM_URL

After a real sync this script prints the new revision of each checkout and reminds you
that vendor/ and catalog/ are now stale. It never regenerates them: that is a reviewed
change, done deliberately and separately.

Why the strip runs after EVERY sync: `git reset --hard` restores the upstream files, so
a sync that does not re-strip re-injects AGENTS.md / CLAUDE.md into the agent context.
EOF
}

# ---------------------------------------------------------------- git helpers
run_git() { # args...
    if command -v timeout >/dev/null 2>&1; then
        GIT_TERMINAL_PROMPT=0 GIT_ASKPASS=/bin/true timeout "$GIT_TIMEOUT" git "$@"
    else
        GIT_TERMINAL_PROMPT=0 GIT_ASKPASS=/bin/true git "$@"
    fi
}

remote_default_ref() { # repo-dir -> remote-tracking ref name (e.g. origin/main)
    local dir="$1" ref
    ref="$(run_git -C "$dir" symbolic-ref --quiet --short refs/remotes/origin/HEAD 2>/dev/null || true)"
    if [ -n "$ref" ]; then printf '%s\n' "$ref"; return 0; fi
    for ref in origin/main origin/master; do
        if run_git -C "$dir" rev-parse --verify --quiet "$ref" >/dev/null 2>&1; then
            printf '%s\n' "$ref"; return 0
        fi
    done
    return 1
}

local_rev() { # repo-dir -> short HEAD, or empty
    run_git -C "$1" rev-parse --short HEAD 2>/dev/null || true
}

remote_rev() { # url -> remote HEAD sha (no local writes)
    run_git ls-remote --exit-code "$1" HEAD 2>/dev/null | awk 'NR==1{print $1}' || true
}

# ---------------------------------------------------------------- strip
# Fast path: delete instruction-candidate files anywhere in the bundle, not just under
# _upstream/. A clone, a copy-paste or a vendor/ refresh can drop one in any directory,
# and every one of them is loaded by the harness. context_guard.py remains the authority
# (it also sees hook configs, shadow skill roots and broken instruction symlinks).
strip_poison() {
    local count=0 find_args=() name rel
    for name in "${POISON_NAMES[@]}"; do
        find_args+=( -name "$name" -o )
    done
    unset 'find_args[${#find_args[@]}-1]'   # drop trailing -o
    while IFS= read -r -d '' f; do
        rel="${f#"$BUNDLE_ROOT"/}"
        if rm -f -- "$f" 2>/dev/null; then
            count=$((count + 1))
            note "  stripped: $rel"
        fi
    done < <(find "$BUNDLE_ROOT" -name .git -prune -o \( "${find_args[@]}" \) -print0 2>/dev/null)
    printf '%s\n' "$count"
}

# Run tools/context_guard.py --prune-upstream and treat its findings as authoritative.
# Returns 0 only when no finding remains after the prune.
run_context_guard() {
    local out rc=0 removed_n findings_n
    if [ ! -f "$GUARD" ]; then
        warn "tools/context_guard.py not found — relying on the built-in strip only"
        return 0
    fi
    out="$(python3 "$GUARD" --prune-upstream --json 2>&1)" || rc=$?

    removed_n="$(printf '%s' "$out" | python3 -c 'import json,sys
try:
    d = json.load(sys.stdin)
except Exception:
    print(-1); raise SystemExit(0)
print(len(d.get("removed") or []))' 2>/dev/null || echo -1)"

    if [ "$removed_n" = "-1" ] || [ -z "$removed_n" ]; then
        err "context_guard.py did not return readable JSON (exit $rc); output follows:"
        printf '%s\n' "$out"
        return 1
    fi

    printf '%s' "$out" | python3 -c 'import json,sys
d = json.load(sys.stdin)
for p in d.get("removed") or []:
    print("  guard pruned: " + p)
for f in d.get("findings") or []:
    print("  [%s] %s: %s" % (f["severity"].upper(), f["kind"], f["path"]))
    print("        " + f["detail"])' || true

    findings_n="$(printf '%s' "$out" | python3 -c 'import json,sys
d = json.load(sys.stdin)
print(len(d.get("findings") or []))' 2>/dev/null || echo -1)"

    if [ "$findings_n" != "0" ]; then
        err "context_guard still reports $findings_n finding(s) after pruning:"
        python3 "$GUARD" || true
        return 1
    fi
    info "  context guard: clean (pruned $removed_n inert/offending file(s), 0 findings remain)"
    return 0
}

# ---------------------------------------------------------------- sync one repo
sync_one() { # label url dir
    local label="$1" url="$2" dir="$3" ref before after

    info ""
    info "${C_BOLD}$label${C_RESET}  $url"
    info "  path : $dir"

    if [ -d "$dir/.git" ]; then
        before="$(local_rev "$dir")"
        if ! run_git -C "$dir" remote get-url origin >/dev/null 2>&1; then
            run_git -C "$dir" remote add origin "$url"
        fi
        if ! run_git -C "$dir" fetch --prune --tags origin; then
            err "  fetch failed for $label (network or auth?) — nothing was reset"
            return 1
        fi
        if ! ref="$(remote_default_ref "$dir")"; then
            err "  cannot resolve origin/HEAD for $label — nothing was reset"
            return 1
        fi
        if ! run_git -C "$dir" reset --hard "$ref" >/dev/null; then
            err "  reset --hard $ref failed for $label"
            return 1
        fi
        after="$(local_rev "$dir")"
        if [ "$before" = "$after" ]; then
            info "  revision : $after (unchanged)"
        else
            info "  revision : $before -> ${C_BOLD}$after${C_RESET}"
        fi
    elif [ -e "$dir" ] && [ ! -d "$dir" ]; then
        err "  $dir exists and is not a directory — refusing to touch it"
        return 1
    elif [ -d "$dir" ] && [ -n "$(ls -A "$dir" 2>/dev/null || true)" ]; then
        err "  $dir exists, is not a git checkout, and is not empty — refusing to clone over it"
        return 1
    else
        info "  state    : not a checkout — shallow clone"
        mkdir -p -- "$(dirname -- "$dir")"
        if ! run_git clone --depth 1 "$url" "$dir"; then
            err "  clone failed for $label (network?)"
            return 1
        fi
        after="$(local_rev "$dir")"
        info "  revision : ${C_BOLD}${after:-unknown}${C_RESET}"
    fi
    return 0
}

# ---------------------------------------------------------------- check one repo
check_one() { # label url dir
    local label="$1" url="$2" dir="$3" want have
    info ""
    info "${C_BOLD}$label${C_RESET}  $url"
    if [ ! -d "$dir/.git" ]; then
        warn "  not a checkout at $dir — a sync would shallow-clone it"
        return 0
    fi
    have="$(local_rev "$dir")"
    want="$(remote_rev "$url")"
    if [ -z "$want" ]; then
        warn "  cannot reach $url (offline?) — local revision $have"
        return 0
    fi
    if [ "$(run_git -C "$dir" rev-parse HEAD 2>/dev/null || true)" = "$want" ]; then
        ok "  up to date at $have"
    else
        warn "  upstream moved: local ${have} -> remote ${want:0:7}  (run without --check to sync)"
    fi
    return 0
}

# ---------------------------------------------------------------- main
MODE="sync"
while [ "$#" -gt 0 ]; do
    case "$1" in
        --check) MODE="check"; shift ;;
        --strip-only) MODE="strip"; shift ;;
        -h|--help) usage; exit 0 ;;
        *) die "unknown option: $1 (try --help)" ;;
    esac
done

command -v git >/dev/null 2>&1 || die "git not found on PATH"

if [ "$MODE" = "check" ]; then
    info "sync-upstream.sh --check  (nothing will be modified)"
    hr
    check_one "abh"  "$ABH_URL"  "$UPSTREAM_DIR/abh"
    check_one "comm" "$COMM_URL" "$UPSTREAM_DIR/comm"
    hr
    info "Note: this is a network read only; no refs, no files, and no vendor/ or"
    info "catalog/ regeneration were performed."
    exit 0
fi

info "sync-upstream.sh$([ "$MODE" = strip ] && echo '  --strip-only' || true)"
info "  bundle   : $BUNDLE_ROOT"
info "  upstream : $UPSTREAM_DIR"
hr

rc=0
if [ "$MODE" = "sync" ]; then
    sync_one "abh"  "$ABH_URL"  "$UPSTREAM_DIR/abh"  || rc=1
    sync_one "comm" "$COMM_URL" "$UPSTREAM_DIR/comm" || rc=1
else
    info "  (git untouched: --strip-only)"
fi

info ""
info "Re-stripping agent-instruction files across the bundle root"
stripped="$(strip_poison)"
info "  removed $stripped file(s) matching: ${POISON_NAMES[*]}"
info "  (DSH injects the AGENTS.md/CLAUDE.md chain between project root and cwd — leaving"
info "   these would load a second, conflicting set of agent instructions.)"

info ""
info "context_guard.py --prune-upstream"
run_context_guard || rc=1

hr
info "${C_BOLD}Revisions${C_RESET}"
info "  abh  : $(local_rev "$UPSTREAM_DIR/abh" || echo 'not present')"
info "  comm : $(local_rev "$UPSTREAM_DIR/comm" || echo 'not present')"
hr
if [ "$MODE" = "sync" ]; then
    warn "vendor/ and catalog/ are now STALE relative to _upstream/."
    warn "Regenerate them deliberately, review the diff, and update VERSION — this script"
    warn "does not do that for you (regeneration is a reviewed change, not an automatic one)."
    info "  vendor  : $BUNDLE_ROOT/vendor/"
    info "  catalog : $BUNDLE_ROOT/catalog/"
    info "  version : $BUNDLE_ROOT/VERSION"
fi

if [ "$rc" -ne 0 ]; then
    err "sync completed with errors (see above)"
    exit 1
fi
exit 0
