#!/usr/bin/env python3
"""Stage 2 SURFACE: turn a classification (and the code-produced coverage cells)
into ``bbh/queue/v1`` — the work list that NEVER eliminates anything.

WHY THIS TOOL EXISTS
--------------------
Classic bug-bounty triage has a kill list: signals that look boring get dropped
before anyone works them. That is how a real bug is lost silently, and it is
also how "we never looked" becomes indistinguishable from "we looked and found
nothing" in the final report. This queue has no kill list, no 'skip' status and
no dropped lead. Everything becomes a lead. The lowest band is ``P3``, which
means "after P1 and P2", not "ignore".

Priority is a documented additive score clamped to 0-100. Every point comes from
a named component with a stated weight (see PRICE TABLE below), and ``--explain``
prints the arithmetic per lead so a human can argue with a ranking instead of
guessing at it. Bands are presentation only: P1 >= 70, P2 >= 40, else P3.

``lead_id`` is a short hash of ``asset_tag|class_id|address|bucket`` so it is
stable across re-runs over the same inputs — ``lead_board.py touch`` refers to
it later, and a re-run must not renumber work that is already in progress. Each
lead's ``status`` and ``touched_by`` are copied forward from ``--prior-queue``.

Usage
-----
    python3 tools/queue_build.py \\
        --classification runs/acme-2026-09/classification.json \\
        --cells-dir runs/acme-2026-09/assets \\
        --catalog catalog/bounty-coverage-matrix.json \\
        --out runs/acme-2026-09/queue.json --explain

Exit codes: 0 = queue written, 1 = real negative (no lead at all),
2 = bad input (classification/prior queue/cells unreadable).
"""
from __future__ import annotations

import argparse
import hashlib
import json
import re
import sys
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable, Sequence

try:  # optional: the schema self-check degrades to a warning without it
    import jsonschema
except ImportError:  # pragma: no cover
    jsonschema = None

SCHEMA_ID = "bbh/queue/v1"
TOOL = "queue_build.py"

# ===========================================================================
# PRICE TABLE — the whole scoring model, in one place.
#
# score = clamp(0, 100, BASE + bucket + param + asset + catalog_bounty + chain)
#   BASE   : every lead exists, so every lead carries the floor.
#   bucket : the class of signal (a leaked credential outranks a generic
#            admin path; see BUCKET_WEIGHT + JS_SECRET_KIND_WEIGHT).
#   param  : the strongest gf/parameter signal on the lead (see PARAM_WEIGHT).
#   asset  : how much the asset itself is worth (apex/API vs a static CDN).
#   catalog: the catalogue's own bounty_tier for the mapped class.
#   chain  : PENALTY when the class only pays chained (NEEDS_CHAIN_PENALTY).
# ===========================================================================

BASE_POINTS = 10
P1_THRESHOLD = 70
P2_THRESHOLD = 40

# Keyed by the classification bucket name (and "coverage-cell" for leads that
# come from applicability/cells.json), so the table reads the same way as the
# classification document an operator is looking at.
BUCKET_WEIGHT: dict[str, int] = {
    "takeover": 30,             # a dangling CNAME can be a whole subdomain
    "js_secrets": 12,           # plus JS_SECRET_KIND_WEIGHT below
    "cloud": 20,                # exposed storage / origin
    "api_endpoints": 20,        # the application's real API surface
    "auth_paths": 18,           # authentication is where ATO lives
    "interesting_params": 16,   # plus PARAM_WEIGHT below
    "admin_paths": 16,          # management/debug surface
    "coverage-cell": 18,        # catalogue-applicable (asset x class) cell
    "ports": 8,                 # a listener, nothing more yet
}

JS_SECRET_KIND_WEIGHT: dict[str, int] = {
    "credential": 24,           # a live credential is the strongest signal here
    "token": 16,
    "api_key": 14,
    "bucket": 10,
    "internal_host": 8,
    "config": 6,
    "endpoint": 4,
    "other": 2,
}

PARAM_WEIGHT: dict[str, int] = {
    "ssrf": 18,
    "sqli": 18,
    "idor": 16,
    "lfi": 14,
    "xss": 12,
    "redirect": 10,
    "generic": 4,               # a parameter we know nothing more about
}

ASSET_CRITICALITY: dict[str, int] = {
    "apex": 18,
    "api": 16,
    "web": 12,
    "mobile": 8,
    "ip": 8,
    "cidr": 6,
    "static_cdn": 2,
    "unknown": 6,
}

BOUNTY_TIER_WEIGHT: dict[str, int] = {
    "high": 20,
    "medium": 14,
    "low": 6,
    "info": 0,
    "unknown": 0,               # no catalogue / no tier -> no points, no error
}

NEEDS_CHAIN_PENALTY = -12       # "only pays chained": start lower, never dropped

# Bucket -> bbh/queue/v1 ``source`` enum value.
BUCKET_SOURCE: dict[str, str] = {
    "api_endpoints": "abh-bucket",
    "auth_paths": "auth-path",
    "admin_paths": "admin-path",
    "interesting_params": "param",
    "js_secrets": "js-secret",
    "cloud": "cloud",
    "takeover": "takeover",
    "ports": "port",
    "coverage-cell": "coverage-cell",
}

# Bucket -> catalogue class, used ONLY when the catalogue actually contains the
# id (see load_catalog). A null class_id is an honest "this raw signal has no
# single class", not an omission: inventing one would fabricate applicability.
CLASS_HINTS: dict[str, str] = {
    "js_secrets": "XC-SECRET-EXPOSURE",
    "auth_paths": "API2-BROKEN-AUTH",
    "admin_paths": "API9-INVENTORY",
    "cloud": "API9-INVENTORY",
    "takeover": "XC-SUBDOMAIN-ORIGIN",
}

GF_PARAM_CLASS: dict[str, str] = {
    "ssrf": "ssrf",
    "sqli": "sqli",
    "idor": "idor",
    "lfi": "lfi",
    "xss": "xss",
    "redirect": "redirect",
}

# A gf pattern is a class-shaped signal, so when the catalogue actually contains
# the matching class we tag the lead with it — that is what lets the catalogue's
# own bounty_tier apply. This fabricates nothing: the raw parameter signal and
# its gf pattern stay on the lead, and a missing catalogue class stays null.
GF_CLASS_HINTS: dict[str, str] = {
    "ssrf": "API7-SSRF",
    "sqli": "WEB-A03-INJECTION",
    "idor": "API1-BOLA",
    "lfi": "WEB-A03-INJECTION",
    "xss": "XC-STORED-XSS",
    "redirect": "XC-OPEN-REDIRECT",
}

TECH_STATIC_HINTS = ("cloudflare", "akamai", "fastly", "amazon cloudfront", "amazon s3",
                     "s3", "bunny", "stackpath", "cdn", "varnish")


# ---------------------------------------------------------------------------
# Catalogue loading (tolerant; missing catalogue degrades, never crashes)
# ---------------------------------------------------------------------------


class QueueInputError(Exception):
    """Unreadable or malformed input — mapped to exit code 2 by main()."""


@dataclass
class ClassInfo:
    class_id: str
    title: str = ""
    bounty_tier: str = "unknown"
    needs_chain: bool = False
    technique_refs: tuple[str, ...] = ()
    scope: str = ""


def _first(d: dict[str, Any], *keys: str) -> Any:
    for k in keys:
        if d.get(k) not in (None, "", [], {}):
            return d[k]
    return None


def _norm_tier(value: Any) -> str:
    text = str(value or "").strip().lower()
    if text in ("critical", "crit"):
        return "high"
    if text in ("high", "medium", "low", "info"):
        return text
    if text in ("none", "n/a", "na"):
        return "info"
    return "unknown"


def _as_refs(value: Any) -> tuple[str, ...]:
    if isinstance(value, str):
        return (value,)
    if isinstance(value, (list, tuple)):
        return tuple(str(v) for v in value if isinstance(v, (str, int)))
    return ()


def load_catalog(path: Path | None) -> tuple[dict[str, ClassInfo], str]:
    """Return ({class_id: ClassInfo}, status_message).

    The catalogue is written by a different stage, so this loader accepts the
    documented shape ({"classes": [{class_id, bounty_tier, needs_chain,
    technique_ref}]}) and the obvious variants, and NEVER hard-codes class ids.
    """
    if path is None:
        return {}, "no --catalog given: bounty_tier/needs_chain/class mapping unavailable"
    if not path.is_file():
        return {}, f"catalogue not found at {path}: bounty_tier/needs_chain unavailable (queue still built)"
    try:
        doc = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        return {}, f"catalogue unreadable ({exc}): bounty_tier/needs_chain unavailable (queue still built)"
    raw: Any
    if isinstance(doc, dict):
        raw = _first(doc, "classes", "catalog", "attack_classes", "items") or {}
    else:
        raw = doc
    entries: list[dict[str, Any]] = []
    if isinstance(raw, dict):
        for key, value in raw.items():
            if isinstance(value, dict):
                entries.append(dict(value, class_id=value.get("class_id") or key))
    elif isinstance(raw, list):
        entries = [e for e in raw if isinstance(e, dict)]
    out: dict[str, ClassInfo] = {}
    for e in entries:
        cid = str(_first(e, "class_id", "id", "class", "name") or "").strip()
        if not cid:
            continue
        out[cid] = ClassInfo(
            class_id=cid,
            title=str(_first(e, "title", "name") or ""),
            bounty_tier=_norm_tier(_first(e, "bounty_tier", "tier", "payout_tier", "payout", "severity")),
            needs_chain=bool(_first(e, "needs_chain", "requires_chain", "chain_only", "chained") or False),
            technique_refs=_as_refs(_first(e, "technique_ref", "technique_refs", "playbook",
                                            "skill_ref", "references", "ref")),
            scope=str(_first(e, "scope") or ""),
        )
    msg = (f"catalogue {path}: {len(out)} class(es), "
           f"{sum(1 for c in out.values() if c.bounty_tier != 'unknown')} with a bounty_tier")
    return out, msg


# ---------------------------------------------------------------------------
# Leads
# ---------------------------------------------------------------------------


@dataclass
class Lead:
    asset_tag: str
    asset_id: str
    class_id: str | None
    address: str
    bucket: str
    source: str
    rationale: str
    unit_id: str | None = None
    params: tuple[str, ...] = ()
    gf_patterns: tuple[str, ...] = ()
    js_kind: str | None = None
    status: str = "queued"
    touched_by: str | None = None
    evidence: tuple[str, ...] = ()

    # Set only on a lead carried forward from a prior queue because its signal vanished from
    # the current classification. Such a lead keeps the priority and tier it was scored with
    # WHEN ITS SIGNAL EXISTED — see the carry-forward block in build() for why re-scoring it
    # would silently demote work that is still owed.
    carried_forward: bool = False
    carried_priority: int | None = None
    carried_tier: str | None = None

    def key(self) -> str:
        return f"{self.asset_tag}|{self.class_id or ''}|{self.address}|{self.bucket}"

    @property
    def lead_id(self) -> str:
        digest = hashlib.sha256(self.key().encode("utf-8")).hexdigest()[:6].upper()
        return f"L-{digest}"


def lead_id_of(asset_tag: str, class_id: str | None, address: str, bucket: str) -> str:
    digest = hashlib.sha256(
        f"{asset_tag}|{class_id or ''}|{address}|{bucket}".encode("utf-8")).hexdigest()[:6].upper()
    return f"L-{digest}"


def asset_criticality(asset: dict[str, Any], scope_kinds: dict[str, str]) -> tuple[str, int]:
    """Return (label, points) for the asset's own worth."""
    tag = str(asset.get("asset_tag") or "")
    tech = [str(t).lower() for t in (asset.get("tech") or [])]
    server = str(asset.get("server") or "").lower()
    if any(h in tech or h in server for h in TECH_STATIC_HINTS):
        return "static_cdn", ASSET_CRITICALITY["static_cdn"]
    kind = scope_kinds.get(tag, "")
    if kind in ("ip", "cidr", "mobile"):
        return kind, ASSET_CRITICALITY[kind]
    if asset.get("apex"):
        return "apex", ASSET_CRITICALITY["apex"]
    if kind == "api" or tag.split(".")[0] == "api":
        return "api", ASSET_CRITICALITY["api"]
    if kind == "web":
        return "web", ASSET_CRITICALITY["web"]
    if tag:
        return "unknown", ASSET_CRITICALITY["unknown"]
    return "unknown", ASSET_CRITICALITY["unknown"]


def param_component(lead: Lead) -> tuple[str, int]:
    """Strongest parameter/gf signal on this lead."""
    best = "generic" if lead.params else ""
    for pattern in lead.gf_patterns:
        p = GF_PARAM_CLASS.get(pattern.lower())
        if p and PARAM_WEIGHT[p] > PARAM_WEIGHT.get(best, 0):
            best = p
    if not best:
        return "none", 0
    return best, PARAM_WEIGHT[best]


def score_lead(lead: Lead, asset: dict[str, Any], scope_kinds: dict[str, str],
               catalog: dict[str, ClassInfo]) -> tuple[int, list[tuple[str, str, int]]]:
    """Return (priority 0-100, [(component, detail, points), ...])."""
    parts: list[tuple[str, str, int]] = [("base", "lead exists", BASE_POINTS)]

    bucket_points = BUCKET_WEIGHT.get(lead.bucket, 0)
    detail = lead.bucket
    if lead.bucket == "js_secrets" and lead.js_kind:
        bucket_points += JS_SECRET_KIND_WEIGHT.get(lead.js_kind, 0)
        detail = f"js_secret/{lead.js_kind}"
    parts.append(("bucket", detail, bucket_points))

    p_label, p_points = param_component(lead)
    parts.append(("param", p_label if p_points else "none", p_points))

    a_label, a_points = asset_criticality(asset, scope_kinds)
    parts.append(("asset", a_label, a_points))

    info = catalog.get(lead.class_id or "")
    tier = info.bounty_tier if info else "unknown"
    parts.append(("catalog", f"bounty_tier={tier}", BOUNTY_TIER_WEIGHT.get(tier, 0)))

    chain = NEEDS_CHAIN_PENALTY if (info and info.needs_chain) else 0
    parts.append(("chain", "needs_chain" if chain else "standalone", chain))

    total = sum(p for _, _, p in parts)
    return max(0, min(100, total)), parts


def tier_for(priority: int) -> str:
    if priority >= P1_THRESHOLD:
        return "P1"
    if priority >= P2_THRESHOLD:
        return "P2"
    return "P3"


# ---------------------------------------------------------------------------
# Input readers
# ---------------------------------------------------------------------------


def read_json(path: Path, what: str) -> Any:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except OSError as exc:
        raise QueueInputError(f"{TOOL}: ERROR cannot read {what} {path}: {exc}") from exc
    except json.JSONDecodeError as exc:
        raise QueueInputError(f"{TOOL}: ERROR {what} {path} is not valid JSON: {exc}") from exc


def cells_from_file(path: Path) -> tuple[list[tuple[str, str, str | None]], int]:
    """Normalise an applicability/cells.json into (class_id, scope_key, unit_id).

    `unit_id` matters for more than bookkeeping: `contracts/surface-queue.schema.json`
    says it is set for every coverage-cell lead, and it is the key `lead_board.py` uses to
    resolve a human-readable address out of surface.json. A cell carries `scope` and
    `scope_key` rather than a `unit_id` field, and for scope == "unit" the scope_key IS the
    unit id — so derive it here. Without this the lead ends up with `unit_id: null` and an
    `address` of "u-0011", which is a valid ledger key and a useless instruction.
    """
    doc = read_json(path, "cells file")
    if isinstance(doc, dict):
        raw = doc.get("cells") or doc.get("applicable_cells") or []
    elif isinstance(doc, list):
        raw = doc
    else:
        raw = []
    default_tag = str(doc.get("asset_tag") or "") if isinstance(doc, dict) else ""
    out: list[tuple[str, str, str | None]] = []
    for item in raw:
        if isinstance(item, str):
            out.append((item, default_tag, None))
            continue
        if not isinstance(item, dict):
            continue
        cid = str(_first(item, "class_id", "class", "id") or "")
        if not cid:
            continue
        scope = str(_first(item, "scope", "scope_kind") or "").lower()
        scope_key = str(_first(item, "scope_key", "key", "unit_id", "address") or "")
        unit_id = _first(item, "unit_id")
        if not unit_id and scope == "unit" and scope_key:
            unit_id = scope_key
        out.append((cid, scope_key, str(unit_id) if unit_id else None))
    return out, len(out)


def unit_addresses(surface_path: Path) -> dict[str, str]:
    if not surface_path.is_file():
        return {}
    try:
        doc = json.loads(surface_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return {}
    out: dict[str, str] = {}
    for unit in doc.get("units") or []:
        if isinstance(unit, dict) and unit.get("unit_id"):
            out[str(unit["unit_id"])] = str(unit.get("address") or "")
    return out


def scope_kinds(scope_path: Path | None) -> dict[str, str]:
    if not scope_path or not scope_path.is_file():
        return {}
    try:
        doc = json.loads(scope_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return {}
    out: dict[str, str] = {}
    for asset in doc.get("assets") or []:
        if not isinstance(asset, dict):
            continue
        value = str(asset.get("value") or "").lower()
        if "://" in value:
            value = value.split("://", 1)[1]
        value = value.split("/")[0].split(":")[0].rstrip(".")
        if value:
            out[value] = str(asset.get("kind") or "")
    return out


def leads_from_classification(doc: dict[str, Any], catalog: dict[str, ClassInfo]) -> list[Lead]:
    leads: list[Lead] = []
    for asset in doc.get("assets") or []:
        if not isinstance(asset, dict):
            continue
        tag = str(asset.get("asset_tag") or "")
        aid = str(asset.get("asset_id") or tag)
        buckets = asset.get("buckets") or {}
        for bucket, items in buckets.items():
            if bucket not in BUCKET_SOURCE:
                continue
            source = BUCKET_SOURCE[bucket]
            hinted = CLASS_HINTS.get(bucket)
            class_id = hinted if (hinted and hinted in catalog) else None
            for entry in items or []:
                if not isinstance(entry, dict):
                    continue
                address = str(entry.get("url") or entry.get("host") or entry.get("cname") or "")
                if bucket == "ports":
                    address = f"{tag}:{entry.get('port')}" if entry.get("port") else tag
                evidence = str(entry.get("evidence") or "")
                params: tuple[str, ...] = ()
                patterns: tuple[str, ...] = ()
                js_kind: str | None = None
                if bucket == "interesting_params":
                    params = tuple(str(p) for p in (entry.get("params") or []))
                if bucket == "js_secrets":
                    js_kind = str(entry.get("kind") or "other")
                src_field = str(entry.get("source") or "")
                # A URL seen by two gf patterns carries "gf:sqli+gf:xss"; take
                # every gf token, not just the first, or the strongest signal is
                # silently lost when sources merge.
                patterns = tuple(re.findall(r"gf:([\w.\-]+)", src_field))
                rationale_bits = [f"classification bucket {bucket}"]
                if js_kind:
                    rationale_bits.append(f"kind={js_kind}")
                if params:
                    rationale_bits.append("params=" + ",".join(params[:6]))
                if patterns:
                    rationale_bits.append("gf=" + ",".join(patterns))
                # Per-entry class: never mutate the bucket-level default, or the
                # first entry's hint leaks onto every later entry of that bucket.
                entry_class = class_id
                for pattern in patterns:
                    hinted_gf = GF_CLASS_HINTS.get(pattern)
                    if entry_class is None and hinted_gf and hinted_gf in catalog:
                        entry_class = hinted_gf
                leads.append(Lead(
                    asset_tag=tag, asset_id=aid, class_id=entry_class, address=address,
                    bucket=bucket, source=source,
                    rationale="; ".join(rationale_bits) + (f" [{evidence}]" if evidence else ""),
                    params=params, gf_patterns=patterns, js_kind=js_kind,
                    evidence=(evidence,) if evidence else (),
                ))
    return leads


def leads_from_cells(cells_dir: Path) -> tuple[list[Lead], dict[str, int]]:
    leads: list[Lead] = []
    seed: dict[str, int] = {}
    for asset_dir in sorted(p for p in cells_dir.iterdir() if p.is_dir()) if cells_dir.is_dir() else []:
        cells_path = asset_dir / "applicability" / "cells.json"
        if not cells_path.is_file():
            continue
        try:
            cells, count = cells_from_file(cells_path)
        except QueueInputError as exc:
            print(f"{TOOL}: WARN {exc} — cells for {asset_dir.name} skipped", file=sys.stderr)
            continue
        seed[asset_dir.name] = count
        addresses = unit_addresses(asset_dir / "recon" / "inventory" / "surface.json")
        for class_id, scope_key, unit_id in cells:
            # A lead whose address is a bare unit id ("u-0001") is useless to the
            # person holding the keyboard, so resolve the scope key to something
            # pointable: the unit's address from surface.json for unit scope, a
            # listener URL for host scope, the asset tag for asset scope.
            if unit_id:
                address = addresses.get(unit_id, "")
                if not address:
                    address = f"{asset_dir.name}#{unit_id}"
                    print(f"{TOOL}: WARN cell {class_id} on {asset_dir.name}: unit {unit_id!r} is "
                          f"not in recon/inventory/surface.json — address degraded to "
                          f"{address!r} (still a lead, just a coarser one)", file=sys.stderr)
            elif re.fullmatch(r"[\w.\-]+:\d+", scope_key or ""):
                address = f"https://{scope_key}"
            else:
                address = scope_key or asset_dir.name
            leads.append(Lead(
                asset_tag=asset_dir.name, asset_id=asset_dir.name, class_id=class_id,
                address=address, bucket="coverage-cell", source="coverage-cell",
                rationale=(f"code-produced applicable cell {class_id} "
                           f"(key={scope_key or 'asset'}) — catalogue predicate matched"),
                unit_id=unit_id,
            ))
    return leads, seed


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------


def build(classification_path: Path, cells_dir: Path | None, catalog_path: Path | None,
          prior_path: Path | None, scope_path: Path | None, engagement_override: str | None
          ) -> tuple[dict[str, Any], dict[str, Any]]:
    cls = read_json(classification_path, "classification")
    if not isinstance(cls, dict):
        raise QueueInputError(
            f"{TOOL}: ERROR classification {classification_path} is not a JSON object")
    catalog, catalog_msg = load_catalog(catalog_path)
    print(f"{TOOL}: {catalog_msg}")

    kinds = scope_kinds(scope_path)
    if not kinds:
        print(f"{TOOL}: no usable --scope: asset kinds are unknown, so criticality falls back to "
              f"apex/static-CDN/unknown and API/web assets score as 'unknown'")
    assets_by_tag: dict[str, dict[str, Any]] = {}
    for asset in cls.get("assets") or []:
        if isinstance(asset, dict) and asset.get("asset_tag"):
            assets_by_tag[str(asset["asset_tag"])] = asset

    bucket_leads = leads_from_classification(cls, catalog)
    cell_leads: list[Lead] = []
    seed: dict[str, int] = {}
    if cells_dir is not None:
        cell_leads, seed = leads_from_cells(cells_dir)
        print(f"{TOOL}: cells dir {cells_dir}: {len(cell_leads)} applicable cell(s) "
              f"across {len(seed)} asset(s)")
    else:
        print(f"{TOOL}: no --cells-dir: queue carries classification leads only "
              f"(no coverage cells to seed)")

    # Never eliminate: dedupe identical leads by their stable id, keep every
    # distinct signal. Merging evidence is not dropping a lead.
    by_id: dict[str, Lead] = {}
    for lead in bucket_leads + cell_leads:
        lid = lead.lead_id
        existing = by_id.get(lid)
        if existing is None:
            by_id[lid] = lead
            continue
        merged_evidence = tuple(dict.fromkeys(existing.evidence + lead.evidence))
        existing.evidence = merged_evidence
        if lead.rationale not in existing.rationale:
            existing.rationale = f"{existing.rationale}; also {lead.rationale}"
        existing.params = tuple(dict.fromkeys(existing.params + lead.params))
        existing.gf_patterns = tuple(dict.fromkeys(existing.gf_patterns + lead.gf_patterns))

    # Preserve prior status/touched_by across re-runs, and carry forward any
    # prior lead whose signal is no longer in the classification: this tool
    # never eliminates, so a shrunken input must not silently delete work.
    preserved = 0
    carried = 0
    prior_count = 0
    if prior_path is not None and prior_path.is_file():
        prior = read_json(prior_path, "prior queue")
        rows = prior.get("leads") if isinstance(prior, dict) else None
        for row in rows or []:
            if not isinstance(row, dict) or not row.get("lead_id"):
                continue
            prior_count += 1
            lead = by_id.get(str(row["lead_id"]))
            if lead is None:
                carried += 1
                # CARRY FORWARD WITHOUT DEMOTING.
                #
                # This lead's signal is gone from the current classification, so score_lead()
                # would now compute a lower score from the reduced evidence — in practice a P1
                # becomes a P2. That matters more than it looks: in bounty mode the completion
                # condition is "every P1 lead reached a terminal status", so a silent demotion
                # removes the lead from the set of things still owed. The operator wanted
                # "never quietly look at less", and re-scoring would deliver exactly that in a
                # subtler form.
                #
                # So the prior priority and tier are carried verbatim, along with the params and
                # evidence that justified them. The lead is flagged so the demotion is not
                # hidden either — it is visible in the file and in --explain.
                prior_prio = row.get("priority")
                prior_tier = str(row.get("tier") or "")
                lead = Lead(
                    asset_tag=str(row.get("asset_tag") or ""),
                    asset_id=str(row.get("asset_id") or row.get("asset_tag") or ""),
                    class_id=(str(row["class_id"]) if row.get("class_id") else None),
                    address=str(row.get("address") or ""),
                    bucket=str(row.get("bucket") or "carried-forward"),
                    source=(str(row["source"]) if row.get("source") in
                            ("coverage-cell", "abh-bucket", "js-secret", "auth-path", "admin-path",
                             "param", "cloud", "takeover", "port", "memory-pattern") else "memory-pattern"),
                    rationale=("carried forward from the prior queue: this lead's signal is not in "
                               "the current classification, and this tool never eliminates. Its "
                               "priority is preserved from the run that DID see the signal"),
                    unit_id=(str(row["unit_id"]) if row.get("unit_id") else None),
                    params=tuple(str(p) for p in (row.get("params") or [])),
                    gf_patterns=tuple(str(p) for p in (row.get("gf_patterns") or [])),
                    evidence=tuple(str(e) for e in (row.get("evidence") or [])),
                    carried_forward=True,
                    carried_priority=(int(prior_prio)
                                      if isinstance(prior_prio, (int, float)) else None),
                    carried_tier=(prior_tier if prior_tier in ("P1", "P2", "P3") else None),
                )
                # force the prior id so lead_board.py keeps working
                lead_id_override = str(row["lead_id"])
                by_id[lead_id_override] = lead
                if row.get("status"):
                    lead.status = str(row["status"])
                if row.get("touched_by") is not None:
                    lead.touched_by = row["touched_by"]
                continue
            if row.get("status"):
                lead.status = str(row["status"])
            if row.get("touched_by") is not None:
                lead.touched_by = row["touched_by"]
            preserved += 1
        print(f"{TOOL}: prior queue {prior_path}: {preserved}/{prior_count} lead(s) matched, "
              f"status/touched_by preserved; {max(0, prior_count - preserved)} prior lead(s) "
              f"are not in this build (nothing was deleted from the queue file by this tool)")
        if carried:
            print(f"{TOOL}: {carried} prior lead(s) carried forward (signal absent from the current "
                  f"classification; nothing is ever eliminated)")
    elif prior_path is not None:
        print(f"{TOOL}: prior queue {prior_path} not found — fresh statuses (queued)")

    scored: list[dict[str, Any]] = []
    explanations: list[tuple[str, int, str, list[tuple[str, str, int]]]] = []
    for lid, lead in by_id.items():
        # lid is the dict key: for a normal lead it is lead.lead_id, and for a
        # carried-forward lead it is the PRIOR id, kept verbatim so that an
        # in-progress lead_board.py status never loses its target.
        asset = assets_by_tag.get(lead.asset_tag, {"asset_tag": lead.asset_tag})
        if lead.carried_forward and lead.carried_priority is not None:
            # Scored when the signal was visible; re-scoring now would demote it. Keep both
            # numbers in the breakdown so the difference is inspectable rather than asserted.
            priority = lead.carried_priority
            rescored, _ = score_lead(lead, asset, kinds, catalog)
            tier = lead.carried_tier or tier_for(priority)
            parts = [("carried",
                      f"priority {priority} preserved from the prior queue "
                      f"(re-scoring the reduced signal today would give {rescored})", priority)]
        else:
            priority, parts = score_lead(lead, asset, kinds, catalog)
            tier = tier_for(priority)
        scored.append({
            "lead_id": lid,
            "asset_tag": lead.asset_tag,
            "asset_id": lead.asset_id,
            "unit_id": lead.unit_id,
            "class_id": lead.class_id,
            "address": lead.address,
            "bucket": lead.bucket,
            "priority": priority,
            "tier": tier,
            "rationale": lead.rationale,
            "source": lead.source,
            "status": lead.status,
            "touched_by": lead.touched_by,
            "evidence": list(lead.evidence),
        })
        if lead.carried_forward:
            scored[-1]["carried_forward"] = True
        if lead.params:
            scored[-1]["params"] = list(lead.params)
        if lead.gf_patterns:
            scored[-1]["gf_patterns"] = list(lead.gf_patterns)
        explanations.append((lid, priority, lead.asset_tag, parts))

    scored.sort(key=lambda r: (-r["priority"], r["asset_tag"], r["class_id"] or "",
                               r["address"], r["lead_id"]))
    for i, row in enumerate(scored, start=1):
        row["lead_seq"] = i

    engagement = (engagement_override or cls.get("engagement")
                  or (cls.get("target") if isinstance(cls.get("target"), str) else "") or "")
    doc: dict[str, Any] = {
        "schema": SCHEMA_ID,
        "engagement": engagement,
        "generated_at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "lead_count": len(scored),
        "leads": scored,
        "coverage_seed": dict(sorted(seed.items())),
        "note": ("This queue never eliminates: no kill list, no skip status, no dropped lead. "
                 "P3 means 'after P1 and P2', not 'ignore'. lead_id is a stable hash of "
                 "asset_tag|class_id|address|bucket, so lead_board.py touch survives a re-run."),
        "tool": TOOL,
    }
    explain = {
        "weights": {
            "base": BASE_POINTS,
            "bucket": BUCKET_WEIGHT,
            "js_secret_kind": JS_SECRET_KIND_WEIGHT,
            "param": PARAM_WEIGHT,
            "asset": ASSET_CRITICALITY,
            "bounty_tier": BOUNTY_TIER_WEIGHT,
            "needs_chain_penalty": NEEDS_CHAIN_PENALTY,
            "thresholds": {"P1": P1_THRESHOLD, "P2": P2_THRESHOLD},
        },
        "explanations": explanations,
        "counts": {
            "classification_leads": len(bucket_leads),
            "coverage_cell_leads": len(cell_leads),
            "unique_leads": len(scored),
            "bands": {t: sum(1 for r in scored if r["tier"] == t) for t in ("P1", "P2", "P3")},
        },
    }
    return doc, explain


def validate(doc: dict[str, Any]) -> list[str]:
    schema_path = Path(__file__).resolve().parent.parent / "contracts" / "surface-queue.schema.json"
    if jsonschema is None:
        print(f"{TOOL}: WARN jsonschema not importable — output NOT schema-checked", file=sys.stderr)
        return []
    if not schema_path.is_file():
        print(f"{TOOL}: WARN schema {schema_path} not found — output NOT schema-checked",
              file=sys.stderr)
        return []
    validator = jsonschema.Draft202012Validator(json.loads(schema_path.read_text(encoding="utf-8")))
    return [f"{'/'.join(str(p) for p in err.absolute_path)}: {err.message}"
            for err in sorted(validator.iter_errors(doc), key=lambda e: list(e.absolute_path))]


def main(argv: Sequence[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        prog=TOOL,
        description="Build bbh/queue/v1 from a classification (+ optional coverage cells). "
                    "Never eliminates anything: the lowest band is P3.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=("Example:\n"
                "  python3 tools/queue_build.py \\\n"
                "      --classification runs/acme-2026-09/classification.json \\\n"
                "      --cells-dir runs/acme-2026-09/assets \\\n"
                "      --catalog catalog/bounty-coverage-matrix.json \\\n"
                "      --out runs/acme-2026-09/queue.json --explain\n\n"
                "Bands: P1 >= 70, P2 >= 40, else P3 ('after P1 and P2' — never a kill).\n"
                "Exit codes: 0 queue written, 1 real negative (no lead), 2 bad input."),
    )
    parser.add_argument("--classification", required=True, help="classification.json (Stage 1)")
    parser.add_argument("--cells-dir", help="run's assets/ dir: adds coverage-cell leads and "
                                            "fills coverage_seed from */applicability/cells.json")
    parser.add_argument("--catalog", help="bounty-coverage-matrix.json (missing -> degrade, "
                                          "bounty_tier/needs_chain unavailable)")
    parser.add_argument("--out", required=True, help="queue.json to write")
    parser.add_argument("--explain", action="store_true",
                        help="print the per-lead score arithmetic (component breakdown)")
    parser.add_argument("--prior-queue", help="existing queue.json whose per-lead status/"
                                              "touched_by must be preserved")
    parser.add_argument("--scope", help="scope.json (optional; asset kinds for scoring)")
    parser.add_argument("--engagement", help="override the engagement slug")
    parser.add_argument("--json", action="store_true", help="print a single JSON summary object")
    parser.add_argument("--no-validate", action="store_true",
                        help="skip the jsonschema self-check of the emitted document")
    args = parser.parse_args(argv)

    cls_path = Path(args.classification).expanduser()
    if not cls_path.is_file():
        print(f"{TOOL}: ERROR classification not found: {cls_path}", file=sys.stderr)
        return 2
    cells_dir = Path(args.cells_dir).expanduser() if args.cells_dir else None
    if cells_dir is not None and not cells_dir.is_dir():
        # NOT fatal, and deliberately so. The flag is documented as optional, and the
        # two-pass queue build runs pass A before any slice exists — so on a fresh run
        # `assets/` genuinely does not exist yet. Failing here would break the command
        # documented in tools/README.md, and would teach the operator to stop passing the
        # flag — which is worse, because pass B would then silently never fold the
        # coverage cells in. Degrade loudly instead, and name the pass.
        print(f"{TOOL}: NOTE cells dir not present yet ({cells_dir}) — building a "
              f"bucket-only queue (pass A). Re-run after cells_build.py to fold in "
              f"coverage-cell leads; lead statuses are preserved.",
              file=sys.stderr)
        cells_dir = None
    out = Path(args.out).expanduser()
    catalog_path = Path(args.catalog).expanduser() if args.catalog else None
    if catalog_path is None:
        default_catalog = Path(__file__).resolve().parent.parent / "catalog" / "bounty-coverage-matrix.json"
        if default_catalog.is_file():
            catalog_path = default_catalog
            print(f"{TOOL}: no --catalog given; using the bundle catalogue {default_catalog}")
    if cells_dir is None:
        default_cells = out.parent / "assets"
        if default_cells.is_dir():
            cells_dir = default_cells
            print(f"{TOOL}: no --cells-dir given; using {default_cells} (run-tree layout)")
    prior_path = Path(args.prior_queue).expanduser() if args.prior_queue else None
    scope_path = Path(args.scope).expanduser() if args.scope else None

    try:
        doc, explain = build(cls_path, cells_dir, catalog_path, prior_path, scope_path,
                             args.engagement)
    except QueueInputError as exc:  # already formatted
        print(str(exc), file=sys.stderr)
        return 2

    emit = (lambda *a: print(*a, file=sys.stderr)) if args.json else print

    counts = explain["counts"]
    emit(f"{TOOL}: leads: classification={counts['classification_leads']} "
         f"coverage-cells={counts['coverage_cell_leads']} unique={counts['unique_leads']} "
         f"bands P1={counts['bands']['P1']} P2={counts['bands']['P2']} P3={counts['bands']['P3']}")
    if not doc["coverage_seed"]:
        emit(f"{TOOL}: coverage_seed empty — no asset carried applicability/cells.json")

    if args.explain:
        emit(f"{TOOL}: price table — base={BASE_POINTS} "
             f"bucket={BUCKET_WEIGHT} js_secret_kind={JS_SECRET_KIND_WEIGHT} "
             f"param={PARAM_WEIGHT} asset={ASSET_CRITICALITY} "
             f"bounty_tier={BOUNTY_TIER_WEIGHT} needs_chain={NEEDS_CHAIN_PENALTY} "
             f"bands P1>={P1_THRESHOLD} P2>={P2_THRESHOLD}")
        by_id = {row["lead_id"]: row for row in doc["leads"]}
        for lid, priority, tag, parts in sorted(
                explain["explanations"], key=lambda e: (-e[1], e[2], e[0])):
            row = by_id.get(lid, {})
            breakdown = " ".join(f"{name}={points:+d}({detail})" for name, detail, points in parts[1:])
            emit(f"  {lid} p={priority:>3} {row.get('tier', '?')} {tag:<24} "
                 f"{str(row.get('class_id') or '-'):<22} {breakdown} => {priority}")

    try:
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(json.dumps(doc, indent=2) + "\n", encoding="utf-8")
    except OSError as exc:
        print(f"{TOOL}: ERROR cannot write {out}: {exc}", file=sys.stderr)
        return 2

    if not args.no_validate:
        errors = validate(doc)
        if errors:
            print(f"{TOOL}: ERROR emitted document fails surface-queue.schema.json:", file=sys.stderr)
            for err in errors[:20]:
                print(f"  {err}", file=sys.stderr)
            return 2

    if not doc["leads"]:
        if args.json:
            print(json.dumps({"schema": SCHEMA_ID, "out": str(out), "leads": 0, "negative": True}))
        else:
            print(f"NEGATIVE: {TOOL} produced no lead from {cls_path} "
                  f"(cells-dir={cells_dir or 'none'}); queue written with 0 leads -> {out}")
        return 1

    if args.json:
        print(json.dumps({"schema": SCHEMA_ID, "out": str(out), "engagement": doc["engagement"],
                          "lead_count": doc["lead_count"], "coverage_seed": doc["coverage_seed"],
                          "bands": counts["bands"]}))
    else:
        print(f"OK: {TOOL} leads={doc['lead_count']} "
              f"P1={counts['bands']['P1']} P2={counts['bands']['P2']} P3={counts['bands']['P3']} "
              f"coverage_seed_assets={len(doc['coverage_seed'])} -> {out}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
