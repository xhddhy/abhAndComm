#!/usr/bin/env python3
"""Enumerate the (surface-unit x attack-class) work list from a surface inventory.

WHY THIS TOOL EXISTS
--------------------
This is the piece that makes "we tested everything" a checkable claim instead of a
sentence in a report. The applicable-cell set is computed HERE, by code, from two
code-owned inputs: a structured surface inventory (`surface_build.py`'s output) and a
fixed class catalogue. An agent produces FACTS about the surface — that an endpoint takes
an object id, that a path has an auth gate — but it never decides which classes those
facts make applicable. So an agent cannot shrink the work list by arguing that something
"looks fine" or "is probably not vulnerable".

The 18 agent flags come from the inventory. The 7 derived flags are computed here, from
the unit's own shape, and are therefore un-fabricatable: a unit cannot be talked out of
being an HTTP listener, so it cannot be talked out of the classes that requires one.

Inputs:
  <asset-dir>/recon/inventory/surface.json      (schema surface/v2)
  <catalog>                                     (bounty-coverage-matrix.json)

Output:
  <asset-dir>/applicability/cells.json
"""
from __future__ import annotations

import argparse
import json
import os
import re
import sys
from urllib.parse import urlparse

CELLS_SCHEMA = "bbh/cells/v1"

# Vocabulary. A literal copy of the catalogue's own lists is deliberate: this tool must
# not silently accept a flag the catalogue does not know, and reading the lists from the
# catalogue would make a malformed catalogue able to widen the vocabulary.
AGENT_FLAGS: tuple[str, ...] = (
    "object_by_id", "json_body", "role_verb_gated", "sensitive_flow",
    "server_fetched_url", "input_sink", "workflow", "deser_or_ci",
    "inbound_webhook", "id_keyed_unauth", "stored_field", "auth_surface",
    "consumes_upstream", "static_js_or_repo", "local_store", "crypto_use",
    "exported_component", "webview",
)
DERIVED_FLAGS: tuple[str, ...] = (
    "http_listener", "tls_listener", "version_fingerprinted",
    "has_api", "is_apex", "serves_js", "mobile_app",
)
ALL_FLAGS = frozenset(AGENT_FLAGS + DERIVED_FLAGS)

# Ports that imply TLS even without an explicit https scheme.
TLS_PORTS = {443, 993, 995, 8443, 8444, 9443, 10443, 4443}
HTTP_PORTS = {80, 280, 591, 593, 981, 1010, 2480, 3000, 4000, 4567, 5000, 5104, 5800,
              7000, 7001, 8000, 8008, 8042, 8080, 8081, 8082, 8088, 8888, 9000, 9080, 9200}
VERSION_TOKEN_RE = re.compile(r"\d+\.\d+(?:\.\d+)*|\d+")
MOBILE_ONLY_FLAGS = ("local_store", "crypto_use", "exported_component", "webview")

DEFAULT_CATALOG_CANDIDATES = (
    "catalog/bounty-coverage-matrix.json",
    # Upstream fallback so the tool is usable before the bundle's catalogue is built.
    "_upstream/comm/skills/coordination/reference/coverage-matrix.json",
)


class CatalogError(Exception):
    """The catalogue is malformed. Fatal: a bad catalogue must never silently produce
    a short work list, because a short work list reads as full coverage."""


# ---------------------------------------------------------------------------
# Predicate evaluation — the catalogue's `applies_when` grammar.
# ---------------------------------------------------------------------------
def eval_applies(node, flags) -> bool:
    fset = flags if isinstance(flags, (set, frozenset)) else set(flags or ())
    if not isinstance(node, dict):
        raise CatalogError(f"applies_when node must be an object, got {type(node).__name__}")
    if "always" in node:
        return bool(node["always"])
    if "any_flag" in node:
        leaves = _check_leaves(node["any_flag"])
        return any(f in fset for f in leaves)
    if "all_flags" in node:
        leaves = _check_leaves(node["all_flags"])
        return all(f in fset for f in leaves)
    if "not" in node:
        return not eval_applies(node["not"], fset)
    raise CatalogError(f"malformed applies_when node: {json.dumps(node)[:80]}")


def _check_leaves(leaves) -> list:
    if not isinstance(leaves, list) or not leaves:
        raise CatalogError(f"flag list must be a non-empty array, got {leaves!r}")
    for f in leaves:
        if f not in ALL_FLAGS:
            raise CatalogError(f"unknown flag {f!r} (not in the {len(ALL_FLAGS)}-flag vocabulary)")
    return leaves


def load_catalog(path: str) -> dict:
    try:
        with open(path, encoding="utf-8") as fh:
            cat = json.load(fh)
    except (OSError, json.JSONDecodeError) as exc:
        raise CatalogError(f"cannot read catalogue {path}: {exc}") from exc
    classes = cat.get("classes")
    if not isinstance(classes, list) or not classes:
        raise CatalogError(f"catalogue {path} has no 'classes' array")
    seen = set()
    for c in classes:
        cid = c.get("class_id")
        if not cid:
            raise CatalogError("a class has no class_id")
        if cid in seen:
            raise CatalogError(f"duplicate class_id {cid!r}")
        seen.add(cid)
        if c.get("scope") not in {"unit", "host", "asset"}:
            raise CatalogError(f"{cid}: scope must be unit|host|asset, got {c.get('scope')!r}")
        if "applies_when" not in c:
            raise CatalogError(f"{cid}: missing applies_when")
        _check_leaves_ok = c["applies_when"]
        # Evaluate once against the empty set purely to surface grammar errors early.
        eval_applies(_check_leaves_ok, set())
    return cat


def resolve_catalog(explicit: str | None) -> str:
    if explicit:
        if not os.path.isfile(explicit):
            raise CatalogError(f"catalogue not found: {explicit}")
        return explicit
    here = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    for cand in DEFAULT_CATALOG_CANDIDATES:
        p = os.path.join(here, cand)
        if os.path.isfile(p):
            return p
    raise CatalogError(
        "no catalogue found; pass --catalog (looked for: "
        + ", ".join(DEFAULT_CATALOG_CANDIDATES) + ")")


# ---------------------------------------------------------------------------
# Flag derivation from the inventory
# ---------------------------------------------------------------------------
def parse_listener(address: str) -> str | None:
    """Return 'host:port' for a URL, host:port, or bare host."""
    if not address:
        return None
    a = address.strip()
    if "://" in a:
        u = urlparse(a)
        host = u.hostname
        if not host:
            return None
        port = u.port or (443 if u.scheme == "https" else 80)
        return f"{host}:{port}"
    a = a.split("/")[0]
    if ":" in a and not a.startswith("["):
        host, _, port = a.rpartition(":")
        if host and port.isdigit():
            return f"{host}:{port}"
    return f"{a}:443" if a else None


def derive_unit_flags(unit: dict) -> tuple[set[str], list[str]]:
    """Agent flags (validated) plus the derived flags. Returns (flags, warnings)."""
    warn: list[str] = []
    addr = unit.get("address", "") or ""
    raw = list(unit.get("flags") or [])
    agent = set()
    for fl in raw:
        if fl in DERIVED_FLAGS:
            # The whole point of the split is that an inventory cannot assert these.
            # Dropping one silently would hide a real bug in surface_build.py, so it is
            # dropped loudly.
            warn.append(f"{unit.get('unit_id')}: derived flag {fl!r} ignored (computed here)")
        elif fl not in AGENT_FLAGS:
            warn.append(f"{unit.get('unit_id')}: unknown flag {fl!r} ignored")
        else:
            agent.add(fl)

    flags = set(agent)
    scheme = urlparse(addr).scheme if "://" in addr else ""
    listener = parse_listener(addr) or ""
    port = None
    tail = listener.rsplit(":", 1)[-1]
    if tail.isdigit():
        port = int(tail)

    # A web surface unit is an HTTP endpoint by definition.
    flags.add("http_listener")
    if scheme == "https" or (port in TLS_PORTS) or unit.get("tls") is True:
        flags.add("tls_listener")
    blob = " ".join(str(x) for x in (unit.get("server"), unit.get("version")) if x)
    tech = unit.get("tech")
    if isinstance(tech, (list, tuple)):
        blob += " " + " ".join(str(t) for t in tech)
    if VERSION_TOKEN_RE.search(blob):
        flags.add("version_fingerprinted")
    # Never asserted from an inventory: no web unit is a mobile app.
    return flags, warn


def load_asset(asset_dir: str) -> dict:
    spath = os.path.join(asset_dir, "recon", "inventory", "surface.json")
    if not os.path.isfile(spath):
        raise CatalogError(f"no surface.json under {asset_dir}/recon/inventory/")
    with open(spath, encoding="utf-8") as fh:
        surf = json.load(fh)
    if surf.get("schema") != "surface/v2":
        raise CatalogError(f"{spath}: expected schema surface/v2, got {surf.get('schema')!r}")

    asset_tag = surf.get("asset_tag") or os.path.basename(asset_dir.rstrip("/"))
    units = []
    listener_flags: dict[str, set] = {}
    asset_flags: set = set()
    warnings: list[str] = []
    types: set = set()

    for u in surf.get("units") or []:
        uid = u.get("unit_id")
        if not uid:
            warnings.append("a unit has no unit_id and was skipped entirely")
            continue
        flags, warn = derive_unit_flags(u)
        warnings.extend(warn)
        types.add(u.get("type"))
        units.append({
            "unit_id": uid,
            "address": u.get("address", ""),
            "type": u.get("type"),
            "flags": flags,
            "equiv_group": u.get("equiv_group"),
            "bucket": u.get("bucket"),
        })
        listener = parse_listener(u.get("address", ""))
        if listener:
            listener_flags.setdefault(listener, set()).update(flags)
        asset_flags |= flags

    # Asset-level rollups. `has_api`/`serves_js` come from the unit TYPES, which is why
    # surface_build.py treats `type` as load-bearing rather than decorative.
    if "endpoint" in types or "service" in types:
        asset_flags.add("has_api")
    if surf.get("apex") is True:
        asset_flags.add("is_apex")
    if "page" in types or any(str(u.get("address", "")).endswith(".js") for u in units):
        asset_flags.add("serves_js")

    return {
        "asset_tag": asset_tag,
        "surface_path": os.path.abspath(spath),
        "apex": surf.get("apex") is True,
        "units": units,
        "listener_flags": listener_flags,
        "asset_flags": asset_flags,
        "warnings": warnings,
    }


# ---------------------------------------------------------------------------
# Cell enumeration
# ---------------------------------------------------------------------------
def enumerate_cells(asset: dict, catalog: dict) -> tuple[list[dict], dict]:
    cells: list[dict] = []
    counts = {"unit": 0, "host": 0, "asset": 0}

    def emit(scope: str, scope_key: str, klass: dict, flags: set) -> None:
        counts[scope] += 1
        cells.append({
            "cell_key": f"{scope}|{scope_key}|{klass['class_id']}",
            "asset_tag": asset["asset_tag"],
            "scope": scope,
            "scope_key": scope_key,
            "class_id": klass["class_id"],
            "taxonomy": klass.get("taxonomy"),
            "title": klass.get("title"),
            "bounty_tier": klass.get("bounty_tier"),
            "needs_chain": klass.get("needs_chain"),
            "negative_kind": klass.get("negative_kind"),
            "min_vantages": klass.get("min_vantages", 0),
            "technique_ref": klass.get("technique_ref"),
            "matched_flags": sorted(f for f in (klass.get("_referenced") or []) if f in flags),
        })

    for klass in catalog["classes"]:
        flags_ref: set = set()
        _collect(klass["applies_when"], flags_ref)
        k = dict(klass)
        k["_referenced"] = sorted(flags_ref)
        scope = klass["scope"]
        if scope == "unit":
            for u in asset["units"]:
                if eval_applies(klass["applies_when"], u["flags"]):
                    emit("unit", u["unit_id"], k, u["flags"])
        elif scope == "host":
            for listener, lflags in sorted(asset["listener_flags"].items()):
                if eval_applies(klass["applies_when"], lflags):
                    emit("host", listener, k, lflags)
        elif scope == "asset":
            if eval_applies(klass["applies_when"], asset["asset_flags"]):
                emit("asset", asset["asset_tag"], k, asset["asset_flags"])

    # Deterministic order: by unit then class. Consumers that want a work order re-sort
    # by bounty_tier; the file itself must be byte-stable across runs.
    cells.sort(key=lambda c: (c["scope"], c["scope_key"], c["class_id"]))
    return cells, counts


def _collect(node, out: set) -> None:
    if not isinstance(node, dict):
        return
    for key in ("any_flag", "all_flags"):
        if key in node:
            out.update(node[key])
    if "not" in node:
        _collect(node["not"], out)


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(
        description="Enumerate the applicable (surface-unit x attack-class) cells for one asset.",
        epilog="Example: python3 tools/cells_build.py "
               "--asset-dir runs/x/assets/api.demo.test")
    ap.add_argument("--asset-dir", required=True)
    ap.add_argument("--catalog", help="Path to the coverage catalogue; defaults to "
                                      "catalog/bounty-coverage-matrix.json.")
    ap.add_argument("--json", action="store_true")
    ap.add_argument("--explain", action="store_true", help="Print the cell list grouped by scope.")
    args = ap.parse_args(argv)

    try:
        catalog_path = resolve_catalog(args.catalog)
        catalog = load_catalog(catalog_path)
        asset = load_asset(args.asset_dir)
    except CatalogError as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 2

    for w in asset["warnings"]:
        print(f"WARN {w}", file=sys.stderr)

    cells, counts = enumerate_cells(asset, catalog)
    out_dir = os.path.join(os.path.abspath(args.asset_dir), "applicability")
    os.makedirs(out_dir, exist_ok=True)
    out_path = os.path.join(out_dir, "cells.json")

    doc = {
        "schema": CELLS_SCHEMA,
        "asset_tag": asset["asset_tag"],
        "catalog": os.path.abspath(catalog_path),
        "catalog_version": (catalog.get("meta") or {}).get("version"),
        "surface": asset["surface_path"],
        "counts": {**counts, "total": len(cells)},
        "asset_flags": sorted(asset["asset_flags"]),
        "listeners": sorted(asset["listener_flags"].keys()),
        "cells": cells,
    }
    with open(out_path, "w", encoding="utf-8") as fh:
        json.dump(doc, fh, indent=1)
        fh.write("\n")

    if args.explain:
        print(f"\n=== {asset['asset_tag']}: {len(cells)} applicable cell(s) -> {out_path}")
        print(f"    asset flags: {', '.join(sorted(asset['asset_flags']))}")
        by_scope: dict[str, list[dict]] = {}
        for c in cells:
            by_scope.setdefault(c["scope_key"], []).append(c)
        for key in sorted(by_scope):
            rows = by_scope[key]
            print(f"\n  [{rows[0]['scope']}] {key}")
            for c in rows:
                tier = c.get("bounty_tier") or "?"
                chain = " (needs chain)" if c.get("needs_chain") else ""
                print(f"      {c['class_id']:<22} tier={tier}{chain}")
                if c["matched_flags"]:
                    print(f"          via: {', '.join(c['matched_flags'])}")

    if args.json:
        print(json.dumps({"asset_tag": asset["asset_tag"], "cells_path": out_path,
                          "counts": doc["counts"]}, indent=1))
    else:
        print(f"OK: {len(cells)} applicable cell(s) for {asset['asset_tag']} "
              f"(unit={counts['unit']} host={counts['host']} asset={counts['asset']}) "
              f"-> {out_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
