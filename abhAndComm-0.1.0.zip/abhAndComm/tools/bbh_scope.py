#!/usr/bin/env python3
"""bbh_scope.py — Stage 0 scope intake, plus the pre-flight scope gate.

WHY THIS EXISTS
---------------
Every other stage of this pipeline trusts one file: `scope.json`. If that file is
wrong, or if a later stage guesses that a host is in scope, the whole engagement
can produce a report on an asset the program never authorised — which is the one
failure mode that gets a hunter banned and the program's safe harbor voided.

So this tool has two jobs:

* `init`  — turn the program's published scope into a validated `bbh/scope/v1`
  document, deterministically (asset ids `a1..aN` in argument order), with the
  rules of engagement materialised as explicit defaults.
* `check` — answer ONE question, fail-closed: may this URL/host be touched?
  It never guesses "in scope". Anything it cannot prove is `unclear` (exit 2)
  and is handed back to a human.

Exit codes (the contract; workflows branch on these, never on prose):
    0 = in scope        1 = out of scope       2 = unclear / bad input

NO NETWORK, EVER
----------------
`check` makes no DNS or HTTP request — it is safe to run inside a sandbox and it
cannot leak the target to a third party. Third-party hosting is detected from an
optional `--dns-cache` JSON file (host -> CNAME) when one is supplied, and
otherwise only from the literal hostname (a host that literally ends in
`github.io`, `zendesk.com`, ... is flagged as unclear).

WILDCARD / APEX INTERPRETATION TABLE (honoured by `check`)
----------------------------------------------------------
`*.example.com` and `example.com` are NOT the same grant. This table is the
whole rule; there is no fuzzy "well, it probably covers it" fallback.

  asset form                        | covers example.com | covers a.example.com
  ----------------------------------|--------------------|---------------------
  `web:example.com`                 | yes (exact)        | NO -> unclear (2)
  `web:example.com:apex`            | yes (exact)        | NO -> unclear (2)
  `wildcard:*.example.com`          | NO -> unclear (2)  | yes
  `api:a.example.com`               | NO                 | yes, that host only
  `web:https://example.com/app`     | only under /app    | NO -> unclear (2)
  `cidr:10.0.0.0/24` (IP targets)   | n/a                | n/a (containment = yes)

Reading: an apex asset never silently covers its subdomains, a wildcard never
covers the apex, and a sub-path asset never covers its siblings. Each of those
mismatches exits 2 (unclear), never 1 (out of scope), because "the program
listed something adjacent" is exactly the situation a human must adjudicate.

Other fail-closed rules (all exit 2): third-party SaaS via CNAME or literal
provider suffix; a staging/dev/qa/test/uat/preprod label that is not itself an
explicit asset value; an inexact match in a scope whose `safe_harbor` is not
literally true. An explicit `out_of_scope` entry, a matched `path_exclusions`
glob and a scope with no matching asset at all are exit 1 (clearly out of scope).

Stdlib only. `jsonschema` is used for `init` validation when importable and a
loud structural fallback is used when it is not.
"""
from __future__ import annotations

import argparse
import fnmatch
import ipaddress
import json
import os
import re
import sys
from urllib.parse import urlparse

try:  # optional: the bundle must survive a bare `python3`
    import jsonschema
except ImportError:  # pragma: no cover - exercised only on a bare interpreter
    jsonschema = None  # type: ignore[assignment]

SCHEMA_ID = "bbh/scope/v1"
SCHEMA_FILE = "scope.schema.json"
BUNDLE_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CONTRACTS_DIR = os.path.join(BUNDLE_ROOT, "contracts")

#: Schema-documented defaults for `roe`, materialised so a downstream stage
#: never has to guess what "absent" means.
DEFAULT_ROE: dict[str, object] = {
    "rate_limit_rps": 5,
    "no_dos": True,
    "no_bruteforce": True,
    "allow_writes": False,
    "max_requests_per_asset": 20000,
}

ASSET_KINDS = ("web", "api", "mobile", "ip", "cidr", "source_repo", "wildcard")
PLATFORMS = ("hackerone", "bugcrowd", "intigriti", "ywh", "immunefi", "custom", "internal")

#: Filesystem-safe engagement slug: it becomes a directory name.
ENGAGEMENT_RE = re.compile(r"^[a-z0-9][a-z0-9._-]*$")

#: Hostname labels that usually mean "not production, probably not in scope".
STAGING_LABELS = frozenset(
    {"staging", "stage", "stg", "dev", "develop", "development", "qa", "test", "testing", "uat", "preprod"}
)

#: Third-party SaaS / shared-hosting suffixes. A target on one of these is
#: somebody else's infrastructure: unclear, never "in scope". Suffix matching is
#: label-anchored (``evilzendesk.com`` does NOT match ``zendesk.com``).
SAAS_SUFFIXES: dict[str, str] = {
    # helpdesk / CRM / support desks
    "zendesk.com": "Zendesk",
    "zendesk.com.br": "Zendesk",
    "salesforce.com": "Salesforce",
    "force.com": "Salesforce",
    "salesforce-sites.com": "Salesforce",
    "my.salesforce.com": "Salesforce",
    "hubspot.net": "HubSpot",
    "hubspot.com": "HubSpot",
    "hs-sites.com": "HubSpot",
    "hubspotpagebuilder.com": "HubSpot",
    "intercom.help": "Intercom",
    "intercom.com": "Intercom",
    "intercomcdn.com": "Intercom",
    "freshdesk.com": "Freshdesk",
    "freshservice.com": "Freshservice",
    "myfreshworks.com": "Freshworks",
    "freshworks.com": "Freshworks",
    "servicenow.com": "ServiceNow",
    "service-now.com": "ServiceNow",
    "atlassian.net": "Atlassian",
    "atlassian.com": "Atlassian",
    "jira.com": "Atlassian",
    # status / docs / forms / scheduling SaaS
    "statuspage.io": "Statuspage",
    "statuspage.com": "Statuspage",
    "status.io": "Status.io",
    "readme.io": "ReadMe",
    "readme.com": "ReadMe",
    "gitbook.io": "GitBook",
    "notion.site": "Notion",
    "typeform.com": "Typeform",
    "calendly.com": "Calendly",
    "surveymonkey.com": "SurveyMonkey",
    "airtable.com": "Airtable",
    # PaaS / static hosting / CDN edges
    "herokudns.com": "Heroku",
    "herokuapp.com": "Heroku",
    "herokussl.com": "Heroku",
    "github.io": "GitHub Pages",
    "fastly.net": "Fastly",
    "fastlylb.net": "Fastly",
    "cloudfront.net": "Amazon CloudFront",
    "azurewebsites.net": "Azure App Service",
    "cloudapp.azure.com": "Azure",
    "cloudapp.net": "Azure",
    "azureedge.net": "Azure CDN",
    "trafficmanager.net": "Azure Traffic Manager",
    "blob.core.windows.net": "Azure Blob Storage",
    "amazonaws.com": "Amazon AWS",
    "elasticbeanstalk.com": "AWS Elastic Beanstalk",
    "netlify.app": "Netlify",
    "netlify.com": "Netlify",
    "vercel.app": "Vercel",
    "now.sh": "Vercel",
    "pages.dev": "Cloudflare Pages",
    "workers.dev": "Cloudflare Workers",
    "firebaseapp.com": "Firebase Hosting",
    "web.app": "Firebase Hosting",
    "appspot.com": "Google App Engine",
    "webflow.io": "Webflow",
    "wixsite.com": "Wix",
    "squarespace.com": "Squarespace",
    "wordpress.com": "WordPress.com",
    "wpengine.com": "WP Engine",
    "myshopify.com": "Shopify",
    "shopify.com": "Shopify",
    "bigcartel.com": "Big Cartel",
    "surge.sh": "Surge",
    "pantheonsite.io": "Pantheon",
    "ondigitalocean.app": "DigitalOcean App Platform",
    "fly.dev": "Fly.io",
    "ngrok.io": "ngrok",
    "ngrok.app": "ngrok",
    "trycloudflare.com": "Cloudflare Tunnel",
}

CHECK_JSON_KEYS = ("in_scope", "verdict", "reason", "matched_asset", "exclusions_applied")


class InputError(Exception):
    """Bad input: exit code 2 with a message a human can act on."""


# --------------------------------------------------------------------------- #
# small helpers
# --------------------------------------------------------------------------- #
def _warn(msg: str) -> None:
    print(f"bbh_scope: {msg}", file=sys.stderr)


def _norm_host(raw: str) -> str:
    """Lowercase, strip a trailing dot, strip a port, unwrap [IPv6] brackets."""
    host = (raw or "").strip().lower().rstrip(".")
    if host.startswith("["):  # [::1]:8443
        end = host.find("]")
        return host[1:end] if end != -1 else host.strip("[]")
    if host.count(":") == 1:  # host:port
        head, _, tail = host.partition(":")
        if tail.isdigit():
            return head
    return host


def _split_host_path(value: str) -> tuple[str, str | None]:
    """Split an asset/target value into (host, path|None)."""
    v = (value or "").strip()
    if not v:
        raise InputError("empty host value")
    if "://" in v or v.startswith("//"):
        parsed = urlparse(v if "://" in v else "https:" + v)
        if not parsed.hostname:
            raise InputError(f"could not parse a host out of {value!r}")
        return parsed.hostname.lower().rstrip("."), (parsed.path or "/")
    if "/" in v:
        head, _, tail = v.partition("/")
        return _norm_host(head), "/" + tail
    return _norm_host(v), None


def _path_covers(base: str | None, target: str) -> bool:
    """True when the asset's path prefix covers the target path."""
    if base in (None, "", "/"):
        return True
    base = base.rstrip("/") or "/"
    target = target or "/"
    if target == base:
        return True
    return target.startswith(base + "/") or target.startswith(base + "?")


def _wildcard_matches(pattern: str, host: str) -> bool:
    """`*.example.com` matches a.example.com but NOT example.com."""
    pat = pattern.strip().lower().rstrip(".")
    if not pat:
        return False
    if not pat.startswith("*."):
        pat = "*." + pat.lstrip("*.")
    return fnmatch.fnmatchcase(host, pat)


def _saas_provider(host: str) -> str | None:
    """Longest label-anchored SaaS suffix match, or None. No network involved."""
    h = _norm_host(host)
    best: str | None = None
    for suffix in SAAS_SUFFIXES:
        if h == suffix or h.endswith("." + suffix):
            if best is None or len(suffix) > len(best):
                best = suffix
    return SAAS_SUFFIXES[best] if best else None


def _staging_label(host: str) -> str | None:
    """Return the offending label when the host carries a non-prod marker.

    The TLD is excluded from the scan, so the reserved `.test` suffix does not
    make every `evil.test` look like a test environment; the domain name and
    subdomain labels are both scanned, splitting hyphens too, so `app-dev.acme.com`
    and `acme-staging.com` are flagged while `staging.acme.com` still is.
    """
    labels = _norm_host(host).split(".")
    if len(labels) > 1:
        labels = labels[:-1]
    for label in re.split(r"[.\-_]", ".".join(labels)):
        if label in STAGING_LABELS:
            return label
    return None


def _oob_matches(pattern: str, host: str, path: str) -> bool:
    """Match an `out_of_scope` entry against a target.

    Interpreted BROADLY on purpose: over-excluding is the fail-closed direction
    for an exclusion list, so a bare domain also excludes its subdomains and
    `*.d` also excludes `d` itself.
    """
    raw = (pattern or "").strip().lower()
    if not raw:
        return False
    if "://" in raw or raw.startswith("//"):
        phost, ppath = _split_host_path(raw)
        return host == phost and _path_covers(ppath, path)
    if raw.startswith("*."):
        suffix = raw[2:].rstrip(".")
        return host == suffix or host.endswith("." + suffix)
    if "/" in raw:
        phost, ppath = _split_host_path(raw)
        if phost != host:
            return False
        return _path_covers(ppath, path)
    return host == raw or host.endswith("." + raw)


def _exclusion_matches(pattern: str, host: str, path: str) -> bool:
    """Match a `path_exclusions` glob, optionally host-qualified.

    Accepted forms: ``/admin/*``, ``admin/*``, ``*.php`` and
    ``https://api.example.com/admin/*``. A directory prefix also excludes
    everything beneath it.
    """
    raw = (pattern or "").strip()
    if not raw:
        return False
    if "://" in raw or raw.startswith("//"):
        phost, ppath = _split_host_path(raw)
        if phost != host:
            return False
        raw = ppath or "/"
    if not raw.startswith("/"):
        raw = "/" + raw
    if fnmatch.fnmatchcase(path, raw):
        return True
    base = raw.rstrip("*").rstrip("/")
    if base and (path == base or path.startswith(base + "/")):
        return True
    return False


# --------------------------------------------------------------------------- #
# structural validation fallback (used by init when jsonschema is absent)
# --------------------------------------------------------------------------- #
def _json_type_ok(value: object, expected: str) -> bool:
    if expected == "string":
        return isinstance(value, str)
    if expected == "boolean":
        return isinstance(value, bool)
    if expected == "integer":
        return isinstance(value, int) and not isinstance(value, bool)
    if expected == "number":
        return isinstance(value, (int, float)) and not isinstance(value, bool)
    if expected == "array":
        return isinstance(value, list)
    if expected == "object":
        return isinstance(value, dict)
    if expected == "null":
        return value is None
    return True


def _structural_errors(doc: object, schema: dict, pointer: str = "$") -> list[str]:
    """Required keys + top-level property types. NOT a schema validation."""
    errors: list[str] = []
    if not isinstance(doc, dict):
        return [f"{pointer}: expected object, got {type(doc).__name__}"]
    for key in schema.get("required", []):
        if key not in doc:
            errors.append(f"{pointer}: missing required key {key!r}")
    props = schema.get("properties", {})
    for key, value in doc.items():
        spec = props.get(key)
        if not isinstance(spec, dict):
            continue
        if "const" in spec and value != spec["const"]:
            errors.append(f"{pointer}.{key}: expected const {spec['const']!r}, got {value!r}")
        if "enum" in spec and value not in spec["enum"]:
            errors.append(f"{pointer}.{key}: {value!r} not in {spec['enum']!r}")
        expected = spec.get("type")
        if isinstance(expected, str) and not _json_type_ok(value, expected):
            errors.append(f"{pointer}.{key}: expected {expected}, got {type(value).__name__}")
        if expected == "array" and isinstance(value, list) and "minItems" in spec:
            if len(value) < int(spec["minItems"]):
                errors.append(f"{pointer}.{key}: needs >= {spec['minItems']} items, has {len(value)}")
        if expected == "array" and isinstance(value, list) and isinstance(spec.get("items"), dict):
            for i, item in enumerate(value):
                errors.extend(_structural_errors(item, spec["items"], f"{pointer}.{key}[{i}]"))
        if expected == "object" and isinstance(value, dict) and isinstance(spec.get("properties"), dict):
            errors.extend(_structural_errors(value, spec, f"{pointer}.{key}"))
    return errors


def load_contract_schema(name: str) -> dict:
    path = os.path.join(CONTRACTS_DIR, name)
    try:
        with open(path, encoding="utf-8") as fh:
            schema = json.load(fh)
    except OSError as exc:
        raise InputError(f"cannot read contract schema {path}: {exc}") from exc
    except json.JSONDecodeError as exc:
        raise InputError(f"contract schema {path} is not valid JSON: {exc}") from exc
    if not isinstance(schema, dict):
        raise InputError(f"contract schema {path} is not a JSON object")
    return schema


def validate_document(doc: object, schema: dict) -> tuple[list[str], bool]:
    """Return (errors, full_validation_ran)."""
    if jsonschema is None:
        return _structural_errors(doc, schema), False
    validator = jsonschema.validators.validator_for(schema)(schema)
    errors = []
    for err in sorted(validator.iter_errors(doc), key=lambda e: list(e.absolute_path)):
        path = "$" + "".join(
            f"[{p}]" if isinstance(p, int) else f".{p}" for p in err.absolute_path
        )
        errors.append(f"{path}: {err.message}")
    return errors, True


# --------------------------------------------------------------------------- #
# `init`
# --------------------------------------------------------------------------- #
def parse_asset_arg(raw: str) -> tuple[str, str, bool]:
    """Parse ``KIND:VALUE[:apex]``.

    Kind is taken from the LEFT of the first ``:``; a trailing ``:apex`` is the
    apex flag ONLY when the tail after the last ``:`` is exactly ``apex`` — so
    ``web:https://x.test:443`` keeps its port and ``web:acme.com:apex`` gets the
    flag. The only losing case is a value that literally ends in ``:apex``.
    """
    text = (raw or "").strip()
    if ":" not in text:
        raise InputError(f"--asset {raw!r}: expected KIND:VALUE[:apex]")
    kind, _, tail = text.partition(":")
    kind = kind.strip().lower()
    value = tail.strip()
    apex = False
    head, sep, last = value.rpartition(":")
    if sep and last.strip().lower() == "apex" and head.strip():
        value, apex = head.strip(), True
    if kind not in ASSET_KINDS:
        raise InputError(
            f"--asset {raw!r}: unknown KIND {kind!r} (expected one of {', '.join(ASSET_KINDS)})"
        )
    if not value:
        raise InputError(f"--asset {raw!r}: empty VALUE")
    if kind == "wildcard":
        if apex:
            raise InputError(
                f"--asset {raw!r}: a wildcard asset is not the apex; drop ':apex' "
                "(use a second `web:<apex>` asset if the apex is also in scope)"
            )
        pat = value.lower()
        if not pat.startswith("*."):
            pat = "*." + pat.lstrip("*.")
        if "." not in pat[2:]:
            raise InputError(
                f"--asset {raw!r}: wildcard {value!r} is too broad — use `*.example.com`"
            )
    return kind, value, apex


def parse_path_exclusion(raw: str) -> tuple[str, str]:
    """Parse ``ASSET=GLOB`` for --path-exclusion.

    ASSET is an asset_id (``a2``) or an asset value (``api.acme.com`` /
    ``https://api.acme.com``). GLOB is a path glob such as ``/admin/*``.
    """
    text = (raw or "").strip()
    target, sep, glob = text.partition("=")
    target, glob = target.strip(), glob.strip()
    if not sep or not target or not glob:
        raise InputError(
            f"--path-exclusion {raw!r}: expected ASSET=GLOB, e.g. "
            "'api.acme.com=/admin/*' or 'a2=/billing/*'"
        )
    return target, glob


def parse_roe(raw: str | None) -> dict[str, object]:
    roe = dict(DEFAULT_ROE)
    if raw is None:
        return roe
    try:
        incoming = json.loads(raw)
    except json.JSONDecodeError as exc:
        if os.path.exists(raw):
            raise InputError(
                f"--roe-json: {raw!r} looks like a path but must be an inline JSON object "
                f"(`--roe-json \"$(cat {raw})\"`); JSON error: {exc}"
            ) from exc
        raise InputError(f"--roe-json: not valid JSON: {exc}") from exc
    if not isinstance(incoming, dict):
        raise InputError(f"--roe-json: expected a JSON object, got {type(incoming).__name__}")
    roe.update(incoming)
    return roe


def cmd_init(args: argparse.Namespace) -> int:
    if not ENGAGEMENT_RE.match(args.engagement or ""):
        _warn(
            f"refusing engagement {args.engagement!r}: must be a filesystem-safe slug "
            "matching [a-z0-9][a-z0-9._-]*"
        )
        return 2
    if not args.asset:
        _warn("init needs at least one --asset KIND:VALUE[:apex]")
        return 2
    try:
        parsed_assets = [parse_asset_arg(a) for a in args.asset]
        roe = parse_roe(args.roe_json)
        path_exclusions = [parse_path_exclusion(p) for p in (args.path_exclusion or [])]
    except InputError as exc:
        _warn(str(exc))
        return 2

    assets = []
    for i, (kind, value, apex) in enumerate(parsed_assets, start=1):
        entry: dict[str, object] = {"asset_id": f"a{i}", "kind": kind, "value": value, "apex": apex}
        if kind == "web" and apex:
            entry["notes"] = "registrable apex"
        assets.append(entry)

    by_id = {str(a["asset_id"]): a for a in assets}
    for target, glob in path_exclusions:
        target_l = target.lower()
        hit = by_id.get(target_l) or next(
            (a for a in assets if str(a["value"]).lower() == target_l), None
        )
        if hit is None:
            _warn(
                f"--path-exclusion {target!r} matches no --asset (use an asset_id such as a2 "
                f"or an exact asset value: {', '.join(str(a['value']) for a in assets)})"
            )
            return 2
        hit.setdefault("path_exclusions", [])
        assert isinstance(hit["path_exclusions"], list)
        hit["path_exclusions"].append(glob)

    doc: dict[str, object] = {
        "schema": SCHEMA_ID,
        "engagement": args.engagement,
        "platform": args.platform,
        "program": args.program or args.engagement,
        "safe_harbor": bool(args.safe_harbor),
        "assets": assets,
        "out_of_scope": list(args.exclude or []),
        "roe": roe,
        "creds_env": list(args.creds_env or []),
    }

    try:
        schema = load_contract_schema(SCHEMA_FILE)
    except InputError as exc:
        _warn(f"not writing {args.out}: {exc}")
        return 2
    errors, full = validate_document(doc, schema)
    if errors:
        for err in errors:
            _warn(f"generated scope failed schema validation: {err}")
        _warn(f"not writing {args.out}: the document is not {SCHEMA_ID}")
        return 1
    if not full:
        _warn(
            "jsonschema is NOT installed — only the STRUCTURAL fallback validated this "
            "document (required keys + top-level types); install it with "
            "`pip install jsonschema` for full enforcement"
        )

    out = os.path.abspath(args.out)
    parent = os.path.dirname(out)
    try:
        if parent:
            os.makedirs(parent, exist_ok=True)
        with open(out, "w", encoding="utf-8") as fh:
            json.dump(doc, fh, indent=2, sort_keys=False)
            fh.write("\n")
    except OSError as exc:
        _warn(f"cannot write {out}: {exc}")
        return 2

    how = "schema-validated" if full else "structurally checked"
    print(
        f"OK: wrote {out} ({SCHEMA_ID}, {how}) — engagement={doc['engagement']} "
        f"platform={doc['platform']} assets={len(assets)} excluded={len(doc['out_of_scope'])} "
        f"safe_harbor={str(doc['safe_harbor']).lower()} roe.rate_limit_rps={roe.get('rate_limit_rps')}"
    )
    return 0


# --------------------------------------------------------------------------- #
# `check` — the safety-critical path
# --------------------------------------------------------------------------- #
def parse_target(args: argparse.Namespace) -> dict[str, object]:
    if args.url and args.host:
        raise InputError("--url and --host are mutually exclusive")
    if not args.url and not args.host:
        raise InputError("check needs --url or --host")
    raw = args.url or args.host
    assert isinstance(raw, str)
    if args.url:
        text = raw if "://" in raw else "https://" + raw
        try:
            parsed = urlparse(text)
            scheme = parsed.scheme.lower()
            host = (parsed.hostname or "").lower().rstrip(".")
            path = parsed.path or "/"
            port = parsed.port
        except ValueError as exc:
            raise InputError(f"--url {raw!r} is not parseable: {exc}") from exc
        if scheme not in ("http", "https"):
            raise InputError(
                f"--url {raw!r}: scheme {scheme!r} is not a web target this gate can judge"
            )
        if not host:
            raise InputError(f"--url {raw!r}: no hostname")
        return {"raw": raw, "host": host, "path": path, "scheme": scheme, "port": port}
    host, path = _split_host_path(raw)
    if not host:
        raise InputError(f"--host {raw!r}: no hostname")
    return {"raw": raw, "host": host, "path": path or "/", "scheme": None, "port": None}


def load_dns_cache(path: str | None) -> dict[str, str]:
    """Optional host -> CNAME map. Never a network lookup; absent file = no data."""
    if not path:
        return {}
    try:
        with open(os.path.abspath(path), encoding="utf-8") as fh:
            raw = json.load(fh)
    except OSError as exc:
        raise InputError(f"--dns-cache {path}: cannot read: {exc}") from exc
    except json.JSONDecodeError as exc:
        raise InputError(f"--dns-cache {path}: not valid JSON: {exc}") from exc
    if not isinstance(raw, dict):
        raise InputError(f"--dns-cache {path}: expected an object of host -> cname")
    cache: dict[str, str] = {}
    for key, value in raw.items():
        if isinstance(value, str):
            cache[_norm_host(str(key))] = value
        elif isinstance(value, list) and value and isinstance(value[0], str):
            cache[_norm_host(str(key))] = value[0]
        elif isinstance(value, dict):
            cname = value.get("cname") or value.get("target")
            if isinstance(cname, str):
                cache[_norm_host(str(key))] = cname
    return cache


def _asset_match(asset: dict, host: str, path: str) -> tuple[str, str]:
    """Classify how an asset relates to the target.

    Returns one of:
      ("exact", why)          the asset names this host (and covers this path)
      ("wildcard", why)       covered only by a `*.suffix` pattern
      ("path", why)           same host, asset's path prefix does not cover
      ("descendant", why)     the target is a subdomain of a non-wildcard asset
      ("no", why)
    """
    kind = str(asset.get("kind", ""))
    value = str(asset.get("value", ""))
    aid = asset.get("asset_id", "?")
    if kind == "wildcard":
        if _wildcard_matches(value, host):
            return "wildcard", f"{aid} (wildcard:{value}) covers {host} via wildcard expansion"
        apex = re.sub(r"^\*\.", "", value.strip().lower()).rstrip(".")
        if apex and host == apex:
            return "apex_of_wildcard", (
                f"{aid} (wildcard:{value}) covers subdomains of {apex} but NOT {apex} itself — "
                "the wildcard/apex distinction is a classic N/A"
            )
        return "no", f"{aid} does not match"
    if kind in ("web", "api", "mobile", "source_repo"):
        ahost, apath = _split_host_path(value)
        if ahost == host:
            if _path_covers(apath, path):
                return "exact", f"{aid} ({kind}:{value}) names host {host} exactly"
            return "path", (
                f"{aid} ({kind}:{value}) names host {host} but its path prefix "
                f"{apath!r} does not cover {path!r}"
            )
        if host.endswith("." + ahost):
            return "descendant", (
                f"{aid} ({kind}:{value}) names {ahost}, and {host} is a SUBDOMAIN of it — "
                "an apex/host asset does not cover subdomains"
            )
        return "no", f"{aid} does not match"
    if kind == "ip":
        if _norm_host(value) == host:
            return "exact", f"{aid} (ip:{value}) names host {host} exactly"
        return "no", f"{aid} does not match"
    if kind == "cidr":
        try:
            net = ipaddress.ip_network(value, strict=False)
            addr = ipaddress.ip_address(host)
        except ValueError:
            return "no", f"{aid} (cidr:{value}) is not comparable with {host}"
        if addr in net:
            return "exact", f"{aid} (cidr:{value}) contains {host}"
        return "no", f"{aid} does not match"
    return "no", f"{aid} (kind {kind}) is not addressable by host"


def _verdict(
    verdict: str,
    reason: str,
    matched_asset: str | None,
    exclusions: list[str],
    as_json: bool,
) -> tuple[int, dict[str, object]]:
    in_scope = True if verdict == "in_scope" else (False if verdict == "out_of_scope" else None)
    code = {"in_scope": 0, "out_of_scope": 1, "unclear": 2}[verdict]
    payload: dict[str, object] = {
        "in_scope": in_scope,
        "verdict": verdict,
        "reason": reason,
        "matched_asset": matched_asset,
        "exclusions_applied": exclusions,
    }
    if as_json:
        print(json.dumps(payload, indent=2))
    else:
        prefix = {"in_scope": "OK: in scope", "out_of_scope": "OUT OF SCOPE", "unclear": "UNCLEAR"}[verdict]
        print(f"{prefix}: {reason}")
    return code, payload


def cmd_check(args: argparse.Namespace) -> int:
    try:
        target = parse_target(args)
    except InputError as exc:
        _warn(str(exc))
        return _verdict("unclear", f"bad input: {exc}", None, [], args.json)[0]

    scope_path = os.path.abspath(args.scope)
    try:
        with open(scope_path, encoding="utf-8") as fh:
            doc = json.load(fh)
    except OSError as exc:
        _warn(f"cannot read scope {scope_path}: {exc}")
        return _verdict("unclear", f"bad input: cannot read scope file {scope_path}: {exc}", None, [], args.json)[0]
    except json.JSONDecodeError as exc:
        _warn(f"scope {scope_path} is not valid JSON: {exc}")
        return _verdict("unclear", f"bad input: scope {scope_path} is not valid JSON: {exc}", None, [], args.json)[0]

    if not isinstance(doc, dict) or not isinstance(doc.get("assets"), list) or not doc["assets"]:
        _warn(f"scope {scope_path} has no usable assets[] array")
        return _verdict("unclear", f"bad input: scope {scope_path} has no assets[] array", None, [], args.json)[0]

    try:
        dns_cache = load_dns_cache(args.dns_cache)
    except InputError as exc:
        _warn(str(exc))
        return _verdict("unclear", f"bad input: {exc}", None, [], args.json)[0]

    host = str(target["host"])
    path = str(target["path"])
    assets = doc["assets"]
    safe_harbor = doc.get("safe_harbor") is True

    # 1. explicit exclusions win over everything: clearly out of scope.
    for pattern in doc.get("out_of_scope") or []:
        if isinstance(pattern, str) and _oob_matches(pattern, host, path):
            return _verdict(
                "out_of_scope",
                f"{host}{path} matches out_of_scope entry {pattern!r}",
                None,
                [pattern],
                args.json,
            )[0]

    # 2. third-party hosting via a supplied CNAME record: never assumed in scope.
    cname = dns_cache.get(host)
    if cname:
        provider = _saas_provider(cname)
        if provider:
            return _verdict(
                "unclear",
                f"{host} CNAMEs to {cname} ({provider} third-party SaaS) per --dns-cache; "
                "hosting is not the program's infrastructure — get explicit authorisation",
                None,
                [],
                args.json,
            )[0]

    # 3. classify every asset against the target.
    buckets: dict[str, list[tuple[dict, str]]] = {
        "exact": [], "wildcard": [], "path": [], "descendant": [], "apex_of_wildcard": []
    }
    for asset in assets:
        if not isinstance(asset, dict):
            continue
        kind, why = _asset_match(asset, host, path)
        if kind in buckets:
            buckets[kind].append((asset, why))

    # 4. a host that IS one of the listed SaaS platform domains (no CNAME evidence
    #    needed) is somebody else's infrastructure, unless the program named it.
    provider = _saas_provider(host)
    if provider and not buckets["exact"]:
        return _verdict(
            "unclear",
            f"{host} is on {provider}'s shared platform domain ({provider} third-party SaaS) "
            "and is not an explicitly listed asset; confirm with the program before testing",
            None,
            [],
            args.json,
        )[0]
    if provider:
        _warn(f"{host} is on {provider}'s platform but is an explicitly listed asset — allowing")

    # 5. exact match: apply the asset's own path exclusions and clear it.
    if buckets["exact"]:
        matched = buckets["exact"][0][0]
        aid = str(matched.get("asset_id", "?"))
        hits: list[str] = []
        for asset, _why in buckets["exact"]:
            for pat in asset.get("path_exclusions") or []:
                if isinstance(pat, str) and _exclusion_matches(pat, host, path):
                    hits.append(pat)
        if hits:
            return _verdict(
                "out_of_scope",
                f"{host}{path} is in asset {aid} but falls under path_exclusions {hits!r}",
                aid,
                hits,
                args.json,
            )[0]
        why = buckets["exact"][0][1]
        return _verdict("in_scope", f"{why}; {host}{path} is in scope", aid, [], args.json)[0]

    # 6. covered only by a wildcard: staging labels and a false/absent safe_harbor
    #    make this unclear rather than in scope.
    if buckets["wildcard"]:
        asset, why = buckets["wildcard"][0]
        aid = str(asset.get("asset_id", "?"))
        label = _staging_label(host)
        if label:
            return _verdict(
                "unclear",
                f"{host} carries the non-production label {label!r} and is only covered by "
                f"wildcard {aid}; the scope does not list this host explicitly — confirm it",
                None,
                [],
                args.json,
            )[0]
        if not safe_harbor:
            return _verdict(
                "unclear",
                f"{why}, but safe_harbor is not true and this is not an exact asset match — "
                "a wildcard-only match is not enough to assume authorisation",
                None,
                [],
                args.json,
            )[0]
        hits = [
            pat
            for pat in (asset.get("path_exclusions") or [])
            if isinstance(pat, str) and _exclusion_matches(pat, host, path)
        ]
        if hits:
            return _verdict(
                "out_of_scope",
                f"{host}{path} is covered by wildcard {aid} but falls under "
                f"path_exclusions {hits!r}",
                aid,
                hits,
                args.json,
            )[0]
        # A wildcard match answers "does the scope cover hosts shaped like this?", NOT
        # "is this host the program's?". Without a CNAME record those two questions cannot
        # be told apart, and the common real-world case is a subdomain delegated to a
        # third-party service — traffic there is out of scope and can be a legal problem,
        # not just a closed report. So the verdict carries the caveat rather than reading
        # as verified, and --require-cname promotes the caveat to a refusal.
        if not cname:
            if getattr(args, "require_cname", False):
                return _verdict(
                    "unclear",
                    f"{why}; {host}{path} would be in scope by wildcard, but --require-cname "
                    "is set and no CNAME record was supplied for this host — ownership is "
                    "unverified, so this is unclear, not in scope",
                    None,
                    [],
                    args.json,
                )[0]
            return _verdict(
                "in_scope",
                f"{why}; {host}{path} is in scope. WARNING: the CNAME was NOT verified "
                "(no --dns-cache entry for this host), so a wildcard match is not evidence of "
                "ownership — if this host is delegated to a third-party service it is out of "
                "scope even though the pattern matches. Supply --dns-cache to check, or pass "
                "--require-cname to make an unverified wildcard match exit 2.",
                aid,
                [],
                args.json,
            )[0]
        return _verdict("in_scope", f"{why}; {host}{path} is in scope", aid, [], args.json)[0]

    # 7. same host, path outside the asset's prefix — adjacent, not authorised.
    if buckets["path"]:
        return _verdict(
            "unclear",
            f"{buckets['path'][0][1]}; the host is listed but this path is not covered — "
            "treat as unclear, do not assume in scope",
            None,
            [],
            args.json,
        )[0]

    # 8. the apex of a `*.suffix` wildcard, or a subdomain of a listed apex/host
    #    with no wildcard asset: the classic wildcard-vs-apex N/A.
    if buckets["apex_of_wildcard"]:
        return _verdict(
            "unclear",
            f"{buckets['apex_of_wildcard'][0][1]}; ask the program whether the apex is included — "
            "do not assume it is",
            None,
            [],
            args.json,
        )[0]
    if buckets["descendant"]:
        label = _staging_label(host)
        extra = f" (non-production label {label!r})" if label else ""
        return _verdict(
            "unclear",
            f"{buckets['descendant'][0][1]}{extra}; no wildcard asset covers it — "
            "ask the program before touching a subdomain",
            None,
            [],
            args.json,
        )[0]

    # 9. nothing matched the host at all.
    label = _staging_label(host)
    if label:
        return _verdict(
            "unclear",
            f"{host} carries the non-production label {label!r} and is not listed in the scope; "
            "non-production environments are frequently out of scope even when the domain is in scope",
            None,
            [],
            args.json,
        )[0]
    listed = ", ".join(str(a.get("value")) for a in assets if isinstance(a, dict))[:200]
    return _verdict(
        "out_of_scope",
        f"{host}{path} matches no asset (scope lists: {listed})",
        None,
        [],
        args.json,
    )[0]


# --------------------------------------------------------------------------- #
# CLI
# --------------------------------------------------------------------------- #
EXAMPLES = """\
examples:
  # Stage 0 intake (asset ids are assigned a1, a2, ... in argument order)
  python3 tools/bbh_scope.py init \\
      --engagement acme-2026-09 --platform hackerone --program acme --safe-harbor \\
      --asset 'web:acme.com:apex' --asset 'api:api.acme.com' \\
      --exclude staging.acme.com --path-exclusion 'api.acme.com=/admin/*' \\
      --creds-env ACME_USER_A \\
      --roe-json '{"rate_limit_rps": 3, "allow_writes": true}' \\
      --out runs/acme-2026-09/scope.json

  # The pre-flight gate: exit 0 in scope, 1 out of scope, 2 unclear
  python3 tools/bbh_scope.py check \\
      --scope runs/acme-2026-09/scope.json --url https://api.acme.com/v2/users/1
  python3 tools/bbh_scope.py check --scope runs/acme-2026-09/scope.json --url https://acme.com/
  python3 tools/bbh_scope.py check --scope runs/acme-2026-09/scope.json --host staging.acme.com
  python3 tools/bbh_scope.py check --scope runs/acme-2026-09/scope.json --host x.acme.com \\
      --dns-cache recon/dns-cache.json --json

  # dns-cache.json is written by recon, never by this tool:
  #   {"www.acme.com": "acme.zendesk.com", "api.acme.com": "acme.herokudns.com"}
"""


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="bbh_scope.py",
        description=(
            "Stage 0 scope intake and the pre-flight scope gate. `check` never makes a "
            "network request and fails closed: 0=in scope, 1=out of scope, 2=unclear/bad input."
        ),
        epilog=EXAMPLES,
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    sub = parser.add_subparsers(dest="command", required=True)

    p_init = sub.add_parser(
        "init",
        help="build a validated bbh/scope/v1 document",
        description=(
            "Build a bbh/scope/v1 document. --asset is repeatable and parsed as "
            "KIND:VALUE[:apex]; asset_id values are a1, a2, ... in argument order. "
            "The result is validated against contracts/scope.schema.json before it is written."
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    p_init.add_argument("--engagement", required=True, metavar="SLUG",
                        help="filesystem-safe engagement slug, e.g. acme-2026-09 "
                             "(must match [a-z0-9][a-z0-9._-]*)")
    p_init.add_argument("--platform", default="custom", choices=PLATFORMS,
                        help="program platform (default: custom)")
    p_init.add_argument("--program", default=None, metavar="NAME",
                        help="program name as published (default: the engagement slug)")
    p_init.add_argument("--asset", action="append", default=[], metavar="KIND:VALUE[:apex]",
                        help=f"in-scope asset, repeatable; KIND is one of {', '.join(ASSET_KINDS)}")
    p_init.add_argument("--exclude", action="append", default=[], metavar="HOST|PATTERN",
                        help="out_of_scope entry, repeatable (a bare domain also excludes its subdomains)")
    p_init.add_argument("--path-exclusion", action="append", default=[], metavar="ASSET=GLOB",
                        help="per-asset path exclusion, repeatable, e.g. 'api.acme.com=/admin/*' "
                             "or 'a2=/billing/*'; enforced by `check`")
    p_init.add_argument("--creds-env", action="append", default=[], metavar="NAME",
                        help="env var NAME holding test credentials (never a value), repeatable")
    p_init.add_argument("--roe-json", default=None, metavar="JSON",
                        help="inline JSON object merged over the roe defaults "
                             f"({json.dumps(DEFAULT_ROE, sort_keys=True)})")
    p_init.add_argument("--safe-harbor", action=argparse.BooleanOptionalAction, default=False,
                        help="program publishes a safe-harbor clause (default: no — absence is "
                             "treated as false and makes inexact matches 'unclear')")
    p_init.add_argument("--out", required=True, metavar="PATH",
                        help="output scope.json (parent directories are created)")

    p_check = sub.add_parser(
        "check",
        help="fail-closed scope gate for one URL/host",
        description=(
            "Decide whether one target may be touched. Exit 0 only for a proven in-scope "
            "match with no out_of_scope entry and no matching path exclusion; exit 1 when "
            "clearly out of scope; exit 2 when unclear (third-party SaaS/CNAME, staging-like "
            "label, wildcard/apex mismatch, inexact match without safe harbor, bad input)."
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    p_check.add_argument("--scope", required=True, metavar="PATH", help="the scope.json to check against")
    p_check.add_argument("--url", default=None, metavar="URL", help="target URL (http/https)")
    p_check.add_argument("--host", default=None, metavar="HOST", help="target host (alternative to --url)")
    p_check.add_argument("--dns-cache", default=None, metavar="PATH",
                         help="optional JSON object {host: cname} recorded by recon; the ONLY way "
                              "CNAME-based third-party detection can see real DNS (no network here)")
    p_check.add_argument("--require-cname", action="store_true",
                         help="treat a wildcard match with no CNAME record for that host as "
                              "UNCLEAR (exit 2) instead of in-scope. Off by default because it "
                              "makes an unverified wildcard unusable; turn it on when you are about "
                              "to send traffic and want ownership proven first")
    p_check.add_argument("--json", action="store_true",
                         help="emit one JSON object: {in_scope, verdict, reason, matched_asset, "
                              "exclusions_applied}")
    return parser


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    if args.command == "init":
        return cmd_init(args)
    return cmd_check(args)


if __name__ == "__main__":
    raise SystemExit(main())
