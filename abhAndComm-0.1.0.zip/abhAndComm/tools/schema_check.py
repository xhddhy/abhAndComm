#!/usr/bin/env python3
"""schema_check.py — validate pipeline artifacts against `contracts/*.schema.json`.

WHY THIS EXISTS
---------------
The bundle's stages hand each other JSON files, and every stage boundary is a
promise: "the file I just wrote validates against the contract I claim". Nothing
downstream re-reads the upstream tool's code, so an artifact that drifts from its
schema (a renamed key, a string where an integer belongs) silently breaks the
next stage. This tool is the cheap, uniform gate for that promise: run it at
every stage boundary; a stage whose output does not validate has not completed.

It is also the anti-fabrication check for hand-written artifacts: a `verdict`
that is missing `checks`, or a `finding` with no `evidence`, fails here before a
validator wastes time on it.

`--kind all --run-dir <run>` walks a run directory and validates everything it
recognises. Recognition is by content first (the document's `schema` const, e.g.
`bbh/verdict/v1`), then by the conventional path (`slices/*.json` is a slice,
`artifacts/validated/*.json` is a verdict). Files it cannot place are skipped and
counted — never silently passed.

`jsonschema` is used when importable. When it is not, a STRUCTURAL fallback runs
(required keys, types, const/enum, array item shapes, local $ref) and says so
loudly in every summary line: a structural pass is not a schema validation and
this tool must never report one as if it were.

Exit codes: 0 = every recognised file validated, 1 = a file failed validation,
2 = bad invocation / unreadable file / file that exists but is not valid JSON /
missing contract schema.
"""
from __future__ import annotations

import argparse
import json
import os
import re
import sys
from typing import Any

try:  # optional: the bundle must survive a bare `python3`
    import jsonschema
except ImportError:  # pragma: no cover - exercised only on a bare interpreter
    jsonschema = None  # type: ignore[assignment]

BUNDLE_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DEFAULT_CONTRACTS_DIR = os.path.join(BUNDLE_ROOT, "contracts")

# --------------------------------------------------------------------------- #
# THE MAPPING — the whole value of this tool. One line per kind; audit here.
# --------------------------------------------------------------------------- #
KIND_SCHEMAS: dict[str, str] = {
    "scope": "scope.schema.json",
    "classification": "classification.schema.json",
    "surface": "surface.v2.schema.json",          # surface/v2, NOT surface-queue
    "queue": "surface-queue.schema.json",         # bbh/queue/v1 (the surface queue)
    "slice": "slice.schema.json",
    "finding": "finding.schema.json",
    "verdict": "validation-verdict.schema.json",  # bbh/verdict/v1
    "seven-questions": "seven-questions.schema.json",
    "repro": "repro-runbook.schema.json",         # bbh/repro/v1
}

#: Convenience spellings operators actually type. Kept explicit so the mapping
#: above stays auditable.
KIND_ALIASES: dict[str, str] = {
    "7q": "seven-questions",
    "seven_questions": "seven-questions",
    "sevenquestions": "seven-questions",
    "repro-runbook": "repro",
    "runbook": "repro",
    "validation-verdict": "verdict",
    "surface-queue": "queue",
    "surface-queue-v1": "queue",
}

#: `schema` const value -> kind. This is how `--kind all` recognises a document
#: by content, independent of where it sits on disk.
SCHEMA_CONST_TO_KIND: dict[str, str] = {
    "bbh/scope/v1": "scope",
    "bbh/classification/v1": "classification",
    "surface/v2": "surface",
    "bbh/queue/v1": "queue",
    "bbh/slice/v1": "slice",
    "bbh/finding/v1": "finding",
    "bbh/verdict/v1": "verdict",
    "bbh/7q/v1": "seven-questions",
    "bbh/repro/v1": "repro",
}

#: (substring of the POSIX-style relative path, kind) — fallback recognition for
#: files that are unparseable or lack a `schema` key. First match wins.
PATH_HINTS: tuple[tuple[str, str], ...] = (
    ("/slices/", "slice"),
    ("/seven-questions/", "seven-questions"),
    ("/artifacts/validated/", "verdict"),
    ("/artifacts/false-positives/", "verdict"),
    ("/artifacts/dropped/", "verdict"),
    ("/findings/", "finding"),
    ("/repro/", "repro"),
)

#: Exact basenames are a stronger hint than a path substring.
BASENAME_HINTS: dict[str, str] = {
    "scope.json": "scope",
    "classification.json": "classification",
    "surface.json": "surface",
    "queue.json": "queue",
}

#: Directory names never worth walking, and files that are schemas not artifacts.
SKIP_DIRS = frozenset({".git", ".hg", ".svn", "node_modules", "__pycache__", ".venv", "venv", ".mypy_cache"})
SKIP_BASENAMES = frozenset({"kev-snapshot.json", "package.json", "package-lock.json"})

STRUCTURAL_BANNER = (
    "STRUCTURAL FALLBACK ONLY — jsonschema is not installed; checked required keys, "
    "types, const/enum, array items and local $ref. Full JSON Schema constraints were "
    "NOT enforced. Install it with: python3 -m pip install jsonschema"
)


# --------------------------------------------------------------------------- #
# structural fallback (required keys + types, recursively, local $ref only)
# --------------------------------------------------------------------------- #
def _type_ok(value: object, expected: str) -> bool:
    if expected == "string":
        return isinstance(value, str)
    if expected == "boolean":
        return isinstance(value, bool)
    if expected == "integer":
        return isinstance(value, int) and not isinstance(value, bool)
    if expected == "number":
        return isinstance(value, (int, float)) and not isinstance(value, bool)
    if expected == "array":
        return isinstance(value, list)
    if expected == "object":
        return isinstance(value, dict)
    if expected == "null":
        return value is None
    return True


def _resolve_ref(schema: dict[str, Any], ref: str) -> dict[str, Any] | None:
    """Resolve a LOCAL `#/$defs/name` (or `#/definitions/name`) reference only."""
    if not ref.startswith("#/"):
        return None
    node: Any = schema
    for part in ref[2:].split("/"):
        part = part.replace("~1", "/").replace("~0", "~")
        if not isinstance(node, dict) or part not in node:
            return None
        node = node[part]
    return node if isinstance(node, dict) else None


def structural_errors(
    doc: object, schema: dict[str, Any], pointer: str = "$", root: dict[str, Any] | None = None
) -> list[str]:
    """Best-effort structural check. NOT a JSON Schema validation — see the module docstring."""
    root = root if root is not None else schema
    errors: list[str] = []

    if "$ref" in schema:
        target = _resolve_ref(root, str(schema["$ref"]))
        if target is None:
            return [f"{pointer}: STRUCTURAL FALLBACK cannot resolve $ref {schema['$ref']!r}"]
        return structural_errors(doc, target, pointer, root)

    expected = schema.get("type")
    if isinstance(expected, list):
        if not any(_type_ok(doc, str(t)) for t in expected):
            return [f"{pointer}: expected one of {expected}, got {type(doc).__name__}"]
    elif isinstance(expected, str) and not _type_ok(doc, expected):
        return [f"{pointer}: expected {expected}, got {type(doc).__name__}"]

    if "const" in schema and doc != schema["const"]:
        errors.append(f"{pointer}: expected const {schema['const']!r}, got {doc!r}")
    if "enum" in schema and doc not in schema["enum"]:
        errors.append(f"{pointer}: {doc!r} is not one of {schema['enum']!r}")

    if isinstance(doc, dict):
        for key in schema.get("required", []):
            if key not in doc:
                errors.append(f"{pointer}: missing required key {key!r}")
        props = schema.get("properties")
        if isinstance(props, dict):
            for key, value in doc.items():
                if key in props and isinstance(props[key], dict):
                    errors.extend(structural_errors(value, props[key], f"{pointer}.{key}", root))
    if isinstance(doc, list):
        if "minItems" in schema and len(doc) < int(schema["minItems"]):
            errors.append(f"{pointer}: needs >= {schema['minItems']} items, has {len(doc)}")
        items = schema.get("items")
        if isinstance(items, dict):
            for i, item in enumerate(doc):
                errors.extend(structural_errors(item, items, f"{pointer}[{i}]", root))
    return errors


# --------------------------------------------------------------------------- #
# jsonschema validation
# --------------------------------------------------------------------------- #
def _fmt_path(path: Any) -> str:
    out = "$"
    for part in path:
        out += f"[{part}]" if isinstance(part, int) else f".{part}"
    return out


def _value_at(doc: object, path: Any) -> object:
    node: Any = doc
    try:
        for part in path:
            node = node[part]
        return node
    except (KeyError, IndexError, TypeError):
        return "<unavailable>"


def _short(value: object, limit: int = 160) -> str:
    text = repr(value)
    return text if len(text) <= limit else text[: limit - 3] + "..."


_POINTER_TOKEN_RE = re.compile(r"\.([A-Za-z0-9_\-]+)|\[(\d+)\]")


def _pointer_parts(pointer: str) -> list[Any]:
    """Turn a `$.a[0].b` pointer (as produced by structural_errors) back into a path."""
    parts: list[Any] = []
    for match in _POINTER_TOKEN_RE.finditer(pointer):
        parts.append(match.group(1) if match.group(1) is not None else int(match.group(2)))
    return parts


def full_errors(doc: object, schema: dict[str, Any]) -> list[dict[str, str]]:
    assert jsonschema is not None
    validator_cls = jsonschema.validators.validator_for(schema)
    validator = validator_cls(schema)
    out: list[dict[str, str]] = []
    for err in sorted(validator.iter_errors(doc), key=lambda e: list(e.absolute_path)):
        path = _fmt_path(err.absolute_path)
        out.append(
            {
                "path": path,
                "message": err.message,
                "value": _short(_value_at(doc, err.absolute_path)),
                "schema_path": _fmt_path(err.absolute_schema_path),
            }
        )
    return out


# --------------------------------------------------------------------------- #
# file handling
# --------------------------------------------------------------------------- #
class ContractError(Exception):
    """Unreadable/missing contract schema: exit 2."""


class InputProblem(Exception):
    """Unreadable file / invalid JSON: exit 2."""


def canonical_kind(kind: str) -> str:
    key = (kind or "").strip().lower()
    key = KIND_ALIASES.get(key, key)
    if key not in KIND_SCHEMAS:
        raise InputProblem(
            f"unknown --kind {kind!r}; known kinds: {', '.join(KIND_SCHEMAS)} "
            f"(aliases: {', '.join(sorted(KIND_ALIASES))})"
        )
    return key


def load_schema(contracts_dir: str, kind: str) -> dict[str, Any]:
    path = os.path.join(os.path.abspath(contracts_dir), KIND_SCHEMAS[kind])
    try:
        with open(path, encoding="utf-8") as fh:
            schema = json.load(fh)
    except OSError as exc:
        raise ContractError(f"cannot read contract schema {path}: {exc}") from exc
    except json.JSONDecodeError as exc:
        raise ContractError(f"contract schema {path} is not valid JSON: {exc}") from exc
    if not isinstance(schema, dict):
        raise ContractError(f"contract schema {path} is not a JSON object")
    return schema


def read_json(path: str) -> object:
    try:
        with open(path, encoding="utf-8") as fh:
            return json.load(fh)
    except OSError as exc:
        raise InputProblem(f"cannot read {path}: {exc}") from exc
    except json.JSONDecodeError as exc:
        raise InputProblem(f"{path} exists but is not valid JSON: {exc}") from exc


def validate_one(
    path: str, kind: str, schema: dict[str, Any]
) -> tuple[list[dict[str, str]], str]:
    """Return (errors, mode) for one file. mode is 'jsonschema' or 'structural'."""
    doc = read_json(path)
    if jsonschema is not None:
        return full_errors(doc, schema), "jsonschema"
    structural: list[dict[str, str]] = []
    for raw in structural_errors(doc, schema):
        pointer, _, message = raw.partition(":")
        structural.append(
            {
                "path": pointer or "$",
                "message": message.strip() or raw,
                "value": _short(_value_at(doc, _pointer_parts(pointer))),
                "schema_path": "",
            }
        )
    return structural, "structural"


def guess_kind_from_path(rel_path: str) -> str | None:
    posix = "/" + rel_path.replace(os.sep, "/").lstrip("/")
    base = os.path.basename(rel_path)
    if base in BASENAME_HINTS:
        return BASENAME_HINTS[base]
    for needle, kind in PATH_HINTS:
        if needle in posix:
            return kind
    return None


def walk_json_files(run_dir: str) -> list[str]:
    found: list[str] = []
    for root, dirs, files in os.walk(run_dir):
        dirs[:] = sorted(d for d in dirs if d not in SKIP_DIRS)
        for name in sorted(files):
            if not name.endswith(".json") or name.endswith(".schema.json"):
                continue
            if name in SKIP_BASENAMES:
                continue
            found.append(os.path.join(root, name))
    return found


# --------------------------------------------------------------------------- #
# CLI
# --------------------------------------------------------------------------- #
EXAMPLES = """\
examples:
  python3 tools/schema_check.py --kind scope runs/acme-2026-09/scope.json
  python3 tools/schema_check.py --kind verdict \\
      runs/acme-2026-09/assets/api.acme.com/artifacts/validated/F-001.json
  python3 tools/schema_check.py --kind all --run-dir runs/acme-2026-09
  python3 tools/schema_check.py --list-kinds

kind -> contract mapping (this is the whole tool; audit it here or with --list-kinds):
""" + "".join(f"  {kind:<16} -> contracts/{name}\n" for kind, name in KIND_SCHEMAS.items())


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="schema_check.py",
        description=(
            "Validate pipeline artifacts against contracts/*.schema.json. Exit 0 = all "
            "recognised files valid, 1 = a file failed validation, 2 = bad invocation, "
            "unreadable file, invalid JSON or missing contract schema."
        ),
        epilog=EXAMPLES,
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument("--kind", required=False, metavar="KIND",
                        help="one of: " + ", ".join(KIND_SCHEMAS) + " (or 'all' with --run-dir)")
    parser.add_argument("files", nargs="*", metavar="FILE",
                        help="the artifact file(s) to validate for --kind")
    parser.add_argument("--run-dir", default=None, metavar="DIR",
                        help="with --kind all: walk this run directory and validate everything recognised")
    parser.add_argument("--contracts-dir", default=DEFAULT_CONTRACTS_DIR, metavar="DIR",
                        help=f"where the *.schema.json contracts live (default: {DEFAULT_CONTRACTS_DIR})")
    parser.add_argument("--json", action="store_true",
                        help="emit one JSON object: {ok, mode, validated, failed, skipped, errors, ...}")
    parser.add_argument("--verbose", action="store_true",
                        help="also list the names of files skipped as unrecognised")
    parser.add_argument("--list-kinds", action="store_true",
                        help="print the kind -> contract mapping and exit")
    return parser


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)

    if args.list_kinds:
        print(f"{'kind':<18} {'contract':<34} schema const ($id)")
        for kind, name in KIND_SCHEMAS.items():
            const = next((c for c, k in SCHEMA_CONST_TO_KIND.items() if k == kind), "?")
            print(f"{kind:<18} contracts/{name:<24} {const}")
        print("\naliases: " + ", ".join(f"{a}->{k}" for a, k in sorted(KIND_ALIASES.items())))
        return 0

    if not args.kind:
        parser.error("--kind is required (or use --list-kinds)")
    mode_all = args.kind.strip().lower() == "all"

    def out(line: str) -> None:
        """Human progress lines: stdout normally, stderr with --json.

        `--json` promises "a single JSON object on stdout", so every human-readable
        line has to move to stderr or a consumer's json.load() chokes on prose.
        """
        print(line, file=sys.stderr if args.json else sys.stdout)

    explicit_kind: str | None = None
    if not mode_all:
        try:
            explicit_kind = canonical_kind(args.kind)
        except InputProblem as exc:
            print(f"ERROR: {exc}", file=sys.stderr)
            return 2

    errors_out: list[dict[str, str]] = []
    skipped: list[str] = []
    input_errors: list[str] = []
    validated = 0
    fell_back = False

    if mode_all:
        if not args.run_dir:
            parser.error("--kind all requires --run-dir DIR")
        if args.files:
            parser.error("--kind all walks --run-dir; do not pass file arguments")
        run_dir = os.path.abspath(args.run_dir)
        if not os.path.isdir(run_dir):
            print(f"ERROR: --run-dir {run_dir} is not a directory", file=sys.stderr)
            return 2
        targets = walk_json_files(run_dir)
        if not targets:
            out(f"OK: 0 files validated (no *.json files under {run_dir})")
            return 0
    else:
        if args.run_dir:
            parser.error("--run-dir is only valid with --kind all")
        if not args.files:
            parser.error("pass at least one FILE, or use --kind all --run-dir DIR")
        targets = [os.path.abspath(f) for f in args.files]

    schema_cache: dict[str, dict[str, Any]] = {}
    for path in targets:
        rel = os.path.relpath(path, os.path.abspath(args.run_dir)) if mode_all and args.run_dir else os.path.basename(path)
        kind: str | None = None
        content_kind: str | None = None
        parsed: object = None
        parse_error: str | None = None
        try:
            parsed = read_json(path)
        except InputProblem as exc:
            parse_error = str(exc)
        if parse_error is None and isinstance(parsed, dict):
            declared = parsed.get("schema")
            if isinstance(declared, str):
                content_kind = SCHEMA_CONST_TO_KIND.get(declared)
                if content_kind is None:
                    parse_error = (
                        f"{path}: declares schema {declared!r}, which is not a known bundle "
                        f"artifact schema ({', '.join(SCHEMA_CONST_TO_KIND)})"
                    )
        if mode_all:
            hint = guess_kind_from_path(rel)
            if parse_error is not None and hint is None:
                # Unrecognised AND unreadable here means "not one of ours": skip by name.
                skipped.append(rel)
                continue
            kind = content_kind or hint
            if kind is None:
                skipped.append(rel)
                continue
            if content_kind and hint and content_kind != hint:
                print(
                    f"schema_check: WARNING {rel}: path looks like a {hint} but the document "
                    f"declares {content_kind} — validating as {content_kind}",
                    file=sys.stderr,
                )
        else:
            kind = explicit_kind
            assert kind is not None
            if parse_error is not None:
                # An explicitly named file that is not valid JSON is an error, never a skip.
                input_errors.append(parse_error)
                print(f"ERROR: {parse_error}", file=sys.stderr)
                continue

        try:
            schema = schema_cache.get(kind) or load_schema(args.contracts_dir, kind)
        except ContractError as exc:
            print(f"ERROR: {exc}", file=sys.stderr)
            return 2
        schema_cache[kind] = schema

        try:
            file_errors, used_mode = validate_one(path, kind, schema)
        except InputProblem as exc:
            input_errors.append(str(exc))
            print(f"ERROR: {exc}", file=sys.stderr)
            continue
        if used_mode == "structural":
            fell_back = True
        if file_errors:
            for err in file_errors:
                err["file"] = path
                err["kind"] = kind
                err["schema"] = KIND_SCHEMAS[kind]
                errors_out.append(err)
                out(
                    f"FAIL {path} [{kind} <- contracts/{KIND_SCHEMAS[kind]}] "
                    f"{err['path']}: {err['message']} (value: {err['value'] or 'n/a'})"
                )
        else:
            validated += 1
            if args.verbose:
                out(f"pass {path} [{kind}]")

    ok = not errors_out and not input_errors
    mode = "structural-fallback" if fell_back else "jsonschema"

    if args.json:
        print(
            json.dumps(
                {
                    "ok": ok,
                    "mode": mode,
                    "validated": validated,
                    "failed": len(errors_out),
                    "skipped": len(skipped),
                    "errors": errors_out,
                    "input_errors": input_errors,
                    "skipped_files": skipped,
                },
                indent=2,
            )
        )
    else:
        if not ok:
            out(
                f"FAIL: {len(errors_out)} validation error(s), {len(input_errors)} unreadable/"
                f"invalid file(s); {validated} file(s) passed"
            )
        elif fell_back:
            out(f"OK: {validated} files validated ({STRUCTURAL_BANNER})")
        else:
            out(f"OK: {validated} files validated")
        if skipped:
            out(f"SKIP: {len(skipped)} file(s) not matching any known kind")
            if args.verbose:
                for name in skipped:
                    out(f"  skipped {name}")
    if fell_back and not args.json:
        print(f"schema_check: {STRUCTURAL_BANNER}", file=sys.stderr)

    if input_errors:
        return 2
    if errors_out:
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
