#!/usr/bin/env python3
"""Stage 3 SLICE: one self-contained work order per asset, ``bbh/slice/v1``.

WHY THIS TOOL EXISTS
--------------------
A coordinator subagent must be able to open ONE file and know everything: which
surface it owns, which catalogue classes are applicable to it (code-produced,
not agent-chosen), which leads are queued for it, and exactly which reference
files the executor should be handed. Anything left implicit is a round wasted.

Two failure modes this tool exists to prevent:

1. **A dead playbook path.** The catalogue's ``technique_ref`` is a repository
   path; a slice that hands an executor a path that does not exist burns a whole
   batch before anyone notices. Every resolved path is checked on disk, and a
   path that does not resolve is DROPPED LOUDLY on stdout and recorded in the
   slice — never emitted as a hopeful string. A directory is expanded to its
   files, never emitted bare.
2. **A soft coverage gate.** ``gate.complete`` is exactly
   ``covered == applicable`` against the code-produced cells, with no soft bar,
   no partial credit, and no credit for a cell that has no evidence. With no
   ``coverage.json`` the slice is incomplete by definition.

Usage
-----
    python3 tools/slice_build.py --run-dir runs/acme-2026-09 \\
        --scope runs/acme-2026-09/scope.json

Writes ``<run-dir>/slices/<asset_tag>.json`` (default).
Exit codes: 0 = slices written, 1 = real negative (no asset carries
recon/inventory/surface.json), 2 = bad input (run dir/assets dir unreadable).
"""
from __future__ import annotations

import argparse
import json
import re
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable, Sequence

try:  # optional: schema self-check degrades to a warning without it
    import jsonschema
except ImportError:  # pragma: no cover
    jsonschema = None

SCHEMA_ID = "bbh/slice/v1"
TOOL = "slice_build.py"
BUNDLE_ROOT = Path(__file__).resolve().parent.parent
MAX_DIR_EXPANSION = 25  # a directory ref never expands into an unbounded dump
LEDGER_COVERED = ("covered", "covered_negative")


class SliceInputError(Exception):
    """Unreadable/malformed input -> exit code 2."""


# ---------------------------------------------------------------------------
# Catalogue
# ---------------------------------------------------------------------------


def load_catalog(path: Path | None) -> tuple[dict[str, dict[str, Any]], str]:
    """Return ({class_id: class dict}, message). Missing catalogue degrades."""
    if path is None:
        return {}, "no --catalog given: class_playbooks cannot be resolved"
    if not path.is_file():
        return {}, (f"catalogue not found at {path}: class_playbooks cannot be resolved "
                    f"(every class is reported as a drop)")
    try:
        doc = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        return {}, f"catalogue unreadable ({exc}): class_playbooks cannot be resolved"
    raw: Any = doc
    if isinstance(doc, dict):
        raw = doc.get("classes") or doc.get("catalog") or doc.get("items") or {}
    out: dict[str, dict[str, Any]] = {}
    if isinstance(raw, dict):
        for key, value in raw.items():
            if isinstance(value, dict):
                out[str(value.get("class_id") or key)] = value
    elif isinstance(raw, list):
        for value in raw:
            if isinstance(value, dict) and value.get("class_id"):
                out[str(value["class_id"])] = value
    return out, f"catalogue {path}: {len(out)} class(es)"


_TECHNIQUE_KEYS = ("technique_ref", "technique_refs", "playbook", "skill_ref",
                   "references", "ref")


def class_technique_refs(info: dict[str, Any]) -> tuple[str, ...]:
    for key in _TECHNIQUE_KEYS:
        value = info.get(key)
        if isinstance(value, str) and value.strip():
            return (value.strip(),)
        if isinstance(value, (list, tuple)):
            refs = tuple(str(v).strip() for v in value if str(v).strip())
            if refs:
                return refs
    return ()


# ---------------------------------------------------------------------------
# Playbook resolution
# ---------------------------------------------------------------------------


def _strip_fragment(ref: str) -> tuple[str, str]:
    if "#" in ref:
        path, frag = ref.split("#", 1)
        return path, frag
    return ref, ""


def _candidate_paths(ref: str, bases: Sequence[Path]) -> list[Path]:
    """Every file the ref could mean, in priority order."""
    path_part, _frag = _strip_fragment(ref)
    candidates: list[Path] = []
    p = Path(path_part)
    if p.is_absolute():
        return [p]
    for base in bases:
        candidates.append(base / path_part)
        # The catalogue was adapted from a bundle whose refs started with
        # "skills/"; the vendored copies live under vendor/upstream-skills/.
        if path_part.startswith("skills/"):
            candidates.append(base / "vendor" / "upstream-skills" / path_part[len("skills/"):])
        if path_part.startswith("vendor/upstream-skills/"):
            candidates.append(base / "skills" / path_part[len("vendor/upstream-skills/"):])
    return candidates


def _expand_dir(path: Path) -> tuple[list[str], str]:
    """Expand a directory reference to files. A bare directory is never emitted."""
    files = sorted(p for p in path.glob("*.md") if p.is_file())
    if not files:
        files = sorted(p for p in path.rglob("*.md") if p.is_file())
    if not files:
        return [], f"{path} is a directory with no readable .md reference files"
    if len(files) > MAX_DIR_EXPANSION:
        extra = len(files) - MAX_DIR_EXPANSION
        return ([str(p.resolve()) for p in files[:MAX_DIR_EXPANSION]],
                f"{path} is a directory: expanded to its first {MAX_DIR_EXPANSION} .md files "
                f"({extra} more not listed; the catalogue should point at a file)")
    return [str(p.resolve()) for p in files], f"{path} is a directory: expanded to its {len(files)} .md files"


def resolve_technique_refs(refs: Sequence[str], bases: Sequence[Path]) -> tuple[list[str], list[str]]:
    """Resolve refs to absolute existing FILES. Returns (paths, drop_reasons)."""
    paths: list[str] = []
    drops: list[str] = []
    for ref in refs:
        _path_part, frag = _strip_fragment(ref)
        candidates = _candidate_paths(ref, bases)
        file_hit = next((c for c in candidates if c.is_file()), None)
        if file_hit is not None:
            resolved = str(file_hit.resolve())
            paths.append(resolved)
            if frag:
                drops.append(f"NOTICE {ref!r}: the '#{frag}' anchor is not a file path; "
                             f"handed {resolved} (the anchor's section is inside it)")
            continue
        dir_hit = next((c for c in candidates if c.is_dir()), None)
        if dir_hit is not None:
            # A bare directory is never emitted: expand it to its files.
            expanded, why = _expand_dir(dir_hit)
            if expanded:
                paths.extend(expanded)
                drops.append(f"NOTICE {ref!r}: {why}")
            else:
                drops.append(f"{ref!r}: {why}")
            continue
        tried = ", ".join(str(c) for c in candidates[:4])
        drops.append(f"{ref!r} does not exist on disk (tried: {tried})")
    seen: set[str] = set()
    ordered = [p for p in paths if not (p in seen or seen.add(p))]
    return ordered, drops


def skill_fallback(refs: Sequence[str], bases: Sequence[Path]) -> tuple[str | None, str]:
    """The relevant vendored SKILL.md — used only when nothing specific resolved."""
    for ref in refs:
        path_part, _ = _strip_fragment(ref)
        parts = Path(path_part).parts
        for marker in ("upstream-skills", "skills"):
            if marker not in parts:
                continue
            idx = parts.index(marker)
            if idx + 1 >= len(parts):
                continue
            skill = parts[idx + 1]
            for base in bases:
                for cand in (base / "vendor" / "upstream-skills" / skill / "SKILL.md",
                             base / "skills" / skill / "SKILL.md",
                             base.joinpath(*parts[:idx + 2]) / "SKILL.md"):
                    if cand.is_file():
                        return str(cand.resolve()), f"fallback SKILL.md for {ref!r}"
    return None, "no skill directory could be derived from the catalogue refs"


def build_class_playbooks(class_ids: Iterable[str], catalog: dict[str, dict[str, Any]],
                          bases: Sequence[Path]) -> tuple[dict[str, list[str]], dict[str, str], list[str]]:
    """class_id -> absolute existing reference files, plus drop reasons."""
    playbooks: dict[str, list[str]] = {}
    drops: dict[str, str] = {}
    notices: list[str] = []
    for class_id in class_ids:
        info = catalog.get(class_id)
        if info is None:
            drops[class_id] = ("class id is not in the catalogue at all — no technique_ref to "
                               "resolve; fix the catalogue or the cells, do not guess a path")
            continue
        refs = class_technique_refs(info)
        if not refs:
            drops[class_id] = "catalogue entry has no technique_ref/playbook field"
            continue
        paths, reasons = resolve_technique_refs(refs, bases)
        for reason in reasons:
            if reason.startswith("NOTICE"):
                notices.append(f"{class_id}: {reason}")
            else:
                notices.append(f"{class_id}: DROPPED {reason}")
        if not paths:
            fallback, why = skill_fallback(refs, bases)
            if fallback:
                paths = [fallback]
                notices.append(f"{class_id}: no specific reference resolved; handed the skill's "
                               f"SKILL.md instead ({why})")
            else:
                drops[class_id] = ("every technique_ref failed to resolve and no SKILL.md fallback "
                                   f"exists ({'; '.join(reasons) or why})")
                continue
        playbooks[class_id] = paths
    return playbooks, drops, notices


# ---------------------------------------------------------------------------
# Cells / gate / surface
# ---------------------------------------------------------------------------


def read_json(path: Path) -> Any:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except OSError as exc:
        raise SliceInputError(f"cannot read {path}: {exc}") from exc
    except json.JSONDecodeError as exc:
        raise SliceInputError(f"{path} is not valid JSON: {exc}") from exc


def load_cells(path: Path) -> tuple[list[tuple[str, str]], int]:
    """Return ([(class_id, scope_key)], cell_count)."""
    if not path.is_file():
        return [], 0
    doc = read_json(path)
    raw: Any = doc
    if isinstance(doc, dict):
        raw = doc.get("cells")
        if raw is None:
            raw = doc.get("applicable_cells") or []
    cells: list[tuple[str, str]] = []
    for item in raw if isinstance(raw, list) else []:
        if isinstance(item, str):
            cells.append((item, ""))
        elif isinstance(item, dict):
            cid = item.get("class_id") or item.get("class") or item.get("id")
            if not cid:
                continue
            key = item.get("scope_key") or item.get("key") or item.get("unit_id") or ""
            cells.append((str(cid), str(key)))
    return cells, len(cells)


def load_coverage_rows(path: Path) -> dict[str, dict[str, Any]]:
    if not path.is_file():
        return {}
    try:
        doc = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return {}
    rows = doc if isinstance(doc, list) else (doc.get("rows") or doc.get("classes") or [])
    out: dict[str, dict[str, Any]] = {}
    for row in rows if isinstance(rows, list) else []:
        if isinstance(row, dict) and row.get("class_id"):
            out[str(row["class_id"])] = row
    return out


def compute_gate(cells: list[tuple[str, str]], cells_present: bool,
                 coverage_present: bool, rows: dict[str, dict[str, Any]]) -> dict[str, Any]:
    """complete = cells present AND coverage present AND covered == applicable."""
    applicable = len(cells)
    covered = 0
    uncovered: list[str] = []
    for class_id, scope_key in cells:
        row = rows.get(class_id)
        hit = False
        for entry in (row or {}).get("units_tested") or []:
            if not isinstance(entry, dict):
                continue
            if str(entry.get("key") or "") != scope_key:
                continue
            if str(entry.get("status") or "") in LEDGER_COVERED:
                hit = True
                break
        if hit:
            covered += 1
        else:
            uncovered.append(f"{class_id}:{scope_key or 'asset'}")
    ratio = 1.0 if applicable == 0 else round(covered / applicable, 4)
    complete = bool(cells_present and coverage_present and covered == applicable)
    reason = []
    if not cells_present:
        reason.append("no applicability/cells.json: applicable set unknown, cannot be complete")
    if not coverage_present:
        reason.append("no coverage.json: covered=0 by definition")
    if cells_present and coverage_present and covered != applicable:
        reason.append(f"{applicable - covered} applicable cell(s) have no covered/covered_negative entry")
    if complete:
        reason.append("covered == applicable")
    gate = {
        "complete": complete,
        "applicable": applicable,
        "covered": covered,
        "ratio": ratio,
        "reason": "; ".join(reason) or "no cells",
        "uncovered_preview": uncovered[:25],
    }
    return gate


def load_surface(path: Path) -> dict[str, Any]:
    doc = read_json(path)
    if not isinstance(doc, dict):
        raise SliceInputError(f"{path} is not a JSON object")
    return doc


def mirror_surface_flags(surface: dict[str, Any]) -> dict[str, Any]:
    """A convenience snapshot. surface.json stays authoritative (stated in-file)."""
    units: dict[str, list[str]] = {}
    agent_flags: set[str] = set()
    types: set[str] = set()
    tls_any = bool(surface.get("tls"))
    js_any = False
    for unit in surface.get("units") or []:
        if not isinstance(unit, dict):
            continue
        uid = str(unit.get("unit_id") or "")
        flags = sorted(str(f) for f in (unit.get("flags") or []) if isinstance(f, str))
        if uid:
            units[uid] = flags
        agent_flags |= set(flags)
        types.add(str(unit.get("type") or ""))
        address = str(unit.get("address") or "")
        if unit.get("tls") or address.startswith("https://"):
            tls_any = True
        if address.endswith(".js") or "?" in address and address.split("?")[0].endswith(".js"):
            js_any = True
    derived: set[str] = set()
    if surface.get("units"):
        derived.add("http_listener")
    if tls_any:
        derived.add("tls_listener")
    if surface.get("apex"):
        derived.add("is_apex")
    if types & {"endpoint", "service"}:
        derived.add("has_api")
    if "page" in types or js_any:
        derived.add("serves_js")
    return {
        "authoritative": ("recon/inventory/surface.json remains authoritative — this is a mirror "
                          "snapshot for the coordinator's convenience. Derived flags are computed "
                          "by cells_build.py; do not treat this mirror as the applicable set."),
        "asset": sorted(agent_flags | derived),
        "units": units,
    }


# ---------------------------------------------------------------------------
# Build
# ---------------------------------------------------------------------------


def build_slice(asset_dir: Path, run_dir: Path, scope_doc: dict[str, Any], queue_doc: dict[str, Any],
                classification_doc: dict[str, Any] | None, catalog: dict[str, dict[str, Any]],
                catalog_path: Path | None, scope_path: Path | None, verbose: bool) -> dict[str, Any]:
    surface_path = asset_dir / "recon" / "inventory" / "surface.json"
    surface = load_surface(surface_path)
    asset_tag = str(surface.get("asset_tag") or asset_dir.name)
    asset_id = asset_tag
    apex = bool(surface.get("apex"))
    tech: list[str] = []
    for asset in (classification_doc or {}).get("assets") or []:
        if isinstance(asset, dict) and str(asset.get("asset_tag")) == asset_tag:
            asset_id = str(asset.get("asset_id") or asset_tag)
            tech = [str(t) for t in (asset.get("tech") or [])]
            apex = bool(asset.get("apex", apex))
            break

    cells_path = asset_dir / "applicability" / "cells.json"
    cells, _count = load_cells(cells_path)
    applicable_cells = sorted({cid for cid, _ in cells})
    cell_keys = sorted(f"{asset_tag}|{key or 'asset'}|{cid}" for cid, key in cells)

    coverage_path = asset_dir / "coverage.json"
    rows = load_coverage_rows(coverage_path)
    gate = compute_gate(cells, cells_path.is_file(), coverage_path.is_file(), rows)

    bases = [asset_dir, run_dir, BUNDLE_ROOT]
    if catalog_path is not None:
        bases.extend([catalog_path.parent, catalog_path.parent.parent])
    playbooks, drops, notices = build_class_playbooks(applicable_cells, catalog, bases)

    if drops:
        for class_id in sorted(drops):
            print(f"  DROP {asset_tag} {class_id} playbook: {drops[class_id]}")
    if verbose:
        for notice in notices:
            print(f"  NOTE {asset_tag}: {notice}")

    leads = [lead for lead in (queue_doc.get("leads") or [])
             if isinstance(lead, dict) and str(lead.get("asset_tag")) == asset_tag]
    leads.sort(key=lambda r: (-int(r.get("priority") or 0), int(r.get("lead_seq") or 10 ** 9),
                              str(r.get("lead_id") or "")))

    slice_doc: dict[str, Any] = {
        "schema": SCHEMA_ID,
        "slice_id": "s-" + re.sub(r"[^a-z0-9]+", "-", asset_tag.lower()).strip("-"),
        "asset_tag": asset_tag,
        "asset_id": asset_id,
        "output_dir": str(asset_dir.resolve()),
        "apex": apex,
        "tech": tech,
        "surface_flags": mirror_surface_flags(surface),
        "applicable_cells": applicable_cells,
        "applicable_cell_keys": cell_keys,
        "cell_count": len(cells),
        "leads": leads,
        "class_playbooks": playbooks,
        "class_playbook_drops": drops,
        "class_playbook_notices": notices,
        "creds_env": [str(v) for v in (scope_doc.get("creds_env") or [])],
        "roe": scope_doc.get("roe") or {},
        "gate": gate,
        "generated_at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "tool": TOOL,
    }
    if scope_path is not None:
        slice_doc["scope_ref"] = str(scope_path.resolve())
    return slice_doc


def validate(doc: dict[str, Any]) -> list[str]:
    schema_path = BUNDLE_ROOT / "contracts" / "slice.schema.json"
    if jsonschema is None:
        return ["WARN jsonschema not importable — output NOT schema-checked"]
    if not schema_path.is_file():
        return [f"WARN schema {schema_path} not found — output NOT schema-checked"]
    validator = jsonschema.Draft202012Validator(json.loads(schema_path.read_text(encoding="utf-8")))
    return [f"{'/'.join(str(p) for p in err.absolute_path)}: {err.message}"
            for err in sorted(validator.iter_errors(doc), key=lambda e: list(e.absolute_path))]


def main(argv: Sequence[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        prog=TOOL,
        description="Build one bbh/slice/v1 per asset (surface + cells + queued leads + resolved "
                    "class playbooks + coverage gate).",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=("Example:\n"
                "  python3 tools/slice_build.py \\\n"
                "      --run-dir runs/acme-2026-09 \\\n"
                "      --scope runs/acme-2026-09/scope.json\n\n"
                "Exit codes: 0 slices written, 1 no asset has recon/inventory/surface.json,\n"
                "            2 bad input (run dir/assets dir unreadable)."),
    )
    parser.add_argument("--run-dir", required=True, help="engagement run dir (holds assets/, queue.json)")
    parser.add_argument("--scope", help="scope.json (sets scope_ref, creds_env, roe)")
    parser.add_argument("--catalog", help="bounty-coverage-matrix.json (missing -> playbook drops, loudly)")
    parser.add_argument("--assets-dir", help="default <run-dir>/assets")
    parser.add_argument("--queue", help="default <run-dir>/queue.json")
    parser.add_argument("--classification", help="default <run-dir>/classification.json if present")
    parser.add_argument("--out-dir", help="default <run-dir>/slices")
    parser.add_argument("--explain", action="store_true",
                        help="print playbook notices (anchor rewrites, directory expansions)")
    parser.add_argument("--json", action="store_true", help="print a single JSON summary object")
    parser.add_argument("--no-validate", action="store_true",
                        help="skip the jsonschema self-check of each slice")
    args = parser.parse_args(argv)

    run_dir = Path(args.run_dir).expanduser()
    if not run_dir.is_dir():
        print(f"{TOOL}: ERROR run dir does not exist: {run_dir}", file=sys.stderr)
        return 2
    assets_dir = Path(args.assets_dir).expanduser() if args.assets_dir else run_dir / "assets"
    if not assets_dir.is_dir():
        print(f"{TOOL}: ERROR assets dir does not exist: {assets_dir}", file=sys.stderr)
        return 2
    out_dir = Path(args.out_dir).expanduser() if args.out_dir else run_dir / "slices"
    queue_path = Path(args.queue).expanduser() if args.queue else run_dir / "queue.json"
    cls_path = (Path(args.classification).expanduser() if args.classification
                else run_dir / "classification.json")
    scope_path = Path(args.scope).expanduser() if args.scope else None
    catalog_path = Path(args.catalog).expanduser() if args.catalog else None
    if catalog_path is None:
        default_catalog = BUNDLE_ROOT / "catalog" / "bounty-coverage-matrix.json"
        if default_catalog.is_file():
            catalog_path = default_catalog

    emit = (lambda *a: print(*a, file=sys.stderr)) if args.json else print

    try:
        scope_doc = read_json(scope_path) if scope_path and scope_path.is_file() else {}
        if scope_path and not scope_path.is_file():
            print(f"{TOOL}: ERROR scope file not found: {scope_path}", file=sys.stderr)
            return 2
        queue_doc = read_json(queue_path) if queue_path.is_file() else {}
        classification_doc = read_json(cls_path) if cls_path.is_file() else None
    except SliceInputError as exc:
        print(f"{TOOL}: ERROR {exc}", file=sys.stderr)
        return 2

    catalog, catalog_msg = load_catalog(catalog_path)
    emit(f"{TOOL}: {catalog_msg}")
    if not queue_doc:
        emit(f"{TOOL}: WARN no queue at {queue_path}: every slice will carry 0 leads "
             f"(run queue_build.py first)")
    if classification_doc is None:
        emit(f"{TOOL}: WARN no classification at {cls_path}: asset_id falls back to asset_tag")

    asset_dirs = sorted(p for p in assets_dir.iterdir() if p.is_dir())
    candidates = [p for p in asset_dirs if (p / "recon" / "inventory" / "surface.json").is_file()]
    for skipped in (p for p in asset_dirs if p not in candidates):
        emit(f"  SKIP {skipped.name}: no recon/inventory/surface.json (not an asset slice; "
             f"nothing written for it)")
    if not candidates:
        emit(f"NEGATIVE: {TOOL} found no asset with recon/inventory/surface.json under {assets_dir}; "
             f"nothing to slice")
        return 1

    try:
        out_dir.mkdir(parents=True, exist_ok=True)
    except OSError as exc:
        print(f"{TOOL}: ERROR cannot create out dir {out_dir}: {exc}", file=sys.stderr)
        return 2

    summaries: list[dict[str, Any]] = []
    for asset_dir in candidates:
        try:
            doc = build_slice(asset_dir, run_dir, scope_doc, queue_doc, classification_doc,
                              catalog, catalog_path, scope_path, args.explain)
        except SliceInputError as exc:
            print(f"{TOOL}: ERROR {asset_dir.name}: {exc}", file=sys.stderr)
            return 2
        if not args.no_validate:
            errors = validate(doc)
            hard = [e for e in errors if not e.startswith("WARN")]
            for warn in (e for e in errors if e.startswith("WARN")):
                print(f"{TOOL}: {warn}", file=sys.stderr)
            if hard:
                print(f"{TOOL}: ERROR slice for {doc['asset_tag']} fails slice.schema.json:",
                      file=sys.stderr)
                for err in hard[:20]:
                    print(f"  {err}", file=sys.stderr)
                return 2
        out_path = out_dir / f"{doc['asset_tag']}.json"
        try:
            out_path.write_text(json.dumps(doc, indent=2) + "\n", encoding="utf-8")
        except OSError as exc:
            print(f"{TOOL}: ERROR cannot write {out_path}: {exc}", file=sys.stderr)
            return 2
        gate = doc["gate"]
        summaries.append({
            "asset_tag": doc["asset_tag"],
            "slice": str(out_path),
            "leads": len(doc["leads"]),
            "applicable_cells": doc["cell_count"],
            "class_playbooks": len(doc["class_playbooks"]),
            "playbook_drops": len(doc["class_playbook_drops"]),
            "covered": gate["covered"],
            "ratio": gate["ratio"],
            "complete": gate["complete"],
        })
        emit(f"  SLICE {doc['asset_tag']:<28} leads={len(doc['leads']):<4} "
             f"cells={doc['cell_count']:<3} playbooks={len(doc['class_playbooks']):<3} "
             f"gate covered={gate['covered']}/{gate['applicable']} ratio={gate['ratio']} "
             f"complete={gate['complete']} -> {out_path}")

    incomplete = [s["asset_tag"] for s in summaries if not s["complete"]]
    emit(f"{TOOL}: {len(summaries)} slice(s); incomplete: "
         f"{', '.join(incomplete) if incomplete else 'none'}")
    if args.json:
        print(json.dumps({"schema": SCHEMA_ID, "out_dir": str(out_dir.resolve()),
                          "slices": summaries}, indent=2))
    else:
        print(f"OK: {TOOL} slices={len(summaries)} out_dir={out_dir.resolve()} "
              f"incomplete={len(incomplete)}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
