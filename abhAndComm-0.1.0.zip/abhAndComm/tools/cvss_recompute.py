#!/usr/bin/env python3
"""cvss_recompute.py — pure-stdlib CVSS v3.1 / v3.0 base-score arithmetic.

WHY THIS EXISTS
---------------
The Stage 6 validator must *recompute* the CVSS base score from the vector a
finding claims. "The vector and the band disagree" has to be a machine check,
not a reviewer's opinion — a claimed `critical` on a vector that scores 6.5 is a
failed validation, and a claimed score that no vector can produce is a
fabrication signal. Talking to a CVSS web API would make that check
non-reproducible and network-dependent, so the arithmetic lives here, in the
bundle, implemented from the FIRST specification:

    ISS            = 1 - [(1-C)(1-I)(1-A)]
    Impact(S:U)    = 6.42 * ISS
    Impact(S:C)    = 7.52 * (ISS - 0.029) - 3.25 * (ISS - 0.02)^15
    Exploitability = 8.22 * AV * AC * PR * UI
    Base(S:U)      = Roundup(min(Impact + Exploitability, 10))
    Base(S:C)      = Roundup(min(1.08 * (Impact + Exploitability), 10))
    Base           = 0.0 when Impact <= 0

Roundup (v3.1 spec) is integer arithmetic, NOT `round()`/`ceil()`:
    i = floor(x * 100000 + 0.5)          # x to 5 decimal places, as an integer
    if i % 10000 == 0: return i/100000   # already an exact tenth — do not bump
    else:              return (i//10000 + 1)/10
This matters: a raw score of 6.6000000000000005 is 6.6, not 6.7, and a raw score
of exactly 9.06 is 9.1. v3.0 vectors use the older Roundup
(`ceil(x * 10)/10`, again on integer tenths) — accepted here because NVD still
publishes v3.0 vectors, but the two agree on every base-metric combination.

Bands (v3.1 ranges): 0.0 none, 0.1-3.9 low, 4.0-6.9 medium, 7.0-8.9 high,
9.0-10.0 critical. A valid vector always produces a score, so this tool has no
"real negative" result: exit 0 on success, 2 on bad input.

`--selftest` is the proof of the arithmetic: it asserts a table of vectors whose
scores were cross-checked against the FIRST reference implementation. Run it
before trusting any verdict this tool produces.

Pure stdlib; no third-party imports at all.
"""
from __future__ import annotations

import argparse
import json
import math
import re
import sys

VERSION_DEFAULT = "3.1"
SUPPORTED_VERSIONS = ("3.1", "3.0")
METRIC_ORDER = ("AV", "AC", "PR", "UI", "S", "C", "I", "A")

#: metric -> allowed values (CVSS v3.x base metrics)
ALLOWED: dict[str, tuple[str, ...]] = {
    "AV": ("N", "A", "L", "P"),
    "AC": ("L", "H"),
    "PR": ("N", "L", "H"),
    "UI": ("N", "R"),
    "S": ("U", "C"),
    "C": ("H", "L", "N"),
    "I": ("H", "L", "N"),
    "A": ("H", "L", "N"),
}

AV_W = {"N": 0.85, "A": 0.62, "L": 0.55, "P": 0.2}
AC_W = {"L": 0.77, "H": 0.44}
PR_W_U = {"N": 0.85, "L": 0.62, "H": 0.27}  # Scope Unchanged
PR_W_C = {"N": 0.85, "L": 0.68, "H": 0.5}   # Scope Changed
UI_W = {"N": 0.85, "R": 0.62}
CIA_W = {"H": 0.56, "L": 0.22, "N": 0.0}

PREFIX_RE = re.compile(r"^CVSS:(?P<version>\d+\.\d+)\s*/\s*", re.IGNORECASE)

#: (lower bound, band) evaluated from the top; 0.0 is its own band.
BANDS: tuple[tuple[float, str], ...] = (
    (9.0, "critical"),
    (7.0, "high"),
    (4.0, "medium"),
    (0.1, "low"),
)


class InputError(Exception):
    """Malformed vector / CLI input: exit 2."""


# --------------------------------------------------------------------------- #
# CVSS 3.x arithmetic
# --------------------------------------------------------------------------- #
def roundup31(x: float) -> float:
    """CVSS v3.1 Roundup — integer arithmetic on the 1e-5 scale, floored to tenths."""
    i = math.floor(x * 100000 + 0.5)
    if i % 10000 == 0:
        return i / 100000.0
    return (i // 10000 + 1) / 10.0


def roundup30(x: float) -> float:
    """CVSS v3.0 Roundup: smallest 1-decimal number >= x, on integer tenths."""
    i = math.floor(x * 100000 + 0.5)
    return ((i + 9999) // 10000) / 10.0


def base_score(metrics: dict[str, str], version: str = VERSION_DEFAULT) -> tuple[float, float]:
    """Return (rounded base score, raw unrounded score)."""
    scope = metrics["S"]
    iss = 1.0 - (1.0 - CIA_W[metrics["C"]]) * (1.0 - CIA_W[metrics["I"]]) * (1.0 - CIA_W[metrics["A"]])
    if scope == "U":
        impact = 6.42 * iss
        pr = PR_W_U[metrics["PR"]]
    else:
        impact = 7.52 * (iss - 0.029) - 3.25 * (iss - 0.02) ** 15
        pr = PR_W_C[metrics["PR"]]
    exploitability = 8.22 * AV_W[metrics["AV"]] * AC_W[metrics["AC"]] * pr * UI_W[metrics["UI"]]
    if impact <= 0:
        return 0.0, 0.0
    raw = impact + exploitability if scope == "U" else 1.08 * (impact + exploitability)
    raw = min(raw, 10.0)
    roundup = roundup31 if version == "3.1" else roundup30
    return roundup(raw), raw


def band_for_score(score: float) -> str:
    if score <= 0.0:
        return "none"
    for lower, name in BANDS:
        if score >= lower:
            return name
    return "none"


def parse_vector(text: str) -> tuple[str, dict[str, str]]:
    """Parse a CVSS v3.1/v3.0 base vector into (version, metrics).

    Accepts a missing `CVSS:3.1/` prefix (assumed 3.1) and 3.0 vectors. Any
    metric code outside the eight base metrics is rejected by name: temporal and
    environmental metrics are NOT part of a base score, so silently ignoring them
    would change the number a validator checks.
    """
    raw = (text or "").strip()
    if not raw:
        raise InputError("empty vector")
    version = VERSION_DEFAULT
    match = PREFIX_RE.match(raw)
    if match:
        version = match.group("version")
        if version not in SUPPORTED_VERSIONS:
            raise InputError(
                f"unsupported CVSS version {version!r} in {text!r}: this tool implements "
                f"the 3.x base metrics only ({', '.join(SUPPORTED_VERSIONS)})"
            )
        raw = raw[match.end():]
    elif raw.upper().startswith("CVSS:"):
        raise InputError(
            f"malformed CVSS prefix in {text!r}: expected `CVSS:3.1/` or `CVSS:3.0/`"
        )

    metrics: dict[str, str] = {}
    for token in re.split(r"[/,]", raw):
        token = token.strip()
        if not token:
            continue
        code, sep, value = token.partition(":")
        code = code.strip().upper()
        value = value.strip().upper()
        if not sep or not code or not value:
            raise InputError(f"malformed token {token!r} in {text!r}: expected CODE:VALUE")
        if code not in ALLOWED:
            hint = ""
            if code in ("E", "RL", "RC", "CR", "IR", "AR", "MAV", "MAC", "MPR", "MUI", "MS", "MC", "MI", "MA"):
                hint = " (temporal/environmental metrics are not part of a base score)"
            raise InputError(
                f"unknown metric code {code!r} in token {token!r}{hint}; base metrics are "
                f"{', '.join(METRIC_ORDER)}"
            )
        if code in metrics:
            raise InputError(f"duplicate metric {code!r} in {text!r}")
        if value not in ALLOWED[code]:
            raise InputError(
                f"metric {code!r} has invalid value {value!r} in token {token!r}; "
                f"allowed: {', '.join(ALLOWED[code])}"
            )
        metrics[code] = value

    missing = [code for code in METRIC_ORDER if code not in metrics]
    if missing:
        raise InputError(
            f"vector {text!r} is missing base metric(s): {', '.join(missing)} "
            f"(a full base vector is {', '.join(METRIC_ORDER)})"
        )
    return version, {code: metrics[code] for code in METRIC_ORDER}


def canonical_vector(version: str, metrics: dict[str, str]) -> str:
    return f"CVSS:{version}/" + "/".join(f"{code}:{metrics[code]}" for code in METRIC_ORDER)


def evaluate(text: str) -> dict[str, object]:
    version, metrics = parse_vector(text)
    score, _raw = base_score(metrics, version)
    return {
        "score": score,
        "band": band_for_score(score),
        "vector": canonical_vector(version, metrics),
        "metrics": dict(metrics),
    }


# --------------------------------------------------------------------------- #
# selftest
# --------------------------------------------------------------------------- #
#: (vector, expected base score, expected band). The 3.1/3.0 anchors below were
#: certified against the FIRST.org reference implementation; the band column is
#: read straight off the v3.1 ranges.
SELFTEST_VECTORS: tuple[tuple[str, float, str], ...] = (
    ("CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:H/A:N", 9.1, "critical"),
    ("CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:H/A:H", 9.8, "critical"),
    ("CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:C/C:H/I:H/A:H", 10.0, "critical"),
    ("CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:N/A:N", 7.5, "high"),
    ("CVSS:3.1/AV:N/AC:L/PR:L/UI:N/S:U/C:H/I:N/A:N", 6.5, "medium"),
    ("CVSS:3.1/AV:A/AC:L/PR:N/UI:N/S:C/C:N/I:N/A:L", 4.7, "medium"),
    ("CVSS:3.1/AV:L/AC:L/PR:N/UI:R/S:C/C:N/I:L/A:N", 3.6, "low"),
    ("CVSS:3.1/AV:P/AC:L/PR:L/UI:N/S:C/C:N/I:L/A:H", 5.9, "medium"),
    ("CVSS:3.1/AV:N/AC:H/PR:H/UI:R/S:U/C:N/I:N/A:N", 0.0, "none"),
    ("CVSS:3.1/AV:P/AC:H/PR:H/UI:R/S:U/C:L/I:N/A:N", 1.6, "low"),
    ("CVSS:3.1/AV:N/AC:L/PR:L/UI:R/S:U/C:L/I:L/A:N", 4.6, "medium"),
    ("CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:C/C:L/I:L/A:N", 7.2, "high"),
    ("CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:C/C:L/I:L/A:H", 9.9, "critical"),
    # bare vector: no CVSS:3.1/ prefix is accepted and assumed to be 3.1
    ("AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:H/A:N", 9.1, "critical"),
    # v3.0 vectors are accepted (older Roundup; identical for base metrics)
    ("CVSS:3.0/AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:H/A:H", 9.8, "critical"),
    ("CVSS:3.0/AV:L/AC:L/PR:N/UI:R/S:C/C:N/I:L/A:N", 3.6, "low"),
    ("CVSS:3.0/AV:P/AC:L/PR:L/UI:N/S:C/C:N/I:L/A:H", 5.9, "medium"),
)

#: Roundup boundaries: (raw, v3.1, v3.0).
SELFTEST_ROUNDUP: tuple[tuple[float, float, float], ...] = (
    (0.0, 0.0, 0.0),
    (4.0, 4.0, 4.0),
    (6.6000000000000005, 6.6, 6.6),   # binary noise must NOT bump to 6.7
    (9.064131, 9.1, 9.1),
    (9.75, 9.8, 9.8),
    (9.06, 9.1, 9.1),
    (2.0, 2.0, 2.0),
)

#: Band boundaries straight from the v3.1 ranges.
SELFTEST_BANDS: tuple[tuple[float, str], ...] = (
    (0.0, "none"),
    (0.1, "low"),
    (3.9, "low"),
    (4.0, "medium"),
    (6.9, "medium"),
    (7.0, "high"),
    (8.9, "high"),
    (9.0, "critical"),
    (10.0, "critical"),
)


def selftest(stream: "object | None" = None) -> int:
    """Assert the known table. `stream` lets --json keep stdout JSON-only."""
    report = stream if stream is not None else sys.stdout
    checks = 0
    failures: list[str] = []

    for vector, want_score, want_band in SELFTEST_VECTORS:
        checks += 1
        try:
            got = evaluate(vector)
        except InputError as exc:  # pragma: no cover - a table bug, not user input
            failures.append(f"{vector}: raised {exc}")
            continue
        if got["score"] != want_score or got["band"] != want_band:
            failures.append(
                f"{vector}: expected {want_score} ({want_band}), got {got['score']} ({got['band']})"
            )

    for raw, want31, want30 in SELFTEST_ROUNDUP:
        checks += 2
        if roundup31(raw) != want31:
            failures.append(f"roundup31({raw!r}): expected {want31}, got {roundup31(raw)}")
        if roundup30(raw) != want30:
            failures.append(f"roundup30({raw!r}): expected {want30}, got {roundup30(raw)}")

    for score, want in SELFTEST_BANDS:
        checks += 1
        if band_for_score(score) != want:
            failures.append(f"band_for_score({score}): expected {want}, got {band_for_score(score)}")

    if failures:
        for line in failures:
            print(f"SELFTEST FAIL: {line}", file=sys.stderr)
        print(f"SELFTEST FAIL: {len(failures)} of {checks} assertions failed", file=report)
        return 1
    print(
        f"SELFTEST PASS: {checks}/{checks} assertions (vectors, roundup boundaries, bands)",
        file=report,
    )
    return 0


# --------------------------------------------------------------------------- #
# CLI
# --------------------------------------------------------------------------- #
EXAMPLES = """\
examples:
  python3 tools/cvss_recompute.py --vector 'CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:H/A:N' --json
  # -> {"score": 9.1, "band": "critical", "vector": "CVSS:3.1/...", "metrics": {...}}
  python3 tools/cvss_recompute.py --vector 'AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:N/A:N'
  python3 tools/cvss_recompute.py --vector 'CVSS:3.0/AV:L/AC:L/PR:N/UI:R/S:C/C:N/I:L/A:N'
  python3 tools/cvss_recompute.py --selftest     # non-zero exit if the arithmetic is wrong
"""


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="cvss_recompute.py",
        description=(
            "Recompute a CVSS v3.1 (or v3.0) base score from its vector, in pure stdlib. "
            "Exit 0 = scored, 2 = malformed vector (the offending token is named)."
        ),
        epilog=EXAMPLES,
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument("--vector", default=None, metavar="VECTOR",
                        help="e.g. 'CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:H/A:N'; the "
                             "'CVSS:3.1/' prefix is optional (bare vectors are treated as 3.1)")
    parser.add_argument("--json", action="store_true",
                        help='emit one JSON object: {"score", "band", "vector", "metrics"}')
    parser.add_argument("--selftest", action="store_true",
                        help="assert the known-vector table and the roundup/band boundaries, "
                             "then exit non-zero if any assertion fails")
    return parser


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)

    if args.selftest:
        code = selftest(sys.stderr if args.json else sys.stdout)
        if code != 0 or not args.vector:
            return code

    if not args.vector:
        parser.error("--vector is required (or use --selftest)")

    try:
        result = evaluate(args.vector)
    except InputError as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 2

    if args.json:
        print(json.dumps(result))
    else:
        metrics = result["metrics"]
        assert isinstance(metrics, dict)
        version = "3.0" if str(result["vector"]).startswith("CVSS:3.0") else "3.1"
        print(
            f"OK: {result['score']} {result['band']} — {result['vector']} "
            f"(CVSS {version} base, recomputed)"
        )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
