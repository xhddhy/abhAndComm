#!/usr/bin/env bash
# Syntax-check the DSH workflow scripts the way the harness actually runs them.
#
# WHY THIS NEEDS ITS OWN SCRIPT
# -----------------------------
# A DSH workflow script is a bare JavaScript BODY, not a module: it has top-level `await`
# and a top-level `return`, and the harness wraps it in an async function before running it.
# That means the two obvious checks both give the WRONG answer:
#
#   node --check workflows/bbh-hunt.js        -> "await is only valid in async functions"
#   cp ... .mjs && node --check ...mjs        -> "Illegal return statement"
#
# Both are false alarms, and the tempting conclusion — "the scripts are broken" — is wrong.
# But the opposite mistake is worse: skipping the check entirely means a genuine typo is only
# discovered when the workflow tool refuses to start, mid-engagement, after the phases have
# already been announced.
#
# So this script reproduces the harness's own wrapping and checks THAT. It also asserts the
# two rules the tool contract imposes and that are easy to violate by habit:
#   * no `export const meta` / `export default` / `import` — meta is a tool parameter, not code;
#   * no `Date.now()`, `new Date()` or `Math.random()` — verdicts must be reproducible across
#     a replay, and the harness sandbox provides no timers.
#
# Usage:  bash tools/workflow_lint.sh [workflows/*.js ...]
# Exit:   0 all clean, 1 a script is invalid, 2 no scripts found / node missing.
set -euo pipefail

BUNDLE="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$BUNDLE"

if ! command -v node >/dev/null 2>&1; then
  echo "workflow_lint: node is not on PATH — cannot syntax-check the workflows" >&2
  exit 2
fi

# Default to every workflow; accept explicit files so a caller can lint just what changed.
if [[ $# -gt 0 ]]; then
  FILES=("$@")
else
  shopt -s nullglob
  FILES=(workflows/*.js)
fi

if [[ ${#FILES[@]} -eq 0 ]]; then
  echo "workflow_lint: no workflow scripts found under workflows/" >&2
  exit 2
fi

TMP="$(mktemp -d "${TMPDIR:-/tmp}/wflint.XXXXXX")"
trap 'rm -rf "$TMP"' EXIT

fail=0
for f in "${FILES[@]}"; do
  name="$(basename "$f" .js)"
  printf '%-26s ' "$name"

  # --- rule 1: no module syntax -------------------------------------------
  if grep -nE '^[[:space:]]*(export[[:space:]]+(const|default|function|class)|import[[:space:]])' "$f" >/dev/null 2>&1; then
    echo "FAIL — module syntax found (meta is a tool parameter; the body must not export or import)"
    grep -nE '^[[:space:]]*(export[[:space:]]+(const|default|function|class)|import[[:space:]])' "$f" | sed 's/^/      /'
    fail=1
    continue
  fi

  # --- rule 2: no non-deterministic time/randomness ------------------------
  # Comments are allowed to MENTION these (the scripts explain the rule); only real code counts.
  if grep -nE 'Date\.now\(|new Date\(|Math\.random\(' "$f" | grep -vE '^[0-9]+:[[:space:]]*(//|\*|/\*)' >/dev/null 2>&1; then
    echo "FAIL — non-deterministic call in code (use an agent that shells out to \`date\`)"
    grep -nE 'Date\.now\(|new Date\(|Math\.random\(' "$f" | grep -vE '^[0-9]+:[[:space:]]*(//|\*|/\*)' | sed 's/^/      /'
    fail=1
    continue
  fi

  # --- rule 3: parses under the harness's own wrapping --------------------
  { echo "async function __dsh_workflow_body(args) {"; cat "$f"; echo "}"; } > "$TMP/$name.mjs"
  if node --check "$TMP/$name.mjs" 2>"$TMP/$name.err"; then
    echo "OK"
  else
    echo "FAIL — syntax error:"
    head -8 "$TMP/$name.err" | sed 's/^/      /'
    fail=1
  fi
done

if [[ "$fail" == "0" ]]; then
  echo "workflow_lint: ${#FILES[@]} script(s) OK"
fi
exit "$fail"
