#!/usr/bin/env python3
"""Find files in this bundle that the harness will interpret as instructions or commands.

WHY THIS TOOL EXISTS
--------------------
This bundle is a security tool that lives inside an agent's workspace and carries a copy of
two third-party repositories. That combination creates a self-inflicted attack surface, and
it is worth naming precisely rather than hand-waving:

  The harness loads the `AGENTS.md` / `CLAUDE.md` chain from the project root down to the
  working directory as workspace guidance. `AGENTS.local.md` and `CLAUDE.local.md` are
  additive overlays. The content is injected into the agent's context as *instructions*.

So any file with one of those names, anywhere between the project root and wherever the
agent is working, is an instruction-injection primitive. Cloning a third-party repo into
your workspace inherits whatever those files say. This is not hypothetical: during the
build of this very bundle a test fixture named `CLAUDE.local.md`, containing the single word
`poison`, landed under `_upstream/` and the harness loaded it.

The same reasoning applies to three other shapes:

  * **Hook configs** (`.claude/settings.json`, `hooks.json`). The harness has a Claude Code
    hook bridge that *executes commands* from these. An instruction file can mislead an
    agent; a hook config runs code.
  * **Shadowed skill roots** (`.agents/skills`, `.dsh/skills` inside the bundle). A skill
    named the same as one of ours would shadow it, and a skill body is loaded on demand as
    instructions.
  * **MCP server configs** that would spawn a process.

`install.sh` runs this as a hard preflight and refuses to install a dirty bundle.

Usage:
  python3 tools/context_guard.py                 # report, exit 1 if anything is found
  python3 tools/context_guard.py --fix           # delete the offending files, then re-check
  python3 tools/context_guard.py --json
  python3 tools/context_guard.py --quiet         # only the exit code
"""
from __future__ import annotations

import argparse
import json
import os
import sys
from pathlib import Path

# Files the harness reads as workspace instructions. The `.local.md` variants are additive
# overlays, which makes them the stealthier half of the pair.
INSTRUCTION_NAMES = (
    "AGENTS.md", "AGENTS.local.md",
    "CLAUDE.md", "CLAUDE.local.md",
    "OPENCODE.md", "GEMINI.md",
)

# Config files that can cause a COMMAND to run, not merely text to be read.
HOOK_CONFIG_NAMES = (
    "hooks.json",
    ".claude/settings.json",
    ".claude/settings.local.json",
    ".claude/hooks.json",
)

# Directories that, if present inside the bundle, would shadow a real skill root.
SHADOW_ROOTS = (".agents/skills", ".dsh/skills", ".claude/skills")

# Upstream snapshot trees. Findings here are expected until `sync-upstream.sh` strips them,
# so they are reported separately rather than mixed with findings in the live bundle.
UPSTREAM_PREFIXES = ("_upstream/",)

SEVERITY_HIGH = "high"
SEVERITY_MEDIUM = "medium"


def classify(rel: str, kind: str) -> str:
    """Severity by kind and location.

    A hook config is always high: it executes. An instruction file in the live bundle is
    high (it is loaded whenever an agent works here); one inside the vendored upstream
    snapshot is medium, because it is stripped at install time and the snapshot is
    read-only by convention — but it still must not be left lying around.
    """
    in_upstream = rel.startswith(UPSTREAM_PREFIXES)
    if kind == "hook_config":
        return SEVERITY_HIGH
    if kind == "shadow_root":
        return SEVERITY_HIGH
    if kind == "instruction_file":
        return SEVERITY_MEDIUM if in_upstream else SEVERITY_HIGH
    return SEVERITY_MEDIUM


def _hook_config_risk(path: Path) -> str | None:
    """Return why this config is dangerous, or None if it is inert.

    A `.claude/settings.json` that only sets permissions is noise; one carrying a `hooks`
    block or an `mcpServers` block can run a command, and that is the thing worth failing
    an install over. Reading the file keeps the check precise instead of crying wolf on
    every project config in the vendored snapshot.
    """
    try:
        data = json.loads(path.read_text(encoding="utf-8", errors="replace"))
    except (OSError, json.JSONDecodeError):
        return "unparsable config — cannot rule out a command hook"
    if not isinstance(data, dict):
        return None
    if data.get("hooks"):
        return "defines command hooks that the harness bridge will execute"
    if data.get("mcpServers"):
        return "defines MCP servers that the harness would spawn"
    return None


def iter_candidates(root: Path):
    """Yield (relpath, kind, detail) for everything the harness would interpret."""
    for dirpath, dirnames, filenames in os.walk(root):
        # VCS metadata is neither loaded nor worth walking.
        dirnames[:] = [d for d in dirnames if d not in {".git", "__pycache__", "node_modules"}]
        rel_dir = os.path.relpath(dirpath, root)
        rel_dir = "" if rel_dir == "." else rel_dir.replace(os.sep, "/")

        # A skill root nested inside the bundle would shadow the real one, because skill
        # discovery takes the first match for a name. Report the directory and stop.
        if any(rel_dir == s or rel_dir.endswith("/" + s) for s in SHADOW_ROOTS):
            yield rel_dir, "shadow_root", "a nested skill root would shadow the installed skills"
            dirnames[:] = []
            continue

        for name in filenames:
            rel = f"{rel_dir}/{name}" if rel_dir else name
            if name in INSTRUCTION_NAMES:
                yield rel, "instruction_file", "the harness loads this as workspace instructions"
            elif name == "hooks.json" or name in ("settings.json", "settings.local.json"):
                if "/.claude/" in f"/{rel}" or name == "hooks.json":
                    why = _hook_config_risk(root / rel)
                    if why:
                        yield rel, "hook_config", why


def preview(path: Path, limit: int = 160) -> str:
    try:
        text = path.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return "<unreadable>"
    text = text.strip()
    if len(text) > limit:
        text = text[:limit] + "…"
    return text.replace("\n", " / ") or "<empty>"


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(
        description="Detect files this bundle could use to inject agent instructions or run commands.",
        epilog="Run from the bundle root. install.sh calls this with --quiet as a preflight.")
    ap.add_argument("--root", default=None, help="Bundle root (default: the parent of tools/).")
    ap.add_argument("--fix", action="store_true", help="Delete the offending files.")
    ap.add_argument("--prune-upstream", action="store_true",
                    help="Also remove inert upstream scaffolding inside _upstream/ — nested "
                         ".claude/skills shadow roots, upstream hook configs and broken "
                         "instruction symlinks. These are never needed at runtime and are "
                         "restored by `git reset --hard`, so prune them after every sync.")
    ap.add_argument("--json", action="store_true")
    ap.add_argument("--quiet", action="store_true", help="Suppress output; rely on the exit code.")
    ap.add_argument("--include-upstream", action="store_true", default=True,
                    help="Include the _upstream/ snapshot (default: on; it is what ships in a clone).")
    args = ap.parse_args(argv)

    root = Path(args.root).resolve() if args.root else Path(__file__).resolve().parent.parent
    if not root.is_dir():
        print(f"error: not a directory: {root}", file=sys.stderr)
        return 2

    findings = []
    for rel, kind, detail in iter_candidates(root):
        if not args.include_upstream and rel.startswith(UPSTREAM_PREFIXES):
            continue
        p = root / rel
        findings.append({
            "path": rel,
            "kind": kind,
            "severity": classify(rel, kind),
            "detail": detail,
            "preview": preview(p) if kind == "instruction_file" else "",
        })

    # Sort worst first so the operator reads the actionable line first.
    findings.sort(key=lambda f: (0 if f["severity"] == SEVERITY_HIGH else 1, f["path"]))

    removed = []
    if args.fix or args.prune_upstream:
        for f in findings:
            target = root / f["path"]
            if f["kind"] == "shadow_root":
                # Only prune a shadow root that holds nothing but symlinks and .gitignore
                # files — that is upstream's inert scaffolding. A directory with real
                # content is somebody's work and is left alone.
                if not args.prune_upstream:
                    continue
                try:
                    entries = list(target.iterdir())
                except OSError:
                    continue
                if all(e.is_symlink() or e.name == ".gitignore" for e in entries):
                    try:
                        for e in entries:
                            e.unlink()
                        target.rmdir()
                        removed.append(f["path"])
                    except OSError as exc:
                        print(f"WARN could not prune {f['path']}: {exc}", file=sys.stderr)
                continue
            if f["kind"] == "hook_config" and not args.prune_upstream:
                # A hook config in a live (non-upstream) path is not ours to delete
                # silently; the operator decides.
                continue
            try:
                target.unlink()
                removed.append(f["path"])
            except OSError as exc:
                print(f"WARN could not remove {f['path']}: {exc}", file=sys.stderr)
        # Broken symlinks whose name matches an instruction candidate are invisible to
        # Path.exists() and to `find -type f`, which is exactly how one survived the first
        # cleanup pass. Sweep them explicitly.
        for p in root.rglob("*"):
            if p.is_symlink() and not p.exists() and p.name in INSTRUCTION_NAMES:
                try:
                    p.unlink()
                    removed.append(str(p.relative_to(root)))
                except OSError:
                    pass
        findings = [f for f in findings if f["path"] not in set(removed)]

    high = [f for f in findings if f["severity"] == SEVERITY_HIGH]

    if args.json:
        print(json.dumps({"root": str(root), "removed": removed, "findings": findings,
                          "clean": not findings, "blocking": bool(high)}, indent=1))
    elif not args.quiet:
        if not findings:
            print(f"OK: no instruction-injection surface found in {root}")
        else:
            print(f"CONTEXT GUARD — {root}")
            for f in findings:
                print(f"  [{f['severity'].upper()}] {f['kind']}: {f['path']}")
                print(f"        {f['detail']}")
                if f["preview"]:
                    print(f"        content: {f['preview']}")
            if removed:
                print(f"\n  removed {len(removed)} file(s): {', '.join(removed)}")
            print(f"\n  {len(findings)} finding(s), {len(high)} blocking.")
            if high:
                print("  A hook config or a live instruction file can steer or execute in an agent "
                      "session.\n  Remove it before installing: add --fix, or delete it by hand.")

    return 1 if high else 0


if __name__ == "__main__":
    raise SystemExit(main())
