#!/usr/bin/env python3
"""Translate Agentic-Bug-Hunter's classification buckets into communitytools' surface/v2
flag vocabulary.

WHY THIS TOOL EXISTS
--------------------
The two upstream projects do not share a data model. ABH thinks in *buckets* — "here are the
api endpoints, here are the params that look injectable, here are the secrets in the JS".
communitytools thinks in *surface flags* — 18 boolean properties of a surface unit, against
which a 39-class catalogue evaluates `applies_when` predicates to produce the coverage work
list. Neither side can read the other's format, so the merge needs exactly one translation
layer, and this is it.

The translation is deliberately rule-based and auditable rather than model-generated. A flag
decides how much work the coverage gate will demand, so a flag an agent could talk itself into
is a flag that can silently shrink the engagement. Every flag written here carries an
`evidence` line naming the observation that produced it, and `--explain` prints the whole
mapping table for a human to argue with.

TWO CLASSES OF FLAG, AND WHY ONLY ONE MAY BE SET HERE
-----------------------------------------------------
`coverage_catalog.AGENT_FLAGS` (18) describe what a *human or agent observed* about a unit:
that it takes an object id, that it fetches a URL server-side, that it has an auth gate.

`AGENT_FLAGS`' companions, the 7 *derived* flags (`http_listener`, `tls_listener`,
`version_fingerprinted`, `has_api`, `is_apex`, `serves_js`, `mobile_app`), are computed by
`cells_build.py` from the unit's own shape — scheme, port, whether a version token is present,
the unit's `type`. They are un-fabricatable on purpose: a unit cannot be *argued* into not
being an HTTP listener, so it cannot be argued out of the classes that requires one.

This tool therefore writes ONLY agent flags. If a derived flag ever appears in the output,
cells_build.py filters it and warns; `--strict-flags` turns that warning into a failure so the
bug surfaces in CI instead of in a coverage number.
"""
from __future__ import annotations

import argparse
import json
import os
import re
import sys
from urllib.parse import urlparse, parse_qs

SCHEMA = "surface/v2"
CLASSIFICATION_SCHEMA = "bbh/classification/v1"

# The 18 flags an observer may assert. Kept here as a literal copy of
# coverage_catalog.AGENT_FLAGS: this tool must not import the catalogue, because the
# catalogue is data the operator may replace and the vocabulary is a fixed contract.
AGENT_FLAGS: tuple[str, ...] = (
    "object_by_id", "json_body", "role_verb_gated", "sensitive_flow",
    "server_fetched_url", "input_sink", "workflow", "deser_or_ci",
    "inbound_webhook", "id_keyed_unauth", "stored_field", "auth_surface",
    "consumes_upstream", "static_js_or_repo", "local_store", "crypto_use",
    "exported_component", "webview",
)
DERIVED_FLAGS: tuple[str, ...] = (
    "http_listener", "tls_listener", "version_fingerprinted",
    "has_api", "is_apex", "serves_js", "mobile_app",
)
# Web-only bundle: these four exist for the MASVS mobile classes, which the bundle's
# catalogue drops. They are listed so the "never set" decision is explicit rather than
# an oversight someone later mistakes for a bug.
MOBILE_ONLY_FLAGS: tuple[str, ...] = (
    "local_store", "crypto_use", "exported_component", "webview",
)

# ---------------------------------------------------------------------------
# Unit types. `has_api` and `serves_js` are derived from these in cells_build.py,
# so `type` is load-bearing and must not be decorative.
# ---------------------------------------------------------------------------
TYPE_ENDPOINT = "endpoint"   # an application API surface
TYPE_PAGE = "page"           # an HTML page / static asset
TYPE_SERVICE = "service"     # a network service that speaks HTTP
TYPE_ASSET = "asset"         # an asset-level record carrying only rollup flags
TYPE_LISTENER = "listener"   # a non-HTTP listener (network engagements)

# ---------------------------------------------------------------------------
# Rule tables. Every entry is (flag, matcher, human reason). The reason string is
# what lands in units[].evidence, so it must name the observation, not restate the flag.
# ---------------------------------------------------------------------------

# Path fragments strongly implying a JSON API rather than an HTML page.
API_PATH_RE = re.compile(
    r"(?:^|/)(?:api|rest|rpc|graphql|gql|json|v\d+)(?:/|$)|\.json(?:$|\?)", re.I)
GRAPHQL_RE = re.compile(r"graphql|/gql(?:/|$)", re.I)

# An object-id position: a numeric segment, a UUID, a long hex blob, or a template token.
UUID_RE = re.compile(
    r"[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}", re.I)
HEXID_RE = re.compile(r"\b[0-9a-f]{16,}\b", re.I)
TEMPLATE_ID_RE = re.compile(r"\{[^}/]*id[^}/]*\}|:(?:id|pk|key)\b|\[(?:id|pk)\]", re.I)
NUMERIC_SEG_RE = re.compile(r"(?:^|/)(\d{1,12})(?:/|$)")
# Path segments that look like a collection followed by an identifier.
ID_PATH_RE = re.compile(
    r"/(?:users?|accounts?|customers?|orders?|invoices?|payments?|transactions?|"
    r"messages?|tickets?|documents?|files?|projects?|teams?|orgs?|organizations?|"
    r"posts?|comments?|items?|products?|carts?|bookings?|reports?|profiles?)"
    r"/(?:[^/]*id[^/]*|:id|\{[^}]*\}|[0-9]+|[0-9a-f-]{8,})(?:/|$)", re.I)

# Query/body parameter names, grouped by the flag they justify.
ID_PARAM_RE = re.compile(
    r"^(?:id|pk|uid|uuid|guid|key|ref|user_?id|account_?id|order_?id|customer_?id|"
    r"owner_?id|tenant_?id|org_?id|group_?id|item_?id|doc_?id|file_?id)$", re.I)
URL_PARAM_RE = re.compile(
    r"^(?:url|uri|link|href|src|source|dest|destination|target|redirect|redirect_?uri|"
    r"redirect_?url|return|return_?url|next|continue|callback|cb|webhook|feed|image_?url|"
    r"avatar_?url|proxy|fetch|load|open|path|file|domain|host|endpoint|api_?url|site)$", re.I)
ROLE_PARAM_RE = re.compile(
    r"^(?:role|roles|is_?admin|admin|permission|permissions|scope|scopes|group|groups|"
    r"privilege|privileges|access|level|type|kind|action|op|operation|cmd|command|"
    r"method|func|function|do|mode)$", re.I)
FLOW_PARAM_RE = re.compile(
    r"^(?:step|stage|phase|state|status|confirm|approve|approval|verify|validation|"
    r"checkout|cart|order|payment|pay|amount|price|total|quantity|qty|coupon|promo|"
    r"discount|credit|credits|wallet|balance|transfer|refund|withdraw|subscribe|plan|"
    r"tier|upgrade|renew|invoice|billing|shipment|delivery|booking|reservation|seat)$", re.I)
STORED_PARAM_RE = re.compile(
    r"^(?:comment|content|body|text|message|msg|note|notes|description|desc|bio|about|"
    r"name|title|subject|label|tag|tags|post|reply|review|feedback|signature|status_?text|"
    r"display_?name|nickname|username|first_?name|last_?name|avatar|photo|image|website|"
    r"homepage|company|address|phone)$", re.I)
AUTH_PARAM_RE = re.compile(
    r"^(?:token|access_?token|refresh_?token|id_?token|password|passwd|pwd|otp|code|"
    r"secret|client_?secret|state|nonce|assertion|saml_?response|session|sessionid|"
    r"jwt|bearer|api_?key|apikey)$", re.I)

AUTH_PATH_RE = re.compile(
    r"/(?:login|logout|signin|sign-in|signup|sign-up|sign_out|register|password|passwd|"
    r"reset|forgot|recover|oauth|oauth2|oidc|saml|sso|token|session|mfa|otp|2fa|totp|"
    r"invite|verify|activate|auth|authorize|consent|account/confirm)(?:/|$|\?)", re.I)
ADMIN_PATH_RE = re.compile(
    r"/(?:admin|administrator|manage|management|console|internal|debug|actuator|jenkins|"
    r"grafana|kibana|phpmyadmin|pma|wp-admin|server-status|swagger|swagger-ui|api-docs|"
    r"\.git|\.env|\.svn|\.hg|_debug|__debug__|metrics|healthz|readyz)(?:/|$|\?)", re.I)
WEBHOOK_PATH_RE = re.compile(
    r"/(?:webhooks?|hooks?|callbacks?|ingress|notify|notification|events?|receive|"
    r"push|listen|subscribe)(?:/|$|\?)", re.I)
CI_PATH_RE = re.compile(
    r"\.github/workflows|\.gitlab-ci|Jenkinsfile|\.circleci|azure-pipelines|"
    r"bitbucket-pipelines|\.travis\.yml|buildkite", re.I)
DESER_HINT_RE = re.compile(
    r"__viewstate|__eventvalidation|viewstate|jsf|\.svc|/soap|webservice|pickle|"
    r"serialize|deserialize|rmi|hessian|jndi|\.ashx|\.asmx", re.I)
JS_ASSET_RE = re.compile(r"\.m?js(?:$|\?)|/static/js/|/assets/js/|/bundles?/", re.I)

# Tech tokens whose presence means the server is consuming a third-party API.
UPSTREAM_SDK_RE = re.compile(
    r"stripe|twilio|sendgrid|mailgun|shopify|auth0|okta|firebase|algolia|segment|"
    r"braintree|paypal|adyen|plaid|intercom|zendesk|salesforce|hubspot|s3\.amazonaws|"
    r"googleapis|azure|cloudinary|contentful|sanity", re.I)


def _q(url: str) -> dict[str, list[str]]:
    try:
        return parse_qs(urlparse(url).query, keep_blank_values=True)
    except ValueError:
        return {}


def _path(url: str) -> str:
    try:
        return urlparse(url).path or ""
    except ValueError:
        return ""


def looks_like_api(url: str) -> bool:
    return bool(API_PATH_RE.search(url) or GRAPHQL_RE.search(url))


def looks_like_js(url: str) -> bool:
    return bool(JS_ASSET_RE.search(url))


def is_object_by_id(url: str, params: list[str]) -> tuple[bool, str]:
    """Does this unit address a specific object by identifier?

    Deliberately generous: a false positive costs one extra BOLA checklist item, while a
    false negative silently removes the highest-paying class in web bounty from the work
    list. The evidence string distinguishes the strong signals from the weak ones so a
    reviewer can re-rank by hand.
    """
    p = _path(url)
    for name in params:
        if ID_PARAM_RE.match(name):
            return True, f"param '{name}' is an object identifier"
    if TEMPLATE_ID_RE.search(url):
        return True, "template id token in path"
    if UUID_RE.search(p):
        return True, "UUID path segment"
    if ID_PATH_RE.search(p):
        return True, "collection path followed by an identifier"
    if NUMERIC_SEG_RE.search(p) and looks_like_api(url):
        return True, "numeric path segment on an API path (weak)"
    if HEXID_RE.search(p):
        return True, "long hex path segment (weak)"
    return False, ""


def classify_params(params: list[str]) -> dict[str, list[str]]:
    """Group parameter names by the flag each justifies. Returns flag -> names."""
    out: dict[str, list[str]] = {}
    for n in params:
        if URL_PARAM_RE.match(n):
            out.setdefault("server_fetched_url", []).append(n)
        if ROLE_PARAM_RE.match(n):
            out.setdefault("role_verb_gated", []).append(n)
        if FLOW_PARAM_RE.match(n):
            out.setdefault("sensitive_flow", []).append(n)
        if STORED_PARAM_RE.match(n):
            out.setdefault("stored_field", []).append(n)
        if AUTH_PARAM_RE.match(n):
            out.setdefault("auth_surface", []).append(n)
        if ID_PARAM_RE.match(n):
            out.setdefault("object_by_id", []).append(n)
    return out


def flags_for_unit(
    *,
    url: str,
    method: str,
    bucket: str,
    params: list[str],
    status_code: int | None,
    unauthenticated: bool,
    gf_source: str = "",
    asset_tech: list[str] | None = None,
    js_secret_contexts: list[str] | None = None,
) -> dict[str, str]:
    """Return {flag: evidence} for one surface unit.

    Order of the branches below mirrors the flag list in AGENT_FLAGS so a reader can diff
    the two by eye. Every returned evidence string answers "what did we see?".
    """
    f: dict[str, str] = {}
    path = _path(url)
    params = [p for p in params if p]
    grouped = classify_params(params)

    # --- object_by_id -------------------------------------------------------
    obid, why = is_object_by_id(url, params)
    if obid:
        f["object_by_id"] = why

    # --- input_sink ---------------------------------------------------------
    # Any parameter or any non-GET method is an input the server parses. This is the
    # broadest flag and intentionally so: it is what makes the injection class
    # applicable, and an unprobed injection sink is exactly the thing a symptom-driven
    # scan never reaches.
    if params:
        f["input_sink"] = f"{len(params)} query parameter(s): {', '.join(sorted(set(params))[:8])}"
    elif method.upper() in {"POST", "PUT", "PATCH", "DELETE"}:
        f["input_sink"] = f"{method.upper()} method accepts a request body"

    # --- json_body ----------------------------------------------------------
    # A JSON create/update body. Requires more than "it is an API": a GET-only endpoint
    # has no body to over-post, and claiming one would create false mass-assignment work.
    if method.upper() in {"POST", "PUT", "PATCH"} and (
            looks_like_api(url) or bucket == "api_endpoints"):
        f["json_body"] = f"{method.upper()} on an API path accepts a structured body"
    elif bucket == "api_endpoints" and method.upper() == "GET" and "json" in gf_source.lower():
        f["json_body"] = "JSON body observed in recon capture"

    # --- role_verb_gated ----------------------------------------------------
    if bucket == "admin_paths" or ADMIN_PATH_RE.search(path):
        f["role_verb_gated"] = "administrative/management path"
    elif grouped.get("role_verb_gated"):
        f["role_verb_gated"] = "role/permission-shaped param: " + ", ".join(grouped["role_verb_gated"][:5])

    # --- sensitive_flow -----------------------------------------------------
    if grouped.get("sensitive_flow"):
        f["sensitive_flow"] = "business-flow param: " + ", ".join(grouped["sensitive_flow"][:6])
    if re.search(r"/(?:checkout|cart|payment|pay|transfer|refund|withdraw|billing|"
                 r"subscribe|order|invoice|wallet|credit)(?:/|$)", path, re.I):
        f["sensitive_flow"] = (f.get("sensitive_flow", "") + "; " if f.get("sensitive_flow") else "") + \
            "sensitive flow path segment"
    # A multi-step flow is both a workflow and (usually) a business-logic target.
    if re.search(r"/(?:flow|onboard|wizard|steps?|process)(?:/|$)", path, re.I):
        f["workflow"] = "multi-step flow path"

    # --- server_fetched_url -------------------------------------------------
    if grouped.get("server_fetched_url"):
        f["server_fetched_url"] = "URL-shaped param: " + ", ".join(grouped["server_fetched_url"][:6])
    if gf_source.lower().startswith("gf:ssrf"):
        f["server_fetched_url"] = (f.get("server_fetched_url", "") + "; " if f.get("server_fetched_url") else "") + \
            "matched the gf ssrf pattern set"

    # --- workflow -----------------------------------------------------------
    if grouped.get("sensitive_flow"):
        flow_names = [n for n in grouped["sensitive_flow"]
                      if re.match(r"^(?:step|stage|phase|state|status|confirm|approve)$", n, re.I)]
        if flow_names:
            f["workflow"] = "flow-state param: " + ", ".join(flow_names[:5])

    # --- deser_or_ci --------------------------------------------------------
    if CI_PATH_RE.search(url):
        f["deser_or_ci"] = "CI/CD configuration path"
    elif DESER_HINT_RE.search(url):
        f["deser_or_ci"] = "deserialization/framework state token in path"
    elif path.startswith("/.git") or path.startswith("/.env"):
        f["deser_or_ci"] = "source-control or environment file exposure"

    # --- inbound_webhook ----------------------------------------------------
    if WEBHOOK_PATH_RE.search(path):
        f["inbound_webhook"] = "inbound webhook/ingress path"

    # --- id_keyed_unauth ----------------------------------------------------
    # Only assert unauth when the recon actually ran without credentials AND the id-keyed
    # request returned a success status. Claiming this from the URL shape alone would
    # manufacture an unauthenticated-oracle class out of nothing.
    if obid and unauthenticated and status_code is not None and 200 <= status_code < 300:
        f["id_keyed_unauth"] = (
            f"id-keyed request returned {status_code} from an unauthenticated recon session")

    # --- stored_field -------------------------------------------------------
    if grouped.get("stored_field"):
        f["stored_field"] = "stored-content param: " + ", ".join(grouped["stored_field"][:6])

    # --- auth_surface -------------------------------------------------------
    if bucket == "auth_paths" or AUTH_PATH_RE.search(path):
        f["auth_surface"] = "authentication path"
    elif grouped.get("auth_surface"):
        f["auth_surface"] = "auth-shaped param: " + ", ".join(grouped["auth_surface"][:5])
    elif status_code in (401, 403):
        f["auth_surface"] = f"endpoint answered {status_code} (auth or authorization gate present)"

    # --- consumes_upstream --------------------------------------------------
    # Scope matters here: API10-CONSUMPTION is a UNIT-scope class, so asserting this
    # flag per unit makes it applicable N times for one integration. The asset's tech
    # stack alone is therefore NOT sufficient evidence — it says the stack mentions
    # Stripe, not that this endpoint calls it. Only a unit that itself shows the
    # integration earns the flag; the asset-wide tech signal is recorded separately in
    # surface.json's `asset_signals` for the coordinator, deliberately outside the flags.
    dsg = " ".join(js_secret_contexts or [])
    if bucket == "js_secrets" and UPSTREAM_SDK_RE.search(dsg):
        hit = UPSTREAM_SDK_RE.search(dsg)
        f["consumes_upstream"] = f"third-party credential in this bundle: {hit.group(0)}"
    elif UPSTREAM_SDK_RE.search(path):
        hit = UPSTREAM_SDK_RE.search(path)
        f["consumes_upstream"] = f"path names a third-party integration: {hit.group(0)}"
    elif re.search(r"/(?:integrations?|connections?|connectors?|marketplace|apps|"
                   r"linked-?accounts?)(?:/|$)", path, re.I):
        f["consumes_upstream"] = "integration/connector management path"

    # --- static_js_or_repo --------------------------------------------------
    if bucket == "js_secrets" or looks_like_js(url):
        f["static_js_or_repo"] = "client-side bundle / static script"

    # --- mobile-only flags --------------------------------------------------
    # Never set for a web asset. Recorded in the module docstring; asserted by
    # --strict-flags so that a future edit adding one fails loudly.
    return f


def unit_type_for(url: str, bucket: str) -> str:
    if bucket == "js_secrets" or looks_like_js(url):
        return TYPE_PAGE
    if bucket in {"api_endpoints", "auth_paths", "admin_paths"} or looks_like_api(url):
        return TYPE_ENDPOINT
    if bucket == "interesting_params":
        return TYPE_ENDPOINT if looks_like_api(url) else TYPE_PAGE
    if bucket == "ports":
        return TYPE_SERVICE
    if bucket in {"cloud", "takeover"}:
        # Asset-level observations, not HTTP surfaces of the application. Typing them
        # TYPE_PAGE would roll up the asset-level serves_js derived flag and make every
        # JS class applicable because an unrelated bucket exists.
        return TYPE_ASSET
    return TYPE_PAGE


def equiv_group_for(url: str) -> str | None:
    """Collapse v1/v2 and trailing-slash variants of the same logical endpoint.

    Rationale: covering BOLA on /v2/users/{id} at the same depth as /v1/users/{id} is
    usually the same test. But a version difference is ALSO a classic place a fix is
    missing, so the group is recorded rather than the units being merged — the executor
    can still work the sibling deliberately, it just does not inflate the denominator.
    """
    try:
        u = urlparse(url)
    except ValueError:
        return None
    path = (u.path or "/").rstrip("/")
    path = re.sub(r"/v\d+(?=/|$)", "/vN", path, flags=re.I)
    path = UUID_RE.sub(":id", path)
    path = NUMERIC_SEG_RE.sub("/:id", path)
    if not path:
        return None
    return f"{u.scheme}://{u.netloc}{path}"


def build_units(asset: dict, unauthenticated: bool, notes: list[str]) -> list[dict]:
    """Turn one classification asset into surface/v2 units."""
    buckets = asset.get("buckets") or {}
    tech = list(asset.get("tech") or [])
    # Contexts, not kinds: the flag needs to know WHICH third party, because
    # "a key exists" is not the same claim as "this bundle calls a third-party API".
    js_contexts = [
        " ".join(str(x) for x in (s.get("context"), s.get("value_redacted"), s.get("evidence")) if x)
        for s in (buckets.get("js_secrets") or [])
    ]

    # (url, method, bucket, params, status, gf_source)
    rows: list[tuple[str, str, str, list[str], int | None, str]] = []

    for e in buckets.get("api_endpoints") or []:
        rows.append((e.get("url", ""), e.get("method", "GET"), "api_endpoints",
                     sorted(_q(e.get("url", ""))), e.get("status_code"), e.get("source", "")))
    for e in buckets.get("auth_paths") or []:
        rows.append((e.get("url", ""), "GET", "auth_paths",
                     sorted(_q(e.get("url", ""))), e.get("status_code"), e.get("evidence", "")))
    for e in buckets.get("interesting_params") or []:
        params = list(e.get("params") or []) or sorted(_q(e.get("url", "")))
        rows.append((e.get("url", ""), e.get("method", "GET"), "interesting_params",
                     params, e.get("status_code"), e.get("source", "")))
    for e in buckets.get("admin_paths") or []:
        rows.append((e.get("url", ""), "GET", "admin_paths",
                     sorted(_q(e.get("url", ""))), e.get("status_code"), ""))
    for e in buckets.get("js_secrets") or []:
        # A secret is a property of the bundle, not of each endpoint it embeds; the
        # bundle becomes one unit so the secret-exposure class applies to it once.
        rows.append((e.get("url", ""), "GET", "js_secrets", [], 200, "js"))
    for e in buckets.get("cloud") or []:
        # Deliberately NOT a surface unit. A bucket name is not an addressable HTTP
        # surface of the application, and typing it as one would make the unconditional
        # misconfiguration class applicable against a string that has no listener. Cloud
        # observations reach the operator through the queue instead; the classification
        # file remains their home.
        notes.append(f"cloud observation kept out of surface units: {e.get('identifier', '?')}")
    for e in buckets.get("takeover") or []:
        notes.append(f"takeover candidate kept out of surface units: {e.get('host', '?')}")
    for e in buckets.get("ports") or []:
        port = e.get("port")
        host = asset.get("asset_tag", "").split(":")[0]
        if port and host:
            scheme = "https" if port in (443, 8443, 9443) else "http"
            rows.append((f"{scheme}://{host}:{port}", "GET", "ports", [], None,
                         e.get("product", "")))

    # Drop rows with no usable address, and report the drop rather than swallowing it.
    kept = []
    for r in rows:
        if r[0] and r[0].startswith(("http://", "https://")):
            kept.append(r)
        elif r[0]:
            kept.append((f"https://{r[0]}", *r[1:]))
        else:
            notes.append(f"dropped a {r[2]} row with no address")

    # Deduplicate on (address, method), merging the flags of the colliding rows.
    merged: dict[tuple[str, str], dict] = {}
    for url, method, bucket, params, status, src in kept:
        key = (url, method.upper())
        if key not in merged:
            # Seed with THIS row's params, not an empty set: a URL that appears exactly
            # once (the common case) would otherwise lose every parameter, which silently
            # removes input_sink and server_fetched_url from the whole engagement.
            merged[key] = {"url": url, "method": method.upper(), "bucket": bucket,
                           "params": set(params), "status": status, "src": [src],
                           "buckets": {bucket}}
        else:
            merged[key]["params"] |= set(params)
            merged[key]["buckets"].add(bucket)
            if src:
                merged[key]["src"].append(src)
            if merged[key]["status"] is None:
                merged[key]["status"] = status

    units = []
    for (url, method), m in merged.items():
        if len(m["buckets"]) > 1:
            # Prefer the most specific bucket for provenance so the unit's `bucket` field
            # names the signal that best explains it.
            for pref in ("js_secrets", "admin_paths", "auth_paths", "api_endpoints",
                         "interesting_params", "cloud", "takeover", "ports"):
                if pref in m["buckets"]:
                    m["bucket"] = pref
                    break
        params = sorted(m["params"])
        gf = " ".join(x for x in m["src"] if x)
        flags = flags_for_unit(
            url=url, method=method, bucket=m["bucket"], params=params,
            status_code=m["status"], unauthenticated=unauthenticated,
            gf_source=gf, asset_tech=tech, js_secret_contexts=js_contexts,
        )
        units.append({
            "address": url,
            "method": method,
            "bucket": m["bucket"],
            "flags": flags,
            "type": unit_type_for(url, m["bucket"]),
            "status_code": m["status"],
            "equiv_group": equiv_group_for(url),
        })
    return units


def assign_ids(units: list[dict], previous: dict[str, str]) -> list[dict]:
    """Assign stable unit_ids, preserving any id an earlier run already issued.

    Coverage ledgers key on unit_id, so re-running this tool over a superset must not
    renumber existing units — otherwise a covered cell silently becomes an uncovered one
    and the gate reports regression that did not happen.
    """
    used = set(previous.values())
    nxt = 1
    for u in sorted(units, key=lambda x: (x["address"], x["method"])):
        addr = f"{u['method']} {u['address']}"
        if addr in previous:
            u["unit_id"] = previous[addr]
            continue
        while f"u-{nxt:04d}" in used:
            nxt += 1
        u["unit_id"] = f"u-{nxt:04d}"
        used.add(u["unit_id"])
        nxt += 1
    return sorted(units, key=lambda x: x["unit_id"])


def load_previous(path: str) -> dict[str, str]:
    if not os.path.isfile(path):
        return {}
    try:
        with open(path, encoding="utf-8") as fh:
            prev = json.load(fh)
    except (json.JSONDecodeError, OSError):
        return {}
    out = {}
    for u in (prev.get("units") or []):
        if u.get("unit_id") and u.get("address"):
            out[f"{(u.get('method') or 'GET').upper()} {u['address']}"] = u["unit_id"]
    return out


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(
        description="Translate ABH classification buckets into communitytools surface/v2 flags.",
        epilog="Example: python3 tools/surface_build.py "
               "--classification runs/x/classification.json --scope runs/x/scope.json "
               "--assets-dir runs/x/assets --explain")
    ap.add_argument("--classification", required=True)
    ap.add_argument("--scope", help="scope.json; assets absent from it are skipped.")
    ap.add_argument("--assets-dir", required=True,
                    help="Root that will hold <asset_tag>/recon/inventory/surface.json.")
    ap.add_argument("--explain", action="store_true",
                    help="Print the flag mapping table and every flag decision.")
    ap.add_argument("--strict-flags", action="store_true",
                    help="Fail if a derived or mobile-only flag would be written.")
    ap.add_argument("--json", action="store_true")
    args = ap.parse_args(argv)

    try:
        with open(args.classification, encoding="utf-8") as fh:
            cls = json.load(fh)
    except (OSError, json.JSONDecodeError) as exc:
        print(f"cannot read classification: {exc}", file=sys.stderr)
        return 2
    if cls.get("schema") not in (None, CLASSIFICATION_SCHEMA):
        print(f"unexpected classification schema {cls.get('schema')!r}", file=sys.stderr)
        return 2

    scope_assets: dict[str, dict] = {}
    out_of_scope: list[str] = []
    if args.scope:
        try:
            with open(args.scope, encoding="utf-8") as fh:
                scope = json.load(fh)
        except (OSError, json.JSONDecodeError) as exc:
            print(f"cannot read scope: {exc}", file=sys.stderr)
            return 2
        for a in scope.get("assets") or []:
            scope_assets[str(a.get("value", "")).lower()] = a
        out_of_scope = [str(x).lower() for x in (scope.get("out_of_scope") or [])]

    # A recon run only counts as unauthenticated when it was told to be. Default to the
    # conservative reading: we cannot assert anonymous access we did not verify.
    unauthenticated = bool(cls.get("unauthenticated"))

    written, skipped = [], []
    for asset in cls.get("assets") or []:
        tag = asset.get("asset_tag") or ""
        if not tag:
            skipped.append(("", "asset has no asset_tag"))
            continue
        low = tag.lower()
        if any(x == low or low.endswith("." + x.lstrip("*.")) for x in out_of_scope):
            skipped.append((tag, "matches out_of_scope"))
            print(f"SKIP {tag}: matches out_of_scope", file=sys.stderr)
            continue

        notes: list[str] = []
        units = build_units(asset, unauthenticated, notes)
        if not units:
            skipped.append((tag, "no surface units after classification"))
            print(f"SKIP {tag}: produced no surface units", file=sys.stderr)
            continue

        # Guard: only agent flags may be written.
        bad: list[str] = []
        for u in units:
            for fl in list(u["flags"]):
                if fl in DERIVED_FLAGS:
                    bad.append(f"{u['address']}: derived flag {fl}")
                    del u["flags"][fl]
                elif fl in MOBILE_ONLY_FLAGS:
                    bad.append(f"{u['address']}: mobile-only flag {fl} on a web asset")
                    del u["flags"][fl]
                elif fl not in AGENT_FLAGS:
                    bad.append(f"{u['address']}: unknown flag {fl}")
                    del u["flags"][fl]
        if bad:
            for b in bad:
                print(f"WARN {b}", file=sys.stderr)
            if args.strict_flags:
                print("failing: --strict-flags set and illegal flags were produced", file=sys.stderr)
                return 1

        asset_dir = os.path.join(os.path.abspath(args.assets_dir), tag)
        inv_dir = os.path.join(asset_dir, "recon", "inventory")
        os.makedirs(inv_dir, exist_ok=True)
        out_path = os.path.join(inv_dir, "surface.json")

        previous = load_previous(out_path)
        if previous:
            notes.append(f"preserved {len(previous)} unit_id(s) from the previous surface.json")
        units = assign_ids(units, previous)

        surface = {
            "schema": SCHEMA,
            "asset_tag": tag,
            "apex": bool(asset.get("apex") is True
                         or scope_assets.get(low, {}).get("apex") is True),
            "generated_from": os.path.abspath(args.classification),
            # Asset-wide observations that are deliberately NOT per-unit flags. The
            # coordinator gets them as context; the coverage gate never scores them,
            # because scoring an asset-level fact per unit is how one integration
            # becomes twenty cells. See the consumes_upstream rule above.
            "asset_signals": {
                "tech": asset.get("tech") or [],
                "server": asset.get("server"),
                "version": asset.get("version"),
                "cloud": asset.get("buckets", {}).get("cloud") or [],
                "takeover": asset.get("buckets", {}).get("takeover") or [],
                "notes": list(asset.get("notes") or []) + notes,
                "upstream_tech_hits": sorted({
                    m.group(0).lower()
                    for m in UPSTREAM_SDK_RE.finditer(" ".join(asset.get("tech") or []))
                }),
            },
            "units": [
                {
                    "unit_id": u["unit_id"],
                    "type": u["type"],
                    "address": u["address"],
                    "method": u["method"],
                    "flags": sorted(u["flags"]),
                    "server": asset.get("server"),
                    "tech": asset.get("tech") or [],
                    "version": asset.get("version"),
                    "tls": bool(asset.get("tls") is True
                                or u["address"].startswith("https://")),
                    "equiv_group": u["equiv_group"],
                    "bucket": u["bucket"],
                    "evidence": [f"{k} <- {v}" for k, v in sorted(u["flags"].items())],
                }
                for u in units
            ],
        }
        with open(out_path, "w", encoding="utf-8") as fh:
            json.dump(surface, fh, indent=1, sort_keys=False)
            fh.write("\n")
        written.append((tag, out_path, len(units)))

        if args.explain:
            print(f"\n=== {tag} — {len(units)} unit(s) -> {out_path}")
            for u in surface["units"]:
                print(f"  {u['unit_id']} [{u['type']}] {u['method']} {u['address']}")
                for ev in u["evidence"]:
                    print(f"        {ev}")
                if not u["evidence"]:
                    print("        (no flags asserted)")
        for n in notes:
            print(f"NOTE {tag}: {n}", file=sys.stderr)

    if args.json:
        print(json.dumps({
            "assets_written": [{"asset_tag": t, "path": p, "units": n} for t, p, n in written],
            "assets_skipped": [{"asset_tag": t, "reason": r} for t, r in skipped],
        }, indent=1))
    else:
        print(f"OK: {len(written)} asset surface(s) written, {len(skipped)} skipped")
        for t, p, n in written:
            print(f"  {t}: {n} unit(s) -> {p}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
