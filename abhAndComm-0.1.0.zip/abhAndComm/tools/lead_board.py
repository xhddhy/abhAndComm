#!/usr/bin/env python3
"""The cross-asset lead board: what to work next, and what was already worked.

WHY THIS TOOL EXISTS
--------------------
`queue.json` answers "what is worth doing" and is written once per pass. It does not answer the
two questions that actually decide a bounty session:

  1. **What do I do right now?** With 85 leads across 4 assets, the next action is not obvious
     from the file, and re-reading it every session is how a high-value lead gets missed.
  2. **What did I already try?** A lead that was worked and produced nothing must be
     distinguishable from one that was never opened. That distinction is the whole reason the
     queue refuses to eliminate anything — but it is only useful if something surfaces it.

This tool is that surface. It joins the queue against each slice's `experiments.md` ledger so the
board reflects work actually done, not work planned.

OWNERSHIP, STATED PLAINLY
-------------------------
`queue.json` has two writers and this is deliberate but narrow:

  * `queue_build.py` owns the file and rewrites it wholesale on each pass;
  * `lead_board.py touch` mutates **only** `status` and `touched_by` on one row, atomically
    (temp file + rename), and appends an audit line.

`queue_build.py --prior-queue` re-reads those two fields and preserves them, which is what makes
the round trip safe. Nothing else in the bundle writes this file. If that ever changes, the
preservation rule has to change with it.

Usage:
  python3 tools/lead_board.py --run-dir runs/acme-2026-09 show
  python3 tools/lead_board.py --run-dir runs/acme-2026-09 show --asset api.acme.com
  python3 tools/lead_board.py --run-dir runs/acme-2026-09 next [--asset api.acme.com]
  python3 tools/lead_board.py --run-dir runs/acme-2026-09 touch --lead "$LEAD_ID" \
      --status investigating --experiment E-004
"""
from __future__ import annotations

import argparse
import json
import os
import re
import sys
import tempfile
from pathlib import Path

TOOL = "lead_board.py"

# The queue's own vocabulary. Repeated here so a typo is rejected at the CLI rather than
# written into the ledger.
ALLOWED_STATUSES = ("queued", "investigating", "candidate", "reported", "exhausted")
# Everything except `queued` means somebody has actually opened the lead.
STARTED = ("investigating", "candidate", "reported", "exhausted")
TERMINAL = ("reported", "exhausted")
TIER_ORDER = {"P1": 0, "P2": 1, "P3": 2}

EXPERIMENT_ROW_RE = re.compile(r"^\s*\|?\s*(E-\d+)\b")
GOAL_RE = re.compile(r"goal[_ ]?attempts?\s*[:=]?\s*(\d+)", re.I)


def load_json(path: Path) -> dict:
    with open(path, encoding="utf-8") as fh:
        return json.load(fh)


def read_ledger(asset_dir: Path) -> dict:
    """Summarise a slice's experiments.md.

    Returns the experiment count and the highest E-number seen. The ledger is the only evidence
    that an asset was actually worked, which is what separates "not looked at" from "looked at,
    empty" — so `next` weights it rather than trusting the queue's status field alone.
    """
    p = asset_dir / "experiments.md"
    if not p.is_file():
        return {"present": False, "experiments": 0, "last": None}
    count, last = 0, None
    try:
        for line in p.read_text(encoding="utf-8", errors="replace").splitlines():
            m = EXPERIMENT_ROW_RE.match(line)
            if m:
                count += 1
                last = m.group(1)
    except OSError:
        return {"present": False, "experiments": 0, "last": None}
    return {"present": True, "experiments": count, "last": last}


def load_run(run_dir: Path) -> tuple[dict, dict]:
    qpath = run_dir / "queue.json"
    if not qpath.is_file():
        raise SystemExit(f"{TOOL}: ERROR no queue.json at {qpath} — run queue_build.py first")
    queue = load_json(qpath)
    ledgers = {}
    assets_dir = run_dir / "assets"
    if assets_dir.is_dir():
        for d in sorted(assets_dir.iterdir()):
            if d.is_dir():
                ledgers[d.name] = read_ledger(d)
    return queue, ledgers


def load_unit_addresses(run_dir: Path) -> dict[str, dict[str, str]]:
    """asset_tag -> {unit_id: address}, read from each slice's surface inventory.

    Coverage-cell leads key on `unit_id` (the catalogue's scope key), which is the right
    identity for a ledger but useless on a work board — "u-0011" tells a human nothing about
    where to point a request. The address lives in surface.json, so resolve it here at the
    display layer rather than widening the queue's contract.
    """
    out: dict[str, dict[str, str]] = {}
    assets_dir = run_dir / "assets"
    if not assets_dir.is_dir():
        return out
    for d in sorted(assets_dir.iterdir()):
        sp = d / "recon" / "inventory" / "surface.json"
        if not sp.is_file():
            continue
        try:
            surf = load_json(sp)
        except (OSError, json.JSONDecodeError):
            continue
        tag = surf.get("asset_tag") or d.name
        out[tag] = {
            u["unit_id"]: (u.get("address") or u.get("unit_id"))
            for u in (surf.get("units") or []) if u.get("unit_id")
        }
    return out


def annotated(queue: dict, ledgers: dict, units: dict[str, dict[str, str]]) -> list[dict]:
    """Every lead, plus the derived facts the board needs to be actionable."""
    out = []
    for lead in queue.get("leads") or []:
        tag = lead.get("asset_tag") or "?"
        led = ledgers.get(tag) or {"present": False, "experiments": 0, "last": None}
        status = lead.get("status") or "queued"
        # "Stale" is defined by work done, not by wall-clock time: the asset has an experiments
        # ledger (so somebody started) but this P1 lead was never opened. A time-based rule would
        # need timestamps, which the artifacts deliberately do not carry — they must stay
        # byte-reproducible across a replay.
        stale = (lead.get("tier") == "P1" and status == "queued" and led["experiments"] > 0)
        addr = lead.get("address") or ""
        uid = lead.get("unit_id")
        resolved = units.get(tag, {}).get(uid) if uid else None
        out.append({
            **lead,
            "status": status,
            "address": resolved or addr,
            "address_raw": addr,
            "asset_experiments": led["experiments"],
            "asset_last_experiment": led["last"],
            "stale_p1": stale,
        })
    return out


def sort_key(lead: dict):
    """Untouched first, then by tier, then by priority. This is the work order."""
    touched = 1 if lead["status"] in STARTED else 0
    return (touched, TIER_ORDER.get(lead.get("tier") or "P3", 9),
            -(lead.get("priority") or 0), lead.get("lead_id") or "")


def cmd_show(leads: list[dict], asset: str | None, as_json: bool) -> int:
    rows = [l for l in leads if not asset or l.get("asset_tag") == asset]
    rows.sort(key=sort_key)

    if as_json:
        print(json.dumps({"leads": rows,
                          "counts": _counts(rows),
                          "stale_p1": [l["lead_id"] for l in rows if l["stale_p1"]]}, indent=1))
        return 0

    counts = _counts(rows)
    print(f"LEAD BOARD — {len(rows)} lead(s)")
    print(f"  by status: " + ", ".join(f"{k}={v}" for k, v in sorted(counts['by_status'].items())))
    print(f"  by tier:   " + ", ".join(f"{k}={v}" for k, v in sorted(counts['by_tier'].items())))
    untouched = counts["by_status"].get("queued", 0)
    print(f"  untouched: {untouched}   started: {len(rows) - untouched}")

    stale = [l for l in rows if l["stale_p1"]]
    if stale:
        print(f"\n  !! {len(stale)} P1 lead(s) never opened on an asset that HAS been worked:")
        for l in stale:
            print(f"     {l['lead_id']}  {l['asset_tag']}  {l.get('class_id') or l.get('bucket')}"
                  f"  — asset has {l['asset_experiments']} experiment(s), last {l['asset_last_experiment']}")

    current_asset = None
    for l in rows:
        if l.get("asset_tag") != current_asset:
            current_asset = l.get("asset_tag")
            led = l["asset_experiments"]
            print(f"\n  [{current_asset}]  ({led} experiment(s)"
                  f"{', last ' + str(l['asset_last_experiment']) if l['asset_last_experiment'] else ''})")
        mark = {"queued": " ", "investigating": "~", "candidate": "*",
                "reported": "+", "exhausted": "x"}.get(l["status"], "?")
        flag = " STALE" if l["stale_p1"] else ""
        name = l.get("class_id") or l.get("bucket") or "?"
        addr = l.get("address") or ""
        addr = addr if len(addr) <= 62 else addr[:59] + "…"
        print(f"    {mark} {l['lead_id']:<8} {l.get('tier') or '?':<3} {l.get('priority', 0):>3}  "
              f"{name:<22} {addr}{flag}")
    print("\n  legend: ' '=queued  '~'=investigating  '*'=candidate  '+'=reported  'x'=exhausted"
          "   (nothing is ever removed, only marked)")
    return 0


def _counts(rows: list[dict]) -> dict:
    by_status: dict[str, int] = {}
    by_tier: dict[str, int] = {}
    for l in rows:
        by_status[l["status"]] = by_status.get(l["status"], 0) + 1
        t = l.get("tier") or "?"
        by_tier[t] = by_tier.get(t, 0) + 1
    return {"by_status": by_status, "by_tier": by_tier}


def cmd_next(leads: list[dict], asset: str | None, as_json: bool) -> int:
    rows = [l for l in leads if not asset or l.get("asset_tag") == asset]
    untouched = sorted([l for l in rows if l["status"] == "queued"], key=sort_key)
    if not untouched:
        started = sorted([l for l in rows if l["status"] == "investigating"], key=sort_key)
        if not started:
            msg = {"status": "all_terminal", "lead": None,
                   "note": "every lead in scope has reached a terminal status"}
            print(json.dumps(msg, indent=1) if as_json
                  else "OK: nothing queued — every lead is reported or exhausted")
            return 0
        pick, why = started[0], "no untouched leads remain; resuming an in-progress lead"
    else:
        pick, why = untouched[0], "highest-priority untouched lead"

    if as_json:
        print(json.dumps({"status": "ok", "why": why, "lead": pick}, indent=1))
    else:
        print(f"NEXT: {pick['lead_id']}  [{pick.get('tier')}] priority {pick.get('priority')}")
        print(f"  asset   : {pick.get('asset_tag')}")
        print(f"  class   : {pick.get('class_id') or '(none — raw bucket signal)'}")
        print(f"  bucket  : {pick.get('bucket')}")
        print(f"  address : {pick.get('address')}")
        print(f"  why     : {pick.get('rationale')}")
        print(f"  chosen  : {why}")
        print(f"\n  mark it started with:\n    python3 tools/lead_board.py --run-dir <run> "
              f"touch --lead {pick['lead_id']} --status investigating --experiment E-NNN")
    return 0


def cmd_ingest(run_dir: Path, classification: str | None, cells_dir: str | None,
               catalog: str | None, prior_queue: str | None) -> int:
    """Build (or refresh) the queue, then report the board.

    WHY THIS SUB-COMMAND EXISTS
    ---------------------------
    The vendored `bb-methodology` skill documents the habit as `lead_board.py ingest <target>`,
    and that name is a better description of the operator's intent than "run queue_build and then
    run me". Upstream ABH does its own ingestion; here the ingestion work lives in
    `queue_build.py`, so this delegates to it **in-process** rather than shelling out — one
    process, one exit code, no quoting hazards, and the queue stays single-writer.

    It is a convenience wrapper, not a second implementation: everything about how leads are
    derived and scored is still `queue_build.py`'s business, and `--explain` still comes from there.
    """
    import importlib.util

    qb_path = Path(__file__).resolve().parent / "queue_build.py"
    if not qb_path.is_file():
        print(f"{TOOL}: ERROR cannot find queue_build.py next to this script", file=sys.stderr)
        return 2

    # Load by path so this works regardless of the caller's cwd and without requiring tools/ to
    # be an importable package.
    spec = importlib.util.spec_from_file_location("_bbh_queue_build", qb_path)
    if spec is None or spec.loader is None:
        print(f"{TOOL}: ERROR cannot load {qb_path}", file=sys.stderr)
        return 2
    mod = importlib.util.module_from_spec(spec)
    # Register BEFORE exec_module: queue_build.py uses @dataclass, and dataclasses resolves
    # `sys.modules[cls.__module__]` while decorating. A module loaded by spec but never
    # registered makes that lookup return None and the import dies with an AttributeError
    # that points at dataclasses rather than at the real cause.
    sys.modules[spec.name] = mod
    try:
        spec.loader.exec_module(mod)
    except BaseException:
        sys.modules.pop(spec.name, None)
        raise

    if not classification:
        guess = run_dir / "classification.json"
        if not guess.is_file():
            print(f"{TOOL}: ERROR --classification is required (no default at {guess})",
                  file=sys.stderr)
            return 2
        classification = str(guess)
    if cells_dir is None:
        candidate = run_dir / "assets"
        cells_dir = str(candidate)  # queue_build degrades loudly if it is not there yet
    if prior_queue is None:
        existing = run_dir / "queue.json"
        if existing.is_file():
            prior_queue = str(existing)

    argv = ["--classification", classification, "--cells-dir", cells_dir,
            "--out", str(run_dir / "queue.json")]
    if catalog:
        argv += ["--catalog", catalog]
    if prior_queue:
        argv += ["--prior-queue", prior_queue]
    # Auto-discover the scope so asset criticality can be scored. Without it queue_build warns
    # that every asset scores as 'unknown', which silently flattens the priority ordering —
    # easy to miss in a long log and hard to notice in the resulting numbers.
    scope_guess = run_dir / "scope.json"
    if scope_guess.is_file():
        argv += ["--scope", str(scope_guess)]

    rc = mod.main(argv)
    if rc != 0:
        return rc

    # Then show the board, so one command answers "what changed and what do I do next".
    queue, ledgers = load_run(run_dir)
    leads = annotated(queue, ledgers, load_unit_addresses(run_dir))
    print()
    cmd_show(leads, None, False)
    print(f"\n  next action:  python3 tools/lead_board.py --run-dir {run_dir} next")
    return 0


def cmd_touch(run_dir: Path, lead_id: str, status: str, experiment: str | None) -> int:
    if status not in ALLOWED_STATUSES:
        print(f"{TOOL}: ERROR unknown status {status!r}; allowed: {', '.join(ALLOWED_STATUSES)}",
              file=sys.stderr)
        return 2
    qpath = run_dir / "queue.json"
    queue = load_json(qpath)

    hit = None
    for lead in queue.get("leads") or []:
        if lead.get("lead_id") == lead_id:
            hit = lead
            break
    if hit is None:
        print(f"{TOOL}: ERROR no lead {lead_id!r} in {qpath}", file=sys.stderr)
        return 2

    before = hit.get("status") or "queued"
    hit["status"] = status
    if experiment:
        hit["touched_by"] = experiment

    # Atomic replace: a half-written queue would lose leads, and leads are the one thing this
    # bundle promises never to lose.
    fd, tmp = tempfile.mkstemp(dir=str(run_dir), prefix=".queue.", suffix=".tmp")
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as fh:
            json.dump(queue, fh, indent=1)
            fh.write("\n")
        os.replace(tmp, qpath)
    except OSError as exc:
        print(f"{TOOL}: ERROR could not write {qpath}: {exc}", file=sys.stderr)
        try:
            os.unlink(tmp)
        except OSError:
            pass
        return 2

    # Append-only audit line, so a status change is traceable after the fact.
    with open(run_dir / "leads-state.log", "a", encoding="utf-8") as fh:
        fh.write(json.dumps({"lead_id": lead_id, "from": before, "to": status,
                             "experiment": experiment}) + "\n")

    print(f"OK: {lead_id} {before} -> {status}"
          f"{' (experiment ' + experiment + ')' if experiment else ''}")
    return 0


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(
        description="Cross-asset lead board: what to work next, and what was already worked.",
        epilog="Example: python3 tools/lead_board.py --run-dir runs/acme-2026-09 show")
    ap.add_argument("--run-dir", required=True)
    ap.add_argument("--json", action="store_true")
    # `--json` is re-declared on each subparser with default=SUPPRESS so it is accepted on
    # BOTH sides of the subcommand. argparse would otherwise reject the natural
    # `lead_board.py --run-dir X next --json`, which is how everyone will type it.
    common = argparse.ArgumentParser(add_help=False)
    common.add_argument("--json", action="store_true", default=argparse.SUPPRESS)
    sub = ap.add_subparsers(dest="cmd", required=True)

    p_show = sub.add_parser("show", parents=[common],
                            help="the board, untouched first, stale P1 flagged")
    p_show.add_argument("--asset")

    p_next = sub.add_parser("next", parents=[common], help="the single lead to work now")
    p_next.add_argument("--asset")

    p_touch = sub.add_parser("touch", help="change one lead's status")
    p_touch.add_argument("--lead", required=True)
    p_touch.add_argument("--status", required=True, choices=ALLOWED_STATUSES)
    p_touch.add_argument("--experiment", help="the E-NNN that worked this lead")

    # `ingest` is the name the vendored bb-methodology skill uses for "build the lead list".
    # Here it delegates to queue_build.py in-process, then prints the board.
    p_ingest = sub.add_parser("ingest", parents=[common],
                              help="build/refresh the queue via queue_build.py, then show the board")
    p_ingest.add_argument("--classification",
                          help="default: <run>/classification.json")
    p_ingest.add_argument("--cells-dir",
                          help="default: <run>/assets (queue_build degrades loudly if absent)")
    p_ingest.add_argument("--catalog")
    p_ingest.add_argument("--prior-queue",
                          help="default: <run>/queue.json when it exists, to preserve statuses")

    args = ap.parse_args(argv)
    run_dir = Path(args.run_dir).expanduser().resolve()
    if not run_dir.is_dir():
        print(f"{TOOL}: ERROR run dir not found: {run_dir}", file=sys.stderr)
        return 2

    if args.cmd == "touch":
        return cmd_touch(run_dir, args.lead, args.status, args.experiment)
    if args.cmd == "ingest":
        return cmd_ingest(run_dir, args.classification, args.cells_dir,
                          args.catalog, args.prior_queue)

    try:
        queue, ledgers = load_run(run_dir)
    except SystemExit as exc:
        print(str(exc), file=sys.stderr)
        return 2
    leads = annotated(queue, ledgers, load_unit_addresses(run_dir))
    if args.cmd == "show":
        return cmd_show(leads, getattr(args, "asset", None), args.json)
    return cmd_next(leads, getattr(args, "asset", None), args.json)


if __name__ == "__main__":
    raise SystemExit(main())
