#!/usr/bin/env python3
"""nvd_lookup.py — one CVE's NVD truth (score/severity/CWE/description) + CISA KEV.

WHY THIS EXISTS
---------------
A finding that says "this is CVE-2024-1234, CVSS 9.8, known exploited" is making
three checkable claims about third-party data. The Stage 6 validator has to check
them without trusting the executor's copy — so this tool fetches the NVD 2.0 API
record and the CISA KEV catalogue itself and prints what the sources actually say.

Reproducibility is the other half of the job. `--cache-dir` freezes each CVE
response to `<dir>/<CVE-ID>.json` and the KEV catalogue to
`<dir>/kev-snapshot.json`. A second run with the same cache dir reads those files
and makes **zero network calls**, so a verdict built on it can be replayed
byte-for-byte months later. The output always says which path was taken
(`source` in `--json`, a `[cache ...]` / `[live fetch]` marker plus a stderr note
in human mode) — a replayed verdict must never hide that it read a snapshot.

JSON aliases the bundle's workflows consume by name: `nvd_score` (= the NVD base
score) and `kev_listed` (= KEV membership), alongside `cvss.base_score`,
`in_kev` and the full `kev` object.

Rate limits: NVD allows ~5 requests / 30 s without a key, so requests are spaced
6.5 s apart (0.7 s with `--api-key` / `$NVD_API_KEY`) — at most 5 (resp. 42) fall
inside any 30 s window. HTTP 403/429 and 5xx back off and retry a bounded number
of times and then fail loudly (exit 2) rather than returning an empty result that
a caller could mistake for "no CVSS".

Exit codes: 0 = scored record, 1 = found in NVD but no CVSS at all, 2 = malformed
id / no such record / network or module failure. Stdlib plus `requests`; if
`requests` is missing the tool prints how to install it and exits 2 — never a
silent empty answer.
"""
from __future__ import annotations

import argparse
import json
import os
import re
import sys
import time
from datetime import datetime, timezone

try:  # optional: the bundle must survive a bare `python3`
    import requests
except ImportError:  # pragma: no cover - exercised only on a bare interpreter
    requests = None  # type: ignore[assignment]

NVD_API_URL = "https://services.nvd.nist.gov/rest/json/cves/2.0"
NVD_WEB_URL = "https://nvd.nist.gov/vuln/detail"
KEV_URL = "https://www.cisa.gov/sites/default/files/feeds/known_exploited_vulnerabilities.json"
CVE_ID_RE = re.compile(r"^CVE-\d{4}-\d{4,}$")

REQUESTS_HINT = (
    "the `requests` module is not importable, so NVD/KEV cannot be queried. "
    "Install it with:  python3 -m pip install requests   (or run inside a venv that has it)"
)

#: NVD's published limits are 5 requests / 30 s unauthenticated and 50 / 30 s with
#: a key. Spacing is set so at most 5 (resp. 42) fall inside ANY 30 s window.
MIN_INTERVAL_NO_KEY = 6.5
MIN_INTERVAL_KEY = 0.7
MAX_RETRIES = 3
TIMEOUT = 30
USER_AGENT = "dsh-bbh-nvd_lookup/1.0 (+bug-bounty validation pipeline)"

_LAST_REQUEST_AT = 0.0


class InputError(Exception):
    """Malformed input: exit 2."""


# --------------------------------------------------------------------------- #
# helpers shared with the rest of the bundle's conventions
# --------------------------------------------------------------------------- #
def cache_path_for(cache_dir: str, cve_id: str) -> str | None:
    """Return the realpath-contained ``<cache_dir>/<CVE-ID>.json`` path for a
    well-formed CVE id, or None when the id must not be cached.

    A None return means "skip caching for this id": the id failed the strict
    regex, was not a bare basename, or the joined path escaped the cache dir.
    This is the only place a cache path is built, so a traversal id can never
    cause a read or write outside the directory the operator named.
    """
    if not CVE_ID_RE.match(cve_id):
        return None
    name = os.path.basename(cve_id)
    if name != cve_id:
        return None
    root = os.path.realpath(cache_dir)
    path = os.path.realpath(os.path.join(root, name + ".json"))
    if path != root and path.startswith(root + os.sep):
        return path
    return None


def severity_label(score: float | None) -> str:
    """CVSS v3/v4 severity bands (v2 has no Critical band — see severity_label_v2)."""
    if score is None:
        return "UNKNOWN"
    if score <= 0.0:
        return "NONE"
    if score < 4.0:
        return "LOW"
    if score < 7.0:
        return "MEDIUM"
    if score < 9.0:
        return "HIGH"
    return "CRITICAL"


def severity_label_v2(score: float | None) -> str:
    """CVSS v2 severity bands: LOW 0.0-3.9, MEDIUM 4.0-6.9, HIGH 7.0-10.0."""
    if score is None:
        return "UNKNOWN"
    if score <= 0.0:
        return "NONE"
    if score < 4.0:
        return "LOW"
    if score < 7.0:
        return "MEDIUM"
    return "HIGH"


def _is_success(data: object) -> bool:
    """A cacheable NVD lookup: no error and at least one vulnerability record."""
    return isinstance(data, dict) and "error" not in data and bool(data.get("vulnerabilities"))


def _throttle(api_key: str | None) -> None:
    """Space outbound NVD requests; the first request in a process never waits."""
    global _LAST_REQUEST_AT
    interval = MIN_INTERVAL_KEY if api_key else MIN_INTERVAL_NO_KEY
    now = time.monotonic()
    if _LAST_REQUEST_AT and now - _LAST_REQUEST_AT < interval:
        time.sleep(interval - (now - _LAST_REQUEST_AT))
    _LAST_REQUEST_AT = time.monotonic()


def _http_get_json(
    url: str, params: dict[str, str] | None, api_key: str | None, what: str
) -> tuple[object | None, str | None]:
    """GET JSON with throttling and bounded backoff. Returns (data, error)."""
    if requests is None:
        return None, REQUESTS_HINT
    headers = {"User-Agent": USER_AGENT, "Accept": "application/json"}
    if api_key:
        headers["apiKey"] = api_key
    last_error = f"{what}: no attempt was made"
    for attempt in range(MAX_RETRIES + 1):
        _throttle(api_key)
        try:
            response = requests.get(url, params=params, headers=headers, timeout=TIMEOUT)
        except Exception as exc:  # requests.exceptions.RequestException and friends
            last_error = f"{what} request failed: {exc}"
            if attempt < MAX_RETRIES:
                time.sleep(min(2 ** attempt * 2, 30))
                continue
            return None, last_error
        status = response.status_code
        if status == 200:
            try:
                return response.json(), None
            except ValueError:
                return None, f"{what} returned a non-JSON body (HTTP 200)"
        if status in (403, 429):
            retry_after = response.headers.get("Retry-After", "")
            delay = float(retry_after) if retry_after.isdigit() else min(2 ** attempt * 5, 30)
            last_error = (
                f"{what} rate-limited us (HTTP {status}); NVD returns 403/429 when the "
                "unauthenticated quota is exceeded — retry later or pass --api-key / set NVD_API_KEY"
            )
            if attempt < MAX_RETRIES:
                time.sleep(min(delay, 30))
                continue
            return None, last_error
        if status == 404:
            return None, f"{what} has no record for this id (HTTP 404)"
        if status >= 500:
            last_error = f"{what} returned HTTP {status} (server error)"
            if attempt < MAX_RETRIES:
                time.sleep(min(2 ** attempt * 2, 30))
                continue
            return None, last_error
        return None, f"{what} returned HTTP {status}: {response.text[:200]}"
    return None, last_error


# --------------------------------------------------------------------------- #
# NVD
# --------------------------------------------------------------------------- #
def fetch_cve(cve_id: str, api_key: str | None = None) -> dict:
    """Fetch one CVE from the NVD 2.0 API.

    Returns the raw NVD response dict, or ``{"error": "..."}``. Kept as a
    module-level seam with this exact shape so tests can stub the network.
    """
    data, error = _http_get_json(NVD_API_URL, {"cveId": cve_id}, api_key, "NVD API")
    if error or not isinstance(data, dict):
        return {"error": error or "NVD API returned an unexpected payload"}
    return data


def _primary_metric(metrics: dict, key: str) -> dict | None:
    entries = metrics.get(key)
    if not isinstance(entries, list) or not entries:
        return None
    for entry in entries:
        if isinstance(entry, dict) and str(entry.get("type", "")).lower() == "primary":
            return entry
    return entries[0] if isinstance(entries[0], dict) else None


def extract_cvss(metrics: dict) -> tuple[dict | None, str | None]:
    """Pick the CVSS metric the bundle standardises on.

    Order: v3.1, else v3.0, else v2 (exactly as the contract states). A CVE with
    only a v4.0 metric still has a score, so it is used as a clearly-noted last
    resort rather than being reported as "no CVSS".
    """
    plan = (
        ("cvssMetricV31", "3.1", False),
        ("cvssMetricV30", "3.0", False),
        ("cvssMetricV2", "2.0", True),
    )
    for key, version, is_v2 in plan:
        entry = _primary_metric(metrics, key)
        if not entry:
            continue
        data = entry.get("cvssData") or {}
        score = data.get("baseScore")
        if score is None:
            continue
        severity = data.get("baseSeverity") or entry.get("baseSeverity")
        if not severity:
            severity = severity_label_v2(score) if is_v2 else severity_label(score)
        return {
            "version": version,
            "base_score": float(score),
            "severity": str(severity).upper(),
            "vector": data.get("vectorString"),
            "source": entry.get("source"),
            "type": entry.get("type"),
            "exploitability_score": entry.get("exploitabilityScore"),
            "impact_score": entry.get("impactScore"),
        }, None

    entry = _primary_metric(metrics, "cvssMetricV40")
    if entry:
        data = entry.get("cvssData") or {}
        score = data.get("baseScore")
        if score is not None:
            return {
                "version": "4.0",
                "base_score": float(score),
                "severity": str(data.get("baseSeverity") or severity_label(score)).upper(),
                "vector": data.get("vectorString"),
                "source": entry.get("source"),
                "type": entry.get("type"),
                "exploitability_score": entry.get("exploitabilityScore"),
                "impact_score": entry.get("impactScore"),
            }, (
                "NVD publishes no v3.1/v3.0/v2 metric for this CVE; the v4.0 base score "
                "is reported instead (the bundle standardises on 3.1)"
            )
    return None, None


def extract_cwes(weaknesses: object) -> tuple[list[str], list[str]]:
    """Return (cwe_ids, other_notes) from NVD's weaknesses[] structure.

    NVD 2.0 nests the values under the SINGULAR key `description` (a list);
    some mirrors/older payloads use `descriptions`, so both are accepted — the
    upstream tool reads only `descriptions` and therefore silently returns no
    CWEs at all against the live API.
    """
    ids: list[str] = []
    notes: list[str] = []
    if not isinstance(weaknesses, list):
        return ids, notes
    for weakness in weaknesses:
        if not isinstance(weakness, dict):
            continue
        entries: list[object] = []
        for key in ("description", "descriptions"):
            value = weakness.get(key)
            if isinstance(value, list):
                entries.extend(value)
        for desc in entries:
            if not isinstance(desc, dict):
                continue
            value = str(desc.get("value", "")).strip()
            if not value:
                continue
            upper = value.upper()
            if re.match(r"^CWE-\d+$", upper):
                if upper not in ids:
                    ids.append(upper)
            elif upper not in notes:
                notes.append(value)
    return ids, notes


def _english_description(cve: dict) -> str:
    for desc in cve.get("descriptions") or []:
        if isinstance(desc, dict) and desc.get("lang") == "en":
            return str(desc.get("value", "")).strip()
    return ""


# --------------------------------------------------------------------------- #
# CISA KEV
# --------------------------------------------------------------------------- #
def _now_iso() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")


def _slim_kev_feed(feed: dict) -> dict:
    entries: dict[str, dict[str, object]] = {}
    for item in feed.get("vulnerabilities") or []:
        if not isinstance(item, dict):
            continue
        cve = str(item.get("cveID", "")).strip().upper()
        if not cve:
            continue
        entries[cve] = {
            "dateAdded": item.get("dateAdded"),
            "requiredAction": item.get("requiredAction"),
            "knownRansomwareCampaignUse": item.get("knownRansomwareCampaignUse"),
            "vendorProject": item.get("vendorProject"),
            "product": item.get("product"),
            "dueDate": item.get("dueDate"),
        }
    return {
        "_why": "frozen CISA KEV snapshot so a replayed verdict needs no network",
        "source": KEV_URL,
        "fetched_at": _now_iso(),
        "catalogVersion": feed.get("catalogVersion"),
        "dateReleased": feed.get("dateReleased"),
        "count": len(entries),
        "entries": entries,
    }


def fetch_kev(api_key: str | None = None) -> tuple[dict | None, str | None]:
    """Fetch the KEV catalogue and reduce it to the fields this tool reports."""
    feed, error = _http_get_json(KEV_URL, None, api_key, "CISA KEV feed")
    if error or not isinstance(feed, dict):
        return None, error or "CISA KEV feed returned an unexpected payload"
    return _slim_kev_feed(feed), None


def read_kev_snapshot(cache_dir: str) -> tuple[dict | None, str | None]:
    path = os.path.join(os.path.realpath(cache_dir), "kev-snapshot.json")
    if not os.path.isfile(path):
        return None, f"no KEV snapshot at {path}"
    try:
        with open(path, encoding="utf-8") as fh:
            snapshot = json.load(fh)
    except (OSError, json.JSONDecodeError) as exc:
        return None, f"cannot read KEV snapshot {path}: {exc}"
    if not isinstance(snapshot, dict) or not isinstance(snapshot.get("entries"), dict):
        return None, f"KEV snapshot {path} is not a snapshot this tool wrote"
    return snapshot, None


def write_kev_snapshot(cache_dir: str, snapshot: dict) -> str | None:
    """Write `<cache_dir>/kev-snapshot.json`; returns the path or None on failure."""
    root = os.path.realpath(cache_dir)
    path = os.path.join(root, "kev-snapshot.json")
    if not path.startswith(root + os.sep):
        return None
    try:
        os.makedirs(root, exist_ok=True)
        with open(path, "w", encoding="utf-8") as fh:
            json.dump(snapshot, fh, indent=1, sort_keys=False)
            fh.write("\n")
    except OSError as exc:
        print(f"nvd_lookup: cannot write KEV snapshot {path}: {exc}", file=sys.stderr)
        return None
    return path


def kev_entry(snapshot: dict | None, cve_id: str) -> dict | None:
    if not snapshot:
        return None
    entry = (snapshot.get("entries") or {}).get(cve_id.upper())
    return entry if isinstance(entry, dict) else None


# --------------------------------------------------------------------------- #
# rendering
# --------------------------------------------------------------------------- #
def build_result(
    cve_id: str,
    data: dict,
    source: str,
    cache_path: str | None,
    snapshot: dict | None,
    kev_source: str | None,
    notes: list[str],
) -> dict[str, object]:
    cve = (data.get("vulnerabilities") or [{}])[0].get("cve", {})
    cvss, cvss_note = extract_cvss(cve.get("metrics") or {})
    if cvss_note:
        notes.append(cvss_note)
    cwe_ids, cwe_notes = extract_cwes(cve.get("weaknesses"))
    profile = kev_entry(snapshot, cve_id)
    kev = {
        "in_kev": bool(profile),
        "dateAdded": (profile or {}).get("dateAdded"),
        "requiredAction": (profile or {}).get("requiredAction"),
        "knownRansomwareCampaignUse": (profile or {}).get("knownRansomwareCampaignUse"),
        "source": kev_source,
        "snapshot_fetched_at": (snapshot or {}).get("fetched_at"),
        "catalogVersion": (snapshot or {}).get("catalogVersion"),
    }
    if snapshot is None:
        kev["in_kev"] = None
    return {
        "cve_id": str(cve.get("id", cve_id)),
        "source": source,
        "cache_path": cache_path,
        "cvss": cvss,
        # Aliases the bundle's workflows read by name (workflows/bbh-validate.js:
        # "use the kev_listed field nvd_lookup.py returns" / cvss.nvd_score).
        "nvd_score": (cvss or {}).get("base_score"),
        "kev_listed": kev["in_kev"],
        "cwe_ids": cwe_ids,
        "cwe_notes": cwe_notes,
        "description": _english_description(cve),
        "published": cve.get("published"),
        "last_modified": cve.get("lastModified"),
        "vuln_status": cve.get("vulnStatus"),
        "nvd_url": f"{NVD_WEB_URL}/{cve_id}",
        "in_kev": kev["in_kev"],
        "kev": kev,
        "notes": notes,
    }


def render_human(result: dict[str, object]) -> str:
    cvss = result.get("cvss")
    kev = result.get("kev") or {}
    source = str(result.get("source"))
    if source == "cache":
        marker = f"[cache: {result.get('cache_path')}]"
    else:
        marker = "[live fetch: NVD API]"
    kev_bits = ""
    if kev.get("in_kev"):
        kev_bits = (
            f" kev=yes dateAdded={kev.get('dateAdded')} requiredAction={kev.get('requiredAction')!r}"
        )
    elif kev.get("in_kev") is False:
        kev_bits = " kev=no"
    else:
        kev_bits = f" kev=UNKNOWN ({'; '.join(str(n) for n in (result.get('notes') or []) if 'KEV' in str(n)) or 'no snapshot'})"
    cwes = ",".join(result.get("cwe_ids") or []) or "none"
    if not cvss:
        return (
            f"NO CVSS: {result.get('cve_id')} exists in NVD ({result.get('vuln_status')}) but no "
            f"CVSS base score is published; cwes={cwes}{kev_bits} {marker}"
        )
    assert isinstance(cvss, dict)
    vector = cvss.get("vector") or "no vector"
    return (
        f"OK: {result.get('cve_id')} {cvss.get('base_score')} {cvss.get('severity')} "
        f"{vector} cwes={cwes}{kev_bits} {marker}"
    )


# --------------------------------------------------------------------------- #
# CLI
# --------------------------------------------------------------------------- #
EXAMPLES = """\
examples:
  python3 tools/nvd_lookup.py CVE-2024-1234 --json
  python3 tools/nvd_lookup.py CVE-2024-1234 --cache-dir runs/acme/artifacts/nvd-cache --json
  #      ^ first run fetches NVD + KEV and freezes them; every later run reads the
  #        snapshot files and makes NO network call (see "source" in the JSON)
  NVD_API_KEY=xxxx python3 tools/nvd_lookup.py CVE-2024-1234
  python3 tools/nvd_lookup.py CVE-2024-1234 --cache-dir /tmp/nvd --refresh --json
"""


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="nvd_lookup.py",
        description=(
            "Look up one CVE in the NVD 2.0 API (CVSS v3.1 -> v3.0 -> v2 base score, "
            "severity, CWEs, description) and check CISA KEV membership. Exit 0 = scored, "
            "1 = in NVD but no CVSS, 2 = malformed id / no record / network or module failure."
        ),
        epilog=EXAMPLES,
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument("cve", metavar="CVE-YYYY-NNNN", help="the CVE id to look up")
    parser.add_argument("--json", action="store_true", help="emit one JSON object instead of one line")
    parser.add_argument("--cache-dir", default=None, metavar="DIR",
                        help="freeze lookups here (<DIR>/<CVE-ID>.json + <DIR>/kev-snapshot.json); "
                             "a cache hit is read with ZERO network calls")
    parser.add_argument("--api-key", default=None, metavar="KEY",
                        help="NVD API key (defaults to $NVD_API_KEY); raises the rate limit from "
                             "~5 requests/30s to ~50/30s")
    parser.add_argument("--refresh", action="store_true",
                        help="ignore an existing CVE cache file and fetch again (rewrites the cache)")
    return parser


def _emit_error(message: str, as_json: bool, cve_id: str | None) -> int:
    if as_json:
        print(json.dumps({"cve_id": cve_id, "error": message}))
    else:
        print(f"ERROR: {message}")
    print(f"nvd_lookup: {message}", file=sys.stderr)
    return 2


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)

    cve_id = args.cve.strip().upper()
    if not CVE_ID_RE.match(cve_id):
        return _emit_error(
            f"malformed CVE id {args.cve!r}: expected CVE-YYYY-NNNN (e.g. CVE-2024-1234)",
            args.json,
            cve_id or None,
        )

    api_key = args.api_key or os.environ.get("NVD_API_KEY") or None

    cache_path: str | None = None
    if args.cache_dir:
        cache_path = cache_path_for(args.cache_dir, cve_id)
        if cache_path is None:
            return _emit_error(
                f"refusing to cache {cve_id!r}: it does not resolve inside {args.cache_dir!r}",
                args.json,
                cve_id,
            )

    notes: list[str] = []
    snapshot: dict | None = None

    if cache_path and os.path.isfile(cache_path) and not args.refresh:
        try:
            with open(cache_path, encoding="utf-8") as fh:
                data = json.load(fh)
        except (OSError, json.JSONDecodeError) as exc:
            return _emit_error(f"cannot read cache file {cache_path}: {exc}", args.json, cve_id)
        if not _is_success(data):
            return _emit_error(
                f"cache file {cache_path} is not a successful NVD response; delete it and re-run",
                args.json,
                cve_id,
            )
        source = "cache"
        snapshot, snap_error = read_kev_snapshot(args.cache_dir)
        if snapshot is None:
            notes.append(f"KEV not determined: {snap_error}")
            print(
                f"nvd_lookup: cache HIT for {cve_id} — using {cache_path}; KEV snapshot "
                f"unavailable ({snap_error}) and NO network call was made because this was a replay",
                file=sys.stderr,
            )
        else:
            print(
                f"nvd_lookup: cache HIT for {cve_id} — read {cache_path} and the KEV snapshot "
                f"({snapshot.get('fetched_at')}); zero network calls",
                file=sys.stderr,
            )
    else:
        data = fetch_cve(cve_id, api_key)
        if not isinstance(data, dict) or "error" in data:
            message = str((data or {}).get("error")) if isinstance(data, dict) else "fetch failed"
            return _emit_error(message, args.json, cve_id)
        if not data.get("vulnerabilities"):
            return _emit_error(
                f"NVD has no record for {cve_id} (the API returned zero vulnerabilities) — "
                "check the id; a CVE reserved but not published yet has no NVD record",
                args.json,
                cve_id,
            )
        source = "nvd-api"
        if cache_path:
            try:
                os.makedirs(os.path.dirname(cache_path), exist_ok=True)
                with open(cache_path, "w", encoding="utf-8") as fh:
                    json.dump(data, fh, indent=1, sort_keys=False)
                    fh.write("\n")
                print(f"nvd_lookup: cached NVD response at {cache_path}", file=sys.stderr)
            except OSError as exc:
                cache_path = None
                notes.append(f"NVD response not cached: {exc}")
                print(f"nvd_lookup: could not cache the response: {exc}", file=sys.stderr)
        snapshot, kev_error = fetch_kev(api_key)
        if snapshot is None:
            notes.append(f"KEV not determined: {kev_error}")
            print(f"nvd_lookup: KEV lookup failed: {kev_error}", file=sys.stderr)
        else:
            if args.cache_dir:
                write_kev_snapshot(args.cache_dir, snapshot)
            print(
                f"nvd_lookup: live fetch from NVD ({KEV_URL.rsplit('/', 1)[-1]} "
                f"catalogVersion={snapshot.get('catalogVersion')})",
                file=sys.stderr,
            )

    result = build_result(
        cve_id,
        data,
        source,
        cache_path,
        snapshot,
        "cache" if source == "cache" else "live",
        notes,
    )

    if args.json:
        print(json.dumps(result, indent=2))
    else:
        print(render_human(result))

    if result.get("cvss") is None:
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
