# abhAndComm — 赏金猎人流水线

把 **Agentic-Bug-Hunter** 的眼睛和 **communitytools** 的账本拼成一条流水线：
ABH 的资产分类 + 攻击面排队 + 7 问 + 建链，接 comm 的分资产 coordinator、surface flags、
覆盖矩阵、盲验证保真，交付物是**你能亲手复现的**手册和 PoC 包。

自包含、可迁移。不依赖目标机上装过那两个上游包。

---

## 快速开始

```bash
# 1. 装到 DSH（默认装进 $DSH_HOME/skills）
./install.sh

# 2. 在 DSH 会话里
/bbh
```

**想看它长什么样：** [`docs/diagrams/workflow-overview.png`](docs/diagrams/workflow-overview.png)
（总览）、[`workflow-detail.png`](docs/diagrams/workflow-detail.png)（每跳的交接产物）、
[`runtime.png`](docs/diagrams/runtime.png)（一个资产内部的运行时拓扑）。

`/bbh` 是主入口，会带你走完整条线并告诉你每一步现在在哪。其他命令：

| 命令 | 干什么 |
|---|---|
| `/bbh` | **主入口**——全流程，含两个必需卡点；也是 workflow 编排层的入口 |
| `/bbh-scope` | 把平台 scope 页变成 `scope.json` |
| `/bbh-recon` | 只对**已知资产**分类（无子域枚举、无 nuclei） |
| `/bbh-surface` | 排队——**只排队，不淘汰** |
| `/bbh-slice` | 分资产切片，生成 surface flags 与覆盖矩阵单元格 |
| `/bbh-execute` | executor 批次（ABH `/hunt` 的等价物） |
| `/bbh-validate` | 保真验证闸（PoC 真跑、CVSS 重算、盲反驳） |
| `/bbh-chain` | A→B→C 建链 |
| `/bbh-seven` | 7 问闸 |
| `/bbh-repro` | 生成复现手册 + PoC 包 |

---

## 它跟两个上游有什么不同

| | 上游怎么做的 | 这里怎么做的 | 为什么 |
|---|---|---|---|
| **扩面** | ABH `/recon` 跑 subfinder/amass/nuclei | **移除**，资产只来自 scope | 你要的是给已知资产分类，不是扩面。留开关就会有人打开，然后 scope 和实际被扫的东西就不是一回事了 |
| **攻击面** | ABH `/surface` 给 P1/P2 + Kill List | **只排队，永不淘汰**。最低档 `P3` = "稍后" | 被 kill 的线索会消失，你事后无法区分"看过没东西"和"根本没看" |
| **覆盖** | comm 硬 100% 闸 | 默认 `bounty` 模式：报告全覆盖率但不设闸；`--mode strict` 回到 100% | 受雇 pentest 按广度付钱，赏金按有效漏洞付钱。永远不可能通过的闸只会被忽略 |
| **命令** | Claude Code 的 `commands/*.md` + `agents/*.md` + 命名 workflow | 全部重写成 **DSH 技能**（`user-invocable` 技能即斜杠命令）+ **内联 workflow 脚本** | DSH 不认那套扩展点。这正是原来那套装不上、装不全的根因 |
| **分类** | 桶（api-endpoints / candidates/*.txt） | 由可审计的规则表翻译成 comm 的 surface flags | 两边数据模型不通，必须有一层翻译。规则比模型可靠，因为 flag 决定要做多少活 |

完整设计理由（含一处**主动偏离上游**的说明）在 [`pipeline/README.md`](pipeline/README.md)。

---

## 人工卡点：两个必需，一个只是收尾

流水线不是全自动跑到黑。**两个必需**：

1. **分类表确认** —— recon 完，把「资产 × 漏洞类」清单摆给你，你点头才进 coordinator。
2. **手动复现** —— 7 问过了、复现手册生成了，停下。**你自己跑一遍**。

第三个（定稿）只是收尾，可以直接跳过。

**只有第 2 个是代码强制的。** `workflows/bbh-hunt.js` 不给 `args.human_confirmation` 就拒绝定稿；
但第一个是"你不去续跑"式的软停——谁带 `resume_from: "checkpoint-1"` 再调一次就直接过去了。
所以把第 1 个当成你自己守的纪律，而不是工具上的锁。对你这种半自动用法，这个性质是对的：
**真正让产出可信的是第 2 步你自己复现，不是里面的闸门。**

技术上怎么实现的（workflow 不能自己暂停，所以做成了返回信封 + `resume_from` 续跑）见
[`pipeline/README.md` 第 4 节](pipeline/README.md)。

---

## 交付物

每个通过验证 + 7 问的 finding 会得到：

```
repro/F-001/
├── RUNBOOK.md          # 环境安装 → 编号命令 → 每步预期输出 → 否定对照 → 排错
├── runbook.json        # 上面那份的源数据（可校验、可重生成）
└── F-001_pack.zip
    ├── poc/            # 可执行 PoC 脚本
    ├── evidence/       # 原始请求/响应（密钥按首4末4脱敏）
    ├── env/            # install.sh + requirements.txt
    └── verify.sh       # 非交互跑完整本手册，逐步打 PASS/FAIL
```

`RUNBOOK.md` 里每一步都带命令、预期输出、以及**失败意味着什么**。没有"同上"、"类似地"、
"对每个都重复一遍"——全部展开。

---

## 依赖

必需：**Python ≥ 3.10**。

可选（缺了会降级而不是崩，工具会明说降级了）：
- `jsonschema` —— 没有则 `schema_check.py` 退化成结构检查并大声说明
- `requests` —— 没有则 `nvd_lookup.py` 无法联网查 CVE，可用 `--cache-dir` 的冻结快照替代

executor 阶段实际打目标时才会用到外部安全工具（`httpx` / `katana` / `gau` / `ffuf` / `jq` 等）。
缺哪个会让哪个阶段降级，`MIGRATION.md` 里列了清单。

---

## 打包与迁移

**打成 zip（推荐，排除规则已经写在脚本里）：**

```bash
bash dist.sh
# -> dist/abhAndComm-0.1.0.zip   2.2 MB / 523 项
```

目标机上：

```bash
unzip abhAndComm-0.1.0.zip && cd abhAndComm && ./install.sh
```

`dist.sh` 会先跑 `context_guard.py`，**发现指令注入面就拒绝打包**——因为 `_upstream/` 里带着上游的
`AGENTS.md` / `CLAUDE.md` 和会执行命令的钩子配置，而打包脚本是最后一个可能把它们漏出去的地方。
打包后它还会**打开 zip 逐项核对**（不信任 `zip` 的退出码），断言 `_upstream/`、`.cache/`、
`__pycache__`、`runs/` 一个都没进去。

**或者 rsync 整个目录：**

```bash
rsync -av --exclude '_upstream' --exclude 'runs' --exclude '__pycache__' \
      --exclude 'docs/diagrams/.cache' \
      abhAndComm/ other-host:/path/to/abhAndComm/
ssh other-host 'cd /path/to/abhAndComm && ./install.sh'
```

完整步骤、两种安装位置的区别、以及排错顺序见 [`MIGRATION.md`](MIGRATION.md)。

### 为什么 `_upstream/` 不进包

`_upstream/` 是 37 MB 的只读构建快照，而且**它含有上游的 agent 指令文件和命令钩子配置**。
把它打进包里，等于把 `tools/context_guard.py` 存在的理由一起发出去。运行时需要的部分已经全部
vendor 到 `vendor/upstream-skills/`（20 个技能）和 `vendor/upstream-commands/abh/`（6 个命令文件）。
需要重新同步上游时，在**源**机器上跑 `tools/sync-upstream.sh`。

---

## 目录

```
skills/bbh-*/            10 个技能（斜杠命令层）
workflows/               3 个 DSH 内联 workflow 脚本 + 说明
contracts/               9 份 JSON Schema + README（阶段接口）
tools/                   14 个工具 + 冻结的 CLI 契约（tools/README.md）
catalog/                 赏金向覆盖矩阵类目（24 类）
vendor/                  自带上游技能（20）+ ABH 命令（6）+ MANIFEST
pipeline/                设计与决策文档 ← 先读这个
examples/run-demo.sh     端到端干跑（39 项断言）
```

---

## 自检

不依赖真实目标，随时可跑：

```bash
./examples/run-demo.sh              # 端到端干跑：造一个合成 recon 树跑完全流程，39 项断言
bash tools/workflow_lint.sh         # workflow 语法（按 harness 包裹方式校验，node --check 会误报）
python3 tools/context_guard.py      # 本包是否会被当成 agent 指令 / 执行钩子
python3 tools/schema_check.py --list-kinds
```

`run-demo.sh` 会造一个形状与 ABH recon 输出一致的合成目标，依次跑 scope → 分类 → 翻译 → 单元格
→ 排队 → 切片 → 覆盖闸 → 面板 → 复现包，并在每一步断言关键不变量（覆盖闸必须拒绝伪造的 N/A、
队列必须零淘汰、线索状态必须跨重建保留、复现手册必须可跟做、zip 必须含 poc/evidence/env/verify.sh）。
它不联网、不碰真实目标。

---

## 工作区指令注入：本包会主动拒绝安装的一种情况

DSH 把 project root → 工作目录之间的 `AGENTS.md` / `CLAUDE.md`（含 `.local.md` 叠加层）当作
**agent 指令**加载。把任何第三方仓库 clone 进工作区，就继承了它里面这些文件说的所有话。

构建本包的过程中这事**真实发生过两次**：一个测试夹具 `CLAUDE.local.md`（内容就一个词 `poison`）
被从 `_upstream/` 加载进了运行中 agent 的上下文；随后一次 `git reset --hard` 又把删掉的上游
`AGENTS.md`/`CLAUDE.md` 恢复并再次注入。

所以 `tools/context_guard.py` 会检测四类被"解释"而不仅仅被"读取"的文件——指令文件、
**会执行命令的钩子配置**、会遮蔽真技能的嵌套技能根、以及 `find -type f` 看不见的断链。
它在这个 bundle 里抓到过 **11 个手工清理漏掉的真问题**，包括上游 ABH 的
`.claude/settings.json` 和 `hooks/hooks.json`（两个都真的定义了命令钩子）。

`install.sh` 把它当**硬前置**：发现 blocking 就拒绝安装。详见
[`pipeline/README.md` 第 8 节](pipeline/README.md)。

---

## 边界

- 只测 `scope.json` 里声明的东西。第三方 CNAME、staging、dev 一律判 **unclear** 而不是放行。
- 不自动提交到任何平台。
- 不做子域枚举、不做 nuclei、不做密码喷洒、不做破坏性操作。
- 每个 finding 都要有判决才算完——测试不是在你停手时结束。

---

## 来源

- [Awarexone/Agentic-Bug-Hunter](https://github.com/Awarexone/Agentic-Bug-Hunter) —— 分类、攻击面、7 问、建链
- [transilienceai/communitytools](https://github.com/transilienceai/communitytools) —— 角色契约、surface flags、覆盖矩阵、保真验证

两个上游的 git revision 记在 `VERSION` 里。`tools/sync-upstream.sh --check` 能看上游有没有动。
