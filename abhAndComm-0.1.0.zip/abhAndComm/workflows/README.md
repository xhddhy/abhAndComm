# workflows/ — the DSH workflow scripts

Three plain-JavaScript **workflow bodies** plus this file. They are the executable
half of the bundle: `tools/` is the frozen CLI contract, `contracts/` is the
artifact contract, and these scripts are the conductor that threads one into the
other through subagents.

| File | Role | Default budget |
|---|---|---|
| `bbh-hunt.js` | The pipeline conductor. Scope → recon-lite → **CP1** → surface queue → slice → per-asset coordinator fan-out → **CP2** → **CP3** → finalize. | 30 experiments/asset, 3 cure cycles |
| `bbh-coordinator.js` | One asset, one coordinator. The bounded think/execute/integrate/validate loop, the cure loop, the chain stage, the 7-Question Gate, the repro pack. | 30 experiments, 3 cure cycles, 3 refuters |
| `bbh-validate.js` | The standalone fidelity engine. Drives each candidate to a terminal verdict on disk. Re-runnable over any asset dir; idempotent with the verdicts the coordinator already wrote. | 3 refuters, 50 findings |

---

## 1. Calling a workflow

A DSH workflow call takes **`meta`** (JSON identity), **`script`** (the file's
*contents*, not its path), and **`args`**. Nothing else. There is no `import` and
no `require` inside a workflow body, so the caller reads the file and inlines it:

```jsonc
// the `workflow` tool call
{
  "meta": {
    "name": "bbh-hunt",
    "description": "Bug-bounty pipeline: scope -> recon-lite -> CP1 -> queue -> slice -> per-asset coordinators -> CP2 -> CP3",
    "whenToUse": "Start or resume a bounty engagement against a scope file.",
    "phases": [
      { "title": "Scope",       "detail": "resolve + validate scope, create the run tree" },
      { "title": "Recon",       "detail": "recon-lite on KNOWN assets only (no subdomain enum, no nuclei) + classify" },
      { "title": "Checkpoint 1","detail": "asset x vulnerability-class table, human confirms" },
      { "title": "Surface",     "detail": "queue every signal; eliminate nothing" },
      { "title": "Slice",       "detail": "surface flags + code-produced cells + per-asset work orders" },
      { "title": "Fanout",      "detail": "one coordinator per asset (the fork)" },
      { "title": "Checkpoint 2","detail": "build runbooks, hand over, WAIT for manual reproduction" },
      { "title": "Checkpoint 3","detail": "record the human's reproduction result" },
      { "title": "Finalize",    "detail": "freeze coverage, update the lead board, write run-summary.json" }
    ]
  },
  "script": "<verbatim contents of workflows/bbh-hunt.js>",
  "args": {
    "scope_file": "runs/acme-2026-09/scope.json",
    "run_dir": "runs/acme-2026-09",
    "max_experiments": 30,
    "max_cure_cycles": 3,
    "parallel_assets": 3,
    "only_assets": ["api.acme.com"],
    "dry_run": false
  }
}
```

`meta.phases` is presentation only — but **keep the titles exactly as listed
below**, because each script calls `phase()` with those strings and a mismatch
makes the progress view lie about where the run is.

```js
// bbh-hunt.js
['Scope', 'Recon', 'Checkpoint 1', 'Surface', 'Slice', 'Fanout', 'Checkpoint 2', 'Checkpoint 3', 'Finalize']
// bbh-coordinator.js
['Bootstrap', 'Loop', 'Validate', 'Chain', 'Gate', 'Repro', 'Report']
// bbh-validate.js
['Discover', 'Validate', 'Persist', 'Report']
```

The coordinator is launched from inside the fan-out the same way — see §4.

---

## 2. `bbh-hunt.js` — the pipeline conductor

### What it does

```
SCOPE -> RECON-LITE (known assets only, NO subdomain enum, NO nuclei)
      -> [CHECKPOINT 1]  asset x vulnerability-class table
      -> SURFACE         queue_build.py: queues everything, eliminates nothing
      -> SLICE           surface_build.py + cells_build.py + slice_build.py
      -> FANOUT          one coordinator per asset (this is the "fork session")
           -> executor batch (1-2)
           -> validate-findings (blind, fidelity)
                -> not pass -> cure (named gaps) -> re-validate
                -> pass -> chain (A->B->C) -> 7-Question Gate
                     -> fail -> cure -> back to validate
                     -> pass -> repro pack
      -> [CHECKPOINT 2]  hand over the runbook, WAIT for manual reproduction
      -> [CHECKPOINT 3]  human confirms
      -> FINALIZE
```

Every stage boundary runs `python3 tools/schema_check.py --kind all --run-dir <RUN_DIR>`.
Every CLI call is a frozen command from `tools/README.md` — the workflow never
invents a flag.

### `args`

| arg | type | default | meaning |
|---|---|---|---|
| `scope_file` | string | — | Path to an existing `bbh/scope/v1` JSON. Mutually exclusive with `scope`. |
| `scope` | object | — | An inline scope object; stage 0 materialises it with `bbh_scope.py init`. |
| `run_dir` | string | derived | The run tree. **Required on every resume.** |
| `resume_from` | string | — | See the resume table in §5. |
| `human_confirmation` | string \| true | — | The human's answer text at a checkpoint. Required to leave CHECKPOINT 3. |
| `max_experiments` | integer | `30` | Per-asset experiment budget handed to each coordinator. |
| `max_cure_cycles` | integer | `3` | Per-finding cure-loop bound handed to each coordinator. |
| `parallel_assets` | integer | `3` | How many coordinators run concurrently. Also the recon fan-out width. |
| `only_assets` | string[] \| csv string | — | Work only these asset tags. Nothing is deleted; the others are simply not worked by this invocation. |
| `votes` | integer | `3` | Adversarial refuter quorum handed to each coordinator. |
| `nvd_cache_dir` | string | `<RUN_DIR>/artifacts/nvd-cache` | Frozen NVD snapshot — what makes a replayed verdict reproducible. |
| `kev_snapshot` | string | — | Frozen CISA KEV JSON path. |
| `dry_run` | boolean | `false` | Return the stage/tool/agent graph and spawn **zero** agents. |

### What it returns

| `status` | When | Shape |
|---|---|---|
| `CHECKPOINT_1` | after recon-lite | `{run_dir, scope_file, assets, artifacts{scope, recon_root, recon_dirs, classification, checkpoint_table}, table_markdown, rows[], skipped[], question, what_happens_next, resume{...}, checkpoints[], notes[]}` |
| `CHECKPOINT_2` | after the fan-out and the repro packs | `{run_dir, artifacts{handover, runbooks[], refused_packs[], coverage_matrix, lead_board, queue, classification}, assets[], question, what_happens_next, resume{...}, checkpoints[], notes[]}` |
| `CHECKPOINT_3` | resumed at `checkpoint-2` **without** `human_confirmation` | `{run_dir, question, expected_answer_shape, resume{...}}` |
| `COMPLETE` | finalized | `{run_dir, engagement, assets[], findings[], confirmed, rejected, dropped, coverage{...}, artifacts{run_summary, coverage_report, coverage_matrix, confirmation_record, handover, queue, classification, scope, slices_dir, repro_dir}, human_confirmation, checkpoints[], notes[]}` |
| `BLOCKED` | a stage could not complete | `{status:'BLOCKED', stage, run_dir, reason, checkpoints, notes}` |
| `DRY_RUN` | `dry_run:true` | `{stages[], options, next}` |

### Run-directory layout it creates and owns

```
<RUN_DIR>/
  scope.json  classification.json  queue.json  checkpoint-1.md
  recon/<asset_tag>/…                     # the ABH recon tree bbh_classify.py reads
  assets/<asset_tag>/
    recon/inventory/surface.json          # surface/v2, agent flags + evidence
    applicability/cells.json              # CODE-produced, un-fabricatable
    coverage.json                         # per-cell ledger, INTEGRATE-owned
    attack-chain.md  session-memory.md  experiments.md
    findings/finding-NNN/                 # finding.json, description.md, poc/, evidence/
    artifacts/{validated,false-positives,dropped,cure}/F-NNN.json
    seven-questions/F-NNN.json   chains/F-NNN.md   reports/{coverage-matrix.json,asset-report.md}
  slices/<asset_tag>.json                 # the self-contained work order
  repro/<finding_id>/{RUNBOOK.md,pack/,*.zip}
  reports/{handover.md,coverage-matrix.json,run-summary.json,checkpoint-3-confirmation.md,…}
  artifacts/nvd-cache/                    # frozen CVE operands
```

---

## 3. `bbh-coordinator.js` — one asset, one coordinator

A rewrite of the upstream `.claude/workflows/coordinator-loop.js` for bounty
semantics. The upstream **structure and discipline** are preserved verbatim; the
platform assumptions are not.

### The three-file state contract

The script holds no state. The engagement memory lives in three files under the
slice's `output_dir`, re-read and rewritten every batch:

| File | Discipline |
|---|---|
| `attack-chain.md` | Working theory. **Rewritten** (not appended) every batch. **Hard cap 50 lines.** Sections: Services / Surface / **Theory (this batch)** / Tested / Next. |
| `session-memory.md` | Durable memory, **append-only**. Access & Credentials / Confirmed Facts / **Dead Ends (+WHY)** / Open Threads / Pivot History / Creative Leads. |
| `experiments.md` | Append-only ledger, `E-NNN` rows: `ID \| Batch \| Goal \| Technique \| Target \| Hypothesis \| Result \| Goal_attempts \| Notes`. Never rewritten, never pruned. |

**The INTEGRATE agent is the SOLE writer of all three** (and of `coverage.json`).
That is the deliberate adaptation of the upstream "each executor updates its own
row" rule: it is what makes 1–2 concurrent executors per batch race-free.

Token discipline is enforced in the prompts: `attack-chain.md` ≤ 50 lines, and
all bookkeeping (chain + memory + ledger + `tools/` logs) ≤ 10% of mission tokens.

### Preserved upstream disciplines (the reason this design works)

- **Think before every batch**: exactly 3 hypotheses, **≥1 tagged `[wildcard]`**, the two unchosen ones kept as backlog, written to `attack-chain.md`.
- **1–2 executors per batch.** A batch is think → (research) → execute → integrate → (skeptic).
- **Interleaved validation**: every candidate is driven to a terminal verdict the instant INTEGRATE materialises it, **before the next batch** — never one downstream pass.
- **Blind validator contract**: the validator receives `finding_id`, `FINDING_DIR`, `TARGET_URL`, `OUTPUT_DIR` and the frozen NVD/KEV operands — and is explicitly forbidden `attack-chain.md`, `session-memory.md`, other findings, mission logs, and any prior verdict. A **FRESH** validator is spawned every cure round.
- **Cure executor contract**: receives **ONLY** `failed_checks` + `missing_evidence` + `FINDING_DIR`, and is forbidden to re-theorize, to change the claim, or to expand scope. A **FRESH** validator re-checks it.
- **The cure loop**: `CURE → cure executor → fresh blind re-validation`, bounded by `max_cure_cycles` (default 3). A CURE that survives the bound is rewritten to `DROPPED` by a mechanical demoter, so the loop can never spin.
- **Coverage-by-VALID**: a cell is `covered` only by a VALID finding in `artifacts/validated/`, a corroborated negative (non-agent corroborator), or a justified N/A/deferral. A cell whose candidates were all REJECTED or DROPPED **stays pending and search continues**. The gate is run in both `--mode bounty` (default) and `--mode strict` — see §8.8.
- **Skeptic** mandatory at experiments 5, 15, 25, then every 25. Blind to `attack-chain.md` on purpose.
- **Bounded** by `max_experiments` (default 30) and by the gate. "I ran out of hypotheses" is never completion while a cell is pending.
- Every agent writes only inside its own `output_dir`.

### `args`

| arg | type | default | meaning |
|---|---|---|---|
| `slice_file` | string | — | Absolute path to `bbh/slice/v1`. The coordinator takes `output_dir` from it. |
| `run_dir` | string | derived | `<run>/assets/<tag>` → `<run>`. |
| `output_dir` | string | slice's | Override only if you know why. Must be absolute. |
| `max_experiments` | integer | `30` | Loop budget. Batches are also capped at this. |
| `max_cure_cycles` | integer | `3` | Cure rounds per finding before DROPPED. |
| `votes` | integer | `3` | Blind refuters per validation; confirmation requires **all** to fail to refute. |
| `nvd_cache_dir` | string | `<RUN_DIR>/artifacts/nvd-cache` | Frozen NVD snapshot. |
| `kev_snapshot` | string | — | Frozen CISA KEV JSON. |
| `parallel_inline_validate` | boolean | `false` | Validate a batch's candidates concurrently. Off by default so quorum storms can't exhaust the agent budget. |
| `dry_run` | boolean | `false` | Return the loop graph, spawn nothing. |

### What it returns

```js
{
  status,                 // COVERAGE_COMPLETE | INCOMPLETE_RESUMABLE | INCOMPLETE_COVERAGE | BLOCKED | DRY_RUN
  asset_tag, asset_id, output_dir, run_dir,
  experiments_run, batches, stop_reason,
  findings: [{finding_id, class_id, cell_key, covers_cells, title, verdict, cure_cycles,
              verdict_path, seven_q_verdict, seven_q_path, chain_used, repro_dir}],
  confirmed: [...ids], rejected: [...ids], dropped: [...ids],
  gated_pass: [...ids], gated_kill: [{finding_id, killed_by, kill_reason}],
  chains: [{finding_id, chain_path, hops[], max_impact_proven, new_candidates[]}],
  repro_packs: [{finding_id, runbook_path, pack_dir, zip_path}], repro_refused: [...],
  coverage: {applicable, covered, pending, ratio, complete, gate_exit, open_cells[]},
  skeptic_briefs: [...], report_path, coverage_matrix, experiments_ledger, state_files[],
  checkpoints: [{id, kind, ...}],   // ASSET_LOOP, SKEPTIC_5/15/25, CHAIN, SEVEN_QUESTION_GATE, REPRO
  blocks: [...], notes: [...]
}
```

`INCOMPLETE_RESUMABLE` means the budget ran out with cells still open — re-invoke
and the resume-ingest step reads `experiments.md`, the existing verdicts and the
gate baseline off disk so nothing is redone. `INCOMPLETE_COVERAGE` means it
stopped stuck with budget remaining: a genuine gap, and the report names it.

---

## 4. The fan-out: how `bbh-hunt.js` launches `bbh-coordinator.js`

A DSH workflow body has no way to invoke another workflow, so `bbh-hunt.js`
spawns **one coordinator agent per asset** and that agent launches the engine:

1. The fan-out agent reads `workflows/bbh-coordinator.js`.
2. It calls the `workflow` tool with `meta` + `script` = that file's contents +
   `args = {slice_file, run_dir, max_experiments, max_cure_cycles, votes, nvd_cache_dir?, kev_snapshot?}`.
3. **If the nested call is refused**, the agent executes the same contract inline
   in its own session — the prompt spells the contract out in full, so nothing is
   lost. This fallback exists because nested-workflow support is a runtime
   property, not something a script can assume.
4. Either way the agent verifies what happened on disk (`ls` the three state
   files, `grep -c '^| E-' experiments.md`, run `coverage_gate.py --asset-dir`)
   before returning a schema-validated summary.

One asset, one coordinator, one private `output_dir`. No coordinator may read or
write another asset's tree.

---

## 5. The checkpoint protocol

A workflow script **cannot pause**. "Waiting for a human" is therefore implemented
as a **return value**: the script returns a checkpoint envelope and stops, and the
calling session asks the user. A later invocation with `resume_from` + the same
`run_dir` continues from the next stage, reading all state from disk.

### Resume tokens

`resume_from` names the **last completed milestone**; execution starts at the stage
*after* it. A bare stage name resumes *at* that stage.

| `resume_from` | Resumes at | Use when |
|---|---|---|
| *(absent)* | `scope` | Fresh run. |
| `scope` | `recon` | Scope exists and is approved. |
| `recon` | `checkpoint-1` | Re-emit the CP1 table without re-crawling. |
| **`checkpoint-1`** | `surface` | **The human approved the asset × class table.** |
| `surface` | `slice` | Queue built; re-slice. |
| `slice` | `fanout` | Slices exist; start/continue coordinators. |
| `fanout` | `checkpoint-2` | Coordinators done; rebuild the handover + packs. |
| **`checkpoint-2`** | `checkpoint-3` | **The human has run the runbook(s).** |
| `checkpoint-3` | `finalize` | Skip the confirmation question. |
| `finalize` | `finalize` | Re-run closeout only. |

Aliases accepted: `cp1`/`cp2`/`cp3`/`one`/`two`/`three`, `queue`→`surface`,
`slices`→`slice`, `coordinator`/`hunt`→`fanout`, `report`/`done`→`finalize`.

### The three checkpoints

**CHECKPOINT 1 — approve the classification.** The workflow returns
`{status:'CHECKPOINT_1', table_markdown, rows[], question, resume:{resume_from:'checkpoint-1', run_dir}}`.
Ask the user the `question`. There is nothing to type back except approval: the
next stage **eliminates nothing**, so "drop asset X" is expressed as
`args.only_assets` on the resume call, not as a queue edit.

```
workflow { meta:<bbh-hunt meta>, script:<contents>, args:{
  resume_from: 'checkpoint-1',
  run_dir: 'runs/acme-2026-09',
  scope_file: 'runs/acme-2026-09/scope.json',
  only_assets: ['api.acme.com'],          // optional
  human_confirmation: 'approved as shown; prioritise API1-BOLA'   // optional, recorded
}}
```

**CHECKPOINT 2 — reproduce by hand.** The workflow builds one `repro_pack.py`
runbook per finding that is CONFIRMED at the fidelity gate *and* PASS at the
7-Question Gate (the packer itself refuses anything else), writes
`reports/handover.md`, and returns
`{status:'CHECKPOINT_2', artifacts.runbooks[], question, resume:{resume_from:'checkpoint-2', ...}}`.
The human follows each `RUNBOOK.md` on a clean box.

**CHECKPOINT 3 — confirm, then finalize.** Re-invoking with `resume_from:'checkpoint-2'`
and **no** `human_confirmation` returns `{status:'CHECKPOINT_3', question, expected_answer_shape}`.
That refusal is deliberate: nothing is promoted on the workflow's own authority.
Supplying the answer finalizes:

```
workflow { meta:<bbh-hunt meta>, script:<contents>, args:{
  resume_from: 'checkpoint-2',
  run_dir: 'runs/acme-2026-09',
  human_confirmation: 'F-001: reproduced exactly; F-002: diverged at step 4 — step 4 returned 403, not the victim body'
}}
```

Finalize writes `reports/checkpoint-3-confirmation.md`, marks **only** the
reproduced findings' leads `reported` via `lead_board.py touch`, re-runs the
coverage gate and `schema_check --kind all`, and writes
`reports/run-summary.json`. A diverged runbook is recorded as diverged and **not
promoted**, even though its stage-6 verdict says CONFIRMED.

### Checkpoint definitions live on disk, not in the envelope

`checkpoint-1.md`, `reports/handover.md`, `reports/checkpoint-3-confirmation.md`,
`reports/run-summary.json`, and every per-asset `reports/asset-report.md` are
written by agents. If a session dies, the next invocation reconstructs its view
from those files — which is exactly why a resume only needs `run_dir`.

---

## 6. `bbh-validate.js` — the fidelity engine

Rewritten from the upstream `.claude/workflows/validate-findings.js`. Per finding,
**in this order**:

1. **Scope re-check** — `tools/bbh_scope.py check`. Exit 1 (out of scope) or 2 (unclear) ⇒ `DROPPED`, never `CONFIRMED`.
2. **PoC truth** — `poc.cmd` is **actually run**. Missing/broken scripts are **repaired** (standalone, argparse, `[*]/[+]/[-]/[!]`, exit 0/1/2, read-only) and re-run; a repaired-and-passing PoC still confirms. Requires **≥3 deterministic runs** after normalising timestamps/UUIDs/tokens/nonces/ports, and the `negative_control` **must not print the success token**.
3. **Evidence completeness** — every path in `evidence.artifacts[]` is stat'd; one missing or zero-byte path fails the check and its exact path lands in `missing_evidence[]`.
4. **Cross-identity proof** — for IDOR/BOLA/ATO/privesc: actor reaches victim data, a **fresh** actor session still reproduces, anonymous differs; artifact `evidence/validation/two-identity-comparison.txt`.
5. **CVSS truth** — `tools/cvss_recompute.py` recomputes from the vector; a vector/band mismatch is a **failed check**, not a rounding note.
6. **CVE truth** — when a CVE is claimed, `tools/nvd_lookup.py --json --cache-dir <frozen>`; NVD + KEV + advisory must agree with the claim and with the recomputation.
7. **Adversarial quorum** — 3 independent, **evidence-only, blind** refuters. Confirmation requires **ALL** to fail to refute. One substantiated refutation ⇒ `REJECTED`.

The verdict is authored by the **checks lane** (the only agent that sees the whole
picture); the refuters never see its reasoning, and it never sees their arguments
before writing. `computeVerdict()` in JS — not an agent — decides the terminal
routing, so the destination directory is never an agent's choice.

### `args`

| arg | type | default | meaning |
|---|---|---|---|
| `asset_dir` | string | — | `<RUN_DIR>/assets/<asset_tag>`. Required. |
| `run_dir` | string | derived (`asset_dir/../..`) | For the scope file and the NVD cache. |
| `findings` | string[] \| csv | all | Validate exactly these ids, even if they already have a terminal verdict. |
| `repair` | boolean | `true` | Allow PoC repair. `false` = never modify a PoC; a broken PoC fails. |
| `votes` | integer | `3` | Blind refuter quorum. |
| `max_findings` | integer | `50` | Deep-validate at most this many. The rest are reported as **pending**, never silently dropped. |
| `nvd_cache_dir` | string | `<RUN_DIR>/artifacts/nvd-cache` | Frozen NVD snapshot. |
| `kev_snapshot` | string | — | Frozen CISA KEV JSON. |
| `dry_run` | boolean | `false` | Inventory only; no validation agents. |

### What it returns

```js
{
  status,   // CONFIRMED | NO_CONFIRMED_FINDINGS | CURE_REQUIRED | PARTIAL_INFRA_FAILURE | NO_FINDINGS | BLOCKED | DRY_RUN
  asset_tag, asset_dir, run_dir, scope_ref,
  counts: {total, confirmed, rejected, cure, dropped, infra},
  votes_per_finding, repair_enabled,
  findings: [{finding_id, class_id, cell_key, covers_cells, title, verdict, severity_claimed,
              cvss{vector,claim_score,recomputed_score,recomputed_band,nvd_score,kev_listed},
              failed_checks[], missing_evidence[], refuters{count,refuted,refutation_args[]},
              cure_cycles, reason, verdict_path}],
  confirmed[], rejected[], cure[], dropped[],
  pending: {over_cap, already_terminal[], unvalidated[]},
  report_path, coverage_join, notes[], disk_disagreements[], blocked_reason
}
```

`PARTIAL_INFRA_FAILURE` means at least one checks lane returned null. That is an
infrastructure failure and is **never** promoted to CONFIRMED — a missing
validator is not a pass.

### Verdict routing and re-runs

| verdict | written to |
|---|---|
| `CONFIRMED` | `artifacts/validated/<id>.json` |
| `REJECTED` | `artifacts/false-positives/<id>.json` |
| `DROPPED` | `artifacts/dropped/<id>.json` |
| `CURE` | `artifacts/cure/<id>.json` — **interim** (see "Deviations" below) |

Every file is verified with `python3 tools/schema_check.py --kind verdict <file>`,
and the writer deletes any stale verdict for the same id in the other directories
so one finding has exactly one live verdict. A re-run skips findings that already
have a terminal verdict; pass `args.findings: ['F-001']` (or delete the verdict
file) to force a re-validation. This makes the engine idempotent with the verdicts
`bbh-coordinator.js` writes inline, and safe to schedule from a cron sweep.

---

## 7. Why the coordinator must NOT run inline in the main session

This is a hard architectural boundary, not a style preference. Running the
coordinator loop in the parent session breaks four things at once:

1. **The state has to live in files, not in a context.** A 30-experiment hunt
   across several assets cannot fit one agent's context. The three-file contract
   (`attack-chain.md` ≤50 lines, append-only `session-memory.md`, append-only
   `experiments.md`) is what lets every think/execute/integrate/validate step be a
   fresh, cheap context that loads exactly what its role permits. A parent that
   "just does the loop itself" has to hold the whole ledger, and the 50-line cap
   and the 10% bookkeeping budget stop meaning anything.

2. **The blind-validator boundary becomes impossible.** Once the parent has
   reasoned about the finding, it cannot un-know it. The validator must receive
   `finding_id`, `FINDING_DIR`, `TARGET_URL`, `OUTPUT_DIR` and the frozen operands
   and **nothing else** — no theory, no other findings, no executor logs — and it
   must be **freshly respawned every cure round**. A parent that both theorises and
   validates produces agreement, not evidence.

3. **`Goal_attempts` and the skeptic stop working.** The reset rule (three failed
   attempts on one *conceptual* goal ⇒ abandon the theory) depends on a
   disinterested ledger, and the mandatory skeptic at experiments 5/15/25 is only
   worth spawning because it is **blind to `attack-chain.md`**. Both are defeated
   if the same context writes the ledger *and* is the thing being audited.

4. **The cure executor would inherit the theory.** Its contract is to close
   **only** the named `failed_checks`/`missing_evidence` and never re-theorize or
   expand scope. Handed to a parent that already has the theory, it will "improve"
   the finding instead of closing the gap — and the next validator's independence
   is gone with it.

Concretely: **one asset, one coordinator, one private `output_dir`.** The parent
session's job is to call the workflow, ask the human at the checkpoints, and
thread `resume_from`/`run_dir` back in. Nothing else.

---

## 8. Deviations from the upstream design (and why)

These are the places where the DSH contract or the bounty semantics forced a
change. None of them weakens a validation property.

| # | Deviation | Why |
|---|---|---|
| 1 | **`export const meta` removed**; the file is a plain JS body ending in `return`. | DSH takes `meta` as a tool-call parameter. Identity is supplied by the caller (§1). |
| 2 | **No nested-workflow call.** The fan-out agent launches `bbh-coordinator.js` through the `workflow` tool, and falls back to executing the contract inline if that is refused. | A workflow body has no `import`, and nested-workflow support is a runtime property. The fallback keeps 100% of the contract either way, and the agent must verify on disk before returning. |
| 3 | **`agentType` dropped** from every spawn. | Not an option DSH accepts; unknown options kill the script. `{label, phase, schema}` only. |
| 4 | **Numeric `minItems`/`minLength`/`pattern`/`format` removed** from all schemas; `type` is always a single type string (never an array), and `blocked_reason` is a string where `''` means "no block". | The DSH enforced schema subset rejects type arrays and unknown keywords, and a rejected schema **throws and kills the script**. Verified against the real `assertObjectJsonSchema`. |
| 5 | **`attack-chain.md` cap enforced by prompt + reported line count**, not by code. | The script has no filesystem. The THINK prompt requires `wc -l` and a prune when over 50; the run returns the count and warns when it is exceeded. |
| 6 | **Queue is built twice** (once before SLICE, once after). | The design says queue → slice, but `queue_build.py --cells-dir` can only emit coverage-cell leads once `cells.json` exists. `queue_build.py` is idempotent and preserves lead status, so the second run folds the cell leads in without losing anything. Both `--explain` outputs are kept. |
| 7 | **A classification merge step** between the per-target `bbh_classify.py` runs and `classification.json`. | `bbh_classify.py` is single-target (`--recon-dir recon/<target>`), but `classification.json` is one `bbh/classification/v1` document. The merge agent only unions; it is forbidden to drop or re-key a bucket entry. With one target it is a copy. |
| 8 | **`coverage_gate.py` exit 1 is the expected SLICE-stage result**, not a failure — and **the gate is run in both of its modes**. | Nothing has been worked at slice time, so the gate cannot pass. It writes `reports/coverage-matrix.json` either way, and that file is the pre-work baseline the fan-out is measured against. The real CLI has `--mode bounty` (the default: gates on worked P1 leads plus validated findings) and `--mode strict` (100% of applicable cells). The prompts run **both** and report both exit codes: `--mode strict` is treated as the completion obligation, because that is the no-soft-bar rule stated in `tools/README.md`, while `bounty` is reported as the lead-level view. Exit 2 (unreadable inputs) *is* a blocker in either mode. |
| 9 | **CURE verdicts are written to `artifacts/cure/<id>.json`**, not to one of the three terminal directories. | `validation-verdict.schema.json` routes CONFIRMED→`validated/`, REJECTED→`false-positives/`, DROPPED→`dropped/` and describes CURE as "back to the executor with the named gaps" — it is not terminal. Putting a CURE file in `dropped/` would mislabel it, and `coverage_gate.py` reads `dropped/` as a terminal non-covered outcome. Keeping it in `artifacts/cure/` means the gate correctly sees no terminal verdict and the cell stays pending. The writer deletes the id's stale verdict in the other three directories so a finding never has two live verdicts. |
| 10 | **`bbh-validate.js` performs exactly one bounded cure round** and then hands a lingering CURE back to the caller. | Deeper cure loops belong to the coordinator, which re-validates on a fresh blind validator each round and is bounded by `max_cure_cycles`. One round here makes a standalone run converge without duplicating the coordinator's loop. |
| 11 | **`only_assets` cannot delete anything.** | The queue "eliminates nothing" by design. Dropping an asset is expressed by not working its slice in this invocation; its tree is untouched and the omission is recorded in `notes[]`. |
| 12 | **`date` is the only clock.** No `Date.now()`, `new Date()` or `Math.random()` anywhere; every timestamp comes from an agent running `date -u +%Y-%m-%dT%H:%M:%SZ`. | Determinism: verdicts must be reproducible. |
| 13 | **Skeptic cadence reported, not enforced.** | The skeptic fires at 5/15/25 and every 25 after, and the return value records which ones actually produced a brief. With `max_experiments` defaulting to 30, E25 is reachable but E15/E25 may not be on a small budget — the checkpoint list says which fired rather than pretending. |

---

## 9. Validating the scripts

`node --check <file>` **cannot** pass on a raw DSH workflow body: the body is an
async function body, so it legitimately contains both top-level `await` (illegal
in a CommonJS file) and a top-level `return` (illegal in an ES module). Checking it
as either one reports a syntax error that is not a real defect.

Validate the way the runtime does — as an async function body — and validate every
`agent()` schema through the real DSH schema validator:

```js
const fs = require('fs')
const AsyncFunction = Object.getPrototypeOf(async function () {}).constructor
new AsyncFunction('agent','pipeline','parallel','phase','log','args',
                  fs.readFileSync('workflows/bbh-hunt.js','utf8'))
// throws SyntaxError on a real syntax problem; returns silently when the body parses
```

For the schema half, import `assertObjectJsonSchema` from
`@deepseek-ai/dsh-tools` and call it on each `opts.schema` — a schema outside the
enforced subset **throws at runtime and kills the script**, so this check is not
optional. All three scripts here were validated that way, in every branch
(including each `dry_run`, `resume_from` token, null-agent, cure-exhausted,
refuted-quorum and blocked paths).

The CLI half was verified the other way round: every `python3 tools/...` line in
these prompts was run for real against the tools in `tools/`, with the exact flags
written here. In particular

* `bbh_scope.py init` accepts the mapping the stage-0 prompt describes
  (`--asset kind:value[:apex]`, `--exclude`, `--path-exclusion ASSET=GLOB`,
  `--creds-env`, `--roe-json`, `--safe-harbor`), and `check` returns 0/1/2 exactly
  as the prompts assert;
* `queue_build.py` really is idempotent across the two passes: with `--prior-queue`
  the lead count went 7 → 26 once `cells.json` existed, with every prior status
  preserved and `coverage_seed_assets` filled in;
* `coverage_gate.py` exits 1 in **both** modes before any work, and writes
  `reports/coverage-matrix.json` either way;
* `slice_build.py` resolves `class_playbooks` to **absolute paths of real files**,
  which is what the executor prompts hand to a child. Note that for a few classes
  the catalogue's own anchor resolves to a `SKILL.md`; the prompts therefore say
  "pass the resolved paths verbatim, prefer the more specific one when there are
  several" rather than forbidding `SKILL.md` outright;
* `schema_check.py`'s accepted `--kind` values are `scope, classification, surface,
  queue, slice, finding, verdict, seven-questions, repro` (plus `all` with
  `--run-dir`) — the prompts use only those;
* `repro_pack.py` exits 1 and prints `REFUSED:` for a non-CONFIRMED / non-PASS
  input and 2 when an input cannot be read.

---

## 10. Reading order for a human

1. `tools/README.md` — the frozen CLI contract these scripts call.
2. `contracts/*.schema.json` — the artifact shapes.
3. `workflows/bbh-hunt.js` — the conductor and the checkpoint protocol.
4. `workflows/bbh-coordinator.js` — the three-file state, the blind-validator and cure contracts.
5. `workflows/bbh-validate.js` — the fidelity checks in order.
