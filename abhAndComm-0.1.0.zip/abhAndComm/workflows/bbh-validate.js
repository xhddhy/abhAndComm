// ============================================================================
// bbh-validate.js — THE FIDELITY ENGINE (DSH workflow script body).
//
// A rewrite of the upstream `.claude/workflows/validate-findings.js` for bounty
// semantics. This is the standalone, re-runnable validator: point it at an asset
// directory (or at one finding) and it drives every candidate to a terminal
// verdict written to
//
//     artifacts/validated/<id>.json | artifacts/false-positives/<id>.json | artifacts/dropped/<id>.json
//
// each conforming to contracts/validation-verdict.schema.json, each checked with
// `python3 tools/schema_check.py --kind verdict <file>`.
//
// PER FINDING, IN THIS EXACT ORDER:
//   1. SCOPE RE-CHECK        tools/bbh_scope.py check -> exit 1/2 is DROPPED, never CONFIRMED
//   2. PoC TRUTH             poc.cmd is ACTUALLY RUN; broken/absent scripts are REPAIRED and re-run;
//                            >= 3 deterministic runs; the negative_control must NOT print the success token
//   3. EVIDENCE COMPLETENESS every path in evidence.artifacts[] exists and is non-empty on disk
//   4. CROSS-IDENTITY PROOF  IDOR/BOLA/ATO/privesc: actor reaches victim data, a FRESH session still
//                            reproduces, and an anonymous request differs
//   5. CVSS TRUTH            tools/cvss_recompute.py recomputes from the vector; vector/band mismatch = FAIL
//   6. CVE TRUTH             when a CVE is claimed: tools/nvd_lookup.py --json against the frozen snapshot
//   7. ADVERSARIAL QUORUM    3 independent, evidence-only, BLIND refuters; confirmation requires ALL to fail to refute
//
// The verdict is authored by the CHECKS agent (the only agent that sees the whole
// picture); the refuters never see its reasoning and the author never sees the
// refuter arguments before writing it. That is the same separation the
// coordinator's inline lane uses, which is why a re-run of this workflow over an
// asset dir is idempotent with the verdicts the coordinator already wrote.
//
// Sandbox: no Date.now() / new Date() / Math.random(). Agents shell out to `date`.
// Agents do all I/O; this script only coordinates.
// ============================================================================

// ---- args ------------------------------------------------------------------
const a = (args && typeof args === 'object' && !Array.isArray(args)) ? args : {}

const ASSET_DIR_IN = a.asset_dir || null
const RUN_DIR_IN = a.run_dir || null
const EXPLICIT = Array.isArray(a.findings)
  ? a.findings.map((x) => String(x).trim()).filter(Boolean)
  : (typeof a.findings === 'string' && a.findings.trim()
    ? a.findings.split(',').map((x) => x.trim()).filter(Boolean)
    : null)
const REPAIR = a.repair !== false
const VOTES = Number(a.votes) > 0 ? Math.floor(Number(a.votes)) : 3
const MAX_FINDINGS = Number(a.max_findings) > 0 ? Math.floor(Number(a.max_findings)) : 50
const NVD_CACHE_DIR = a.nvd_cache_dir || null
const KEV_SNAPSHOT = a.kev_snapshot || null
const DRY_RUN = a.dry_run === true

const BUNDLE = 'the bundle root (your cwd: it contains tools/README.md, contracts/ and workflows/)'

// ============================================================================
// Helpers and shared prompt material
// ============================================================================
function slash(p) { return String(p || '').replace(/\/+$/, '') }

async function inChunks(items, size, fn) {
  const out = []
  const width = size > 0 ? size : 1
  for (let i = 0; i < items.length; i += width) {
    const chunk = items.slice(i, i + width)
    const res = await parallel(chunk.map((it) => () => fn(it)))
    for (const r of res) out.push(r)
  }
  return out
}

const DISCIPLINE = [
  'STANDING DISCIPLINE (fidelity engine):',
  '- SCOPE IS LAW: python3 tools/bbh_scope.py check --scope <scope.json> --url <url>; exit 0 in scope, 1 out of scope,',
  '  2 unclear. Out of scope or unclear means the finding is DROPPED, not confirmed.',
  '- READ-ONLY AND NON-DESTRUCTIVE toward the target. No brute force, no DoS, no writes to another tenant. Obey the',
  '  scope file roe{}. A PoC re-run is a re-run of an existing, authorised reproduction — never a new exploitation campaign.',
  '- EVIDENCE OR IT DID NOT HAPPEN. A check with no recorded raw output is a FAILED check.',
  '- TIMESTAMPS: run `date -u +%Y-%m-%dT%H:%M:%SZ`. Never invent a time.',
  '- DETERMINISM: never Date/Math randomness in a PoC you repair or write. Same input, same decisive output, three times.',
  '- Write only where your role permits. Validators never modify the executor\'s poc/ or evidence/ files; they ADD to',
  '  evidence/validation/ and they write the verdict JSON.',
].join('\n')

function cveOperands() {
  return [
    'FROZEN CVE OPERANDS (reproducibility — always pass the cache dir so a replayed verdict reads the snapshot, not the network):',
    `  python3 tools/nvd_lookup.py <CVE-ID> --json --cache-dir ${NVD_CACHE_DIR || '<RUN_DIR>/artifacts/nvd-cache'}`,
    KEV_SNAPSHOT
      ? `  CISA KEV: read the frozen snapshot at ${KEV_SNAPSHOT} directly (do not hit the network).`
      : '  CISA KEV: use the kev_listed field nvd_lookup.py returns.',
    '  Also follow the advisory reference URLs NVD returns and quote the affected-version line verbatim.',
  ].join('\n')
}

// The verdict contract, stated once so every prompt that writes one agrees.
const VERDICT_CONTRACT = [
  'VERDICT CONTRACT (contracts/validation-verdict.schema.json, schema id bbh/verdict/v1):',
  '  { "schema": "bbh/verdict/v1", "finding_id": "F-NNN", "asset_tag": "<asset>",',
  '    "validated_at": "<date -u +%Y-%m-%dT%H:%M:%SZ>", "verdict": "CONFIRMED|REJECTED|CURE|DROPPED",',
  '    "checks": { "<check_name>": {"pass": <bool>, "detail": "<what decided it>", "cmd": "<exact command>",',
  '                                  "output_digest": "<short digest of the RAW output>"} , ... },',
  '    "failed_checks": ["<machine-readable check name>", ...],',
  '    "missing_evidence": ["<exact relative path to produce>", ...],',
  '    "refuters": {"count": N, "refuted": M, "refutation_args": ["..."]},',
  '    "cvss": {"vector": "...", "claim_score": <n|null>, "recomputed_score": <n|null>, "recomputed_band": "...",',
  '             "nvd_score": <n|null>, "kev_listed": <bool|null>},',
  '    "evidence_package": ["<path>", ...], "reason": "<one paragraph a human can act on>", "cure_cycles": <int> }',
  '  Canonical check names (use these EXACT strings in checks{}, failed_checks[] and missing_evidence[]):',
  '    scope_in_scope, poc_runs, poc_deterministic, negative_control, impact_real, cross_identity,',
  '    cvss_recomputed, cve_truth, not_known_duplicate, evidence_complete.',
  '  A check with no recorded output is a FAILED check. The reason field is what a human triages from — write it plainly.',
].join('\n')

// ============================================================================
// PHASE: Discover — inventory what to validate
// ============================================================================
phase('Discover')

const DISCOVER_SCHEMA = {
  type: 'object', additionalProperties: true,
  required: ['findings'],
  properties: {
    asset_dir: { type: 'string' },
    run_dir: { type: 'string' },
    scope_ref: { type: 'string' },
    asset_tag: { type: 'string' },
    findings: {
      type: 'array',
      items: {
        type: 'object', additionalProperties: true,
        required: ['id', 'dir', 'finding_json'],
        properties: {
          id: { type: 'string' },
          dir: { type: 'string' },
          finding_json: { type: 'string' },
          class_id: { type: 'string' },
          cell_key: { type: 'string' },
          covers_cells: { type: 'array', items: { type: 'string' } },
          title: { type: 'string' },
          endpoint: { type: 'string' },
          method: { type: 'string' },
          claimed_severity: { type: 'string' },
          claimed_cvss_vector: { type: 'string' },
          cve_ids: { type: 'array', items: { type: 'string' } },
          has_poc_cmd: { type: 'boolean' },
          poc_script: { type: 'string' },
          evidence_artifacts: { type: 'array', items: { type: 'string' } },
          identity_present: { type: 'boolean' },
          is_cross_identity_class: { type: 'boolean' },
          existing_verdict: { type: 'string' },
          existing_verdict_path: { type: 'string' },
          finding_json_valid: { type: 'boolean' },
        },
      },
    },
    skipped: {
      type: 'array',
      items: {
        type: 'object', additionalProperties: true,
        required: ['id', 'reason'],
        properties: { id: { type: 'string' }, reason: { type: 'string' } },
      },
    },
    notes: { type: 'array', items: { type: 'string' } },
    blocked_reason: { type: 'string' },
  },
}

const discover = await agent(
  `${DISCIPLINE}\n\n` +
  `ROLE: VALIDATION DISCOVERY. cwd is ${BUNDLE}. Inventory every candidate finding for this asset. You do NOT judge them\n` +
  `yet and you do NOT send a single request to the target.\n\n` +
  `ASSET_DIR: ${ASSET_DIR_IN || '<not supplied — see the BLOCKED rule>'}\n` +
  `RUN_DIR: ${RUN_DIR_IN || '<not supplied — derive it: the asset dir is <run>/assets/<asset_tag>, so run_dir is two levels up>'}\n` +
  (EXPLICIT ? `EXPLICIT FINDINGS (validate EXACTLY these, ignore the rest): ${JSON.stringify(EXPLICIT)}\n` : '') +
  `CONTRACTS: contracts/finding.schema.json (bbh/finding/v1), contracts/validation-verdict.schema.json (bbh/verdict/v1)\n\n` +
  `CROSS-IDENTITY CLASSES (the ones that require check 4): API1-BOLA, WEB-A01-ACCESS/CROSS-TENANT classes whose class_id\n` +
  `contains IDOR, BOLA, BOPLA, ATO or PRIVESC — judge from the class_id string and from whether finding.json populates\n` +
  `evidence.identity. Report is_cross_identity_class per finding.\n\n` +
  `BLOCKED RULE: if asset_dir is empty or does not exist, return findings:[] with blocked_reason saying so. Do not guess a\n` +
  `different asset directory: validating the wrong asset's findings is worse than validating nothing.\n\n` +
  `DO:\n` +
  `1. Determine asset_tag from the asset dir's basename and report it. Locate the scope file: prefer <RUN_DIR>/scope.json;\n` +
  `   otherwise report the path the slice carries (<asset_dir>/../../slices/<asset_tag>.json has scope_ref).\n` +
  `2. Ensure these directories exist (mkdir -p, no-op if present):\n` +
  `     <asset_dir>/artifacts/validated <asset_dir>/artifacts/false-positives <asset_dir>/artifacts/dropped\n` +
  `3. Enumerate every <asset_dir>/findings/finding-*/ directory that contains a finding.json. If EXPLICIT was given, keep\n` +
  `   only those ids. SKIP nothing silently: anything skipped goes in skipped[] with the reason.\n` +
  `4. For EACH one, read finding.json and report: id, dir, finding_json path, class_id, cell_key, covers_cells, title,\n` +
  `   endpoint, method, claimed_severity, claimed_cvss_vector, cve_ids[] (regex CVE-\\d{4}-\\d{4,}), has_poc_cmd,\n` +
  `   poc_script (poc.script), evidence_artifacts[] (the RELATIVE paths in evidence.artifacts), identity_present\n` +
  `   (is evidence.identity present with an actor or victim?), is_cross_identity_class (per the rule above), and\n` +
  `   finding_json_valid = did 'python3 tools/schema_check.py --kind finding <finding.json>' exit 0?\n` +
  `5. Resume detection: for each finding, check whether a terminal verdict already exists at\n` +
  `   <asset_dir>/artifacts/{validated,false-positives,dropped,cure}/<id>.json. If one does, report existing_verdict (read the\n` +
  `   verdict field out of the file) and existing_verdict_path. Do NOT delete it — the caller decides whether to re-validate.\n` +
  `6. Report every finding.json that FAILS schema validation in notes[] with the tool's stdout — a finding whose own\n` +
  `   artifact does not validate cannot be confirmed, and the checks stage will fail it on evidence_complete.\n\n` +
  `Return DISCOVER_SCHEMA. blocked_reason is a STRING: '' means no block.`,
  { schema: DISCOVER_SCHEMA, label: 'discover', phase: 'Discover' }
)

if (!discover || discover.blocked_reason) {
  return {
    status: 'BLOCKED', phase: 'Discover',
    reason: discover ? discover.blocked_reason : 'discovery agent returned null',
    asset_dir: ASSET_DIR_IN, counts: { total: 0, confirmed: 0, rejected: 0, cure: 0, dropped: 0 },
  }
}

const ASSET_TAG = discover.asset_tag || slash(ASSET_DIR_IN).split('/').filter(Boolean).pop()
const ASSET_DIR = slash(discover.asset_dir || ASSET_DIR_IN)
const RUN_DIR = slash(RUN_DIR_IN || discover.run_dir || ASSET_DIR.replace(/\/assets\/[^/]+$/, ''))
const SCOPE_REF = discover.scope_ref || `${RUN_DIR}/scope.json`
const NVD_DIR = NVD_CACHE_DIR || `${RUN_DIR}/artifacts/nvd-cache`

let inventory = (discover.findings || []).filter((f) => f && f.id && f.dir)
const toValidate = []
const skippedResume = []

for (const f of inventory) {
  // A finding that already has a TERMINAL verdict is not re-validated on a plain
  // re-run: the verdict is the artifact this engine produces, and re-running it
  // would burn the quorum on a question already answered. Deleting the verdict
  // file is how you ask for a re-validation.
  const alreadyTerminal = f.existing_verdict && ['CONFIRMED', 'REJECTED', 'CURE', 'DROPPED'].indexOf(String(f.existing_verdict).toUpperCase()) >= 0
  if (alreadyTerminal && !EXPLICIT) {
    skippedResume.push({ id: f.id, reason: `already terminal (${f.existing_verdict}) at ${f.existing_verdict_path} — delete that file (or pass args.findings=['${f.id}']) to force a re-validation` })
    continue
  }
  toValidate.push(f)
}

const capped = toValidate.slice(0, MAX_FINDINGS)
const overCap = toValidate.length - capped.length
if (overCap > 0) {
  log(`NOTE: ${toValidate.length} candidate(s) to validate; deep-validating the first ${MAX_FINDINGS} (args.max_findings). The other ${overCap} are NOT dropped silently — they stay PENDING and are listed in this run's return value.`)
}

if (!capped.length) {
  log(`validate: nothing to validate for ${ASSET_TAG} (${skippedResume.length} already terminal).`)
}

if (DRY_RUN) {
  return {
    status: 'DRY_RUN',
    asset_dir: ASSET_DIR,
    asset_tag: ASSET_TAG,
    scope_ref: SCOPE_REF,
    would_validate: capped.map((f) => ({ id: f.id, class_id: f.class_id, cve_ids: f.cve_ids || [], cross_identity: f.is_cross_identity_class === true, existing_verdict: f.existing_verdict || null })),
    already_terminal: skippedResume,
    over_cap: overCap,
    plan: {
      votes: VOTES,
      repair: REPAIR,
      checks: ['scope_in_scope', 'poc_runs', 'poc_deterministic', 'negative_control', 'evidence_complete', 'cross_identity', 'impact_real', 'cvss_recomputed', 'cve_truth', 'not_known_duplicate'],
      terminal_paths: {
        CONFIRMED: `${ASSET_DIR}/artifacts/validated/<id>.json`,
        REJECTED: `${ASSET_DIR}/artifacts/false-positives/<id>.json`,
        CURE: `${ASSET_DIR}/artifacts/false-positives/<id>.json (interim) — returned to the caller with failed_checks + missing_evidence`,
        DROPPED: `${ASSET_DIR}/artifacts/dropped/<id>.json`,
      },
    },
  }
}

log(`validate: ${capped.length} candidate(s) for ${ASSET_TAG}, ${VOTES} blind refuter(s) each, repair=${REPAIR}`)

// ============================================================================
// PHASE: Validate — checks -> blind refuters -> verdict, per finding
// ============================================================================
phase('Validate')

const CHECKS_SCHEMA = {
  type: 'object', additionalProperties: true,
  required: ['finding_id', 'checks', 'poc_ran'],
  properties: {
    finding_id: { type: 'string' },
    checks: {
      type: 'object', additionalProperties: true,
      properties: {
        scope_in_scope: { type: 'object', additionalProperties: true },
        poc_runs: { type: 'object', additionalProperties: true },
        poc_deterministic: { type: 'object', additionalProperties: true },
        negative_control: { type: 'object', additionalProperties: true },
        impact_real: { type: 'object', additionalProperties: true },
        cross_identity: { type: 'object', additionalProperties: true },
        cvss_recomputed: { type: 'object', additionalProperties: true },
        cve_truth: { type: 'object', additionalProperties: true },
        evidence_complete: { type: 'object', additionalProperties: true },
      },
    },
    failed_checks: { type: 'array', items: { type: 'string' } },
    missing_evidence: { type: 'array', items: { type: 'string' } },
    poc_ran: { type: 'boolean' },
    poc_repaired: { type: 'boolean' },
    deterministic_runs: { type: 'integer' },
    decisive_output: { type: 'string' },
    negative_control_output: { type: 'string' },
    negative_control_silent: { type: 'boolean' },
    cvss: { type: 'object', additionalProperties: true },
    cve: { type: 'object', additionalProperties: true },
    cross_identity: { type: 'object', additionalProperties: true },
    evidence_missing: { type: 'array', items: { type: 'string' } },
    verdict_recommendation: { type: 'string', description: 'CONFIRMED | REJECTED | CURE | DROPPED' },
    reason: { type: 'string' },
    blocked_reason: { type: 'string' },
  },
}

function checksPrompt(f) {
  return `${DISCIPLINE}\n\n` +
  `ROLE: AUTHORITATIVE FINDING VALIDATOR (the checks lane). cwd is ${BUNDLE}. You verify ONE finding against raw evidence\n` +
  `and produce its proof package. You are the only agent in this lane that sees the whole picture; ${VOTES} blind refuters\n` +
  `will attack your conclusion afterwards and they will NOT see your reasoning.\n\n` +
  `FINDING: ${f.id}   FINDING_DIR: ${f.dir}   FINDING_JSON: ${f.finding_json}\n` +
  `ASSET: ${ASSET_TAG}   ASSET_DIR: ${ASSET_DIR}   RUN_DIR: ${RUN_DIR}   SCOPE: ${SCOPE_REF}\n` +
  `TARGET: ${f.endpoint || '(read endpoint + method from finding.json)'}   METHOD: ${f.method || '?'}\n` +
  `CLASS_ID: ${f.class_id || '?'}   CELL_KEY: ${f.cell_key || '?'}   CROSS-IDENTITY CLASS: ${f.is_cross_identity_class === true}\n` +
  `CLAIMED: severity=${f.claimed_severity || '?'} vector=${f.claimed_cvss_vector || '?'}   CVE(s): ${JSON.stringify(f.cve_ids || [])}\n` +
  `REPAIR ENABLED: ${REPAIR}\n\n` +
  `YOU MUST NOT READ: ${ASSET_DIR}/attack-chain.md, ${ASSET_DIR}/session-memory.md, any other finding's directory, any\n` +
  `mission log under ${ASSET_DIR}/logs/, or any existing verdict. Reading them voids your independence. You MAY read this\n` +
  `finding's own directory and ${ASSET_DIR}/recon/ (raw recon is evidence, not theory).\n\n` +
  `Read ${f.finding_json} first. Every check below must end with pass (boolean), detail, the exact cmd you ran, and a short\n` +
  `digest of the RAW output. A check with no recorded output is a FAILED check.\n\n` +
  `1. scope_in_scope — for the finding's endpoint and EVERY URL in its evidence:\n` +
  `     python3 tools/bbh_scope.py check --scope ${SCOPE_REF} --url <url>\n` +
  `   exit 0 = in scope (pass). exit 1 = OUT OF SCOPE and exit 2 = unclear (third party / staging / no safe harbor): both\n` +
  `   mean the verdict must be DROPPED, never CONFIRMED and never REJECTED — a real bug the program cannot take.\n\n` +
  `2. poc_runs, 3. poc_deterministic, 4. negative_control — THE PoC MUST ACTUALLY RUN.\n` +
  `   * Read poc.cmd from finding.json. cd to ${f.dir} and RUN IT. Capture stdout+stderr verbatim to\n` +
  `     ${f.dir}/evidence/validation/poc-rerun-output.txt.\n` +
  (REPAIR
    ? `   * REPAIR IS ON. If poc.script is missing, does not parse, references the wrong host, or emits nothing: WRITE OR FIX\n` +
      `     it. It must be standalone (argparse positional target, TIMEOUT default 10, prefixes [*]/[+]/[-]/[!], exit 0 =\n` +
      `     vulnerable / 1 = not vulnerable / 2 = error), read-only, and it must not change the finding's claim. Re-run it.\n` +
      `     Set poc_repaired=true. A repaired-and-passing PoC still CONFIRMS the finding — repair is expected work here, not a\n` +
      `     reason to fail. A PoC that cannot be made to emit the proof token IS a failure: poc_runs=false.\n`
    : `   * REPAIR IS OFF (args.repair=false). Do NOT write or modify any PoC. If it cannot prove the issue, poc_runs=false.\n`) +
  `   * Run it AT LEAST 3 TIMES. Normalise each run (strip timestamps, UUIDs, session tokens, nonces, dynamic ports,\n` +
  `     request ids; lowercase) and confirm all runs agree AND that a vuln-class SIGNAL TOKEN is present — SQLi: a DB error\n` +
  `     or a column value; RCE/deser: uid=0 or a hostname; traversal/LFI: a /etc/passwd line; SSRF: an internal body;\n` +
  `     XSS: the exact payload echoed; auth bypass: Set-Cookie or a 200 after disallowed navigation; IDOR/BOLA: the OTHER\n` +
  `     identity's field; info/config: the disclosed value. Record the token in decisive_output.\n` +
  `   * RUN poc.negative_control. It MUST NOT print the success token. Record its raw output in negative_control_output and\n` +
  `     set negative_control_silent. If the control also prints the token, the signal is NOISE: negative_control=false and\n` +
  `     the recommendation is REJECTED. This is the single most common false positive and you are the last line of defence.\n` +
  `   * ALWAYS write ${f.dir}/evidence/validation/verification-script.py — a STANDALONE reproduction with its own imports,\n` +
  `     its own target refs and its own output parsing that does NOT import the executor's poc. A human runs that one file.\n` +
  `   * Write ${f.dir}/evidence/validation/validation-summary.md per the template in skills/coordination/reference/VALIDATION.md\n` +
  `     (if that file is absent, use: Verdict / Checks / PoC Re-execution / Claims Verified / Notes / Evidence Package).\n\n` +
  `5. evidence_complete — stat EVERY path in evidence.artifacts[] (relative to ${f.dir}):\n` +
  `     for p in <paths>; do test -f "${f.dir}/$p" && wc -c "${f.dir}/$p" || echo "MISSING $p"; done\n` +
  `   A single missing or zero-byte path FAILS the check and the exact relative path goes into evidence_missing[]. Also\n` +
  `   verify evidence.request is a real verbatim request and evidence.response is a real response (not a paraphrase).\n\n` +
  `6. impact_real — is real data or a real state change actually IN the evidence? Name it. A 200 status is not impact; a\n` +
  `   database row belonging to another user is. If the evidence only shows a mechanism without the impact the finding\n` +
  `   claims, this check FAILS — that is what the 7-Question Gate's Q6 will also catch later, and it is cheaper to catch here.\n\n` +
  (f.is_cross_identity_class
    ? `7. cross_identity — REQUIRED for this class. All three must hold, and you must produce the artifact:\n` +
      `     (a) the ACTOR reaches the VICTIM's data or action — quote the victim-owned field from the response;\n` +
      `     (b) a FRESH session for the actor STILL reproduces it — re-authenticate; do not reuse an old cookie/token;\n` +
      `     (c) an ANONYMOUS request DIFFERS — a 401/403, a redirect to login, or simply not the victim's data.\n` +
      `   Write ${f.dir}/evidence/validation/two-identity-comparison.txt with the three raw exchanges side by side.\n` +
      `   If (c) does not differ, the endpoint is public and this is NOT the finding claimed: cross_identity=false and\n` +
      `   recommend REJECTED. If evidence.identity is absent, cross_identity=false and add BOTH\n` +
      `   "evidence/two-identity-comparison.txt" and "evidence.identity{actor,victim} in finding.json" to evidence_missing[].\n`
    : `7. cross_identity — NOT required for this class (class_id=${f.class_id || '?'}). Report it as pass:true with the detail\n` +
      `   "not applicable: class_id ${f.class_id || '?'} is not an IDOR/BOLA/ATO/privesc class". Still record it so the verdict\n` +
      `   has one entry per canonical check name.\n`) +
  `\n8. cvss_recomputed — never trust the claimed number:\n` +
  `     python3 tools/cvss_recompute.py --vector "<finding.cvss_vector>" --json\n` +
  `   Compare the recomputed score/band against severity_claim AND against cvss_vector. A vector/band mismatch FAILS the\n` +
  `   check. Also apply the root-cause floor: if description.md asserts a HIGHER latent impact following from a confirmed\n` +
  `   missing control, do not silently accept an under-rated band — note it in the detail. Never invent impact the finding\n` +
  `   does not claim.\n\n` +
  (f.cve_ids && f.cve_ids.length
    ? `9. cve_truth — this finding claims ${JSON.stringify(f.cve_ids)}.\n${cveOperands()}\n` +
      `   The claimed CVE id, vector, base score and severity must ALL agree with NVD and with your own from-vector\n` +
      `   recomputation (|delta| <= 0.1 on the score, exact on the band). Flag KEV membership. Write\n` +
      `   ${f.dir}/evidence/validation/cve-verification.md with the NVD summary, the chosen CVSS version + vector, your\n` +
      `   computed score, KEV status, the advisory URL and the quoted affected-version line. Any unreconciled divergence FAILS.\n` +
      `   Also check the vulnerable feature is actually ENABLED and REACHABLE on this asset — a version banner is not a patch\n` +
      `   level, and a backported/appliance-bundled package is a candidate until the backport is checked.\n\n`
    : `9. cve_truth — no CVE is claimed. Report pass:true with detail "not applicable: no CVE claimed". Do not go looking for\n` +
      `   one.\n\n`) +
  `10. not_known_duplicate — search the program's DISCLOSED reports for this exact class + endpoint (and the program's\n` +
  `   changelog / API docs if reachable). Record the queries you ran and what you found. If you cannot search, record the\n` +
  `   limitation explicitly — do not silently pass it, and do not fail the finding for a search you were unable to run.\n\n` +
  `${VERDICT_CONTRACT}\n\n` +
  `THEN RECOMMEND (the refuters and the caller get the final say):\n` +
  `  CONFIRMED — every check passed (a disclosed repair is fine) and impact is real.\n` +
  `  REJECTED  — the negative control was not silent, the evidence contradicts the claim, or the mechanism does not\n` +
  `              establish the claimed impact.\n` +
  `  CURE      — the bug is real but the package is incomplete or broken. Put the EXACT canonical check names in\n` +
  `              failed_checks[] and the EXACT relative paths to produce in missing_evidence[]. The cure executor receives\n` +
  `              NOTHING else, so be specific enough that a stranger could close the gap.\n` +
  `  DROPPED   — out of scope or unclear per check 1.\n\n` +
  `Write NOTHING outside ${f.dir}/evidence/validation/ (and never modify the executor's poc or evidence files).\n` +
  `Return CHECKS_SCHEMA. blocked_reason is a STRING: '' means no block.`
}

const REFUTER_SCHEMA = {
  type: 'object', additionalProperties: true,
  required: ['refuted', 'reason'],
  properties: {
    refuter: { type: 'integer' },
    refuted: { type: 'boolean' },
    reason: { type: 'string' },
    weakest_link: { type: 'string' },
    falsifiable_test: { type: 'string' },
    blocked_reason: { type: 'string' },
  },
}

function refuterPrompt(f, i) {
  return `ROLE: ADVERSARIAL REFUTER #${i} of ${VOTES} (blind, evidence-only). cwd is ${BUNDLE}.\n` +
    `Your job is to REFUTE the finding "${f.id}". You have been given no story: no coordinator theory, no validator\n` +
    `reasoning, no verdict, and the arguments of the other refuters. Default to skepticism — if a claim is not\n` +
    `independently supported by the raw material, it is refuted.\n\n` +
    `FINDING_DIR: ${f.dir}   FINDING_JSON: ${f.finding_json}\n` +
    `TARGET: ${f.endpoint || '(from finding.json)'}   CLASS_ID: ${f.class_id || '?'}\n` +
    `CLAIMED: severity=${f.claimed_severity || '?'} vector=${f.claimed_cvss_vector || '?'} CVEs=${JSON.stringify(f.cve_ids || [])}\n\n` +
    `YOU MAY READ ONLY: ${f.dir}/ (finding.json, description.md, poc/, evidence/ — including the evidence/validation/\n` +
    `artifacts the checks lane just produced).\n` +
    `YOU MUST NOT READ: ${ASSET_DIR}/attack-chain.md, ${ASSET_DIR}/session-memory.md, other findings, mission logs, any\n` +
    `verdict file, or any other refuter's output. Do not coordinate with the other refuters.\n\n` +
    `${f.cve_ids && f.cve_ids.length ? cveOperands() + '\n\n' : ''}` +
    `INTERROGATE, from the raw evidence alone:\n` +
    `  * Does the captured output actually PROVE the vulnerability, or is it incidental, ambiguous, or self-asserted? A\n` +
    `    response that would look identical on a NON-vulnerable target proves nothing.\n` +
    `  * Could the same output be produced WITHOUT the bug — by a public endpoint, a cached page, a WAF error, a default\n` +
    `    response, or your own request being echoed back?\n` +
    `  * Is the IMPACT demonstrated, or merely enabled? An enabler (a spray capability, a writable ACL, an SSRF reachability\n` +
    `    probe) scored as a demonstrated compromise is refuted.\n` +
    `  * For an IDOR/BOLA claim: is the "victim" data actually another principal's, or the actor's own object read back?\n` +
    `  * For a CORS claim: is there Access-Control-Allow-Credentials: true AND ambient cookie auth AND sensitive data? A\n` +
    `    reflected origin alone is not token theft.\n` +
    `  * For a CVE claim: is the vulnerable feature really enabled and reachable on THIS asset? A version banner is not a\n` +
    `    patch level. Do the claimed vector, score and severity survive recomputation and NVD?\n` +
    `  * Is any factual claim in the write-up absent from the raw captures? One unsupported factual claim is a refutation.\n` +
    `  * Does the PoC's decisive output depend on something the PoC itself controls (a token it planted, a value it echoed)?\n\n` +
    `You may run READ-ONLY commands of your own to check a claim against the target (scope-check first with\n` +
    `python3 tools/bbh_scope.py check --scope ${SCOPE_REF} --url <url>; exit 1 or 2 means do not send). Do not run the PoC's\n` +
    `destructive branches, do not brute force, do not flood.\n\n` +
    `Return REFUTER_SCHEMA. refuted=true means you found a REAL reason to doubt the finding, its score, or its CVE.\n` +
    `weakest_link = the single most doubtful element. falsifiable_test = the one check that would settle it.`
}

const CURE_SCHEMA = {
  type: 'object', additionalProperties: true,
  required: ['cured_gates'],
  properties: {
    cured_gates: { type: 'array', items: { type: 'string' } },
    uncured_gates: { type: 'array', items: { type: 'string' } },
    produced_evidence: { type: 'array', items: { type: 'string' } },
    notes: { type: 'string' },
    blocked_reason: { type: 'string' },
  },
}

function curePrompt(f, failedChecks, missingEvidence) {
  return `ROLE: FINDING CURE (scoped gap-closer — NOT a re-investigation). cwd is ${BUNDLE}.\n` +
    `A blind validator could not confirm "${f.id}" for the specific reasons below. Close EXACTLY those gaps.\n\n` +
    `FINDING: ${f.id}   FINDING_DIR: ${f.dir}   TARGET: ${f.endpoint || '(from finding.json)'}   ASSET_DIR: ${ASSET_DIR}\n` +
    `UNMET CHECKS (failed_checks): ${JSON.stringify(failedChecks || [])}\n` +
    `MISSING EVIDENCE (produce EXACTLY these paths, relative to the finding dir): ${JSON.stringify(missingEvidence || [])}\n\n` +
    `HARD BOUNDARIES — violating any of these voids the cure:\n` +
    `  * Do NOT re-theorize. Do NOT change the claim, the class_id or the endpoint.\n` +
    `  * Do NOT expand scope. Do NOT hunt other vulnerabilities. Do NOT read ${ASSET_DIR}/attack-chain.md or\n` +
    `    ${ASSET_DIR}/session-memory.md. Those are not your business: you have one job and it is named above.\n` +
    `  * Do NOT write outside ${f.dir}. Do NOT fabricate: every artifact comes from a real command you really ran.\n\n` +
    `WHAT EACH CHECK NAME MEANS:\n` +
    `  evidence_complete / missing paths -> create each named path with REAL content (re-run the tool that generates it).\n` +
    `  poc_runs / poc_deterministic      -> fix poc.cmd and the script until 3 consecutive runs print the SAME decisive\n` +
    `                                       output; update poc.runs and poc.deterministic in finding.json.\n` +
    `  negative_control                  -> make the control genuinely silent and capture its output as an artifact.\n` +
    `  cross_identity                    -> produce evidence/two-identity-comparison.txt (actor reaches victim data, a\n` +
    `                                       FRESH actor session still does, anonymous differs) and populate\n` +
    `                                       evidence.identity.{actor,victim,anonymous} in finding.json.\n` +
    `  impact_real                       -> capture the actual victim-owned data or the real state change, not a status code.\n` +
    `  cvss_recomputed                   -> python3 tools/cvss_recompute.py --vector "<vector>" --json, then correct\n` +
    `                                       finding.json's cvss_vector/severity_claim until score and band agree.\n` +
    `  cve_truth                         -> ${cveOperands().split('\n').join('\n                                       ')}\n` +
    `  not_known_duplicate               -> run the disclosed-report search and write the queries + results to\n` +
    `                                       evidence/validation/duplicate-search.md.\n` +
    `  scope_in_scope                    -> the endpoint is out of scope. Do NOT try to make it in scope. Report it as\n` +
    `                                       uncured so the caller can DROP it.\n` +
    `  q:<question_id>                   -> a 7-Question Gate failure. Produce the specific evidence that question needs:\n` +
    `                                       q1: a clean-box end-to-end run you actually performed; q2: the program policy line\n` +
    `                                       quoted with its source; q3: the scope-check exit code; q4: the lowest-privilege\n` +
    `                                       identity that reproduces it; q5: the disclosed-report search record; q6: the\n` +
    `                                       exfiltrated/foreign value itself; q7: the confirmed chain hop that makes it valid.\n` +
    `  Anything you cannot map: say so in uncured_gates[] and explain why. Do not guess.\n\n` +
    `Reversible, authorised, non-destructive actions ONLY. When done, re-validate your own artifact:\n` +
    `  python3 tools/schema_check.py --kind finding ${f.finding_json}\n\n` +
    `Return CURE_SCHEMA. Your return is NOT trusted as proof — a fresh validator re-checks everything, which is exactly why\n` +
    `you must leave the evidence on disk instead of asserting it in prose. blocked_reason is a STRING: '' means no block.`
}

const WRITE_SCHEMA = {
  type: 'object', additionalProperties: true,
  required: ['written'],
  properties: {
    written: { type: 'boolean' },
    verdict_path: { type: 'string' },
    verdict: { type: 'string' },
    schema_check_exit: { type: 'integer' },
    counts: { type: 'object', additionalProperties: true },
    notes: { type: 'array', items: { type: 'string' } },
    blocked_reason: { type: 'string' },
  },
}

// Terminal routing, in JS, so the destination is never the agent's choice.
// Terminal routing, in JS, so the destination is never the agent's choice.
// CURE is deliberately NOT routed to dropped/: the contract's three terminal
// directories each hold exactly their own verdict, and the coverage gate reads
// dropped/ as a terminal non-covered outcome. A cure-pending finding is neither
// terminal nor covered, so it lives in an interim artifacts/cure/ until a later
// round resolves it. Stale terminal files for the same id are removed.
function terminalSubdir(verdict) {
  if (verdict === 'CONFIRMED') return 'validated'
  if (verdict === 'REJECTED') return 'false-positives'
  if (verdict === 'DROPPED') return 'dropped'
  return 'cure'
}

function computeVerdict(checks, votes) {
  const refuteCount = (votes || []).filter((v) => v && v.refuted).length
  const failed = (checks && Array.isArray(checks.failed_checks)) ? checks.failed_checks.slice() : []
  const missing = (checks && Array.isArray(checks.missing_evidence)) ? checks.missing_evidence.slice() : []

  if (!checks) {
    return { verdict: 'CURE', failed_checks: ['checks_infra_error'], missing_evidence: [], reason: 'the checks lane returned null — this is an infrastructure failure, never a confirmation', refuteCount }
  }
  const c = checks.checks || {}
  const canonical = ['scope_in_scope', 'poc_runs', 'poc_deterministic', 'negative_control', 'evidence_complete', 'impact_real', 'cvss_recomputed']
  for (const k of canonical) {
    const entry = c[k]
    if (!entry || entry.pass !== true) { if (failed.indexOf(k) < 0) failed.push(k) }
  }
  // Scope decides DROPPED before anything else can promote it.
  if (c.scope_in_scope && c.scope_in_scope.pass !== true) {
    return { verdict: 'DROPPED', failed_checks: failed, missing_evidence: missing, reason: (c.scope_in_scope.detail || 'the endpoint is out of scope or unclear'), refuteCount }
  }
  // A substantiated refutation is a REJECTED verdict. The quorum requires ALL to
  // fail to refute; one real refutation is enough to reject.
  if (refuteCount > 0) {
    return {
      verdict: 'REJECTED', failed_checks: failed.concat(['adversarial:refuted']), missing_evidence: missing,
      reason: `${refuteCount} of ${(votes || []).length} blind refuter(s) substantiated a refutation: ` + (votes || []).filter((v) => v && v.refuted).map((v) => v.reason).join(' | '),
      refuteCount,
    }
  }
  const quorumMet = (votes || []).length >= VOTES
  if (!quorumMet) {
    if (failed.indexOf('adversarial:quorum_incomplete') < 0) failed.push('adversarial:quorum_incomplete')
    if (missing.indexOf('<N blind refuter results>') < 0) missing.push('<N blind refuter results>')
  }
  if (failed.length === 0) {
    return { verdict: 'CONFIRMED', failed_checks: [], missing_evidence: [], reason: checks.reason || 'all checks passed and no refuter succeeded', refuteCount }
  }
  // Real bug, incomplete package -> CURE (never a silent pass, never a rejection
  // of something that is substantively there).
  return { verdict: 'CURE', failed_checks: failed, missing_evidence: missing, reason: checks.reason || 'the finding is substantively present but its package is incomplete', refuteCount }
}

// Validate ONE finding: checks lane -> blind refuters (parallel) -> deterministic
// verdict -> cure round on a FRESH checks lane if CURE. Bounded so a stuck
// finding can never spin the engine.
async function validateOne(f) {
  let round = 0
  let last = null
  while (true) {
    const checks = await agent(checksPrompt(f), { schema: CHECKS_SCHEMA, label: `checks:${f.id}`, phase: 'Validate' })
    const votes = checks
      ? (await parallel(Array.from({ length: VOTES }, (_, i) => () =>
        agent(refuterPrompt(f, i + 1), { schema: REFUTER_SCHEMA, label: `refute:${f.id}#${i + 1}`, phase: 'Validate' })
      ))).filter(Boolean)
      : []
    const v = computeVerdict(checks, votes)
    last = { checks, votes, verdict: v, round }

    if (v.verdict === 'CURE' && round < 1 && REPAIR) {
      // One bounded cure round inside the engine. Deeper cure loops belong to the
      // coordinator (which re-validates on a FRESH blind validator each round and
      // is bounded by max_cure_cycles); this engine does exactly one so a
      // standalone run still converges, then hands the finding back on CURE.
      log(`cure ${f.id} round ${round + 1}: failed=${JSON.stringify(v.failed_checks)}`)
      await agent(curePrompt(f, v.failed_checks, v.missing_evidence), { schema: CURE_SCHEMA, label: `cure:${f.id}#${round + 1}`, phase: 'Validate' })
      round++
      continue
    }
    return last
  }
}

const results = await inChunks(capped, 1, (f) => validateOne(f))

// ============================================================================
// PHASE: Persist — one writer agent per asset dir, exact bytes, then verify
// ============================================================================
phase('Persist')

const counts = { total: capped.length, confirmed: 0, rejected: 0, cure: 0, dropped: 0, infra: 0 }
const verdictRows = []

for (let i = 0; i < capped.length; i++) {
  const f = capped[i]
  const r = results[i]
  if (!r || !r.verdict) {
    counts.infra++
    verdictRows.push({ finding_id: f.id, dir: f.dir, finding_json: f.finding_json, class_id: f.class_id, cell_key: f.cell_key, endpoint: f.endpoint, claim_score: null, claim_vector: f.claimed_cvss_vector || '', verdict: 'CURE', checks: {}, failed_checks: ['checks_infra_error'], missing_evidence: [], refuters: { count: 0, refuted: 0, refutation_args: [] }, cvss: { vector: f.claimed_cvss_vector || '', claim_score: null, recomputed_score: null, recomputed_band: '', nvd_score: null, kev_listed: null }, evidence_package: [], reason: 'validation lane returned no result — infrastructure failure, never a confirmation', cure_cycles: 0 })
    continue
  }
  const v = r.verdict
  const checks = r.checks || {}
  const cve = checks.cve || {}
  const cvss = checks.cvss || {}
  const key = v.verdict === 'CONFIRMED' ? 'confirmed' : v.verdict === 'REJECTED' ? 'rejected' : v.verdict === 'DROPPED' ? 'dropped' : 'cure'
  counts[key] = (counts[key] || 0) + 1
  if (!r.checks) counts.infra++
  verdictRows.push({
    finding_id: f.id,
    dir: f.dir,
    finding_json: f.finding_json,
    class_id: f.class_id,
    cell_key: f.cell_key,
    covers_cells: f.covers_cells || [],
    endpoint: f.endpoint || '',
    method: f.method || '',
    title: f.title || '',
    claim_severity: f.claimed_severity || '',
    claim_vector: cvss.vector || f.claimed_cvss_vector || '',
    claim_score: typeof cvss.claim_score === 'number' ? cvss.claim_score : null,
    verdict: v.verdict,
    checks: checks.checks || {},
    failed_checks: v.failed_checks || [],
    missing_evidence: v.missing_evidence || [],
    refuters: { count: (r.votes || []).length, refuted: v.refuteCount || 0, refutation_args: (r.votes || []).filter((x) => x && x.refuted).map((x) => x.reason) },
    cvss: {
      vector: cvss.vector || f.claimed_cvss_vector || '',
      claim_score: typeof cvss.claim_score === 'number' ? cvss.claim_score : null,
      recomputed_score: typeof cvss.recomputed_score === 'number' ? cvss.recomputed_score : null,
      recomputed_band: cvss.recomputed_band || '',
      nvd_score: typeof cve.nvd_score === 'number' ? cve.nvd_score : null,
      kev_listed: typeof cve.on_kev === 'boolean' ? cve.on_kev : null,
    },
    evidence_package: checks.evidence_package || [],
    reason: v.reason || checks.reason || '',
    cure_cycles: r.round || 0,
  })
}

if (verdictRows.length) {
  const writePlan = verdictRows.map((row) => ({
    path: `${ASSET_DIR}/artifacts/${terminalSubdir(row.verdict)}/${row.finding_id}.json`,
    content: JSON.stringify({
      schema: 'bbh/verdict/v1',
      finding_id: row.finding_id,
      asset_tag: ASSET_TAG,
      verdict: row.verdict,
      checks: row.checks,
      failed_checks: row.failed_checks,
      missing_evidence: row.missing_evidence,
      refuters: row.refuters,
      cvss: row.cvss,
      evidence_package: row.evidence_package,
      reason: row.reason,
      cure_cycles: row.cure_cycles,
    }, null, 2),
  }))

  const written = await agent(
    `ROLE: VERDICT WRITER (persist verbatim; no judgment, no requests). cwd is ${BUNDLE}.\n` +
    `Your ONLY job is to write each file below with EXACTLY the given bytes, after stamping the timestamp.\n\n` +
    `ASSET_DIR: ${ASSET_DIR}   ASSET_TAG: ${ASSET_TAG}\n` +
    `CONTRACT: contracts/validation-verdict.schema.json (bbh/verdict/v1)\n\n` +
    `STEPS:\n` +
    `1. Get the timestamp ONCE: TS=$(date -u +%Y-%m-%dT%H:%M:%SZ)   (echo it so it appears in your transcript).\n` +
    `2. mkdir -p ${ASSET_DIR}/artifacts/validated ${ASSET_DIR}/artifacts/false-positives ${ASSET_DIR}/artifacts/dropped ${ASSET_DIR}/artifacts/cure\n` +
    `2b. For each file you are about to write, DELETE any older verdict for the SAME finding id in the OTHER three
` +
    `    directories, so one finding has exactly ONE live verdict. A CURE verdict must not leave a stale CONFIRMED file
` +
    `    behind — that would let an uncured finding be counted as covered. List every deletion you make in notes[].\n` +
    `3. Write each file below with these bytes EXACTLY, adding the single line "validated_at": "$TS" as the fourth key\n` +
    `   (after asset_tag, before verdict). Do NOT reformat, re-key, re-order, round, or add any other field. Do NOT\n` +
    `   pretty-print differently. Do NOT summarise a check — every check entry, digest and refuter argument must survive\n` +
    `   byte for byte.\n\n` +
    writePlan.map((w, i) => `--- FILE ${i + 1} of ${writePlan.length}: ${w.path} ---\n${w.content}`).join('\n\n') +
    `\n\n4. Then run, for EVERY file written:\n` +
    `     python3 tools/schema_check.py --kind verdict <path>\n` +
    `   and record each exit code. A file whose exit code is not 0 is NOT written correctly: fix that file's JSON only\n` +
    `   (never its content) and re-run. Report per-file exit codes in notes[].\n` +
    `5. Report written=true only if every file exists and every schema_check exited 0.\n\n` +
    `Return WRITE_SCHEMA with counts = ${JSON.stringify(counts)} (echo it, do not recompute it).`,
    { schema: WRITE_SCHEMA, label: 'persist:verdicts', phase: 'Persist' }
  )

  if (!written || !written.written) {
    log(`WARNING verdict persistence did not verify clean: ${written ? (written.blocked_reason || JSON.stringify(written.notes || [])) : 'writer agent returned null'}`)
  }

  // The coordinator's coverage ledger joins a covered cell to a CONFIRMED verdict
  // by class_id + cell key + asset_tag. Hand it the fields it needs so the join is
  // mechanical rather than re-derived from prose.
  const joinable = verdictRows.filter((r) => r.verdict === 'CONFIRMED')
  if (joinable.length) {
    await agent(
      `ROLE: COVERAGE JOIN HANDOFF (append-only bookkeeping; no judgment, no requests). cwd is ${BUNDLE}.\n` +
      `The coverage gate credits a cell as covered only when a VALID finding exists whose class_id + unit_refs + asset_tag\n` +
      `match that cell. Record the newly confirmed findings where the coordinator's INTEGRATE step will find them.\n\n` +
      `ASSET_DIR: ${ASSET_DIR}\n` +
      `CONFIRMED THIS RUN:\n${JSON.stringify(joinable.map((r) => ({ finding_id: r.finding_id, class_id: r.class_id, cell_key: r.cell_key, covers_cells: r.covers_cells || [], verdict_path: `${ASSET_DIR}/artifacts/validated/${r.finding_id}.json`, finding_json: r.finding_json, endpoint: r.endpoint, title: r.title })), null, 2)}\n\n` +
      `DO:\n` +
      `1. Create ${ASSET_DIR}/artifacts/coverage-join.json if absent (an object: {"findings": []}), else read it.\n` +
      `2. Append one entry per confirmed finding above: {finding_id, class_id, cell_key, covers_cells, verdict_path,\n` +
      `   finding_json, asset_tag: "${ASSET_TAG}", joined_at: <date -u +%Y-%m-%dT%H:%M:%SZ>}. If an entry for the same\n` +
      `   finding_id already exists, REPLACE that entry (idempotent re-run) — never duplicate it, never delete another\n` +
      `   finding's entry.\n` +
      `3. Verify each verdict_path in the entries actually exists on disk (test -f) and that its "verdict" field reads\n` +
      `   CONFIRMED. If one does not, remove that entry and report it — a join entry pointing at a non-confirmed verdict\n` +
      `   would let an uncovered cell be credited, which is the one thing this file must never do.`,
      { schema: WRITE_SCHEMA, label: 'coverage-join', phase: 'Persist' }
    )
  }
}

// ============================================================================
// PHASE: Report — the honest summary
// ============================================================================
phase('Report')

const pendingSummary = {
  over_cap: overCap,
  already_terminal: skippedResume,
  unvalidated: toValidate.slice(MAX_FINDINGS).map((f) => ({ id: f.id, class_id: f.class_id, dir: f.dir })),
}

const summary = await agent(
  `${DISCIPLINE}\n\n` +
  `ROLE: VALIDATION SUMMARY (read-back + one report; no requests, no new judgments). cwd is ${BUNDLE}.\n` +
  `The fidelity engine has finished for this asset. Record what it decided, from the files on disk — not from this prompt.\n\n` +
  `ASSET: ${ASSET_TAG}   ASSET_DIR: ${ASSET_DIR}   RUN_DIR: ${RUN_DIR}\n` +
  `COUNTS THIS RUN (echo them; verify against disk): ${JSON.stringify(counts)}\n` +
  `PER-FINDING OUTCOMES: ${JSON.stringify(verdictRows.map((r) => ({ finding_id: r.finding_id, verdict: r.verdict, class_id: r.class_id, failed_checks: r.failed_checks, refuters: r.refuters })))}\n` +
  `NOT VALIDATED THIS RUN (never silently dropped — they stay pending): ${JSON.stringify(pendingSummary)}\n\n` +
  `DO:\n` +
  `1. ls ${ASSET_DIR}/artifacts/validated ${ASSET_DIR}/artifacts/false-positives ${ASSET_DIR}/artifacts/dropped ${ASSET_DIR}/artifacts/cure and confirm\n` +
  `   the on-disk set matches the outcomes above. Report ANY disagreement in notes[] — a verdict that exists on disk but\n` +
  `   was not reported, or was reported but is not on disk, is a real defect and must be named, not smoothed over.\n` +
  `2. Write ${ASSET_DIR}/reports/validation-report.md:\n` +
  `     # Validation report - ${ASSET_TAG}\n` +
  `     ## Counts            total / confirmed / rejected / cure / dropped / infrastructure-failure\n` +
  `     ## Confirmed         per finding: id, class, severity, recomputed CVSS, the decisive output token, evidence package\n` +
  `     ## False positives   per finding: id, the refuter arguments verbatim and which check failed (this is the audit trail\n` +
  `                         that justifies calling it a false positive — quote the refuters, do not paraphrase them)\n` +
  `     ## Cure              per finding: id, failed_checks, missing_evidence (exactly what the next cure round must close)\n` +
  `     ## Dropped           per finding: id and why (out of scope / unclear / uncured)\n` +
  `     ## Not validated     the over-cap and already-terminal findings, so nothing is mistaken for "clean"\n` +
  `     ## Method            one paragraph: scope re-check, PoC re-run 3x with a silent negative control, evidence stat,\n` +
  `                         cross-identity where the class requires it, CVSS recomputation from the vector, CVE truth against\n` +
  `                         the frozen snapshot, and an adversarial quorum of ${VOTES} blind refuters where ALL must fail to refute.\n` +
  `3. Run and record verbatim: python3 tools/schema_check.py --kind all --run-dir ${RUN_DIR}\n` +
  `   (exit 2 = a malformed artifact: name the file; do not edit a verdict to make it pass).\n\n` +
  `Return SUMMARY_SCHEMA.`,
  {
    schema: {
      type: 'object', additionalProperties: true,
      required: ['report_path'],
      properties: {
        report_path: { type: 'string' },
        disk_disagreements: { type: 'array', items: { type: 'string' } },
        schema_check_exit: { type: 'integer' },
        notes: { type: 'array', items: { type: 'string' } },
        blocked_reason: { type: 'string' },
      },
    },
    label: 'summary', phase: 'Report',
  }
)

const status = counts.infra > 0
  ? 'PARTIAL_INFRA_FAILURE'
  : (counts.cure > 0 ? 'CURE_REQUIRED' : (counts.confirmed > 0 ? 'CONFIRMED' : (counts.rejected > 0 || counts.dropped > 0 ? 'NO_CONFIRMED_FINDINGS' : 'NO_FINDINGS')))

log(`validate ${ASSET_TAG}: ${counts.confirmed} confirmed, ${counts.rejected} rejected, ${counts.cure} cure, ${counts.dropped} dropped (of ${counts.total})`)

return {
  status: status,
  asset_tag: ASSET_TAG,
  asset_dir: ASSET_DIR,
  run_dir: RUN_DIR,
  scope_ref: SCOPE_REF,
  counts: counts,
  votes_per_finding: VOTES,
  repair_enabled: REPAIR,
  findings: verdictRows.map((r) => ({
    finding_id: r.finding_id,
    class_id: r.class_id,
    cell_key: r.cell_key,
    covers_cells: r.covers_cells || [],
    title: r.title,
    verdict: r.verdict,
    severity_claimed: r.claim_severity,
    cvss: r.cvss,
    failed_checks: r.failed_checks,
    missing_evidence: r.missing_evidence,
    refuters: r.refuters,
    cure_cycles: r.cure_cycles,
    reason: r.reason,
    verdict_path: `${ASSET_DIR}/artifacts/${terminalSubdir(r.verdict)}/${r.finding_id}.json`,
  })),
  confirmed: verdictRows.filter((r) => r.verdict === 'CONFIRMED').map((r) => r.finding_id),
  rejected: verdictRows.filter((r) => r.verdict === 'REJECTED').map((r) => r.finding_id),
  cure: verdictRows.filter((r) => r.verdict === 'CURE').map((r) => r.finding_id),
  dropped: verdictRows.filter((r) => r.verdict === 'DROPPED').map((r) => r.finding_id),
  pending: pendingSummary,
  report_path: summary ? summary.report_path : `${ASSET_DIR}/reports/validation-report.md`,
  coverage_join: `${ASSET_DIR}/artifacts/coverage-join.json`,
  notes: (summary && Array.isArray(summary.notes)) ? summary.notes : [],
  disk_disagreements: (summary && Array.isArray(summary.disk_disagreements)) ? summary.disk_disagreements : [],
  blocked_reason: summary ? (summary.blocked_reason || '') : 'summary agent returned null',
}
