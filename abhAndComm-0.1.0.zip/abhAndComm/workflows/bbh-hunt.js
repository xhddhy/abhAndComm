// ============================================================================
// bbh-hunt.js — the bug-bounty pipeline CONDUCTOR (DSH workflow script body).
//
// This file is the plain-JavaScript BODY a DSH `workflow` tool call passes as
// `script`. It is NOT a module: no `export`, no TypeScript, no imports. The only
// capabilities available are agent() / pipeline() / parallel() / phase() / log()
// / args. There is no filesystem, no network, no timer and no Node API here: the
// AGENTS do all I/O, this script only coordinates and threads data between them.
//
// Sandbox determinism: never Date.now(), new Date() or Math.random(). Every
// timestamp in every artifact is produced by an agent shelling out to `date -u`.
//
// PIPELINE (the design this implements, in order):
//
//   SCOPE -> RECON-LITE (known assets only: NO subdomain enum, NO nuclei)
//         -> [CHECKPOINT 1: asset x vulnerability-class table, human confirms]
//         -> SURFACE QUEUE (queues everything, eliminates nothing)
//         -> SLICE per asset (surface flags + coverage-matrix cells + playbooks)
//         -> PER-ASSET COORDINATOR FAN-OUT (one coordinator per asset = the fork)
//              -> executor batch (1-2)
//              -> validate (blind, fidelity)
//                   -> not pass -> cure (named gaps only) -> re-validate
//                   -> pass -> chain (A->B->C)
//                        -> 7-Question Gate
//                             -> fail -> cure -> back to validate
//                             -> pass -> repro pack
//         -> [CHECKPOINT 2: hand over the runbook, WAIT for manual reproduction]
//         -> [CHECKPOINT 3: human confirms; FINALIZE]
//
// A workflow script cannot itself pause for a human. The checkpoints are
// therefore implemented as RETURNS: the script returns a checkpoint envelope
// ({status:'CHECKPOINT_1'|...}) so the calling session can ask the user, and the
// caller re-invokes this same script with `args.resume_from` (plus the same
// `args.run_dir`) to continue from the next stage, reading all state from disk.
// See workflows/README.md for the exact call shapes.
//
// Every tool invocation in every prompt below is a FROZEN CLI from tools/README.md.
// Every artifact conforms to contracts/*.schema.json and is checked with
// tools/schema_check.py at the stage boundary that produced it.
// ============================================================================

// ---- args ------------------------------------------------------------------
const a = (args && typeof args === 'object' && !Array.isArray(args)) ? args : {}

const SCOPE_FILE_IN = a.scope_file || null
const SCOPE_INLINE = (a.scope && typeof a.scope === 'object' && !Array.isArray(a.scope)) ? a.scope : null
const RUN_DIR_IN = a.run_dir || null
const HUMAN_CONFIRMATION = (typeof a.human_confirmation === 'string' && a.human_confirmation.trim())
  ? a.human_confirmation.trim()
  : (a.human_confirmation === true ? 'confirmed' : null)
const MAX_EXPERIMENTS = Number(a.max_experiments) > 0 ? Math.floor(Number(a.max_experiments)) : 30
const MAX_CURE_CYCLES = Number(a.max_cure_cycles) >= 0 ? Math.floor(Number(a.max_cure_cycles)) : 3
const PARALLEL_ASSETS = Number(a.parallel_assets) > 0 ? Math.floor(Number(a.parallel_assets)) : 3
const VOTES = Number(a.votes) > 0 ? Math.floor(Number(a.votes)) : 3
const NVD_CACHE_DIR = a.nvd_cache_dir || null
const KEV_SNAPSHOT = a.kev_snapshot || null
const DRY_RUN = a.dry_run === true
const BUNDLE = 'the bundle root (your cwd: it contains tools/README.md, contracts/ and workflows/)'

const ONLY_ASSETS = Array.isArray(a.only_assets)
  ? a.only_assets.map((x) => String(x).trim()).filter(Boolean)
  : (typeof a.only_assets === 'string' && a.only_assets.trim()
    ? a.only_assets.split(',').map((x) => x.trim()).filter(Boolean)
    : null)

// ---- stage machine ---------------------------------------------------------
// `resume_from` names the LAST COMPLETED milestone; work continues at the stage
// AFTER it. A bare stage name resumes AT that stage. Documented in README.md.
const ORDER = ['scope', 'recon', 'checkpoint-1', 'surface', 'slice', 'fanout', 'checkpoint-2', 'checkpoint-3', 'finalize']

function normaliseResume(v) {
  const s = String(v == null ? '' : v).trim().toLowerCase().replace(/_/g, '-')
  if (!s) return null
  const alias = {
    'cp1': 'checkpoint-1', 'one': 'checkpoint-1',
    'cp2': 'checkpoint-2', 'two': 'checkpoint-2',
    'cp3': 'checkpoint-3', 'three': 'checkpoint-3',
    'recon-lite': 'recon', 'classify': 'recon',
    'queue': 'surface', 'surface-queue': 'surface',
    'slices': 'slice',
    'coordinator': 'fanout', 'coordinators': 'fanout', 'hunt': 'fanout',
    'report': 'finalize', 'done': 'finalize',
  }
  return alias[s] || (ORDER.indexOf(s) >= 0 ? s : null)
}

// resume token -> the stage we actually begin executing
const RESUME_START = {
  'scope': 'recon',
  'recon': 'checkpoint-1',
  'checkpoint-1': 'surface',
  'surface': 'slice',
  'slice': 'fanout',
  'fanout': 'checkpoint-2',
  'checkpoint-2': 'checkpoint-3',
  'checkpoint-3': 'finalize',
  'finalize': 'finalize',
}

const RESUME_TOKEN = normaliseResume(a.resume_from)
const START_STAGE = RESUME_TOKEN ? RESUME_START[RESUME_TOKEN] : 'scope'
const START_IDX = ORDER.indexOf(START_STAGE)

function started(stage) { return ORDER.indexOf(stage) >= START_IDX }

// ---- shared prompt fragments ----------------------------------------------
const DISCIPLINE = [
  'STANDING DISCIPLINE (bug-bounty edition — every agent on this run obeys it):',
  '- SCOPE IS LAW. Every URL you touch must pass `python3 tools/bbh_scope.py check --scope <scope.json> --url <url>`.',
  '  exit 0 = in scope, 1 = OUT OF SCOPE (do not send the request), 2 = unclear (third party / staging / no safe harbor) -> record and STOP on that host.',
  '- NO DISCOVERY, by design: no subdomain enumeration (subfinder/amass/crt.sh/assetfinder), no nuclei, no port-sweeps of hosts',
  '  the program did not name. This pipeline classifies the assets the program already told us about.',
  '- NO BRUTE FORCE, no password spraying, no DoS, no destructive or cross-tenant writes. Obey scope.json roe{}',
  '  (rate_limit_rps, no_dos, no_bruteforce, allow_writes): allow_writes=false still permits a create-then-delete in your OWN tenant, never a write to another tenant.',
  '- DIAGNOSE BEFORE RETRY: read the error, check the prerequisite, then act. Never re-send a cosmetic variant.',
  '- EVIDENCE OR IT DID NOT HAPPEN. A claim without a raw request/response on disk is not a finding; an artifact whose',
  '  path does not exist is a failed check, not a rounding note.',
  '- TOKEN DISCIPLINE: attack-chain.md is capped at 50 lines and REWRITTEN every batch; all bookkeeping (attack-chain +',
  '  session-memory + experiments + tools logs) must stay under 10% of the mission token budget. Bullets, never prose.',
  '- TIMESTAMPS: you have no clock in the script layer. Always get one by running `date -u +%Y-%m-%dT%H:%M:%SZ`.',
  '- STAY IN YOUR LANE: write only inside the output directory you were given. Never write another asset\'s tree.',
  '- AUTONOMY: never ask the human a question. If something is genuinely blocked, record it as a named block with the',
  '  command that failed and its exit code, and return.',
].join('\n')

const SCHEMA_CHECK_NOTE = [
  'STAGE GATE: before you return, run',
  '  python3 tools/schema_check.py --kind all --run-dir <RUN_DIR>',
  'Exit 0 = every artifact under the run dir validates against contracts/*.schema.json. Exit 2 = a malformed/unreadable',
  'artifact: fix it and re-run. A stage whose output does not validate has NOT completed — report that in blocked_reason',
  'rather than claiming success. (`--kind all --run-dir` does not yet know about artifacts that do not exist; a stage that',
  'was never run is not an error here, it is simply absent.)',
].join('\n')

function nvdNote() {
  const cache = NVD_CACHE_DIR
    ? `--cache-dir ${NVD_CACHE_DIR}`
    : '--cache-dir <RUN_DIR>/artifacts/nvd-cache'
  return [
    'FROZEN CVE OPERANDS (reproducibility — always pass the cache dir so a replayed verdict reads the snapshot, not the network):',
    `  python3 tools/nvd_lookup.py <CVE-ID> --json ${cache}`,
    KEV_SNAPSHOT ? `  CISA KEV snapshot: ${KEV_SNAPSHOT}` : '  CISA KEV: read from the nvd_lookup.py output (kev_listed).',
  ].join('\n')
}

// ---- helpers ---------------------------------------------------------------
function slash(p) { return String(p || '').replace(/\/+$/, '') }

async function inChunks(items, size, fn) {
  const out = []
  const width = size > 0 ? size : 1
  for (let i = 0; i < items.length; i += width) {
    const chunk = items.slice(i, i + width)
    const res = await parallel(chunk.map((it) => () => fn(it)))
    for (const r of res) out.push(r)
  }
  return out
}

const checkpoints = []
const notes = []

function checkpoint(id, detail) {
  checkpoints.push(Object.assign({ id: id }, detail || {}))
}

// ---- DRY RUN ---------------------------------------------------------------
if (DRY_RUN) {
  log('bbh-hunt: dry_run=true — returning the planned stage/tool/agent graph without spawning anything.')
  return {
    status: 'DRY_RUN',
    run_dir: RUN_DIR_IN,
    resume_from: RESUME_TOKEN,
    start_stage: START_STAGE,
    options: {
      max_experiments: MAX_EXPERIMENTS,
      max_cure_cycles: MAX_CURE_CYCLES,
      parallel_assets: PARALLEL_ASSETS,
      votes: VOTES,
      only_assets: ONLY_ASSETS,
      nvd_cache_dir: NVD_CACHE_DIR,
      kev_snapshot: KEV_SNAPSHOT,
    },
    stages: [
      { stage: 'scope', agents: 1, tools: ['tools/schema_check.py --kind scope <scope.json>', 'tools/bbh_scope.py check --scope <scope.json> --url <each asset>'] },
      { stage: 'recon', agents: '1 per in-scope target + 1 classify/merge', tools: ['tools/bbh_classify.py --recon-dir <RUN_DIR>/recon/<target> --scope <scope.json> --out <RUN_DIR>/classification-<target>.json', 'tools/schema_check.py --kind all --run-dir <RUN_DIR>'] },
      { stage: 'checkpoint-1', agents: 1, tools: [], returns: 'CHECKPOINT_1 envelope' },
      { stage: 'surface', agents: 1, tools: ['tools/queue_build.py --classification <RUN_DIR>/classification.json --cells-dir <RUN_DIR>/assets --out <RUN_DIR>/queue.json --explain'] },
      { stage: 'slice', agents: 1, tools: ['tools/surface_build.py', 'tools/cells_build.py', 'tools/slice_build.py', 'tools/queue_build.py (re-run, folds in coverage-cell leads)', 'tools/coverage_gate.py --run-dir <RUN_DIR>'] },
      { stage: 'fanout', agents: '1 coordinator per asset (chunks of parallel_assets)', tools: ['workflows/bbh-coordinator.js per asset', 'tools/cvss_recompute.py', 'tools/nvd_lookup.py --json', 'tools/bbh_scope.py check', 'tools/schema_check.py --kind verdict <file>'] },
      { stage: 'checkpoint-2', agents: '1 per confirmed finding', tools: ['tools/repro_pack.py', 'tools/coverage_gate.py --run-dir <RUN_DIR>', 'tools/lead_board.py --run-dir <RUN_DIR> show'], returns: 'CHECKPOINT_2 envelope' },
      { stage: 'checkpoint-3', agents: 0, tools: [], returns: 'CHECKPOINT_3 envelope until args.human_confirmation is supplied' },
      { stage: 'finalize', agents: 1, tools: ['tools/coverage_gate.py --run-dir <RUN_DIR>', 'tools/schema_check.py --kind all --run-dir <RUN_DIR>', 'tools/lead_board.py --run-dir <RUN_DIR> show'] },
    ],
    next: { resume_from: 'scope', note: 're-invoke with dry_run omitted (or false) to execute' },
  }
}

log(`bbh-hunt: start_stage=${START_STAGE}${RESUME_TOKEN ? ` (resume_from=${RESUME_TOKEN})` : ''} run_dir=${RUN_DIR_IN || '<to be resolved in SCOPE>'}`)

// ============================================================================
// STAGE 0 — SCOPE
// ============================================================================
phase('Scope')

let RUN_DIR = RUN_DIR_IN ? slash(RUN_DIR_IN) : null
let SCOPE_FILE = SCOPE_FILE_IN
let engagement = null
let platform = null
let safeHarbor = false
let ROE = { rate_limit_rps: 5, no_dos: true, no_bruteforce: true, allow_writes: false, max_requests_per_asset: 20000 }
let CREDS_ENV = []
let ASSETS = []

const SCOPE_SCHEMA = {
  type: 'object', additionalProperties: true,
  required: ['run_dir', 'scope_file', 'assets'],
  properties: {
    run_dir: { type: 'string' },
    scope_file: { type: 'string' },
    engagement: { type: 'string' },
    platform: { type: 'string' },
    program: { type: 'string' },
    safe_harbor: { type: 'boolean' },
    roe: { type: 'object', additionalProperties: true },
    creds_env: { type: 'array', items: { type: 'string' } },
    assets: {
      type: 'array',
      items: {
        type: 'object', additionalProperties: true,
        required: ['asset_id', 'asset_tag', 'kind', 'value'],
        properties: {
          asset_id: { type: 'string' },
          asset_tag: { type: 'string' },
          kind: { type: 'string' },
          value: { type: 'string' },
          apex: { type: 'boolean' },
          path_exclusions: { type: 'array', items: { type: 'string' } },
        },
      },
    },
    probe_results: {
      type: 'array',
      items: {
        type: 'object', additionalProperties: true,
        required: ['url', 'exit_code'],
        properties: {
          url: { type: 'string' },
          exit_code: { type: 'integer' },
          meaning: { type: 'string' },
        },
      },
    },
    schema_check_exit: { type: 'integer' },
    blocked_reason: { type: 'string' },
    notes: { type: 'array', items: { type: 'string' } },
  },
}

if (started('scope')) {
  const scopeAgent = await agent(
    `${DISCIPLINE}\n\n` +
    `ROLE: SCOPE INTAKE (stage 0). cwd is ${BUNDLE}. You establish the run directory and prove the scope file is usable.\n` +
    `This is the ONLY stage allowed to create the run tree. Nothing downstream may re-derive it.\n\n` +
    `INPUTS\n` +
    `  scope_file arg : ${SCOPE_FILE_IN || '<none supplied>'}\n` +
    `  run_dir arg    : ${RUN_DIR_IN || '<none supplied — you must derive it>'}\n` +
    (SCOPE_INLINE ? `  inline scope   : ${JSON.stringify(SCOPE_INLINE)}\n` : '') +
    `  contract       : contracts/scope.schema.json (schema id bbh/scope/v1)\n\n` +
    `DO, in order:\n` +
    `1. RESOLVE THE SCOPE FILE.\n` +
    (SCOPE_FILE_IN
      ? `   The caller supplied scope_file=${SCOPE_FILE_IN}. Verify it exists and is readable (test -f). Do NOT rewrite it.\n`
      : (SCOPE_INLINE
        ? `   No scope_file was supplied; an inline scope object was. Materialise it with the frozen CLI (add any --asset/--exclude\n` +
          `   flags the object needs; --asset takes KIND:VALUE[:apex] with KIND in the contract's enum):\n` +
          `     python3 tools/bbh_scope.py init --engagement <slug> [--platform <platform>] [--program <name>] \\\n` +
          `         [--safe-harbor|--no-safe-harbor] --asset '<kind>:<value>[:apex]' [--asset ...] \\\n` +
          `         [--exclude '<host|pattern>'] [--path-exclusion '<asset>=<glob>'] [--creds-env <NAME>] \\\n` +
          `         [--roe-json '<json>'] --out <run_dir>/scope.json\n` +
          `   --asset is repeatable and KIND must be one of web, api, mobile, ip, cidr, source_repo, wildcard; asset_id values\n` +
          `   are assigned a1, a2, ... in argument order. Map the inline object's keys onto these flags exactly: assets[].kind and\n` +
          `   assets[].value -> --asset, assets[].apex -> the ':apex' suffix, assets[].path_exclusions ->\n` +
          `   --path-exclusion '<value>=<glob>', out_of_scope[] -> --exclude, creds_env[] -> --creds-env, roe -> --roe-json,\n` +
          `   safe_harbor -> --safe-harbor/--no-safe-harbor. NEVER drop an exclusion.\n` +
          `   Then verify the file you just wrote. Inline scope object: ${JSON.stringify(SCOPE_INLINE)}\n`
        : `   NEITHER scope_file nor an inline scope object was supplied. Return immediately with assets:[] and\n` +
          `   blocked_reason='no scope supplied: pass args.scope_file or args.scope'. Do NOT invent a scope.\n`)) +
    `2. RESOLVE THE RUN DIRECTORY. If run_dir was supplied use it verbatim (absolute). Else derive\n` +
    `   <repo>/runs/<engagement-slug-from-the-scope-file> and report its ABSOLUTE path (compute with\n` +
    `   \`cd <path> && pwd\`; never guess). Create the tree:\n` +
    `     mkdir -p <RUN_DIR>/{recon,assets,slices,reports,repro,artifacts/nvd-cache}\n` +
    `   The run dir is the ONLY place this pipeline writes. ${NVD_CACHE_DIR ? `The frozen NVD cache dir for this run is ${NVD_CACHE_DIR}.` : `Use <RUN_DIR>/artifacts/nvd-cache as the frozen NVD cache dir for the whole run and report it back.`}\n` +
    `3. VALIDATE THE SCOPE against contracts/scope.schema.json:\n` +
    `     python3 tools/schema_check.py --kind scope <scope_file>\n` +
    `   Record the exit code. If the tool rejects the KIND (exit 2, message says unknown/unsupported kind) fall back to a\n` +
    `   plain check: the file parses as JSON and carries schema='bbh/scope/v1', a non-empty engagement and a non-empty\n` +
    `   assets[] whose entries each have asset_id, kind (a contract enum value) and value. Say which route you used.\n` +
    `4. PROVE THE SCOPE ACTUALLY DECIDES. For EVERY asset, run the frozen checker against a representative URL and record\n` +
    `   the exit code verbatim:\n` +
    `     python3 tools/bbh_scope.py check --scope <scope_file> --url <representative-url-for-that-asset>\n` +
    `   exit 0 = in scope, 1 = out of scope, 2 = unclear (third party CNAME / staging / no safe harbor).\n` +
    `   An asset that returns 1 must be reported in notes and excluded from assets[]. An asset that returns 2 must be\n` +
    `   reported AND excluded (unclear is never assumed in scope) unless the program text in the scope file says otherwise —\n` +
    `   in that case quote the line. Also probe one deliberately out-of-scope URL if the file lists out_of_scope entries, so\n` +
    `   we have evidence the checker fires.\n` +
    `5. For each surviving asset compute asset_tag = the host (or host:port) that keys its slice directory: the value\n` +
    `   lowercased with any scheme and trailing slash stripped. Same tag the tools will use.\n` +
    `6. Echo the rules of engagement and the creds_env NAMES verbatim into your return — downstream executors enforce them.\n\n` +
    `HARD RULES: never edit the scope file; never widen the scope; never probe a host that is absent from it.\n` +
    `Return SCOPE_SCHEMA. blocked_reason is a STRING: the empty string means 'no block'; otherwise it is the reason. Set it if` +
    ` step 1 or step 3 failed.`,
    { schema: SCOPE_SCHEMA, label: 'scope:intake', phase: 'Scope' }
  )

  if (!scopeAgent) {
    return { status: 'BLOCKED', stage: 'scope', reason: 'scope intake agent returned null', checkpoints: checkpoints }
  }
  if (scopeAgent.blocked_reason) {
    return { status: 'BLOCKED', stage: 'scope', reason: scopeAgent.blocked_reason, checkpoints: checkpoints }
  }
  RUN_DIR = slash(scopeAgent.run_dir)
  SCOPE_FILE = scopeAgent.scope_file
  engagement = scopeAgent.engagement || null
  platform = scopeAgent.platform || null
  safeHarbor = scopeAgent.safe_harbor === true
  if (scopeAgent.roe && typeof scopeAgent.roe === 'object') ROE = scopeAgent.roe
  CREDS_ENV = Array.isArray(scopeAgent.creds_env) ? scopeAgent.creds_env : []
  ASSETS = Array.isArray(scopeAgent.assets) ? scopeAgent.assets : []
  if (Array.isArray(scopeAgent.notes)) for (const n of scopeAgent.notes) notes.push(n)

  log(`scope: run_dir=${RUN_DIR} assets=${ASSETS.length} safe_harbor=${safeHarbor}`)
  if (!ASSETS.length) {
    return { status: 'BLOCKED', stage: 'scope', reason: 'scope resolved to zero in-scope assets', run_dir: RUN_DIR, checkpoints: checkpoints }
  }
} else {
  // Resumed past SCOPE: RUN_DIR and SCOPE_FILE must come from args. The stage
  // agents re-read every fact from disk, so this script only needs the paths.
  if (!RUN_DIR || !SCOPE_FILE) {
    return {
      status: 'BLOCKED',
      stage: START_STAGE,
      reason: 'resume_from was given but args.run_dir (and args.scope_file) were not: a resumed run reads all state from disk and cannot guess the run directory.',
      checkpoints: checkpoints,
    }
  }
  notes.push('Resumed past SCOPE: the asset list is re-derived from <RUN_DIR>/slices/*.json at the fan-out stage.')
}

// ============================================================================
// STAGE 1 — RECON-LITE (known assets only)
// ============================================================================
phase('Recon')

const RECON_SCHEMA = {
  type: 'object', additionalProperties: true,
  required: ['target', 'recon_dir', 'files_written'],
  properties: {
    target: { type: 'string' },
    asset_tags: { type: 'array', items: { type: 'string' } },
    recon_dir: { type: 'string' },
    files_written: { type: 'array', items: { type: 'string' } },
    classification_out: { type: 'string' },
    classify_exit: { type: 'integer' },
    bucket_counts: { type: 'object', additionalProperties: true },
    unclassified_observations: { type: 'array', items: { type: 'string' } },
    blocked_reason: { type: 'string' },
  },
}

const MERGE_SCHEMA = {
  type: 'object', additionalProperties: true,
  required: ['classification_out', 'asset_count'],
  properties: {
    classification_out: { type: 'string' },
    asset_count: { type: 'integer' },
    asset_tags: { type: 'array', items: { type: 'string' } },
    negative_finding_count: { type: 'integer' },
    schema_check_exit: { type: 'integer' },
    per_target_files: { type: 'array', items: { type: 'string' } },
    blocked_reason: { type: 'string' },
  },
}

let CLASSIFICATION = `${RUN_DIR}/classification.json`
let RECON_DIRS = []
let assetTags = ASSETS.map((x) => x.asset_tag).filter(Boolean)

if (started('recon')) {
  // One recon-lite agent per in-scope target we can crawl (web/api/wildcard hosts).
  const crawlable = ASSETS.filter((x) => ['web', 'api', 'wildcard'].indexOf(String(x.kind)) >= 0)
  const nonCrawlable = ASSETS.filter((x) => ['web', 'api', 'wildcard'].indexOf(String(x.kind)) < 0)

  const reconResults = await inChunks(crawlable, PARALLEL_ASSETS, (asset) => {
    const tag = asset.asset_tag
    const dir = `${RUN_DIR}/recon/${tag}`
    return agent(
      `${DISCIPLINE}\n\n` +
      `ROLE: RECON-LITE EXECUTOR (stage 1) for ONE already-known asset. You observe and record; you never claim a finding.\n` +
      `cwd is ${BUNDLE}.\n\n` +
      `ASSET: asset_id=${asset.asset_id} kind=${asset.kind} value=${asset.value} asset_tag=${tag} apex=${asset.apex === true}\n` +
      `SCOPE FILE: ${SCOPE_FILE}   RUN DIR: ${RUN_DIR}\n` +
      `ROE (verbatim from scope.json): ${JSON.stringify(ROE)}\n` +
      `CREDS ENV NAMES available to you (NAMES only — read the value from the environment at runtime, never print it): ${JSON.stringify(CREDS_ENV)}\n` +
      `CONTRACT YOU FEED: contracts/classification.schema.json (schema id bbh/classification/v1). Your job is to produce the\n` +
      `RAW INPUT TREE that tools/bbh_classify.py buckets — it does not scan, it reads files.\n\n` +
      `ABSOLUTE PROHIBITIONS (this is the whole point of the stage — violating it invalidates the run):\n` +
      `  * NO subdomain enumeration of any kind: no subfinder, amass, assetfinder, crt.sh, certspotter, chaos, dnsx brute force.\n` +
      `  * NO nuclei, no template scanning, no vulnerability scanner.\n` +
      `  * NO host discovery: do not touch a hostname that is not an in-scope asset value or an address you observed in this\n` +
      `    asset's own responses/JS. Anything else you notice is a NOTE, never a probe.\n` +
      `  * NO crawling outside the asset's host, and no path matching scope.json assets[].path_exclusions.\n` +
      `  * Respect roe.rate_limit_rps (default 5): serialise with a small sleep; never burst. No DoS, no brute force,\n` +
      `    no fuzzing with big wordlists, ${ROE.allow_writes === true ? 'writes allowed per roe (still never destructive/cross-tenant)' : 'NO state-changing requests at all'}.\n\n` +
      `BEFORE EVERY REQUEST: python3 tools/bbh_scope.py check --scope ${SCOPE_FILE} --url <url>\n` +
      `  exit 0 -> send it. exit 1 -> do NOT send; record the URL under unclassified_observations. exit 2 -> do NOT send; record it too.\n\n` +
      `WRITE THE ABH RECON TREE under ${dir}/ with EXACTLY these names (bbh_classify.py reads them; create only what you\n` +
      `actually observed — an absent file is fine, an empty invented one is not):\n` +
      `  live/urls.txt                      one live-in-scope URL per line (status code + content-type go in PROVENANCE.md)\n` +
      `  urls/all.txt                       every URL collected, live or not\n` +
      `  api-endpoints.txt                  endpoints that look like an application API (JSON body, versioned path, /api/, /graphql, REST verbs)\n` +
      `  params/<name>.txt                  one file per source family (e.g. params/gf-idor.txt, params/arjun.txt); lines = URLs carrying those params\n` +
      `  candidates/xss.txt candidates/ssrf.txt candidates/idor.txt candidates/sqli.txt candidates/redirect.txt candidates/lfi.txt\n` +
      `                                     URLs whose parameters are ATTACK CANDIDATES. A line here is a claim that the parameter exists\n` +
      `                                     and reaches the server — it must be backed by a request you actually made.\n` +
      `  js/endpoints.txt                   endpoints recovered from JS bundles\n` +
      `  js/secrets.txt                     hardcoded keys/tokens/internal hosts recovered from JS. NEVER a live secret in full:\n` +
      `                                     write first4+last4 only, plus the bundle URL and the surrounding context.\n` +
      `  config-exposure.txt                exposed config/backup/.git/.env/.map paths you observed\n` +
      `  admin/<name>.txt                   admin/management/debug/internal paths you observed\n` +
      `  ports/<host>.txt                   ONLY when the program exposes this asset as an ip/cidr; per-port lines from a\n` +
      `                                     bounded scan of THAT asset only (never a sweep)\n` +
      `  PROVENANCE.md                      MANDATORY. A table: file -> the exact curl/tool invocation that produced each line\n` +
      `                                     group, plus the raw status code. Every bucket entry must cite the request that\n` +
      `                                     produced it (classification.schema.json says so in its description).\n\n` +
      `Also write ${dir}/NOTES.md: tech fingerprint you actually observed (server header verbatim, framework, version token\n` +
      `ONLY if a version string was really seen), TLS yes/no, page title, and anything you could not classify.\n\n` +
      `Source material, in the order to prefer it: the program's own documentation/API docs if the scope file points at any,\n` +
      `the asset's robots.txt/sitemap.xml/.well-known/, a single crawl of the asset root to depth 2, its JS bundles, and any\n` +
      `credentials the engagement was given (creds_env) for an authenticated pass. If a credentials NAMED in creds_env is not\n` +
      `set in your environment, skip the authenticated pass and say so — chained request counts matter more than coverage here.\n\n` +
      `THEN CLASSIFY, once, with the frozen CLI:\n` +
      `  python3 tools/bbh_classify.py --recon-dir ${dir} --scope ${SCOPE_FILE} --out ${RUN_DIR}/classification-${tag}.json\n` +
      `Capture its stdout and its exit code verbatim (exit 0 ok, 1 a real negative result, 2 bad input). Read the JSON it\n` +
      `wrote and report the per-bucket counts. Do NOT hand-edit its output — it is code-produced on purpose.\n\n` +
      `Return RECON_SCHEMA. blocked_reason is a STRING: '' means no block. Use it only for a hard environmental failure (asset\n` +
      `unreachable at the network\n` +
      `level for every request); an empty asset returns zero buckets, not a block.`,
      { schema: RECON_SCHEMA, label: `recon:${tag}`, phase: 'Recon' }
    )
  })

  const good = reconResults.filter(Boolean)
  RECON_DIRS = good.map((r) => r.recon_dir).filter(Boolean)
  for (const r of good) {
    if (r.classification_out) notes.push(`recon ${r.target}: classified into ${r.classification_out} (exit ${r.classify_exit})`)
    if (Array.isArray(r.unclassified_observations)) for (const u of r.unclassified_observations.slice(0, 20)) notes.push(`observed-not-probed: ${u}`)
  }
  for (const asset of nonCrawlable) {
    notes.push(`asset ${asset.asset_tag} (kind=${asset.kind}) has no HTTP surface to crawl: recorded as a negative finding for the queue, never silently dropped.`)
  }

  // Merge the per-target classifications into the single run-level artifact.
  const perTarget = good.map((r) => r.classification_out).filter(Boolean)
  const merge = await agent(
    `${DISCIPLINE}\n\n` +
    `ROLE: CLASSIFICATION MERGE (stage 1, deterministic bookkeeping — no judgment, no new claims). cwd is ${BUNDLE}.\n\n` +
    `RUN DIR: ${RUN_DIR}\nSCOPE FILE: ${SCOPE_FILE}\n` +
    `PER-TARGET CLASSIFICATIONS (each conforms to contracts/classification.schema.json, schema id bbh/classification/v1):\n` +
    `${perTarget.length ? perTarget.map((p) => `  - ${p}`).join('\n') : '  <none — no target produced a classification>'}\n` +
    `ASSETS THAT PRODUCED NOTHING: ${JSON.stringify(nonCrawlable.map((x) => ({ asset_id: x.asset_id, asset_tag: x.asset_tag, kind: x.kind, reason: 'no HTTP surface: kind is not web/api/wildcard' })))}\n\n` +
    `DO:\n` +
    `1. Read every per-target JSON above (and its sibling recon NOTES.md when a field is missing).\n` +
    `2. Write ${RUN_DIR}/classification.json — ONE valid bbh/classification/v1 object:\n` +
    `   { "schema":"bbh/classification/v1", "target": <the engagement apex/most representative host>,\n` +
    `     "engagement": <from scope.json>, "generated_at": <output of \`date -u +%Y-%m-%dT%H:%M:%SZ\`>,\n` +
    `     "assets": [ <every per-target asset object, VERBATIM — same asset_id/asset_tag/apex/server/tech/version/tls/status_code/title\n` +
    `                   and the same bucket entries with their evidence strings. Union duplicate asset_tag entries by keeping\n` +
    `                   every distinct bucket entry from both; never drop a signal to make the merge tidy.> ],\n` +
    `     "negative_findings": [ <every asset probed with nothing to show, INCLUDING the no-HTTP-surface assets listed above,\n` +
    `                   each {asset_id, reason}. 'not looked at' and 'looked at, empty' must stay distinguishable.> ] }\n` +
    `   If exactly one per-target file exists and there is nothing to add, a byte-faithful copy is the correct merge.\n` +
    `3. Do NOT invent a bucket entry. Do NOT re-key, re-order or de-duplicate within an asset's buckets.\n` +
    `4. Run: python3 tools/schema_check.py --kind all --run-dir ${RUN_DIR}  — record the exit code.\n` +
    `   ${SCHEMA_CHECK_NOTE}\n\n` +
    `Return MERGE_SCHEMA with the absolute path, the asset_tag list and the counts.`,
    { schema: MERGE_SCHEMA, label: 'classify:merge', phase: 'Recon' }
  )

  if (!merge || merge.blocked_reason) {
    return {
      status: 'BLOCKED', stage: 'recon', run_dir: RUN_DIR,
      reason: merge ? merge.blocked_reason : 'classification merge agent returned null',
      checkpoints: checkpoints, notes: notes,
    }
  }
  CLASSIFICATION = merge.classification_out || CLASSIFICATION
  if (Array.isArray(merge.asset_tags) && merge.asset_tags.length) assetTags = merge.asset_tags
  log(`recon: ${merge.asset_count} asset(s) classified -> ${CLASSIFICATION}`)
}

// ============================================================================
// CHECKPOINT 1 — asset x vulnerability-class table, human confirms
// ============================================================================
phase('Checkpoint 1')

const CP1_SCHEMA = {
  type: 'object', additionalProperties: true,
  required: ['table_path', 'rows'],
  properties: {
    table_path: { type: 'string' },
    table_markdown: { type: 'string' },
    rows: {
      type: 'array',
      items: {
        type: 'object', additionalProperties: true,
        required: ['asset_tag'],
        properties: {
          asset_tag: { type: 'string' },
          kind: { type: 'string' },
          bucket_counts: { type: 'object', additionalProperties: true },
          signal_count: { type: 'integer' },
          candidate_classes: { type: 'array', items: { type: 'string' } },
          notes: { type: 'string' },
        },
      },
    },
    skipped: {
      type: 'array',
      items: {
        type: 'object', additionalProperties: true,
        required: ['asset_tag', 'reason'],
        properties: { asset_tag: { type: 'string' }, reason: { type: 'string' } },
      },
    },
    total_candidate_cells_estimate: { type: 'integer' },
    question: { type: 'string' },
    blocked_reason: { type: 'string' },
  },
}

if (started('checkpoint-1')) {
  const cp1 = await agent(
    `${DISCIPLINE}\n\n` +
    `ROLE: CHECKPOINT 1 BRIEFING OFFICER (human-in-the-loop gate). cwd is ${BUNDLE}. You produce the table a human must\n` +
    `approve before any active work starts. You do NOT send requests. You read files and translate them.\n\n` +
    `RUN DIR: ${RUN_DIR}\n` +
    `CLASSIFICATION (bbh/classification/v1): ${CLASSIFICATION}\n` +
    `SCOPE (bbh/scope/v1): ${SCOPE_FILE}\n` +
    `CATALOGUE (the class ids you must use — read them, do not invent ids): catalog/bounty-coverage-matrix.json\n` +
    `  If that file is absent, fall back to the class_id column of the catalogue's human companion or, failing that, the\n` +
    `  class table in contracts/ — and say in the table which source you used.\n\n` +
    `WRITE ${RUN_DIR}/checkpoint-1.md containing, in this order:\n` +
    `  # Checkpoint 1 — asset x vulnerability-class classification\n` +
    `  ## Run facts      engagement, platform, safe_harbor, roe verbatim, creds_env NAMES, asset count, date (\`date -u +%Y-%m-%dT%H:%M:%SZ\`)\n` +
    `  ## Table 1 — signals per asset\n` +
    `     | asset_tag | kind | api_endpoints | auth_paths | interesting_params | js_secrets | admin_paths | cloud | takeover | ports |\n` +
    `     Counts from the classification buckets. Then one line per asset naming the concrete top signals (the actual URLs).\n` +
    `  ## Table 2 — candidate vulnerability classes per asset\n` +
    `     | asset_tag | candidate class_id | why this asset suggests it | confidence |\n` +
    `     Derive the candidate classes ONLY from observed buckets, e.g. interesting_params with an id-like parameter ->\n` +
    `     API1-BOLA / XC-EXISTENCE-ORACLE; auth_paths -> API2-BROKEN-AUTH; api_endpoints with JSON bodies -> API3-BOPLA;\n` +
    `     js_secrets -> XC-SECRET-EXPOSURE; server-fetched URL params -> API7-SSRF; admin_paths -> API5-BFLA; an apex with a\n` +
    `     CDN -> XC-SUBDOMAIN-ORIGIN; a fingerprinted version -> WEB-A06-COMPONENTS; always-applicable classes\n` +
    `     (API4-RESOURCE, API8-MISCONFIG, API9-INVENTORY, XC-SECURITY-HEADERS, XC-VERBOSE-ERRORS) for every HTTP asset.\n` +
    `     Mark each row confidence: high | medium | low and cite the bucket entry that justifies it.\n` +
    `  ## Not looked at / looked at and empty\n` +
    `     Every negative_findings entry and every asset that returned nothing, with its reason.\n` +
    `  ## What this checkpoint does NOT decide\n` +
    `     The queue stage that follows eliminates NOTHING: every signal becomes a lead and the lowest band is P3 ('after\n` +
    `     P1 and P2'), never 'skip'. The code-produced applicable-cell set is computed later by tools/cells_build.py from the\n` +
    `     surface flags — it can only grow the work, never shrink it, and this table is an estimate, not the work-list.\n` +
    `  ## Question for the human\n` +
    `     The single question the caller must put to the user (see below).\n\n` +
    `HARD RULES: no request is sent in this stage. Do not soften or drop a signal to make the table look clean — a table the\n` +
    `human can audit is the deliverable. The table must render in under 120 lines; if an asset has more than 12 top signals,\n` +
    `list the 12 with the highest attack potential and write '(N more in classification.json)'.\n\n` +
    `Return CP1_SCHEMA. rows[] must have one entry per asset in the table (bucket_counts = the raw bucket counts, signal_count\n` +
    `= their sum, candidate_classes = the class ids you listed). question = the exact question the caller should ask, e.g.\n` +
    `"Approve this asset x class table? Everything is queued and nothing is eliminated; reply with the assets to drop (if any)\n` +
    `and any class you want prioritised."`,
    { schema: CP1_SCHEMA, label: 'checkpoint-1', phase: 'Checkpoint 1' }
  )

  if (!cp1 || cp1.blocked_reason) {
    return {
      status: 'BLOCKED', stage: 'checkpoint-1', run_dir: RUN_DIR,
      reason: cp1 ? cp1.blocked_reason : 'checkpoint-1 agent returned null',
      checkpoints: checkpoints, notes: notes,
    }
  }

  checkpoint('CHECKPOINT_1', {
    kind: 'human-approval',
    table: cp1.table_path,
    raised_at_stage: 'checkpoint-1',
    resume_with: 'checkpoint-1',
  })

  return {
    status: 'CHECKPOINT_1',
    run_dir: RUN_DIR,
    scope_file: SCOPE_FILE,
    engagement: engagement,
    platform: platform,
    safe_harbor: safeHarbor,
    roe: ROE,
    creds_env: CREDS_ENV,
    assets: ASSETS,
    artifacts: {
      scope: SCOPE_FILE,
      recon_root: `${RUN_DIR}/recon`,
      recon_dirs: RECON_DIRS,
      classification: CLASSIFICATION,
      checkpoint_table: cp1.table_path,
    },
    table_markdown: cp1.table_markdown || '',
    rows: cp1.rows || [],
    skipped: cp1.skipped || [],
    question: cp1.question || 'Approve this asset x vulnerability-class table? Nothing is eliminated at the next stage — everything is queued.',
    what_happens_next: 'SURFACE: tools/queue_build.py turns every classified signal into a priced lead (bbh/queue/v1). No signal is dropped; the lowest band is P3.',
    resume: {
      resume_from: 'checkpoint-1',
      run_dir: RUN_DIR,
      scope_file: SCOPE_FILE,
      note: 'Re-invoke this workflow with these args to continue. Add args.only_assets=[...] to restrict the run, args.human_confirmation="<note>" to record the approval text.',
    },
    checkpoints: checkpoints,
    notes: notes,
  }
}

// ============================================================================
// STAGE 2 — SURFACE QUEUE (queues everything, eliminates nothing)
// ============================================================================
phase('Surface')

const QUEUE_SCHEMA = {
  type: 'object', additionalProperties: true,
  required: ['queue_path', 'lead_count'],
  properties: {
    queue_path: { type: 'string' },
    lead_count: { type: 'integer' },
    tier_counts: { type: 'object', additionalProperties: true },
    coverage_seed: { type: 'object', additionalProperties: true },
    explain_path: { type: 'string' },
    queue_build_exit: { type: 'integer' },
    schema_check_exit: { type: 'integer' },
    notes: { type: 'array', items: { type: 'string' } },
    blocked_reason: { type: 'string' },
  },
}

const QUEUE_PATH = `${RUN_DIR}/queue.json`

if (started('surface')) {
  const q = await agent(
    `${DISCIPLINE}\n\n` +
    `ROLE: SURFACE QUEUE (stage 2, deterministic tool run + read-back; no judgment). cwd is ${BUNDLE}.\n\n` +
    `RUN DIR: ${RUN_DIR}\n` +
    `CLASSIFICATION: ${CLASSIFICATION}\n` +
    `OUT: ${QUEUE_PATH}   (contract: contracts/surface-queue.schema.json, schema id bbh/queue/v1)\n\n` +
    `DO:\n` +
    `1. Run the frozen queue builder and capture BOTH its stdout and its exit code verbatim:\n` +
    `     python3 tools/queue_build.py --classification ${CLASSIFICATION} --cells-dir ${RUN_DIR}/assets --out ${QUEUE_PATH} --explain > ${RUN_DIR}/reports/queue-explain.txt 2>&1\n` +
    `   The --explain table is the human-auditable per-lead arithmetic; keep it at ${RUN_DIR}/reports/queue-explain.txt.\n` +
    `   NOTE ON ORDERING (expected, not an error): at this point ${RUN_DIR}/assets/ has no per-asset inventory yet, so\n` +
    `   coverage-cell leads cannot exist and only abh-bucket/js-secret/auth-path/admin-path/param leads are produced. The\n` +
    `   slice stage RE-RUNS this exact command to fold the code-produced coverage-cell leads in; queue_build.py is idempotent\n` +
    `   and preserves every lead's status across a re-run, so nothing is lost by running it twice. Say so in notes.\n` +
    `2. Read ${QUEUE_PATH} and report: lead_count, the P1/P2/P3 tier counts, every source value present, and the coverage_seed.\n` +
    `3. ASSERT THE DESIGN RULE and report the result explicitly: there must be no kill list and no 'skip'/'eliminated' status\n` +
    `   anywhere in the file — every lead's status must be one of queued|investigating|candidate|reported|exhausted, and the\n` +
    `   lowest tier present must be P3. If you find any lead with a status outside that enum, or any signal from the\n` +
    `   classification that produced no lead at all, that is a BLOCKER: name the missing signal, do not paper over it.\n` +
    `4. Run: python3 tools/schema_check.py --kind all --run-dir ${RUN_DIR}  — record the exit code.\n` +
    `   ${SCHEMA_CHECK_NOTE}\n\n` +
    `Return QUEUE_SCHEMA.`,
    { schema: QUEUE_SCHEMA, label: 'surface:queue', phase: 'Surface' }
  )

  if (!q || q.blocked_reason) {
    return {
      status: 'BLOCKED', stage: 'surface', run_dir: RUN_DIR,
      reason: q ? q.blocked_reason : 'surface queue agent returned null',
      checkpoints: checkpoints, notes: notes,
    }
  }
  log(`surface: ${q.lead_count} lead(s) queued (nothing eliminated) -> ${q.queue_path}`)
}

// ============================================================================
// STAGE 3 — SLICE per asset (surface flags + coverage cells + playbooks)
// ============================================================================
phase('Slice')

const SLICE_ITEM_SCHEMA = {
  type: 'object', additionalProperties: true,
  required: ['asset_tag', 'slice_path', 'output_dir'],
  properties: {
    asset_tag: { type: 'string' },
    asset_id: { type: 'string' },
    slice_path: { type: 'string' },
    output_dir: { type: 'string' },
    cell_count: { type: 'integer' },
    lead_count: { type: 'integer' },
    class_ids: { type: 'array', items: { type: 'string' } },
    playbook_classes: { type: 'array', items: { type: 'string' } },
    surface_units: { type: 'integer' },
    gate_complete: { type: 'boolean' },
  },
}

const SLICE_SCHEMA = {
  type: 'object', additionalProperties: true,
  required: ['slices', 'asset_count'],
  properties: {
    asset_count: { type: 'integer' },
    slices: {
      type: 'array',
      items: SLICE_ITEM_SCHEMA,
    },
    queue_rerun_lead_count: { type: 'integer' },
    coverage_gate_exit: { type: 'integer' },
    coverage_gate_meaning: { type: 'string' },
    applicable_total: { type: 'integer' },
    schema_check_exit: { type: 'integer' },
    surface_explain_path: { type: 'string' },
    skipped_assets: { type: 'array', items: { type: 'object', additionalProperties: true } },
    notes: { type: 'array', items: { type: 'string' } },
    blocked_reason: { type: 'string' },
  },
}

let SLICES = []
let APPLICABLE_TOTAL = 0

if (started('slice')) {
  const sl = await agent(
    `${DISCIPLINE}\n\n` +
    `ROLE: SLICE BUILDER (stage 3, deterministic tool runs + read-back; no judgment). cwd is ${BUNDLE}.\n` +
    `You turn the classification into, per asset: the communitytools surface flags, the CODE-PRODUCED applicable cells,\n` +
    `and the self-contained work order every coordinator will receive.\n\n` +
    `RUN DIR: ${RUN_DIR}\nSCOPE: ${SCOPE_FILE}\nCLASSIFICATION: ${CLASSIFICATION}\n\n` +
    `CONTRACTS: contracts/surface.v2.schema.json (surface/v2), contracts/slice.schema.json (bbh/slice/v1).\n` +
    `CATALOG: catalog/bounty-coverage-matrix.json\n\n` +
    `RUN, in exactly this order, capturing stdout AND exit code for each:\n` +
    `1. python3 tools/surface_build.py --classification ${CLASSIFICATION} --scope ${SCOPE_FILE} --assets-dir ${RUN_DIR}/assets --explain > ${RUN_DIR}/reports/surface-explain.txt 2>&1\n` +
    `   -> writes <RUN_DIR>/assets/<asset_tag>/recon/inventory/surface.json for every in-scope asset.\n` +
    `   AUDIT ITS DESIGN RULES and report violations verbatim (they are bugs, not style):\n` +
    `     (a) units[].flags may contain ONLY the 18 agent-set flags in the surface/v2 contract. Any of the 7 derived flags\n` +
    `         (http_listener, tls_listener, version_fingerprinted, has_api, is_apex, serves_js, mobile_app) written here is a bug.\n` +
    `     (b) every flag must have a matching \"<flag> <- <why>\" line in units[].evidence.\n` +
    `     (c) unit_id must be u-NNNN in stable sorted-address order and never renumbered.\n` +
    `     (d) an asset excluded by scope must be skipped WITH a printed reason, never silently.\n` +
    `     (e) an asset whose files are all empty must produce a surface.json with an empty units[] — NOT be omitted.\n` +
    `2. For EVERY asset dir that now has recon/inventory/surface.json:\n` +
    `     python3 tools/cells_build.py --asset-dir ${RUN_DIR}/assets/<asset_tag> --catalog catalog/bounty-coverage-matrix.json\n` +
    `   -> <asset-dir>/applicability/cells.json. This work-list is CODE-PRODUCED and un-fabricatable: an agent cannot shrink\n` +
    `   it. Record the applicable cell count per asset.\n` +
    `3. python3 tools/slice_build.py --run-dir ${RUN_DIR} --scope ${SCOPE_FILE}\n` +
    `   -> ${RUN_DIR}/slices/<asset_tag>.json, one bbh/slice/v1 per asset, with absolute output_dir, the mirrored\n` +
    `   surface_flags, the applicable_cells list, the leads for THIS asset, and class_playbooks resolved to concrete\n` +
    `   reference-file paths (already resolved to concrete files, never a directory).\n` +
    `4. RE-RUN the queue now that cells exist, so coverage-cell leads are folded in. Pass --prior-queue so every status and\n` +
    `   touched_by recorded on the first run is preserved explicitly rather than relying on the in-place default:\n` +
    `     cp ${QUEUE_PATH} ${RUN_DIR}/queue.prior.json\n` +
    `     python3 tools/queue_build.py --classification ${CLASSIFICATION} --cells-dir ${RUN_DIR}/assets --prior-queue ${RUN_DIR}/queue.prior.json --out ${QUEUE_PATH} --explain > ${RUN_DIR}/reports/queue-explain.txt 2>&1\n` +
    `   Report the new lead count. A lead count that DECREASED across the two runs is a blocker — report it.\n` +
    `5. STAGE-3 GATE, read carefully because exit 1 is EXPECTED here. Run BOTH modes; they answer different questions:\n` +
    `     python3 tools/coverage_gate.py --run-dir ${RUN_DIR}                    # --mode bounty (default): THE COMPLETION OBLIGATION\n` +
    `     python3 tools/coverage_gate.py --run-dir ${RUN_DIR} --mode strict      # 100%-of-applicable-cells: a REPORTED DIAGNOSTIC, not a gate\n` +
    `   Which one is the obligation is a deliberate design choice, so do not invert it: bounty mode gates on worked P1 leads,\n` +
    `   claims that exceed their evidence, findings left without a verdict, and fabricated N/As. Strict mode additionally\n` +
    `   demands every applicable cell, which a bug-bounty run does not reach — you are one of many hunters and the program\n` +
    `   pays per valid finding, so a 100% bar is one the operator learns to ignore. Strict's value here is its BACKLOG: the\n` +
    `   untouched-by-tier and untouched-by-class counts in reports/coverage-matrix.json tell the next session where to dig.\n` +
    `   No work has happened yet, so BOTH modes exit 1 at this point; that is the correct baseline and NOT a stage failure.\n` +
    `   Report which it was:\n` +
    `     exit 0 -> coverage already complete (record it; unexpected at this point)\n` +
    `     exit 1 -> baseline incomplete, EXPECTED. Record applicable/covered and the untouched backlog from ${RUN_DIR}/reports/coverage-matrix.json.\n` +
    `     exit 2 -> inputs unreadable: that IS a blocker. Name the missing input.\n` +
    `   This gate writes ${RUN_DIR}/reports/coverage-matrix.json on every run, pass or fail — that file is the pre-work\n` +
    `   baseline the fan-out is measured against.\n` +
    `6. python3 tools/schema_check.py --kind all --run-dir ${RUN_DIR}  — record the exit code.\n` +
    `   ${SCHEMA_CHECK_NOTE}\n\n` +
    `FOR EACH SLICE, additionally verify and report: slice.output_dir is ABSOLUTE; applicable_cells is non-empty for any asset\n` +
    `that has at least one surface unit; every class_id in applicable_cells exists in the catalog; class_playbooks has an\n` +
    `entry for every class in applicable_cells (a class with no playbook entry is a real gap — report it, do not fill it in\n` +
    `yourself); and slice.roe/creds_env are populated from scope.json.\n\n` +
    `NO SLICE IS SKIPPED SILENTLY. List every asset in ${RUN_DIR}/assets/ that did NOT get a slice in skipped_assets[] with a\n` +
    `reason. If an asset was excluded by scope, quote surface_build.py's printed reason.\n\n` +
    `Return SLICE_SCHEMA.`,
    { schema: SLICE_SCHEMA, label: 'slice:build', phase: 'Slice' }
  )

  if (!sl || sl.blocked_reason) {
    return {
      status: 'BLOCKED', stage: 'slice', run_dir: RUN_DIR,
      reason: sl ? sl.blocked_reason : 'slice builder agent returned null',
      checkpoints: checkpoints, notes: notes,
    }
  }
  SLICES = (sl.slices || []).filter(Boolean)
  APPLICABLE_TOTAL = Number(sl.applicable_total) || SLICES.reduce((n, s) => n + (Number(s.cell_count) || 0), 0)
  if (Array.isArray(sl.notes)) for (const n of sl.notes) notes.push(n)
  log(`slice: ${SLICES.length} slice(s), ${APPLICABLE_TOTAL} applicable cell(s). coverage gate exit=${sl.coverage_gate_exit} (${sl.coverage_gate_meaning || ''})`)
  if (!SLICES.length) {
    return {
      status: 'BLOCKED', stage: 'slice', run_dir: RUN_DIR,
      reason: 'no slice was produced for any asset — nothing to fan out to',
      coverage_gate_exit: sl.coverage_gate_exit, checkpoints: checkpoints, notes: notes,
    }
  }
} else {
  notes.push('Resumed past SLICE: slice facts are re-derived from <RUN_DIR>/slices/*.json by the fan-out stage below.')
}

// ============================================================================
// STAGE 4 — PER-ASSET COORDINATOR FAN-OUT (the fork)
// ============================================================================
phase('Fanout')

// A resumed run has no in-memory slice list: re-derive it from disk. This is the
// same file the SLICE stage wrote, so the two paths cannot disagree.
let assetRuns = []
if (started('fanout')) {
if (!SLICES.length) {
  const disc = await agent(
    `${DISCIPLINE}\n\n` +
    `ROLE: SLICE DISCOVERY (deterministic read-back; no judgment, no requests). cwd is ${BUNDLE}.\n` +
    `A run is resuming at the fan-out stage. Re-derive the work list from disk — never from memory.\n\n` +
    `RUN DIR: ${RUN_DIR}\nSLICES DIR: ${RUN_DIR}/slices\nCONTRACT: contracts/slice.schema.json (schema id bbh/slice/v1)\n\n` +
    `DO:\n` +
    `1. ls -1 ${RUN_DIR}/slices/*.json  (and ${RUN_DIR}/assets/ to cross-check).\n` +
    `2. For EACH slice JSON, read it and report asset_tag, asset_id, the object's own path as slice_path, and output_dir\n` +
    `   VERBATIM (output_dir must be absolute — if it is relative, say so in notes and treat it as a blocker, because a\n` +
    `   relative output_dir resolves differently for different agents).\n` +
    `3. Also report cell_count = the length of applicable_cells, lead_count = the length of leads, class_ids = the distinct\n` +
    `   class_id values in leads (or applicable_cells when a lead carries none), playbook_classes = the keys of\n` +
    `   class_playbooks, surface_units = the number of entries in surface_flags.units, and gate_complete = slice.gate.complete.\n` +
    `4. Report any asset directory under ${RUN_DIR}/assets/ that has NO slice, and any slice whose output_dir does not exist.\n\n` +
    `Return SLICE_SCHEMA (asset_count = slices.length). Do not modify any slice.`,
    { schema: SLICE_SCHEMA, label: 'fanout:discover-slices', phase: 'Fanout' }
  )
  if (!disc || disc.blocked_reason) {
    return {
      status: 'BLOCKED', stage: 'fanout', run_dir: RUN_DIR,
      reason: disc ? disc.blocked_reason : 'slice discovery agent returned null — cannot fan out without a work list',
      checkpoints: checkpoints, notes: notes,
    }
  }
  SLICES = (disc.slices || []).filter(Boolean)
  if (Array.isArray(disc.notes)) { /* SLICE_SCHEMA has no notes key on discovery; ignore */ }
  if (!SLICES.length) {
    return { status: 'BLOCKED', stage: 'fanout', run_dir: RUN_DIR, reason: 'no slice JSON found under ' + RUN_DIR + '/slices', checkpoints: checkpoints, notes: notes }
  }
}

// args.only_assets: restrict this invocation to a subset (a single asset re-run,
// or a human dropping an asset at CHECKPOINT 1). Nothing is deleted from disk —
// the unselected slices simply are not worked by THIS invocation.
if (ONLY_ASSETS && ONLY_ASSETS.length) {
  const want = new Set(ONLY_ASSETS)
  const kept = SLICES.filter((s) => want.has(s.asset_tag) || (s.asset_id && want.has(s.asset_id)))
  const dropped = SLICES.filter((s) => !(want.has(s.asset_tag) || (s.asset_id && want.has(s.asset_id))))
  for (const d of dropped) notes.push(`only_assets: ${d.asset_tag} exists on disk but was NOT worked by this invocation (its slice and any prior results are untouched).`)
  if (!kept.length) {
    return {
      status: 'BLOCKED', stage: 'fanout', run_dir: RUN_DIR,
      reason: 'only_assets matched no slice: ' + JSON.stringify(ONLY_ASSETS) + ' (available: ' + JSON.stringify(SLICES.map((s) => s.asset_tag)) + ')',
      checkpoints: checkpoints, notes: notes,
    }
  }
  SLICES = kept
  log(`only_assets: working ${SLICES.length} of the slices on disk -> ${SLICES.map((s) => s.asset_tag).join(', ')}`)
}

const COORD_SCHEMA = {
  type: 'object', additionalProperties: true,
  required: ['status', 'asset_tag', 'output_dir'],
  properties: {
    status: { type: 'string', description: 'COVERAGE_COMPLETE | INCOMPLETE_RESUMABLE | INCOMPLETE_COVERAGE | BLOCKED' },
    asset_tag: { type: 'string' },
    output_dir: { type: 'string' },
    experiments_run: { type: 'integer' },
    batches: { type: 'integer' },
    coverage: {
      type: 'object', additionalProperties: true,
      properties: {
        applicable: { type: 'integer' },
        covered: { type: 'integer' },
        pending: { type: 'integer' },
        ratio: { type: 'number' },
        complete: { type: 'boolean' },
        gate_exit: { type: 'integer' },
      },
    },
    findings: {
      type: 'array',
      items: {
        type: 'object', additionalProperties: true,
        required: ['finding_id', 'verdict'],
        properties: {
          finding_id: { type: 'string' },
          class_id: { type: 'string' },
          title: { type: 'string' },
          severity: { type: 'string' },
          verdict: { type: 'string', description: 'CONFIRMED | REJECTED | CURE | DROPPED' },
          cure_cycles: { type: 'integer' },
          verdict_path: { type: 'string' },
          seven_q_verdict: { type: 'string', description: 'PASS | KILL | CURE | NOT_RUN' },
          seven_q_path: { type: 'string' },
          chain_used: { type: 'string' },
          repro_dir: { type: 'string' },
        },
      },
    },
    checkpoints: { type: 'array', items: { type: 'object', additionalProperties: true } },
    blocks: { type: 'array', items: { type: 'string' } },
    notes: { type: 'array', items: { type: 'string' } },
  },
}

// The coordinator lane is a WORKFLOW, not a prompt: workflows/bbh-coordinator.js
// is the per-asset engine. The fan-out agent launches it through the DSH
// `workflow` tool (script = the file's contents, args = the slice handoff). If
// the nesting is refused, the SAME contract is executed inline by that agent.
function coordinatorPrompt(slice) {
  return `${DISCIPLINE}\n\n` +
    `ROLE: PER-ASSET COORDINATOR LAUNCHER — one asset, one coordinator. cwd is ${BUNDLE}.\n` +
    `You are the "fork session" for asset ${slice.asset_tag}. You own this asset's tree and NOTHING else.\n\n` +
    `SLICE (the complete, self-contained work order — read it first): ${slice.slice_path}\n` +
    `OUTPUT_DIR (your write boundary; absolute): ${slice.output_dir}\n` +
    `ASSET TAG: ${slice.asset_tag}\n` +
    `APPLICABLE CELLS: ${slice.cell_count != null ? slice.cell_count : '<see slice>'}   LEADS: ${slice.lead_count != null ? slice.lead_count : '<see slice>'}\n` +
    `CONTRACTS: contracts/slice.schema.json, contracts/finding.schema.json, contracts/validation-verdict.schema.json,\n` +
    `           contracts/seven-questions.schema.json, contracts/repro-runbook.schema.json,\n` +
    `           contracts/surface.v2.schema.json, contracts/surface-queue.schema.json\n` +
    `FROZEN CLI CONTRACT: tools/README.md (every command you and your children run comes from there, verbatim)\n` +
    `ROLE/CONTEXT CONTRACTS: workflows/bbh-coordinator.js encodes them (three-file state, blind validator lane, cure lane).\n\n` +
    `YOUR TASK — run the per-asset coordinator engine:\n` +
    `1. Read workflows/bbh-coordinator.js (it is a DSH workflow script body: plain JS, top-level await, ends with return).\n` +
    `2. Launch it with the DSH workflow tool, passing meta + script=the file's contents + args:\n` +
    `     meta = { name: 'bbh-coordinator', description: 'one asset, one coordinator',\n` +
    `              phases: [{title:'Bootstrap'},{title:'Loop'},{title:'Validate'},{title:'Chain'},{title:'Gate'},{title:'Repro'},{title:'Report'}] }\n` +
    `     args = { slice_file: '${slice.slice_path}', run_dir: '${RUN_DIR}', max_experiments: ${MAX_EXPERIMENTS},\n` +
    `              max_cure_cycles: ${MAX_CURE_CYCLES}, votes: ${VOTES}${NVD_CACHE_DIR ? `, nvd_cache_dir: '${NVD_CACHE_DIR}'` : ''}${KEV_SNAPSHOT ? `, kev_snapshot: '${KEV_SNAPSHOT}'` : ''} }\n` +
    `3. If the workflow tool refuses the nested call (or is unavailable to you), DO NOT STALL AND DO NOT ABANDON THE ASSET:\n` +
    `   execute the same contract yourself, inline, in this session, using the slice + contracts + tools above. The contract is\n` +
    `   fully specified in workflows/bbh-coordinator.js — the three-file state under OUTPUT_DIR (attack-chain.md <=50 lines\n` +
    `   rewritten every batch, session-memory.md append-only, experiments.md append-only E-NNN ledger with INTEGRATE as sole\n` +
    `   writer), think-before-every-batch with exactly 3 hypotheses and >=1 tagged [wildcard], 1-2 executors per batch,\n` +
    `   INTERLEAVED blind validation of each candidate the moment it materialises, the cure loop on ONLY the named\n` +
    `   failed_checks+missing_evidence with a FRESH validator each round (bound ${MAX_CURE_CYCLES}), the chain stage on\n` +
    `   CONFIRMED findings, the 7-Question Gate after the chain (a Q-failure returns to the cure loop with the failing\n` +
    `   question named), the repro pack on a 7Q PASS via tools/repro_pack.py, coverage-by-VALID, and a skeptic at experiments\n` +
    `   5/15/25. Budget: ${MAX_EXPERIMENTS} experiments.\n` +
    `4. Either way, verify the engine actually wrote what it claims: ls OUTPUT_DIR/attack-chain.md, session-memory.md,\n` +
    `   experiments.md and count the E- rows with:\n` +
    `     grep -c '^| E-' ${slice.output_dir}/experiments.md\n` +
    `   Then run the asset gate yourself, in BOTH modes, and record each exit code:\n` +
    `     python3 tools/coverage_gate.py --asset-dir ${slice.output_dir}\n` +
    `     python3 tools/coverage_gate.py --asset-dir ${slice.output_dir} --mode strict\n` +
    `   (exit 0 complete, 1 incomplete, 2 inputs unreadable. The DEFAULT bounty mode is the completion obligation for\n` +
    `   this engagement; --mode strict adds the 100%-of-applicable-cells bar, which a bounty run does not reach —\n` +
    `   read strict for its untouched-backlog counts, not as a pass/fail gate) and\n` +
    `     python3 tools/schema_check.py --kind all --run-dir ${RUN_DIR}\n\n` +
    `WHAT YOU MUST NOT DO: do not write outside ${slice.output_dir}; do not touch another asset's tree; do not re-plan the\n` +
    `slice (applicable_cells is CODE-PRODUCED and may not be shrunk — a cell can only be closed with a VALID finding, a\n` +
    `corroborated negative, or a justified N/A, and an agent setting a code-applicable cell to N/A is a hard fabrication FAIL);\n` +
    `do not merge your findings into another asset's report.\n\n` +
    `Return COORD_SCHEMA, transcribed from the engine's own return value (do not improve on it). Every path you return must be\n` +
    `one you verified exists. blocks[] must name any check you could not run with the exact command and its exit code.`
}

const coordinatorResults = await inChunks(SLICES, PARALLEL_ASSETS, (slice) => {
  return agent(coordinatorPrompt(slice), {
    schema: COORD_SCHEMA,
    label: `coordinator:${slice.asset_tag}`,
    phase: 'Fanout',
  })
})

assetRuns = coordinatorResults.filter(Boolean)
for (const r of assetRuns) {
  const c = r.coverage || {}
  log(`asset ${r.asset_tag}: status=${r.status} findings=${(r.findings || []).length} experiments=${r.experiments_run} coverage=${c.covered}/${c.applicable}`)
}
const coordFailed = SLICES.filter((s) => !assetRuns.some((r) => r && r.asset_tag === s.asset_tag))
for (const s of coordFailed) notes.push(`coordinator for ${s.asset_tag} returned null — that asset is NOT covered; re-run with resume_from='fanout' and only_assets=['${s.asset_tag}']`)
} else {
  notes.push('Resumed past FANOUT: per-asset results are re-derived from disk by the checkpoint-2 / finalize agents.')
}

// ============================================================================
// CHECKPOINT 2 — hand over the runbook, WAIT for manual reproduction
// ============================================================================
phase('Checkpoint 2')

const REPRO_SCHEMA = {
  type: 'object', additionalProperties: true,
  required: ['built'],
  properties: {
    built: {
      type: 'array',
      items: {
        type: 'object', additionalProperties: true,
        required: ['finding_id', 'runbook_path'],
        properties: {
          finding_id: { type: 'string' },
          asset_tag: { type: 'string' },
          runbook_path: { type: 'string' },
          pack_dir: { type: 'string' },
          zip_path: { type: 'string' },
          time_estimate_min: { type: 'integer' },
          repro_pack_exit: { type: 'integer' },
        },
      },
    },
    refused: {
      type: 'array',
      items: {
        type: 'object', additionalProperties: true,
        required: ['finding_id', 'reason'],
        properties: { finding_id: { type: 'string' }, reason: { type: 'string' } },
      },
    },
    handover_path: { type: 'string' },
    coverage_gate_exit: { type: 'integer' },
    coverage_matrix_path: { type: 'string' },
    lead_board_path: { type: 'string' },
    schema_check_exit: { type: 'integer' },
    blocked_reason: { type: 'string' },
  },
}

// Findings eligible for a repro pack: CONFIRMED at the fidelity gate AND PASS at
// the 7-Question Gate. tools/repro_pack.py enforces this itself and exits 1 with
// the reason, so a bad candidate is rejected by code, not by our bookkeeping.
const eligible = []
for (const r of assetRuns) {
  for (const f of (r.findings || [])) {
    if (!f || !f.finding_id) continue
    if (String(f.verdict).toUpperCase() === 'CONFIRMED' && String(f.seven_q_verdict).toUpperCase() === 'PASS') {
      eligible.push({ asset_tag: r.asset_tag, output_dir: r.output_dir, f: f })
    }
  }
}

if (started('checkpoint-2')) {
  let repro = { built: [], refused: [] }

  if (eligible.length) {
    repro = await agent(
      `${DISCIPLINE}\n\n` +
      `ROLE: REPRO PACK BUILDER + HANDOVER AUTHOR (checkpoint 2, tool runner). cwd is ${BUNDLE}.\n` +
      `The deliverable of this whole pipeline is a runbook a human can follow BY HAND. You build one pack per eligible\n` +
      `finding and then write the single handover document the human acts on.\n\n` +
      `RUN DIR: ${RUN_DIR}\n` +
      `ELIGIBLE FINDINGS (fidelity verdict CONFIRMED and 7-Question Gate PASS — both are code/tool-checked on disk):\n` +
      `${JSON.stringify(eligible.map((e) => ({ asset_tag: e.asset_tag, output_dir: e.output_dir, finding_id: e.f.finding_id, class_id: e.f.class_id, verdict_path: e.f.verdict_path, seven_q_path: e.f.seven_q_path, title: e.f.title, severity: e.f.severity })), null, 2)}\n\n` +
      `FOR EACH finding, run the frozen packer:\n` +
      `  python3 tools/repro_pack.py --finding-dir <output_dir>/findings/finding-<NNN> \\\n` +
      `      --verdict <verdict_path> --seven-q <seven_q_path> --out ${RUN_DIR}/repro/<finding_id>\n` +
      `  (finding-dir is the directory whose name matches the finding; confirm it with ls before running.)\n` +
      `  It writes RUNBOOK.md (rendered from bbh/repro/v1, every command fenced, install section first, TROUBLESHOOTING from\n` +
      `  gotchas + each step's on_failure), pack/ (poc/, evidence/, env/install.sh, verify.sh) and a zip next to the runbook.\n` +
      `  It REFUSES to build when the Stage-6 verdict is not CONFIRMED or the Stage-8 verdict is not PASS (exit 1, printing\n` +
      `  REFUSED: with the reason; exit 2 means an input could not be read at all) — record that verbatim in refused[] and\n` +
      `  keep going; never work around it, never hand-render a runbook.\n` +
      `  Then run the pack's own non-interactive check and record its output:\n` +
      `    bash ${RUN_DIR}/repro/<finding_id>/pack/verify.sh\n` +
      `  A verify.sh that FAILS is not a blocker for the handover — it is the most useful thing the human can look at. Record\n` +
      `  which step failed and its output.\n\n` +
      `THEN write ${RUN_DIR}/reports/handover.md — the document the human reads:\n` +
      `  # Handover — reproduce these by hand\n` +
      `  ## What was proven      one line per confirmed finding: id, class, severity, one-line impact, evidence path\n` +
      `  ## Runbooks            | finding | runbook | est. minutes | verify.sh result | — with the ABSOLUTE path of each RUNBOOK.md\n` +
      `  ## How to reproduce    the short version: cd to the pack dir, read RUNBOOK.md, follow setup then reproduce top to bottom.\n` +
      `                         State that every command in the runbook is copy-pasteable and that the operator must compare against\n` +
      `                         the printed 'expected' column, not against their intuition.\n` +
      `  ## What to look for    per finding: success_criteria and the single most likely false-positive trap from verify.false_positive_traps\n` +
      `  ## Not confirmed       every finding whose verdict was REJECTED / CURE / DROPPED, with the failing check names from its\n` +
      `                         verdict (these live in artifacts/false-positives/ and artifacts/dropped/ and are audit-only)\n` +
      `  ## Coverage gaps       the coverage_gate output below, verbatim: which applicable cells are still pending\n` +
      `  ## Stop conditions     what the human should do if a runbook does NOT reproduce: record the exact diverging step and its\n` +
      `                         output, do not improvise a different exploit, and do not report it as confirmed.\n\n` +
      `FINALLY run and record verbatim:\n` +
      `  python3 tools/coverage_gate.py --run-dir ${RUN_DIR}                     (default bounty mode)\n` +
      `  python3 tools/coverage_gate.py --run-dir ${RUN_DIR}                 (bounty mode — the completion obligation)\n` +
      `  python3 tools/coverage_gate.py --run-dir ${RUN_DIR} --mode strict   (100%-of-cells diagnostic: read the backlog)\n` +
      `  (exit 0 complete, 1 incomplete, 2 unreadable — report BOTH exit codes and both per-cell detail blocks)\n` +
      `  python3 tools/lead_board.py --run-dir ${RUN_DIR} show > ${RUN_DIR}/reports/lead-board.txt 2>&1\n` +
      `  python3 tools/schema_check.py --kind all --run-dir ${RUN_DIR}\n` +
      `  ${SCHEMA_CHECK_NOTE}\n\n` +
      `Return REPRO_SCHEMA. handover_path is the absolute path you wrote. coverage_matrix_path is\n` +
      `${RUN_DIR}/reports/coverage-matrix.json after the gate run.`,
      { schema: REPRO_SCHEMA, label: 'checkpoint-2:repro-packs', phase: 'Checkpoint 2' }
    )
  } else {
    // Still produce a handover: "nothing confirmed yet" is a real deliverable.
    repro = await agent(
      `${DISCIPLINE}\n\n` +
      `ROLE: HANDOVER AUTHOR (checkpoint 2, no eligible findings). cwd is ${BUNDLE}.\n` +
      `No finding reached (fidelity verdict CONFIRMED AND 7-Question Gate PASS), so there is nothing to pack. Your job is to\n` +
      `make that state auditable rather than silent.\n\n` +
      `RUN DIR: ${RUN_DIR}\n` +
      `PER-ASSET RESULTS: ${JSON.stringify(assetRuns.map((r) => ({ asset_tag: r.asset_tag, status: r.status, experiments_run: r.experiments_run, coverage: r.coverage, findings: (r.findings || []).map((f) => ({ finding_id: f.finding_id, class_id: f.class_id, verdict: f.verdict, cure_cycles: f.cure_cycles, seven_q_verdict: f.seven_q_verdict, verdict_path: f.verdict_path, seven_q_path: f.seven_q_path })), blocks: r.blocks })), null, 2)}\n\n` +
      `DO:\n` +
      `1. Run and record verbatim:\n` +
      `     python3 tools/coverage_gate.py --run-dir ${RUN_DIR}\n` +
      `     python3 tools/coverage_gate.py --run-dir ${RUN_DIR} --mode strict\n` +
      `     python3 tools/lead_board.py --run-dir ${RUN_DIR} show > ${RUN_DIR}/reports/lead-board.txt 2>&1\n` +
      `     python3 tools/schema_check.py --kind all --run-dir ${RUN_DIR}\n` +
      `2. Write ${RUN_DIR}/reports/handover.md with: what ran (batches/experiments per asset), every candidate and its exact\n` +
      `   terminal verdict + failed_checks (read each verdict JSON in artifacts/false-positives/ and artifacts/dropped/ and quote\n` +
      `   failed_checks + reason), the coverage gate's per-cell detail verbatim, and a concrete NEXT ACTION list: for each pending\n` +
      `   cell the highest-value named lead and the asset coordinator should work it; for each CURE-stuck finding the exact gap\n` +
      `   that stayed unclosed. Do not write 'no findings' and stop — a coverage report with named gaps is the deliverable.\n\n` +
      `Return REPRO_SCHEMA with built:[] and refused[] listing every candidate and why it was not packable.`,
      { schema: REPRO_SCHEMA, label: 'checkpoint-2:handover', phase: 'Checkpoint 2' }
    )
  }

  if (!repro || repro.blocked_reason) {
    return {
      status: 'BLOCKED', stage: 'checkpoint-2', run_dir: RUN_DIR,
      reason: repro ? repro.blocked_reason : 'checkpoint-2 agent returned null',
      checkpoints: checkpoints, notes: notes,
    }
  }

  checkpoint('CHECKPOINT_2', {
    kind: 'human-reproduction',
    handover: repro.handover_path,
    runbooks: (repro.built || []).map((b) => b.runbook_path),
    coverage_gate_exit: repro.coverage_gate_exit,
    raised_at_stage: 'checkpoint-2',
    resume_with: 'checkpoint-2',
  })

  return {
    status: 'CHECKPOINT_2',
    run_dir: RUN_DIR,
    engagement: engagement,
    artifacts: {
      handover: repro.handover_path,
      runbooks: (repro.built || []).map((b) => ({ finding_id: b.finding_id, asset_tag: b.asset_tag, runbook: b.runbook_path, pack: b.pack_dir, zip: b.zip_path, est_minutes: b.time_estimate_min })),
      refused_packs: repro.refused || [],
      coverage_matrix: repro.coverage_matrix_path,
      lead_board: repro.lead_board_path,
      queue: QUEUE_PATH,
      classification: CLASSIFICATION,
    },
    assets: assetRuns.map((r) => ({
      asset_tag: r.asset_tag, status: r.status, experiments_run: r.experiments_run,
      coverage: r.coverage, findings: r.findings || [], blocks: r.blocks || [],
    })),
    question: 'Run each RUNBOOK.md by hand on a clean box and compare against its printed `expected` at every step. Does every runbook below reproduce exactly as written? Answer with the per-finding result (reproduced / diverged at step N with the observed output). Nothing is reported as confirmed until you say so.',
    what_happens_next: 'CHECKPOINT_3 records your verdict and FINALIZES: the coverage report is frozen, the lead board is marked reported for what you confirmed, and reports/run-summary.json is written. A runbook that diverged is recorded as diverged — it is not silently promoted.',
    resume: {
      resume_from: 'checkpoint-2',
      run_dir: RUN_DIR,
      human_confirmation: '<your reproduction result, per finding — required to finalize>',
      note: 'Re-invoke with resume_from=checkpoint-2 and human_confirmation=<text>. Without human_confirmation the workflow returns the CHECKPOINT_3 envelope and asks again rather than finalizing on its own.',
    },
    checkpoints: checkpoints,
    notes: notes,
  }
}

// ============================================================================
// CHECKPOINT 3 — human confirms; FINALIZE
// ============================================================================
phase('Checkpoint 3')

if (started('checkpoint-3') && !HUMAN_CONFIRMATION) {
  checkpoint('CHECKPOINT_3', { kind: 'awaiting-human-confirmation', raised_at_stage: 'checkpoint-3' })
  return {
    status: 'CHECKPOINT_3',
    run_dir: RUN_DIR,
    question: 'Did the runbook(s) reproduce as written? Reply with the per-finding result. Pass it back as args.human_confirmation (with resume_from="checkpoint-2") and this run will finalize; without it, nothing is finalized and no finding is promoted.',
    expected_answer_shape: '<finding_id>: reproduced | diverged at step <N>: <observed output>',
    resume: {
      resume_from: 'checkpoint-2',
      run_dir: RUN_DIR,
      human_confirmation: '<the per-finding reproduction result>',
    },
    checkpoints: checkpoints,
    notes: notes,
  }
}

phase('Finalize')

const FINAL_SCHEMA = {
  type: 'object', additionalProperties: true,
  required: ['summary_path'],
  properties: {
    summary_path: { type: 'string' },
    coverage_report_path: { type: 'string' },
    coverage_gate_exit: { type: 'integer' },
    coverage_complete: { type: 'boolean' },
    confirmed_count: { type: 'integer' },
    rejected_count: { type: 'integer' },
    dropped_count: { type: 'integer' },
    pending_cells: { type: 'integer' },
    schema_check_exit: { type: 'integer' },
    lead_board_updated: { type: 'boolean' },
    notes: { type: 'array', items: { type: 'string' } },
    blocked_reason: { type: 'string' },
  },
}

const fin = await agent(
  `${DISCIPLINE}\n\n` +
  `ROLE: FINALIZER (checkpoint 3, after the human confirmed manual reproduction). cwd is ${BUNDLE}.\n` +
  `You write the run's closing record. You do NOT re-run exploits and you do NOT promote anything the human did not confirm.\n\n` +
  `RUN DIR: ${RUN_DIR}\n` +
  `HUMAN REPRODUCTION RESULT (verbatim, from the caller — this is the authoritative accept/reject signal):\n` +
  `${HUMAN_CONFIRMATION}\n\n` +
  (started('checkpoint-2')
    ? `PER-ASSET RESULTS FROM THIS SESSION:\n${JSON.stringify(assetRuns.map((r) => ({ asset_tag: r.asset_tag, status: r.status, experiments_run: r.experiments_run, coverage: r.coverage, findings: r.findings || [], blocks: r.blocks || [] })), null, 2)}\n`
    : `NOTE: this invocation resumed straight to FINALIZE, so there are no in-memory fan-out results. Re-derive everything\nfrom disk: ${RUN_DIR}/slices/*.json, ${RUN_DIR}/assets/*/artifacts/{validated,false-positives,dropped}/*.json,\n${RUN_DIR}/assets/*/seven-questions/*.json, ${RUN_DIR}/assets/*/coverage.json, ${RUN_DIR}/assets/*/experiments.md.\n`) +
  `\nDO, in order:\n` +
  `1. Write ${RUN_DIR}/reports/checkpoint-3-confirmation.md:\n` +
  `   the human's reproduction result VERBATIM, the UTC timestamp from \`date -u +%Y-%m-%dT%H:%M:%SZ\`, and a table\n` +
  `   | finding_id | asset | runbook | human result (reproduced / diverged at step N) | promoted? |\n` +
  `   'promoted' is true ONLY for a finding the human explicitly reported as reproduced. A diverged runbook is recorded as\n` +
  `   diverged and NOT promoted, even though its Stage-6 verdict says CONFIRMED — a validator's CONFIRMED means 'the PoC\n` +
  `   runs'; the human's confirmation is what makes it reproducible-by-a-third-party. Never rewrite or edit a verdict file.\n` +
  `2. For every promoted finding, update the cross-asset board with the frozen CLI (one call per lead; find the lead id with\n` +
  `   \`python3 tools/lead_board.py --run-dir ${RUN_DIR} show\`):\n` +
  `     python3 tools/lead_board.py --run-dir ${RUN_DIR} touch --lead <L-NNNN> --status reported --experiment <E-NNN>\n` +
  `   A lead whose finding was NOT promoted keeps its current status — do not mark it exhausted or reported.\n` +
  `3. Run the two closing gates and record exit codes verbatim:\n` +
  `     python3 tools/coverage_gate.py --run-dir ${RUN_DIR}                    (writes ${RUN_DIR}/reports/coverage-matrix.json)\n` +
  `     python3 tools/coverage_gate.py --run-dir ${RUN_DIR} --mode strict      (the 100% diagnostic; bounty mode is the obligation — see the stage-3 gate note)\n` +
  `     python3 tools/schema_check.py --kind all --run-dir ${RUN_DIR}\n` +
  `   ${SCHEMA_CHECK_NOTE}\n` +
  `4. Write ${RUN_DIR}/reports/run-summary.json — a single JSON object a caller can consume:\n` +
  `   { "schema": "bbh/run-summary/v1", "engagement": <from scope.json>, "generated_at": <date -u>,\n` +
  `     "assets": [ {asset_tag, status, experiments_run, coverage:{applicable,covered,pending,ratio,complete}} ],\n` +
  `     "findings": [ {finding_id, asset_tag, class_id, title, severity, cvss_vector, stage6_verdict, seven_q_verdict,\n` +
  `                    human_reproduction, promoted, runbook_path, pack_dir, verdict_path, seven_q_path} ],\n` +
  `     "counts": {confirmed, rejected, cure, dropped, promoted},\n` +
  `     "coverage": {applicable, covered, pending, ratio, complete, gate_exit},\n` +
  `     "open_leads": [ {lead_id, asset_tag, class_id, tier, status} ],\n` +
  `     "blocks": [ <every named block from every asset, verbatim> ] }\n` +
  `   Read the values from the artifacts on disk — do not transcribe from your own memory of this prompt.\n` +
  `5. Write ${RUN_DIR}/reports/coverage-report.md: the gate's per-asset and per-cell detail verbatim, plus a short section\n` +
  `   naming every cell that is still pending and the concrete next action for it.\n\n` +
  `Return FINAL_SCHEMA. blocked_reason is a STRING: '' means no block; set it only if a gate exited 2 (unreadable inputs).`,
  { schema: FINAL_SCHEMA, label: 'finalize', phase: 'Finalize' }
)

if (!fin) {
  return { status: 'BLOCKED', stage: 'finalize', run_dir: RUN_DIR, reason: 'finalizer agent returned null', checkpoints: checkpoints, notes: notes }
}

checkpoint('CHECKPOINT_3', {
  kind: 'human-confirmation-recorded',
  recorded_at: 'reports/checkpoint-3-confirmation.md',
  human_confirmation: HUMAN_CONFIRMATION,
})

log(`finalize: summary=${fin.summary_path} coverage_gate_exit=${fin.coverage_gate_exit} confirmed=${fin.confirmed_count}`)

const allFindings = []
for (const r of assetRuns) for (const f of (r.findings || [])) allFindings.push(Object.assign({ asset_tag: r.asset_tag }, f))

return {
  status: fin.blocked_reason ? 'BLOCKED' : 'COMPLETE',
  run_dir: RUN_DIR,
  engagement: engagement,
  platform: platform,
  safe_harbor: safeHarbor,
  stage_reached: 'finalize',
  started_at_stage: START_STAGE,
  assets: assetRuns.map((r) => ({
    asset_tag: r.asset_tag,
    status: r.status,
    experiments_run: r.experiments_run,
    batches: r.batches,
    coverage: r.coverage || null,
    blocks: r.blocks || [],
  })),
  findings: allFindings,
  confirmed: allFindings.filter((f) => String(f.verdict).toUpperCase() === 'CONFIRMED').length,
  rejected: allFindings.filter((f) => String(f.verdict).toUpperCase() === 'REJECTED').length,
  dropped: allFindings.filter((f) => String(f.verdict).toUpperCase() === 'DROPPED').length,
  coverage: {
    applicable: APPLICABLE_TOTAL,
    complete: fin.coverage_complete === true,
    pending_cells: fin.pending_cells != null ? fin.pending_cells : null,
    gate_exit: fin.coverage_gate_exit,
  },
  artifacts: {
    run_summary: fin.summary_path,
    coverage_report: fin.coverage_report_path,
    coverage_matrix: `${RUN_DIR}/reports/coverage-matrix.json`,
    confirmation_record: `${RUN_DIR}/reports/checkpoint-3-confirmation.md`,
    handover: `${RUN_DIR}/reports/handover.md`,
    queue: QUEUE_PATH,
    classification: CLASSIFICATION,
    scope: SCOPE_FILE,
    slices_dir: `${RUN_DIR}/slices`,
    repro_dir: `${RUN_DIR}/repro`,
  },
  human_confirmation: HUMAN_CONFIRMATION,
  checkpoints: checkpoints,
  reason: fin.blocked_reason || null,
  notes: notes.concat(Array.isArray(fin.notes) ? fin.notes : []),
}
