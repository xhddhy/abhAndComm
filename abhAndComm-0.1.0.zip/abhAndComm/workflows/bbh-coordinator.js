// ============================================================================
// bbh-coordinator.js — ONE ASSET, ONE COORDINATOR (DSH workflow script body).
//
// A rewrite of the upstream `.claude/workflows/coordinator-loop.js` for bounty
// semantics. The engine is turned inside-out exactly as upstream: THIS SCRIPT is
// the stateless conductor; THE ENGAGEMENT STATE LIVES IN THREE FILES under the
// slice's output_dir, re-read and re-written every batch:
//
//   attack-chain.md     working theory (<= 50 lines, REWRITTEN every batch)
//   session-memory.md   durable memory (append-only): access/creds, confirmed
//                       facts, DEAD ENDS (so we never re-try them), open threads,
//                       pivot history, creative leads
//   experiments.md      append-only ledger (E-NNN rows; never rewritten/pruned)
//
// The INTEGRATE agent is the SOLE WRITER of all three (plus coverage.json), so
// parallel executors never race on the ledger. That is the one deliberate
// adaptation of the upstream "executor updates its own row" rule, and it is what
// makes 1-2 concurrent executors per batch safe.
//
// WHY THIS SHAPE (do not "simplify" it): a 30-experiment, N-batch hunt cannot fit
// in one context. Files are the memory; every think/execute/integrate/validate
// agent is a fresh, cheap context that loads exactly the state its role permits
// and nothing else. Two boundaries carry the whole design and are enforced by the
// prompts below, never by trust:
//
//   * BLIND VALIDATOR — receives finding_id, FINDING_DIR, TARGET_URL, OUTPUT_DIR
//     and the frozen NVD/KEV snapshot paths, and NOT attack-chain.md, not the
//     coordinator's theory, not other findings, not the executor's logs. A FRESH
//     validator is spawned for every cure round, so independence survives a cure.
//   * CURE EXECUTOR — receives ONLY the named failed_checks + missing_evidence +
//     FINDING_DIR, and must NOT re-theorize or expand scope.
//
// Sandbox: no Date.now() / new Date() / Math.random(). Agents shell out to `date`.
// No filesystem, no network, no Node API here — the agents do all I/O.
// ============================================================================

// ---- args ------------------------------------------------------------------
const a = (args && typeof args === 'object' && !Array.isArray(args)) ? args : {}

const SLICE_FILE = a.slice_file || null
const RUN_DIR_IN = a.run_dir || null
const OUTPUT_DIR_IN = a.output_dir || null
const MAX_EXPERIMENTS = Number(a.max_experiments) > 0 ? Math.floor(Number(a.max_experiments)) : 30
const MAX_CURE_CYCLES = Number(a.max_cure_cycles) >= 0 ? Math.floor(Number(a.max_cure_cycles)) : 3
const VOTES = Number(a.votes) > 0 ? Math.floor(Number(a.votes)) : 3
const NVD_CACHE_DIR = a.nvd_cache_dir || null
const KEV_SNAPSHOT = a.kev_snapshot || null
const PARALLEL_INLINE_VALIDATE = a.parallel_inline_validate === true
const DRY_RUN = a.dry_run === true

// A batch appends at least one experiment, so batches can never exceed the
// experiment budget; the absolute ceiling is a runaway backstop only.
const MAX_BATCHES = MAX_EXPERIMENTS
const DRY_LIMIT = 3 // consecutive zero-progress batches before the loop stops
const ABSOLUTE_MAX_BATCHES = 400

const BUNDLE = 'the bundle root (your cwd: it contains tools/README.md, contracts/ and workflows/)'

// ---- prompts: shared fragments --------------------------------------------
const DISCIPLINE = [
  'STANDING DISCIPLINE (bug-bounty edition):',
  '- SCOPE IS LAW: every request must pass `python3 tools/bbh_scope.py check --scope <scope.json> --url <url>` first.',
  '  exit 0 in scope, 1 OUT OF SCOPE (do not send), 2 unclear -> record and stop on that host.',
  '- ROE: obey scope.json roe{} (rate_limit_rps, no_dos, no_bruteforce, allow_writes).',
  '- NO BRUTE FORCE (no credential spraying, no wordlist fuzzing as a primitive), no DoS, never a destructive or',
  '  cross-tenant write. Reason about logic flaws instead.',
  '- DIAGNOSE BEFORE RETRY: read the error, check the prerequisite, then act. Never re-send a cosmetic variant.',
  '- EVIDENCE OR IT DID NOT HAPPEN: a claim with no raw request/response on disk is not a finding.',
  '- TOKEN DISCIPLINE: attack-chain.md <= 50 lines and REWRITTEN every batch; ALL bookkeeping (attack-chain.md +',
  '  session-memory.md + experiments.md + tools/ logs) stays under 10% of the mission token budget. Bullets, not prose.',
  '- TIMESTAMPS: run `date -u +%Y-%m-%dT%H:%M:%SZ`. Never invent a time.',
  '- STAY IN YOUR LANE: write only inside the output directory you were given, and only inside the subpaths your role owns.',
  '- AUTONOMY: never ask the human a question. Record a named block (command + exit code) and return.',
].join('\n')

// ---- prompts: the three-file state contract --------------------------------
const STATE_CONTRACT = [
  'THE THREE-FILE STATE CONTRACT (this is the engagement memory — the script holds none):',
  '  <OUTPUT_DIR>/attack-chain.md    WORKING THEORY. Rewritten (not appended) every batch by INTEGRATE. HARD CAP 50 LINES.',
  '      ## Services            <port> <service> <version>, one per line',
  '      ## Surface             <endpoint or interface> - <observation>',
  '      ## Theory (this batch) EXACTLY 3 hypotheses, numbered, at least one tagged [wildcard] with a one-line reason;',
  '                             then "Chosen: <which and why>"',
  '      ## Tested (cumulative, terse)  <E-NNN> <technique> -> <one-line result>; prune resolved items to one-liners',
  '      ## Next                the SINGLE most concrete next step',
  '      The two hypotheses you did NOT choose stay in the file as backlog. That is how the loop keeps alternatives alive.',
  '  <OUTPUT_DIR>/session-memory.md   DURABLE MEMORY, append-only, never delete a line. Sections, each a bullet list:',
  '      ## Access & Credentials   footholds, tokens, sessions, test accounts we hold (NAMES/env-vars, never a raw secret)',
  '      ## Confirmed Facts       verified truths about this asset only',
  '      ## Dead Ends             what definitively does NOT work + WHY, so no batch ever re-tries it',
  '      ## Open Threads          promising leads not yet pursued',
  '      ## Pivot History         goals attempted, why abandoned',
  '      ## Creative Leads        wildcard ideas + research topics already searched (so a reset does not repeat them)',
  '  <OUTPUT_DIR>/experiments.md      APPEND-ONLY LEDGER. Never rewrite, never prune, never reorder a row.',
  '      | ID | Batch | Goal | Technique | Target | Hypothesis | Result | Goal_attempts | Notes |',
  '      ID = E-NNN monotonic. Goal = the CONCEPTUAL goal (not the technique), e.g. "read another tenant\'s invoice",',
  '      "reach the internal metadata service", "prove role check is missing on DELETE". Technique = the specific method tried.',
  '      Result in {success, partial, fail, pending} - use the literal "fail". Goal_attempts = the running count of fail',
  '      rows for THAT Goal so far (prior fails + 1). Three fails on one Goal is the signal to abandon that theory.',
  '      Dedup: skip a row only if Goal + Technique + Target + parameters-meaningful-to-the-test ALL match a prior row.',
  '  OWNERSHIP: INTEGRATE is the SOLE writer of attack-chain.md, session-memory.md and experiments.md. Executors,',
  '  validators, cure executors and the skeptic NEVER write them (that is what keeps parallel executors race-free).',
].join('\n')

const COVERAGE_CONTRACT = [
  'COVERAGE-BY-VALID (deterministic — you supply facts, code enforces the work-list):',
  '  * <OUTPUT_DIR>/applicability/cells.json is CODE-PRODUCED by tools/cells_build.py from surface.json. It is the',
  '    completion obligation. YOU MAY NOT SHRINK IT. Marking a code-applicable cell N/A is a HARD FABRICATION FAIL.',
  '  * <OUTPUT_DIR>/coverage.json is written by INTEGRATE (sole writer), one row per class_id:',
  '      { "class_id": "<id>", "applicability": "applicable", "status": "pending",',
  '        "units_tested": [ { "key": "<scope_key>", "status": "covered", "e_id": "E-NNN", "finding_id": "F-NNN" } ] }',
  '  * A cell is `covered` ONLY by a VALID finding in <OUTPUT_DIR>/artifacts/validated/ whose class_id + unit_refs +',
  '    asset_tag match the cell. A cell whose candidates were all REJECTED or DROPPED STAYS PENDING and search continues.',
  '  * A cell is `covered_negative` only for a genuinely clean probe, with a non-agent corroborator: a',
  '    <OUTPUT_DIR>/tools/NNN_*.md whose "Experiment: E-NNN" header cites raw tool output, or a corroborator file path.',
  '    "I tried and saw nothing" is not a negative; it is a pending cell with an open lead.',
  '  * `deferred` is only for a cell the tester genuinely cannot reach (MFA/OTP-gated, IP allowlist) and requires BOTH a',
  '    deferral_reason AND a client_input_request path that resolves to a real file on disk. An unsubstantiated deferral',
  '    is a hard miss. Never defer something you could probe with the credentials in hand.',
  '  * EQUIV GROUPS: cells sharing a (class_id, equiv_group) are the same logical target. Validate ONE representative for',
  '    real; the gate credits its siblings. Do not spend a separate mission per sibling.',
  '  * THE GATE: run it in BOTH modes and report both exit codes.',
  '      python3 tools/coverage_gate.py --asset-dir <OUTPUT_DIR>                   # default --mode bounty: lead-level view',
  '      python3 tools/coverage_gate.py --asset-dir <OUTPUT_DIR> --mode strict     # 100% of applicable cells: THE COMPLETION OBLIGATION',
  '    --mode strict must exit 0 with coverage_ratio == 1.0 and no missing / extra / dangling / false-NA cells before this',
  '    asset may be called COMPLETE. A cell you genuinely cannot reach is closed honestly with a substantiated `deferred`',
  '    (reason + a client_input_request path that resolves on disk), never by shrinking the work-list.',
  '    "I ran out of hypotheses" is NOT completion.',
].join('\n')

function cveOperands() {
  return [
    'FROZEN CVE OPERANDS (never rely on the finding\'s own claim):',
    `  1. NVD: python3 tools/nvd_lookup.py <CVE-ID> --json --cache-dir ${NVD_CACHE_DIR || '<RUN_DIR>/artifacts/nvd-cache'}`,
    KEV_SNAPSHOT
      ? `  2. CISA KEV: the frozen snapshot at ${KEV_SNAPSHOT} (read it directly; do not hit the network).`
      : '  2. CISA KEV: the kev_listed field nvd_lookup.py returns.',
    '  3. Vendor advisory: follow the reference URLs NVD returns and quote the affected-version line.',
    '  Reconcile: claimed CVE id, CVSS vector, base score and severity must all agree with NVD and with the from-vector',
    '  recomputation (|delta| <= 0.1 on the score, exact match on the vector and the band). Any unreconciled divergence',
    '  is a FAILED CHECK, not a note.',
  ].join('\n')
}

const SCHEMA_CHECK_GATE = [
  'STAGE GATE: `python3 tools/schema_check.py --kind all --run-dir <RUN_DIR>` must exit 0 before you claim a stage',
  'complete (exit 2 = a malformed artifact: fix it and re-run). For every verdict you write you must ALSO run',
  '`python3 tools/schema_check.py --kind verdict <verdict.json>` and record its exit code.',
].join('\n')

// ---- helpers ---------------------------------------------------------------
function slash(p) { return String(p || '').replace(/\/+$/, '') }

function skepticDue(prev, cur) {
  for (const t of [5, 15, 25]) if (prev < t && cur >= t) return t
  if (cur >= 50) {
    const curMult = Math.floor(cur / 25) * 25
    const prevMult = Math.floor(prev / 25) * 25
    if (curMult > prevMult && curMult >= 50) return curMult
  }
  return 0
}

function pad3(n) { return String(n).padStart(3, '0') }

async function inChunks(items, size, fn) {
  const out = []
  const width = size > 0 ? size : 1
  for (let i = 0; i < items.length; i += width) {
    const chunk = items.slice(i, i + width)
    const res = await parallel(chunk.map((it) => () => fn(it)))
    for (const r of res) out.push(r)
  }
  return out
}

// ---- DRY RUN ---------------------------------------------------------------
if (DRY_RUN) {
  log('bbh-coordinator: dry_run=true — returning the planned loop graph, no agents spawned.')
  return {
    status: 'DRY_RUN',
    asset_tag: null,
    slice_file: SLICE_FILE,
    output_dir: OUTPUT_DIR_IN,
    budget: { max_experiments: MAX_EXPERIMENTS, max_batches: MAX_BATCHES, max_cure_cycles: MAX_CURE_CYCLES, votes: VOTES },
    batch_shape: ['think (3 hypotheses, >=1 [wildcard])', '(research)', 'execute 1-2', 'integrate (SOLE writer of the 3 state files + coverage.json)', 'inline blind validation of every new candidate', '(skeptic at experiments 5/15/25)'],
    terminal_lanes: {
      validate: 'blind validator: scope re-check -> PoC truth (>=3 deterministic runs, negative control silent) -> evidence completeness -> cross-identity for IDOR/BOLA/ATO/privesc -> CVSS recompute -> CVE truth -> adversarial quorum',
      cure: 'CURE -> fresh cure executor (named failed_checks + missing_evidence ONLY) -> FRESH blind re-validator, bounded by max_cure_cycles, then DROPPED',
      chain: 'CONFIRMED -> chain A->B->C (each hop CONFIRMED with its own evidence, or labelled HYPOTHESIS and never claimed)',
      gate: '7-Question Gate -> PASS keeps it; CURE returns to the cure loop with the failing question named; KILL records the kill',
      repro: 'PASS -> python3 tools/repro_pack.py --finding-dir ... --verdict ... --seven-q ... --out ...',
    },
    checkpoints: [],
    note: 'read status/asset_tag/coverage from disk; this is a plan, not a run.',
  }
}

log(`bbh-coordinator: slice=${SLICE_FILE || '<none>'} budget=${MAX_EXPERIMENTS} experiments / cure cycles=${MAX_CURE_CYCLES} / votes=${VOTES}`)

// ============================================================================
// PHASE: Bootstrap — read the slice, create the tree, seed the three state files
// ============================================================================
phase('Bootstrap')

const BOOTSTRAP_SCHEMA = {
  type: 'object', additionalProperties: true,
  required: ['ok', 'output_dir', 'asset_tag'],
  properties: {
    ok: { type: 'boolean' },
    output_dir: { type: 'string' },
    asset_tag: { type: 'string' },
    asset_id: { type: 'string' },
    scope_ref: { type: 'string' },
    run_dir: { type: 'string' },
    apex: { type: 'boolean' },
    tech: { type: 'array', items: { type: 'string' } },
    applicable_cells: { type: 'array', items: { type: 'string' } },
    cell_count: { type: 'integer' },
    lead_count: { type: 'integer' },
    class_ids: { type: 'array', items: { type: 'string' } },
    playbook_classes: { type: 'array', items: { type: 'string' } },
    surface_units: { type: 'integer' },
    crebs_env: { type: 'array', items: { type: 'string' } },
    roe: { type: 'object', additionalProperties: true },
    exp_count: { type: 'integer' },
    gate_exit_baseline: { type: 'integer' },
    applicable_pending_baseline: { type: 'integer' },
    seed_files: { type: 'array', items: { type: 'string' } },
    schema_check_exit: { type: 'integer' },
    blocked_reason: { type: 'string' },
  },
}

const boot = await agent(
  `${DISCIPLINE}\n\n` +
  `ROLE: COORDINATOR BOOTSTRAP for ONE asset. cwd is ${BUNDLE}. You read the work order, create the private tree, and\n` +
  `seed the three state files. You do NOT send a single request to the target.\n\n` +
  `SLICE FILE (the complete, self-contained work order; contract contracts/slice.schema.json): ${SLICE_FILE || '<args.slice_file was not supplied — see the BLOCKED rule below>'}\n` +
  `OUTPUT_DIR override from args: ${OUTPUT_DIR_IN || '<none — take slice.output_dir VERBATIM>'}\n` +
  `RUN DIR from args: ${RUN_DIR_IN || '<none — derive from the slice, it is <run>/assets/<asset_tag>>'}\n\n` +
  `BLOCKED RULE: if slice_file is empty, or the file does not exist, or slice.output_dir is not an ABSOLUTE path, return\n` +
  `ok:false with that as blocked_reason. Never invent an output directory: a relative output_dir resolves differently for\n` +
  `different agents and would silently split the asset's state across two trees.\n\n` +
  `${STATE_CONTRACT}\n\n` +
  `${COVERAGE_CONTRACT}\n\n` +
  `DO:\n` +
  `1. Read the slice. Extract, VERBATIM: slice_id, asset_tag, asset_id, output_dir, scope_ref, apex, tech, surface_flags,\n` +
  `   applicable_cells, cell_count, leads, class_playbooks, creds_env, roe, gate. Echo them back in your return.\n` +
  `2. Create the private tree (nothing outside OUTPUT_DIR):\n` +
  `     mkdir -p <OUTPUT_DIR>/{findings,logs,tools,reports,artifacts/validated,artifacts/false-positives,artifacts/dropped,seven-questions,chains,repro,evidence}\n` +
  `3. RESUME-AWARE SEEDING — read before you write:\n` +
  `   * If <OUTPUT_DIR>/attack-chain.md, session-memory.md and experiments.md ALREADY EXIST: PRESERVE them byte for byte.\n` +
  `     Do NOT re-seed, do NOT truncate, do NOT "tidy" them. Report exp_count = the real number of rows whose first cell\n` +
  `     starts with "E-" (count with: grep -c '^| E-' <OUTPUT_DIR>/experiments.md).\n` +
  `   * If they do NOT exist, write all three with the exact headers above: attack-chain.md with the five section headings\n` +
  `     and, under Surface, every unit address from surface.json with its flags and evidence; experiments.md with the\n` +
  `     table header row and NO data rows; session-memory.md with the six section headings and, under Open Threads, one\n` +
  `     bullet per queued lead (lead_id + class_id + address + priority tier) so no lead can be lost by forgetting it.\n` +
  `   * If exactly one or two exist, create ONLY the missing one(s) and preserve what is there.\n` +
  `4. Read <OUTPUT_DIR>/applicability/cells.json if present and report the applicable cell keys; also report the class_ids\n` +
  `   they cover. If it is absent, report that as a NOTE (the coordinator can still work from slice.applicable_cells, but\n` +
  `   the coverage gate cannot pass without cells.json — say so).\n` +
  `5. Read <OUTPUT_DIR>/recon/inventory/surface.json and report the unit count and the per-unit flag sets. AUDIT the flags\n` +
  `   against the surface/v2 contract: units[].flags may contain ONLY the 18 agent-set flags, and every flag must have a\n` +
  `   matching "<flag> <- <why>" evidence line. Report any violation verbatim — a derived flag written here is a bug that\n` +
  `   would let an agent fabricate applicability.\n` +
  `6. Run the coverage gate once in BOTH modes to capture the PRE-WORK baseline (exit 1 is EXPECTED before any work):\n` +
  `     python3 tools/coverage_gate.py --asset-dir <OUTPUT_DIR>                # default bounty mode: the lead-level view\n` +
  `     python3 tools/coverage_gate.py --asset-dir <OUTPUT_DIR> --mode strict  # 100% of applicable cells: the completion obligation\n` +
  `   Record the exit code and the applicable/covered/pending counts it prints. This is the baseline this run is measured\n` +
  `   against; do not treat exit 1 as an error.\n` +
  `7. Run: python3 tools/schema_check.py --kind all --run-dir <RUN_DIR>  — record the exit code.\n` +
  `   ${SCHEMA_CHECK_GATE}\n\n` +
  `Return BOOTSTRAP_SCHEMA. ok must be true only when the tree exists and all three state files are present on disk.\n` +
  `blocked_reason is a STRING: '' means no block; otherwise state the exact failed command and its exit code.`,
  { schema: BOOTSTRAP_SCHEMA, label: 'bootstrap', phase: 'Bootstrap' }
)

if (!boot || !boot.ok) {
  return {
    status: 'BLOCKED',
    phase: 'Bootstrap',
    asset_tag: boot ? boot.asset_tag : null,
    reason: boot ? (boot.blocked_reason || 'bootstrap returned ok:false') : 'bootstrap agent returned null',
    findings: [], coverage: null, experiments_run: 0, checkpoints: [],
  }
}

const OUTPUT_DIR = slash(OUTPUT_DIR_IN || boot.output_dir)
const ASSET_TAG = boot.asset_tag
const RUN_DIR = slash(RUN_DIR_IN || boot.run_dir || OUTPUT_DIR.replace(/\/assets\/[^/]+$/, ''))
const SCOPE_REF = boot.scope_ref || `${RUN_DIR}/scope.json`
const NVD_DIR = NVD_CACHE_DIR || `${RUN_DIR}/artifacts/nvd-cache`
const APPLICABLE = Array.isArray(boot.applicable_cells) ? boot.applicable_cells : []
const PLAYBOOKS = boot.playbook_classes || []
const CHECKPOINTS = []

log(`bootstrap: asset=${ASSET_TAG} output_dir=${OUTPUT_DIR} cells=${boot.cell_count || APPLICABLE.length} leads=${boot.lead_count || 0} exp=${boot.exp_count || 0}`)

// ============================================================================
// Prompt builders
// ============================================================================

// --- THINK ------------------------------------------------------------------
const THINK_SCHEMA = {
  type: 'object', additionalProperties: true,
  required: ['hypotheses', 'chosen', 'research_needed'],
  properties: {
    active_goal: { type: 'string' },
    hypotheses: {
      type: 'array',
      items: {
        type: 'object', additionalProperties: true,
        required: ['id', 'hypothesis', 'wildcard'],
        properties: {
          id: { type: 'integer' },
          hypothesis: { type: 'string' },
          reasoning: { type: 'string' },
          wildcard: { type: 'boolean' },
          class_id: { type: 'string' },
          backlog: { type: 'boolean' },
        },
      },
    },
    wildcard_count: { type: 'integer' },
    chosen: {
      type: 'array',
      items: {
        type: 'object', additionalProperties: true,
        required: ['mission_id', 'objective', 'class_id'],
        properties: {
          mission_id: { type: 'string' },
          objective: { type: 'string' },
          goal: { type: 'string' },
          technique: { type: 'string' },
          target: { type: 'string' },
          role: { type: 'string', description: 'explore | exploit' },
          class_id: { type: 'string' },
          covers_cells: { type: 'array', items: { type: 'string' } },
          playbook_files: { type: 'array', items: { type: 'string' } },
          scenario_files: { type: 'array', items: { type: 'string' } },
          patt_url: { type: 'string' },
          expected_signal: { type: 'string' },
          invented: { type: 'boolean' },
        },
      },
    },
    research_needed: { type: 'boolean' },
    research_reason: { type: 'string' },
    open_cells: { type: 'array', items: { type: 'string' } },
    terminate: { type: 'boolean' },
    terminate_reason: { type: 'string' },
    attack_chain_lines: { type: 'integer' },
    blocked_reason: { type: 'string' },
  },
}

function thinkPrompt(batch, resetMode, resetGoal, skepticBriefs, openCells, verdictSignal) {
  return `${DISCIPLINE}\n\n` +
    `ROLE: coordinator THINK (P2${resetMode ? ' + P4b RESET' : ''}). cwd is ${BUNDLE}. You reason BETWEEN batches;\n` +
    `executors never do. You are the only agent that decides what gets tested next.\n\n` +
    `ASSET: ${ASSET_TAG}   BATCH: ${batch}\n` +
    `OUTPUT_DIR: ${OUTPUT_DIR}\n` +
    `RUN DIR: ${RUN_DIR}   SCOPE: ${SCOPE_REF}\n` +
    `ROE: ${JSON.stringify(boot.roe || {})}\n` +
    `CREDS ENV NAMES: ${JSON.stringify(boot.creds_env || [])}   (NAMES only; read values from the environment, never print them)\n` +
    `EXPERIMENT BUDGET: ${MAX_EXPERIMENTS} (spent so far: ${exp})\n\n` +
    `READ FIRST — this IS your state, there is no other memory:\n` +
    `  ${OUTPUT_DIR}/attack-chain.md   (your own theory file)\n` +
    `  ${OUTPUT_DIR}/experiments.md    (the FULL ledger — read every row; do not propose what already failed)\n` +
    `  ${OUTPUT_DIR}/session-memory.md (especially ## Dead Ends and ## Open Threads)\n` +
    `  ${OUTPUT_DIR}/recon/inventory/surface.json  (the authoritative surface: units, flags, evidence)\n` +
    `  ${OUTPUT_DIR}/applicability/cells.json      (the CODE-PRODUCED work-list)\n` +
    (skepticBriefs.length ? `  and the latest skeptic brief(s), whose counter-hypotheses are candidates for your wildcard slot:\n    ${skepticBriefs.join('\n    ')}\n` : '') +
    `\n${COVERAGE_CONTRACT}\n\n` +
    `OPEN CELLS REPORTED SO FAR (class_id @ scope_key; the gate is authoritative, this list is its last reported state):\n` +
    `  ${openCells.length ? openCells.join('\n  ') : '<none reported yet — run the gate yourself in step 1>'}\n` +
    `INTERLEAVED VERDICTS SO FAR: confirmed=${JSON.stringify((verdictSignal && verdictSignal.confirmed) || [])} ` +
    `rejected=${JSON.stringify((verdictSignal && verdictSignal.rejected) || [])} dropped=${JSON.stringify((verdictSignal && verdictSignal.dropped) || [])}\n` +
    `  A class whose candidates were all REJECTED/DROPPED is NOT covered — it stays pending and you must keep searching.\n` +
    `  A class already covered by a finding in artifacts/validated/ needs no further mission unless you are chasing the CHAIN.\n\n` +
    (resetMode
      ? `*** P4b RESET MODE *** The goal "${resetGoal}" has failed 3+ times. ABANDON its current theory entirely. Re-read the\n` +
        `whole ledger and session-memory ## Dead Ends. Your 3 hypotheses must open genuinely NEW directions and at least one must\n` +
        `CONTRADICT the prior dominant theory. Do NOT propose a cosmetic variant of anything already in the ledger.\n` +
        `research_needed MUST be true. Set it so.\n\n`
      : '') +
    `DO:\n` +
    `1. DETERMINISTIC BACKLOG: run BOTH tools and use their output as the completion obligation:\n` +
    `     python3 tools/cells_build.py --asset-dir ${OUTPUT_DIR} --catalog catalog/bounty-coverage-matrix.json\n` +
    `     python3 tools/coverage_gate.py --asset-dir ${OUTPUT_DIR}\n` +
    `     python3 tools/coverage_gate.py --asset-dir ${OUTPUT_DIR} --mode strict\n` +
    `   Read ${OUTPUT_DIR}/reports/coverage-matrix.json for the per-cell detail. Rank the pending cells by\n` +
    `   (impact x likelihood-on-surface x low-credential reachability). AT LEAST ONE mission this batch MUST target the\n` +
    `   highest-value pending cell: set its class_id AND covers_cells, and mount that class's playbook files.\n` +
    `2. WRITE EXACTLY 3 HYPOTHESES into ${OUTPUT_DIR}/attack-chain.md under "## Theory (this batch)". Numbered 1-3, at least\n` +
    `   one tagged [wildcard]. The wildcard must be an angle NO playbook prescribes — invent it from intuition, from an\n` +
    `   analogy to an adjacent class, or from a creative recombination of observed facts. Write the reasoning for each.\n` +
    `   Record the two you do NOT choose as backlog; they persist in the file for later batches.\n` +
    `3. CHOOSE 1-2 to run now (never more than 2 — concurrency is bounded on purpose). Each chosen mission MUST name:\n` +
    `     mission_id, objective, goal (the CONCEPTUAL goal, matching the Goal column convention), technique, target,\n` +
    `     role (explore | exploit), class_id, covers_cells (the exact cell keys), expected_signal (what you will SEE if the\n` +
    `     hypothesis holds), and playbook_files = 1-2 CONCRETE file paths taken from slice.class_playbooks[class_id].\n` +
    `   The authoritative playbook map for THIS asset is: ${JSON.stringify(boot.class_playbooks || boot.playbook_classes || 'see slice.class_playbooks')}\n` +
    `   Pass those paths VERBATIM — they are already resolved to concrete files, so never write "read the skill" or name a\n` +
    `   directory. When a class resolves to more than one file, pick the 1-2 most specific (a scenario/reference file beats a\n` +
    `   SKILL.md); when the map itself resolves to a SKILL.md, that IS the authoritative path for that class — pass it as\n` +
    `   given. If a class has no playbook entry, say so\n` +
    `   explicitly in expected_signal and treat the mission as INVENTED (invented:true).\n` +
    `4. Set research_needed=true if ANY trigger applies: reset mode; a technology the playbooks do not cover; no clear\n` +
    `   hypothesis; a novel error class; unreadable source; or the previous batch made zero progress.\n` +
    `5. Set terminate=true ONLY if the asset is environmentally impossible to continue (and say why) — NOT because you ran\n` +
    `   out of ideas. You may NOT terminate while any applicable cell is pending: pending cells are the completion contract.\n` +
    `6. Update attack-chain.md "## Next" to the single most concrete next step, keep the whole file <= 50 LINES, and COUNT\n` +
    `   the lines (wc -l) into attack_chain_lines. If it exceeds 50, prune the Tested section to one-liners until it fits.\n` +
    `   Do NOT append to experiments.md — INTEGRATE owns the ledger, not you.\n\n` +
    `Return THINK_SCHEMA. blocked_reason is a STRING: '' means no block.`
}

// --- RESEARCH ---------------------------------------------------------------
const RESEARCH_SCHEMA = {
  type: 'object', additionalProperties: true,
  required: ['brief'],
  properties: {
    brief: { type: 'string', description: '<=10 lines, each tagged [model]/[web]/[skills]/[chain]/[wildcard], >=1 [wildcard]' },
    topics_searched: { type: 'array', items: { type: 'string' } },
    cves_found: { type: 'array', items: { type: 'string' } },
    novelty: { type: 'string' },
    blocked_reason: { type: 'string' },
  },
}

function researchPrompt(think) {
  return `${DISCIPLINE}\n\n` +
    `ROLE: coordinator CREATIVE RESEARCH (P2b). cwd is ${BUNDLE}. You break a stall or de-risk a novel angle.\n` +
    `You have a HARD BUDGET: at most 3 web searches, at most 2 page fetches, and under 2 minutes of wall time.\n` +
    `If two queries return noise, STOP and finalise from model knowledge. Research must NEVER block execution.\n\n` +
    `ASSET: ${ASSET_TAG}   OUTPUT_DIR: ${OUTPUT_DIR}\n` +
    `WHY RESEARCH FIRED: ${think.research_reason || '(see triggers)'}\n` +
    `MISSIONS THIS BATCH: ${JSON.stringify((think.chosen || []).map((c) => ({ objective: c.objective, technique: c.technique, class_id: c.class_id, invented: c.invented })))}\n` +
    `OPEN CELLS: ${JSON.stringify(think.open_cells || [])}\n\n` +
    `SYNTHESISE from three sources:\n` +
    `  (a) MODEL KNOWLEDGE - 3-5 candidate hypotheses specific to this surface;\n` +
    `  (b) THE PLAYBOOKS - the concrete reference files named in the missions, cross-referenced for the technique you are\n` +
    `      about to try: ${JSON.stringify((think.chosen || []).flatMap((c) => c.playbook_files || []))};\n` +
    `  (c) THE WEB - technique writeups, vendor advisories, disclosed-report patterns. Distil each into\n` +
    `      {technique, payload shape, preconditions, version-affected}. NEVER pass raw HTML downstream.\n` +
    `For every CVE you surface, run: python3 tools/nvd_lookup.py <CVE-ID> --json --cache-dir ${NVD_DIR}\n` +
    `  and report the id in cves_found[] — do not repeat its score from memory.\n\n` +
    `BE INVENTIVE: if the surface is unusual, reason by analogy from adjacent classes and propose a NOVEL approach, not\n` +
    `just the catalogued one. At least one brief line must be tagged [wildcard].\n\n` +
    `Produce brief: at most 10 lines, each tagged [model]/[web]/[skills]/[chain]/[wildcard]. Then APPEND the topics you\n` +
    `searched to ${OUTPUT_DIR}/session-memory.md under "## Creative Leads" as bullets prefixed "searched: " — so the next\n` +
    `reset never repeats them. That is the ONLY write you may make to session-memory.md (append a Creative Leads bullet);\n` +
    `never edit or delete another line, and never touch attack-chain.md or experiments.md.\n\n` +
    `Return RESEARCH_SCHEMA. blocked_reason is a STRING: '' means no block.`
}

// --- EXECUTE ----------------------------------------------------------------
const EXEC_SCHEMA = {
  type: 'object', additionalProperties: true,
  required: ['mission_id', 'objective'],
  properties: {
    mission_id: { type: 'string' },
    objective: { type: 'string' },
    outcome: { type: 'string', description: 'success | partial | fail' },
    finding_id: { type: 'string' },
    finding_dir: { type: 'string' },
    class_id: { type: 'string' },
    covers_cells: { type: 'array', items: { type: 'string' } },
    title: { type: 'string' },
    claimed_severity: { type: 'string' },
    claimed_cvss_vector: { type: 'string' },
    endpoint: { type: 'string' },
    expected_output: { type: 'string' },
    poc_cmd: { type: 'string' },
    poc_runs: { type: 'integer' },
    negative_control: { type: 'string' },
    chain_hints: { type: 'array', items: { type: 'string' } },
    is_negative: { type: 'boolean' },
    negative_kind: { type: 'string', description: 'active_probe | reachability | none' },
    corroborator: { type: 'string' },
    experiments_logged: { type: 'integer' },
    ladder_attempts: { type: 'array', items: { type: 'string' } },
    log_path: { type: 'string' },
    tools_logged: { type: 'array', items: { type: 'string' } },
    notes: { type: 'string' },
    blocked_reason: { type: 'string' },
  },
}

function execPrompt(mission, brief, missionId, predictedExpId) {
  const files = Array.isArray(mission.playbook_files) ? mission.playbook_files : []
  const scen = Array.isArray(mission.scenario_files) ? mission.scenario_files : []
  return `${DISCIPLINE}\n\n` +
    `ROLE: ${mission.role || 'exploit'}-executor for ONE mission. cwd is ${BUNDLE}. Fresh context: you get the mission and\n` +
    `the state files, nothing else — do not go looking for the coordinator's reasoning.\n\n` +
    `MISSION_ID: ${missionId}   EXPERIMENT_ID hint: ${predictedExpId}\n` +
    `ASSET: ${ASSET_TAG}   OUTPUT_DIR: ${OUTPUT_DIR}   RUN DIR: ${RUN_DIR}   SCOPE: ${SCOPE_REF}\n` +
    `TARGET: ${mission.target || '<the in-scope address from the mission>'}\n` +
    `OBJECTIVE: ${mission.objective}\n` +
    `GOAL (conceptual, for the ledger): ${mission.goal || mission.objective}\n` +
    `TECHNIQUE: ${mission.technique || '(choose appropriately)'}${mission.invented ? '  [INVENTED — no playbook prescribes this; execute carefully and document the method so it can become a reusable technique]' : ''}\n` +
    `ATTACK CLASS: ${mission.class_id}   COVERS CELLS: ${JSON.stringify(mission.covers_cells || [])}\n` +
    `EXPECTED SIGNAL (what proves the hypothesis): ${mission.expected_signal || ''}\n` +
    `ROE: ${JSON.stringify(boot.roe || {})}   (allow_writes=false still permits a create-then-delete in your OWN tenant; NEVER a\n` +
    `  write to another tenant, never a destructive write. Clean up every write you make and log both the write and the cleanup.)\n\n` +
    `MOUNTED REFERENCE FILES (read these EXACT resolved paths — the coordinator already picked the most specific 1-2 for\n` +
    `  this class; do not go looking for a different file and do not read a directory listing):\n` +
    `  ${files.length ? files.join('\n  ') : '<the coordinator resolved no playbook for this class: say so in notes and proceed from first principles>'}\n` +
    (scen.length ? `SCENARIO FILES (step-by-step recipes for this technique):\n  ${scen.join('\n  ')}\n` : '') +
    (mission.patt_url ? `PAYLOAD REFERENCE (fetch only at escalation rung 5, not before): ${mission.patt_url}\n` : '') +
    (brief ? `\nRESEARCH BRIEF (advisory, not gospel — report any contradiction you observe):\n${brief}\n` : '') +
    `\nSTATE YOU MAY READ: ${OUTPUT_DIR}/attack-chain.md, ${OUTPUT_DIR}/session-memory.md, ${OUTPUT_DIR}/experiments.md\n` +
    `  (Read them for context. NEVER write them.)\n\n` +
    `PROCEDURE:\n` +
    `1. Scope-check every URL BEFORE sending: python3 tools/bbh_scope.py check --scope ${SCOPE_REF} --url <url>\n` +
    `   exit 1 or 2 -> do not send it; record it and move on.\n` +
    `2. Read the surface first: ${OUTPUT_DIR}/recon/inventory/surface.json and any source/JS you can reach. Most answers are\n` +
    `   already in the data — do not start by guessing payloads.\n` +
    `3. Run the FULL ESCALATION LADDER before calling anything a failure: quickstart payload -> encoding/parser variants ->\n` +
    `   filter/WAF bypass -> the cheat-sheet catalogue -> the payload reference (rung 5 only). Record EVERY rung you tried in\n` +
    `   ladder_attempts[] with its one-line result — a negative with three rungs missing is not a negative, it is unfinished.\n` +
    `4. RESPECT roe.rate_limit_rps (default 5) with a small sleep between requests. No bursts.\n` +
    `5. ON SUCCESS: reproduce it ${'3'} times. The bug is not proven until three runs produce the SAME decisive output, and\n` +
    `   until a NEGATIVE CONTROL (the same script against a target/parameter where the bug is ABSENT) does NOT print the\n` +
    `   success token. Capture both.\n\n` +
    `WRITE (race-free — the coordinator owns the three state files; you must not touch them):\n` +
    `  * ALWAYS: ${OUTPUT_DIR}/logs/mission-${missionId}.md — objective, each technique/rung -> result, raw observations,\n` +
    `    and (on failure) exactly what would unblock it.\n` +
    `  * ALWAYS: ${OUTPUT_DIR}/tools/NNN_<tool>.md for each significant tool run — header format:\n` +
    `      # Tool NNN - <tool>\\n## Cmd\\n<exact invocation>\\n## Out\\n<raw output, truncated to 500 lines>\\n## Linked\\n- experiment: ${predictedExpId}\n` +
    `    A covered_negative cell needs one of these files to cite raw tool output as its non-agent corroborator. A negative\n` +
    `    with no tools file cannot be corroborated and the cell will stay pending.\n` +
    `  * ON A FINDING: ${OUTPUT_DIR}/findings/finding-<NNN>/ containing\n` +
    `      finding.json   — conforming to contracts/finding.schema.json (schema id bbh/finding/v1). Required keys:\n` +
    `                       schema, finding_id ("F-NNN"), experiment_id ("${predictedExpId}"), asset_tag ("${ASSET_TAG}"),\n` +
    `                       class_id ("${mission.class_id}"), cell_key, title, severity_claim, endpoint, method, description,\n` +
    `                       impact, cvss_vector, evidence{request, response, status_code, artifacts[], identity{actor,victim,anonymous}},\n` +
    `                       poc{script, cmd, dependencies[], expected_output, negative_control, runs, deterministic}.\n` +
    `                       - evidence.request is the EXACT HTTP request verbatim. evidence.response is the body or the\n` +
    `                         decisive excerpt. evidence.artifacts are paths RELATIVE to the finding dir and every one of them\n` +
    `                         MUST exist on disk (the blind validator stats each one; a missing path is an automatic failure).\n` +
    `                       - impact must name real data or a real action. Never "could potentially".\n` +
    `                       - poc.cmd is the EXACT invocation from the finding directory. poc.expected_output is the literal\n` +
    `                         token the validator greps for. poc.negative_control is what the same script prints when the bug is\n` +
    `                         absent. poc.runs is how many times you ran it (>=3).\n` +
    `                       - For IDOR / BOLA / ATO / privesc you MUST populate evidence.identity with BOTH sides (actor and\n` +
    `                         victim) and produce the two-identity comparison artifact; the validator requires it.\n` +
    `                       - chain_hints[] is for candidate B/C links you noticed but did not pursue — the chain stage reads it.\n` +
    `      description.md — the human-facing write-up (what, where, why it matters, how to fix).\n` +
    `      poc/           — the runnable script(s) + any fixture. Standalone: argparse positional target, TIMEOUT default 10,\n` +
    `                       prefixes [*]/[+]/[-]/[!], exit 0 = vulnerable / 1 = not vulnerable / 2 = error.\n` +
    `      evidence/      — raw request/response captures, screenshots, the identity comparison, raw tool output.\n` +
    `    Then verify your own artifact parses before you return:\n` +
    `      python3 tools/cvss_recompute.py --vector "<your cvss_vector>" --json     (the band must match severity_claim)\n` +
    `      python3 tools/schema_check.py --kind finding ${OUTPUT_DIR}/findings/finding-<NNN>/finding.json\n` +
    `    A finding.json that does not validate is not a finding. Fix it or report it as a negative.\n\n` +
    `REPORT NEGATIVES IN FULL: what you tried, where it broke, and what would unblock it. A well-corroborated negative\n` +
    `CLOSES a coverage cell (covered_negative) and is a first-class result — do not dress up a non-finding as a finding.\n\n` +
    `Return EXEC_SCHEMA. experiments_logged = how many DISTINCT ladder attempts this warrants as ledger rows. Set\n` +
    `is_negative=true and negative_kind (active_probe | reachability) when the mission produced a clean negative, and give\n` +
    `corroborator = the tools/NNN_*.md path that proves it. blocked_reason is a STRING: '' means no block.`
}

// --- INTEGRATE --------------------------------------------------------------
const INTEGRATE_SCHEMA = {
  type: 'object', additionalProperties: true,
  required: ['exp_count'],
  properties: {
    exp_count: { type: 'integer' },
    rows_appended: { type: 'integer' },
    new_findings: {
      type: 'array',
      items: {
        type: 'object', additionalProperties: true,
        required: ['id', 'dir', 'class_id'],
        properties: {
          id: { type: 'string' },
          dir: { type: 'string' },
          class_id: { type: 'string' },
          cell_key: { type: 'string' },
          covers_cells: { type: 'array', items: { type: 'string' } },
          title: { type: 'string' },
          claimed_severity: { type: 'string' },
          claimed_cvss_vector: { type: 'string' },
          finding_json_valid: { type: 'boolean' },
          schema_check_exit: { type: 'integer' },
        },
      },
    },
    coverage_update: {
      type: 'array',
      items: {
        type: 'object', additionalProperties: true,
        required: ['class_id', 'key', 'status'],
        properties: {
          class_id: { type: 'string' },
          key: { type: 'string' },
          status: { type: 'string', description: 'covered | covered_negative | deferred | pending' },
          e_id: { type: 'string' },
          finding_id: { type: 'string' },
          negative_kind: { type: 'string' },
          corroborator: { type: 'string' },
        },
      },
    },
    coverage_complete: { type: 'boolean' },
    coverage_ratio: { type: 'number' },
    applicable_pending: { type: 'integer' },
    open_cells: { type: 'array', items: { type: 'string' } },
    gate_exit: { type: 'integer' },
    progress: { type: 'boolean' },
    active_goal: { type: 'string' },
    goal_attempts: { type: 'integer' },
    recommend_reset: { type: 'boolean' },
    stuck_goal: { type: 'string' },
    terminate: { type: 'boolean' },
    terminate_reason: { type: 'string' },
    attack_chain_lines: { type: 'integer' },
    coverage_gate_output: { type: 'string' },
    notes: { type: 'array', items: { type: 'string' } },
    blocked_reason: { type: 'string' },
  },
}

function integratePrompt(batch, execResults, resetMode, verdictSignal) {
  return `${DISCIPLINE}\n\n` +
    `ROLE: coordinator INTEGRATE (P4). cwd is ${BUNDLE}. You are the SOLE WRITER of the three state files and of\n` +
    `coverage.json. Parallel executors just ran; their results are below. Nobody else may write these files — that is what\n` +
    `keeps them race-free.\n\n` +
    `ASSET: ${ASSET_TAG}   BATCH: ${batch}${resetMode ? ' (post-reset batch)' : ''}   OUTPUT_DIR: ${OUTPUT_DIR}   RUN DIR: ${RUN_DIR}\n\n` +
    `EXECUTOR RESULTS THIS BATCH:\n${JSON.stringify(execResults, null, 2)}\n\n` +
    `VERDICTS ALREADY TERMINAL (from previous batches; this batch's own new candidates validate AFTER you return):\n` +
    `  confirmed=${JSON.stringify((verdictSignal && verdictSignal.confirmed) || [])}\n` +
    `  rejected=${JSON.stringify((verdictSignal && verdictSignal.rejected) || [])}\n` +
    `  dropped=${JSON.stringify((verdictSignal && verdictSignal.dropped) || [])}\n\n` +
    `${STATE_CONTRACT}\n\n` +
    `${COVERAGE_CONTRACT}\n\n` +
    `DO, in order:\n` +
    `1. APPEND one row per DISTINCT experiment the executors performed to ${OUTPUT_DIR}/experiments.md. E-NNN strictly\n` +
    `   monotonic continuing from the current last row. Use the literal "fail" for a failure (the Goal_attempts rollup keys\n` +
    `   on it). Goal_attempts = prior fails on that Goal + 1. NEVER rewrite, prune, reorder or reformat an existing row.\n` +
    `   Apply the dedup rule before appending.\n` +
    `2. REWRITE ${OUTPUT_DIR}/attack-chain.md (<= 50 LINES — check with wc -l): refresh "## Tested" with terse one-liners\n` +
    `   (prune resolved items), keep the un-chosen hypotheses as backlog, set "## Next" to the single most promising step.\n` +
    `   Report attack_chain_lines.\n` +
    `3. UPDATE ${OUTPUT_DIR}/session-memory.md (append/merge, NEVER delete): new Access & Credentials; new Confirmed Facts;\n` +
    `   every dead end with its WHY under Dead Ends (this is what stops a future batch repeating it); move pursued Open\n` +
    `   Threads out and add the new ones; log any goal pivot under Pivot History.\n` +
    `4. UPDATE ${OUTPUT_DIR}/coverage.json. For every cell an executor actually exercised this batch, write ONE units_tested\n` +
    `   entry {key, status, e_id, finding_id?, negative_kind?, corroborator?}. Apply the coverage rules EXACTLY:\n` +
    `     * covered ONLY when a VALID finding in ${OUTPUT_DIR}/artifacts/validated/ has this class_id + this unit key +\n` +
    `       asset_tag "${ASSET_TAG}". A candidate you materialise NOW is not validated yet — it is NOT covered this batch.\n` +
    `     * covered_negative ONLY with a real corroborator (a tools/NNN_*.md whose "Experiment: E-NNN" header cites raw tool\n` +
    `       output, or a corroborator path that exists). No corroborator -> the cell stays pending.\n` +
    `     * deferred ONLY with a deferral_reason AND a client_input_request path that resolves on disk.\n` +
    `     * NEVER mark a code-applicable cell NA. NEVER credit a cell for a REJECTED or DROPPED candidate.\n` +
    `   Then run, in this order:\n` +
    `     python3 tools/cells_build.py --asset-dir ${OUTPUT_DIR} --catalog catalog/bounty-coverage-matrix.json\n` +
    `     python3 tools/coverage_gate.py --asset-dir ${OUTPUT_DIR}\n` +
    `     python3 tools/coverage_gate.py --asset-dir ${OUTPUT_DIR} --mode strict\n` +
    `   and report the gate's exit code, coverage_ratio, complete flag and the missing_cells count as applicable_pending.\n` +
    `   Copy the gate's open-cell lines into open_cells[]. The GATE is authoritative; if your ledger disagrees with it, the\n` +
    `   gate wins and you fix the ledger.\n` +
    `5. CATALOGUE new candidate findings into new_findings[]: id, dir, class_id, cell_key, covers_cells, title,\n` +
    `   claimed_severity, claimed_cvss_vector, finding_json_valid (did 'python3 tools/schema_check.py --kind finding <path>' run and exit 0?)\n` +
    `   exit 0?), schema_check_exit. Do NOT filter out a candidate because you doubt it — the blind validator decides, not you.\n` +
    `   Do NOT promote anything into artifacts/validated/ yourself; that directory belongs to the blind validator alone.\n` +
    `6. DECIDE and report:\n` +
    `     * progress = did this batch produce NEW information, access, a candidate, OR close a cell? A re-run of a known\n` +
    `       failure with no new observation is NOT progress.\n` +
    `     * active_goal + goal_attempts (fails on the current conceptual goal). recommend_reset=true when goal_attempts >= 3.\n` +
    `     * terminate = true ONLY if every avenue is exhausted AND ## Open Threads is empty AND the gate reports no pending\n` +
    `       applicable cell. "I am out of hypotheses" with pending cells is NOT a reason to terminate.\n\n` +
    `Return INTEGRATE_SCHEMA. exp_count MUST be the authoritative count of E- rows now in experiments.md\n` +
    `(verify with: grep -c '^| E-' ${OUTPUT_DIR}/experiments.md). blocked_reason is a STRING: '' means no block.`
}

// --- BLIND VALIDATOR --------------------------------------------------------
const VALIDATOR_SCHEMA = {
  type: 'object', additionalProperties: true,
  required: ['finding_id', 'verdict', 'verdict_path'],
  properties: {
    finding_id: { type: 'string' },
    verdict: { type: 'string', description: 'CONFIRMED | REJECTED | CURE | DROPPED' },
    checks: { type: 'object', additionalProperties: true },
    failed_checks: { type: 'array', items: { type: 'string' } },
    missing_evidence: { type: 'array', items: { type: 'string' } },
    refuters: { type: 'object', additionalProperties: true },
    cvss: { type: 'object', additionalProperties: true },
    evidence_package: { type: 'array', items: { type: 'string' } },
    reason: { type: 'string' },
    cure_cycles: { type: 'integer' },
    verdict_path: { type: 'string' },
    schema_check_exit: { type: 'integer' },
    poc_ran: { type: 'boolean' },
    deterministic_runs: { type: 'integer' },
    negative_control_silent: { type: 'boolean' },
    blocked_reason: { type: 'string' },
  },
}

// THE BLIND VALIDATOR CONTRACT. Everything below the "MUST NOT READ" line is the
// reason a CONFIRMED verdict means anything at all. Do not add context to it.
function validatorPrompt(cand, cureRound) {
  const isFinal = cureRound >= MAX_CURE_CYCLES
  return `ROLE: BLIND FINDING VALIDATOR (fidelity engine). cwd is ${BUNDLE}. You have NEVER seen this finding before, and you\n` +
    `have deliberately NOT been given the story behind it. Your job is to decide, from raw evidence on disk, whether it is\n` +
    `real — and to default to skepticism: a claim you cannot independently reproduce is not confirmed.\n\n` +
    `FINDING: ${cand.id}\n` +
    `FINDING_DIR (absolute): ${cand.dir}\n` +
    `TARGET_URL: ${cand.endpoint || '<read endpoint + method from finding.json>'}\n` +
    `OUTPUT_DIR: ${OUTPUT_DIR}\n` +
    `CLAIMED: class_id=${cand.class_id} severity=${cand.claimed_severity || '?'} vector=${cand.claimed_cvss_vector || '?'}\n` +
    `CURE ROUND: ${cureRound} of ${MAX_CURE_CYCLES}${isFinal ? '  *** THIS IS THE FINAL ROUND: a still-failing verdict MUST be DROPPED, never CURE. ***' : ''}\n` +
    `CONTRACTS: contracts/validation-verdict.schema.json (schema id bbh/verdict/v1), contracts/finding.schema.json\n` +
    `ROLE REFERENCE: (read it if present, ignore if absent) skills/coordination/reference/VALIDATION.md\n\n` +
    `YOU MUST NOT READ, for any reason: ${OUTPUT_DIR}/attack-chain.md; ${OUTPUT_DIR}/session-memory.md; any other finding's\n` +
    `directory; any coordinator/executor mission log under ${OUTPUT_DIR}/logs/; the coordinator's theory; any previous\n` +
    `verdict for this or another finding; any refuter or validator output. If you catch yourself about to open one of those,\n` +
    `stop — reading them voids your independence and makes your verdict worthless. You MAY read the finding's own directory\n` +
    `(${cand.dir}) and ${OUTPUT_DIR}/recon/ (raw recon data is evidence, not theory).\n\n` +
    `${cveOperands()}\n\n` +
    `RUN THESE SEVEN CHECKS, IN THIS ORDER, and record for each one: pass (boolean), detail, the exact cmd you ran, and a\n` +
    `short digest of the raw output. A check with NO recorded raw output is a FAILED check.\n\n` +
    `1. SCOPE RE-CHECK. For the finding's endpoint AND every URL in its evidence:\n` +
    `     python3 tools/bbh_scope.py check --scope ${SCOPE_REF} --url <url>\n` +
    `   exit 0 = in scope (pass). exit 1 = OUT OF SCOPE -> this is a DROPPED verdict (a real bug the program does not cover),\n` +
    `   never CONFIRMED and never REJECTED. exit 2 = unclear -> DROPPED with the third-party/staging reason named.\n\n` +
    `2. PoC TRUTH. poc.cmd must ACTUALLY RUN. Read poc.cmd from finding.json, cd to ${cand.dir}, and run it. Capture\n` +
    `   stdout+stderr verbatim to ${cand.dir}/evidence/validation/poc-rerun-output.txt.\n` +
    `   - If the script is missing, does not parse, or fails to run: REPAIR it (write a standalone script that proves the\n` +
    `     stated claim read-only; do not change the claim) and re-run. A repaired-and-passing PoC still CONFIRMS the finding —\n` +
    `     record the repair explicitly. A PoC that cannot be made to emit the proof token is a FAILED check, full stop.\n` +
    `   - Run it at least 3 TIMES. All runs must print the SAME decisive output after normalising timestamps, UUIDs,\n` +
    `     session tokens, nonces and dynamic ports. That is the poc_deterministic check.\n` +
    `   - Run poc.negative_control. It MUST NOT print the success token. If the control also prints it, the signal is noise\n` +
    `     and the finding FAILS — this is the single most common false positive and you are the last line of defence.\n` +
    `   - Also write ${cand.dir}/evidence/validation/verification-script.py: a STANDALONE reproduction with its own imports\n` +
    `     and target refs that does NOT import the executor's poc. A human runs that one file to reproduce.\n\n` +
    `3. EVIDENCE COMPLETENESS. Every path in evidence.artifacts[] must EXIST and be non-empty. Stat each one\n` +
    `   (test -f / wc -c) and report the list. A single missing path is a FAILED check with that exact path in missing_evidence[].\n\n` +
    `4. CROSS-IDENTITY PROOF — required when class_id is an IDOR / BOLA / ATO / privilege-escalation class, and when the\n` +
    `   finding claims one. All three of these must hold:\n` +
    `     (a) the ACTOR identity reaches the VICTIM's data or action (quote the victim-owned field in the response);\n` +
    `     (b) a FRESH session for the actor STILL reproduces it (re-authenticate, do not reuse the old cookie/token);\n` +
    `     (c) an ANONYMOUS request DIFFERS (a 401/403, a redirect to login, or simply not the victim's data).\n` +
    `   Write ${cand.dir}/evidence/validation/two-identity-comparison.txt with the three raw exchanges side by side.\n` +
    `   If (c) does not differ, the endpoint is public and this is NOT the finding claimed: FAIL.\n` +
    `   If evidence.identity is absent for one of those classes: FAILED check with\n` +
    `   missing_evidence[] = ["evidence/two-identity-comparison.txt", "evidence.identity.{actor,victim} in finding.json"].\n\n` +
    `5. CVSS TRUTH. Recompute from the vector — never trust the claimed number:\n` +
    `     python3 tools/cvss_recompute.py --vector "<finding.cvss_vector>" --json\n` +
    `   Compare score, band and vector against severity_claim. A vector/band mismatch is a FAILED check (cvss_recomputed),\n` +
    `   not a rounding note. Also apply the root-cause floor: if description.md asserts a HIGHER latent impact that follows\n` +
    `   from a confirmed missing control, and the claimed band is more than one band below the recomputed one, FAIL it for\n` +
    `   under-rating. Do not invent impact the finding does not claim.\n\n` +
    `6. CVE TRUTH — only when a CVE is claimed. Use the frozen operands above. The claimed CVE id, CVSS vector, base score\n` +
    `   and severity must ALL agree with NVD and with your own from-vector recomputation; flag KEV membership. Write\n` +
    `   ${cand.dir}/evidence/validation/cve-verification.md per CVE (NVD summary, chosen CVSS version + vector, computed\n` +
    `   score, KEV status, advisory URL, quoted affected-version line). Any unreconciled divergence FAILS the check.\n\n` +
    `7. ADVERSARIAL QUORUM. Spawn ${VOTES} INDEPENDENT refuters, each of whom sees ONLY the finding's raw evidence (this\n` +
    `   directory, including the validation/ artifacts you just produced) and NOT your reasoning, NOT the verdict you are\n` +
    `   leaning towards, NOT each other's arguments. Each must try to REFUTE the finding and answer: does the captured output\n` +
    `   actually PROVE the vulnerability, or is it incidental / ambiguous / self-asserted? Could the same output be produced\n` +
    `   on a NON-vulnerable target? Is the impact demonstrated or merely enabled? Does the CVE's vulnerable feature actually\n` +
    `   exist, enabled and reachable, on this asset (a version banner is not a patch level)? Apply common false-High\n` +
    `   calibration: a CORS reflected-origin without Access-Control-Allow-Credentials:true plus cookie auth is not token\n` +
    `   theft; an enabler scored as a demonstrated compromise is refuted; a scanner version-only "Critical" on a\n` +
    `   backported/appliance package is a candidate until the backport is checked.\n` +
    `   CONFIRMATION REQUIRES ALL ${VOTES} TO FAIL TO REFUTE. A single substantiated refutation is a REJECTED verdict and\n` +
    `   its argument goes into refuters.refutation_args[]. Record refuters.count and refuters.refuted.\n\n` +
    `DECIDE:\n` +
    `  CONFIRMED  — every check passed (or passed after a disclosed repair) and no refuter succeeded.\n` +
    `  REJECTED   — a refuter substantiated a refutation, or the core claim is contradicted by the raw evidence. This is the\n` +
    `               false-positive verdict; write it to artifacts/false-positives/ and say so plainly.\n` +
    `  CURE       — the bug is real but the package is incomplete or broken (missing artifact, non-deterministic PoC, a vector\n` +
    `               to recompute, an identity comparison to produce). Put the EXACT check names in failed_checks[] and the\n` +
    `               EXACT artifact paths to produce in missing_evidence[]. The cure executor gets nothing else, so be specific.\n` +
    `               ${isFinal ? 'NOT ALLOWED on this final round — use DROPPED.' : ''}\n` +
    `  DROPPED    — out of scope, or still uncured after the cure budget. It is a real bug the program cannot take, so it is\n` +
    `               neither reported nor counted as covered. Write it to artifacts/dropped/ with the reason.\n\n` +
    `WRITE THE VERDICT to exactly one of:\n` +
    `  ${OUTPUT_DIR}/artifacts/validated/<id>.json       (CONFIRMED)\n` +
    `  ${OUTPUT_DIR}/artifacts/false-positives/<id>.json (REJECTED)\n` +
    `  ${OUTPUT_DIR}/artifacts/dropped/<id>.json         (DROPPED)\n` +
    `conforming to contracts/validation-verdict.schema.json, with: schema "bbh/verdict/v1", finding_id, asset_tag "${ASSET_TAG}",\n` +
    `validated_at from 'date -u +%Y-%m-%dT%H:%M:%SZ', verdict, checks{} (one entry per check above with pass/detail/cmd/\n` +
    `output_digest), failed_checks[], missing_evidence[], refuters{count,refuted,refutation_args[]}, cvss{vector,claim_score,\n` +
    `recomputed_score,recomputed_band,nvd_score,kev_listed}, evidence_package[], reason (one paragraph a human can act on),\n` +
    `cure_cycles=${cureRound}. Write NOTHING else anywhere, and never modify the executor's files except to add the\n` +
    `evidence/validation/ artifacts described above.\n` +
    `Then run: python3 tools/schema_check.py --kind verdict <the file you wrote>  — record its exit code.\n` +
    `A verdict file that does not validate is not a verdict. Fix it and re-run.\n\n` +
    `Return VALIDATOR_SCHEMA. blocked_reason is a STRING: '' means no block.`
}

// --- CURE EXECUTOR ----------------------------------------------------------
const CURE_SCHEMA = {
  type: 'object', additionalProperties: true,
  required: ['cured_gates'],
  properties: {
    cured_gates: { type: 'array', items: { type: 'string' } },
    uncured_gates: { type: 'array', items: { type: 'string' } },
    produced_evidence: { type: 'array', items: { type: 'string' } },
    poc_changed: { type: 'boolean' },
    finding_dir: { type: 'string' },
    notes: { type: 'string' },
    blocked_reason: { type: 'string' },
  },
}

function curePrompt(cand, failedChecks, missingEvidence, cureRound) {
  return `ROLE: CURE EXECUTOR (scoped gap-closer — NOT a re-investigator). cwd is ${BUNDLE}.\n` +
    `A blind validator could not confirm finding ${cand.id} because of the specific gaps below. Close EXACTLY those gaps.\n\n` +
    `FINDING: ${cand.id}\nFINDING_DIR: ${cand.dir}\nTARGET_URL: ${cand.endpoint || '<from finding.json>'}\nOUTPUT_DIR: ${OUTPUT_DIR}\n` +
    `CURE ROUND: ${cureRound + 1} of ${MAX_CURE_CYCLES}\n` +
    `UNMET CHECKS (failed_checks, machine-readable): ${JSON.stringify(failedChecks || [])}\n` +
    `MISSING EVIDENCE (produce EXACTLY these paths): ${JSON.stringify(missingEvidence || [])}\n` +
    `CONTRACT: contracts/finding.schema.json\n\n` +
    `HARD BOUNDARIES — violating any of these voids the cure and the next validator will fail it again:\n` +
    `  * Do NOT re-theorize. Do NOT change the claim, the class_id, or the affected endpoint.\n` +
    `  * Do NOT expand scope. Do NOT hunt for other vulnerabilities. Do NOT open attack-chain.md, session-memory.md, or\n` +
    `    any other finding's directory — you have exactly one job and it is named above.\n` +
    `  * Do NOT write anything outside ${cand.dir}, and inside it touch only the files the named gaps require.\n` +
    `  * Do NOT fabricate. Every artifact must come from a real command you really ran. Re-run the tool that generates it.\n\n` +
    `WHAT EACH CHECK NAME MEANS AND WHAT TO DO:\n` +
    `  evidence:missing_files / evidence_complete -> create each path in MISSING EVIDENCE with REAL content.\n` +
    `  poc_runs / poc_deterministic            -> fix poc.cmd and the script until 3 consecutive runs print the SAME\n` +
    `                                             decisive output; update poc.runs and poc.deterministic in finding.json.\n` +
    `  negative_control                        -> make the control genuinely silent (it must NOT print the success token)\n` +
    `                                             and capture its output as an artifact.\n` +
    `  cross_identity                          -> produce evidence/two-identity-comparison.txt (actor reaches victim data,\n` +
    `                                             a FRESH actor session still does, anonymous differs) and populate\n` +
    `                                             evidence.identity.{actor,victim,anonymous} in finding.json.\n` +
    `  cvss_recomputed                         -> python3 tools/cvss_recompute.py --vector "<vector>" --json and correct\n` +
    `                                             finding.json's cvss_vector / severity_claim until band and score agree.\n` +
    `  cve_truth                               -> ${cveOperands().split('\n').join('\n                                             ')}\n` +
    `  scope_in_scope                          -> the endpoint is out of scope. Do NOT try to make it in scope. Stop and\n` +
    `                                             report it as uncured so the validator can DROP it.\n` +
    `  not_known_duplicate                     -> search the program's disclosed reports for this exact class+endpoint and\n` +
    `                                             record the search (queries used, results) as an artifact.\n` +
    `  Any check you cannot map: say so in uncured_gates[] and explain why. Do not guess.\n\n` +
    `Reversible, authorised, non-destructive actions ONLY (scope.json roe: ${JSON.stringify(boot.roe || {})}).\n` +
    `When you are done, re-validate your own artifact: python3 tools/schema_check.py --kind finding ${cand.dir}/finding.json\n\n` +
    `Return CURE_SCHEMA. Your return is NOT trusted as proof — a FRESH blind validator re-checks everything you did, which\n` +
    `is why you must leave the evidence on disk rather than asserting it in prose. blocked_reason is a STRING: '' = no block.`
}

// --- DEMOTER (cure budget exhausted) ---------------------------------------
const DEMOTE_SCHEMA = {
  type: 'object', additionalProperties: true,
  required: ['demoted'],
  properties: {
    demoted: { type: 'boolean' },
    dropped_path: { type: 'string' },
    schema_check_exit: { type: 'integer' },
    reason: { type: 'string' },
    blocked_reason: { type: 'string' },
  },
}

function demotePrompt(cand, verdict, cureRound) {
  return `ROLE: CURE-BUDGET DEMOTER (mechanical rewrite; no judgment, no requests). cwd is ${BUNDLE}.\n` +
    `Finding ${cand.id} still has unmet checks after ${cureRound} cure round(s), which is the configured maximum\n` +
    `(${MAX_CURE_CYCLES}). The cure loop is CLOSED. Your single job is to record that terminal state honestly.\n\n` +
    `FINDING: ${cand.id}   FINDING_DIR: ${cand.dir}   OUTPUT_DIR: ${OUTPUT_DIR}\n` +
    `UNMET CHECKS: ${JSON.stringify((verdict && verdict.failed_checks) || [])}\n` +
    `MISSING EVIDENCE: ${JSON.stringify((verdict && verdict.missing_evidence) || [])}\n` +
    `CONTRACT: contracts/validation-verdict.schema.json\n\n` +
    `DO EXACTLY THIS:\n` +
    `1. Read the current verdict file at ${(verdict && verdict.verdict_path) || `${OUTPUT_DIR}/artifacts/<sub>/${cand.id}.json`}.\n` +
    `2. Write ${OUTPUT_DIR}/artifacts/dropped/${cand.id}.json: the SAME object with verdict changed to "DROPPED",\n` +
    `   cure_cycles set to ${cureRound}, and reason extended with: "cure budget (${MAX_CURE_CYCLES}) exhausted with unmet\n` +
    `   checks <failed_checks>; not confirmable as submitted." Keep every check, digest and refuter entry exactly as it was —\n` +
    `   do NOT soften or delete a failed check.\n` +
    `3. If a file for this finding exists under artifacts/validated/ or artifacts/false-positives/, delete it so the finding\n` +
    `   cannot be double-counted. Never delete anything else.\n` +
    `4. Run: python3 tools/schema_check.py --kind verdict ${OUTPUT_DIR}/artifacts/dropped/${cand.id}.json  — record the exit code.\n\n` +
    `Return DEMOTE_SCHEMA. blocked_reason is a STRING: '' means no block.`
}

// --- SKEPTIC ----------------------------------------------------------------
const SKEPTIC_SCHEMA = {
  type: 'object', additionalProperties: true,
  required: ['brief_path'],
  properties: {
    brief_path: { type: 'string' },
    dominant_theory: { type: 'string' },
    objection_found: { type: 'boolean' },
    counter_hypotheses: { type: 'array', items: { type: 'string' } },
    contradicting_evidence: { type: 'array', items: { type: 'string' } },
    unstated_assumptions: { type: 'array', items: { type: 'string' } },
    blocked_reason: { type: 'string' },
  },
}

function skepticPrompt(N) {
  return `ROLE: SKEPTIC at experiment ${N} (mandatory checkpoint). cwd is ${BUNDLE}. You are BLIND to the coordinator's\n` +
    `theory on purpose — that is what keeps you empirical rather than agreeable.\n\n` +
    `ASSET: ${ASSET_TAG}   OUTPUT_DIR: ${OUTPUT_DIR}   EXPERIMENT_COUNT: ${N}\n\n` +
    `READ ONLY: ${OUTPUT_DIR}/experiments.md (the full ledger) and the recon tree ${OUTPUT_DIR}/recon/ (listing + key files).\n` +
    `YOU MUST NOT READ: ${OUTPUT_DIR}/attack-chain.md, ${OUTPUT_DIR}/session-memory.md, any playbook/skill file, any research\n` +
    `brief, any finding directory, any verdict. Reading them voids your independence and your brief becomes worthless.\n\n` +
    `FROM THE LEDGER ALONE:\n` +
    `1. Infer the DOMINANT theory being pursued — what does this run appear to believe about the asset?\n` +
    `2. ARGUE AGAINST IT. Name the unstated assumptions it rests on.\n` +
    `3. Surface any recon evidence that CONTRADICTS the current direction.\n` +
    `4. Propose EXACTLY 2 counter-hypotheses, at least one grounded in evidence already collected. Do not propose a\n` +
    `   technique already tried with Goal_attempts >= 1.\n` +
    `5. Call out any GOAL with Goal_attempts >= 3 — that theory is spent and the run should have abandoned it.\n\n` +
    `Write ${OUTPUT_DIR}/skeptic-brief-${N}.md: the inferred theory, your objections, the 2 counter-hypotheses, and the\n` +
    `contradicting evidence with its file path. Spend at most 5 minutes; if no real objection forms, write exactly\n` +
    `"no skepticism — current theory looks well-grounded" and exit rather than manufacturing one.\n\n` +
    `Write NOTHING else. Return SKEPTIC_SCHEMA. blocked_reason is a STRING: '' means no block.`
}

// --- CHAIN ------------------------------------------------------------------
const CHAIN_SCHEMA = {
  type: 'object', additionalProperties: true,
  required: ['finding_id', 'chain_path'],
  properties: {
    finding_id: { type: 'string' },
    chain_path: { type: 'string' },
    hops: {
      type: 'array',
      items: {
        type: 'object', additionalProperties: true,
        required: ['hop', 'from', 'to', 'status'],
        properties: {
          hop: { type: 'string' },
          from: { type: 'string' },
          to: { type: 'string' },
          status: { type: 'string', description: 'CONFIRMED | HYPOTHESIS | IMPOSSIBLE' },
          evidence: { type: 'string' },
          cmd: { type: 'string' },
        },
      },
    },
    max_impact_proven: { type: 'string' },
    new_candidates: {
      type: 'array',
      items: {
        type: 'object', additionalProperties: true,
        required: ['id', 'dir', 'class_id'],
        properties: {
          id: { type: 'string' },
          dir: { type: 'string' },
          class_id: { type: 'string' },
          covers_cells: { type: 'array', items: { type: 'string' } },
          title: { type: 'string' },
          claimed_severity: { type: 'string' },
          claimed_cvss_vector: { type: 'string' },
        },
      },
    },
    reachable_without_privilege: { type: 'boolean' },
    blocked_reason: { type: 'string' },
  },
}

function chainPrompt(cand, nextFindingNum) {
  return `${DISCIPLINE}\n\n` +
    `ROLE: CHAIN EXECUTOR (the ABH /chain equivalent) for ONE confirmed finding. cwd is ${BUNDLE}.\n` +
    `A primitive is confirmed. Your job is to answer "so what?" rigorously: what does A unlock, and what does that unlock?\n\n` +
    `ROOT FINDING: ${cand.id}   FINDING_DIR: ${cand.dir}   CLASS: ${cand.class_id}\n` +
    `ASSET: ${ASSET_TAG}   OUTPUT_DIR: ${OUTPUT_DIR}   SCOPE: ${SCOPE_REF}   ROE: ${JSON.stringify(boot.roe || {})}\n` +
    `READ: ${cand.dir}/finding.json (especially chain_hints[]), ${cand.dir}/description.md, ${cand.dir}/evidence/,\n` +
    `      and the asset's surface ${OUTPUT_DIR}/recon/inventory/surface.json.\n` +
    `YOU MUST NOT READ: ${OUTPUT_DIR}/attack-chain.md or ${OUTPUT_DIR}/session-memory.md (not your theory to inherit),\n` +
    `      or any other finding's directory except where a hop genuinely needs to cite it.\n\n` +
    `METHOD — build an explicit A -> B -> C chain, one hop at a time:\n` +
    `  A = the confirmed primitive you were handed.\n` +
    `  B = the concrete new capability A enables (read another tenant's object, act as another user, reach an internal\n` +
    `      service, execute code, persist).\n` +
    `  C = the end impact a program would actually pay for (cross-tenant data at scale, account takeover, RCE, full read of\n` +
    `      a sensitive store). Stop at C, or continue to D only if D is a genuinely different impact class.\n\n` +
    `FOR EACH HOP you must either PROVE it or LABEL it — there is no third option:\n` +
    `  * status "CONFIRMED": you actually executed it. Give the exact cmd and the raw output that proves it, and write the\n` +
    `    output to ${cand.dir}/evidence/chain/hop-<n>.txt. Re-run it to confirm determinism before you call it confirmed.\n` +
    `  * status "HYPOTHESIS": you reasoned it but did not (or could not) execute it. Say exactly what would be required to\n` +
    `    confirm it. A HYPOTHESIS hop is NEVER worded as a proven impact anywhere in your output.\n` +
    `  * status "IMPOSSIBLE": you tested it and it does not work. Say why.\n` +
    `A chain is only as strong as its weakest hop: max_impact_proven must be the impact reachable using CONFIRMED hops only.\n\n` +
    `IF A HOP IS ITSELF A NEW, DISTINCT VULNERABILITY (not merely a consequence), file it as a new candidate so it goes\n` +
    `through blind validation like anything else:\n` +
    `  ${OUTPUT_DIR}/findings/finding-${pad3(nextFindingNum)}/ with a finding.json conforming to contracts/finding.schema.json,\n` +
    `  exactly as an executor would write it (verbatim request/response, artifacts that exist on disk, a runnable poc.cmd\n` +
    `  with >=3 deterministic runs and a silent negative control, explicit impact). Report it in new_candidates[].\n` +
    `  Do NOT validate it yourself and do NOT put it in artifacts/validated/ — the blind validator decides.\n\n` +
    `WRITE ${OUTPUT_DIR}/chains/${cand.id}.md:\n` +
    `  # Chain for ${cand.id}\\n## A (confirmed primitive)\\n## B\\n## C\\n## Hop evidence\\n## What is NOT proven\\n## What would confirm the rest\n` +
    `  Every hop: status, the command, the observed output (or the reason it is unproven). "## What is NOT proven" is\n` +
    `  mandatory and must never be empty — an honest chain that stops at B is worth far more than an invented C.\n\n` +
    `ROE: reversible, non-destructive, own-tenant writes only if allow_writes permits; clean up anything you create.\n` +
    `Scope-check every new URL: python3 tools/bbh_scope.py check --scope ${SCOPE_REF} --url <url>\n\n` +
    `Return CHAIN_SCHEMA. reachable_without_privilege = can the chain be walked by an ordinary user with no admin help?\n` +
    `blocked_reason is a STRING: '' means no block.`
}

// --- 7-QUESTION GATE --------------------------------------------------------
const GATE_SCHEMA = {
  type: 'object', additionalProperties: true,
  required: ['finding_id', 'verdict', 'q_path'],
  properties: {
    finding_id: { type: 'string' },
    verdict: { type: 'string', description: 'PASS | KILL | CURE' },
    killed_by: { type: 'string' },
    kill_reason: { type: 'string' },
    failed_questions: { type: 'array', items: { type: 'string' } },
    downgrade_to: { type: 'string' },
    cycle: { type: 'integer' },
    q_path: { type: 'string' },
    chain_used: { type: 'string' },
    schema_check_exit: { type: 'integer' },
    blocked_reason: { type: 'string' },
  },
}

function gatePrompt(cand, chain, cycle) {
  return `${DISCIPLINE}\n\n` +
    `ROLE: 7-QUESTION GATE (the ABH submission gate) for ONE finding. cwd is ${BUNDLE}.\n` +
    `This answers a DIFFERENT question from validation. Validation asks "is this real?". You ask "is this worth submitting\n` +
    `to THIS program, and does the impact actually land?". ONE wrong answer stops the finding. Be strict — a wrong PASS\n` +
    `costs reputation and a week of triage.\n\n` +
    `FINDING: ${cand.id}   FINDING_DIR: ${cand.dir}   CLASS: ${cand.class_id}   CYCLE: ${cycle} of ${MAX_CURE_CYCLES}\n` +
    `ASSET: ${ASSET_TAG}   OUTPUT_DIR: ${OUTPUT_DIR}   SCOPE: ${SCOPE_REF}\n` +
    `VALIDATION VERDICT: ${cand.verdict_path}\n` +
    `CHAIN DOCUMENT: ${chain || `${OUTPUT_DIR}/chains/${cand.id}.md (absent — treat the chain as unproven)`}\n` +
    `CONTRACT: contracts/seven-questions.schema.json (schema id bbh/7q/v1) — read it; the answers object is\n` +
    `additionalProperties:false and every one of the seven keys is required.\n\n` +
    `ANSWER ALL SEVEN, each with pass (boolean) and detail. Detail must cite a file you read or a command you ran.\n\n` +
    `Q1 q1_demonstrable_right_now - Can you demonstrate it RIGHT NOW, end to end? Write it as a five-line block:\n` +
    `     setup / request / result / impact / cost. FAIL if the "request" line reads "I need to look at the code more",\n` +
    `     or if reproducing it needs a step you have not performed. Setup on a clean box, run it, quote the result.\n` +
    `Q2 q2_impact_accepted - Is this bug class inside the program's ACCEPTED list and outside its EXCLUSIONS? Read the\n` +
    `     program's policy text from the scope file / the program page. Quote the line that admits or excludes it.\n` +
    `     If the program does not publish one, say so and pass only when Q6 does.\n` +
    `Q3 q3_asset_in_scope - Is the EXACT host in scope, and is it production (not staging/dev/third-party)? Run\n` +
    `     python3 tools/bbh_scope.py check --scope ${SCOPE_REF} --url <the finding's endpoint> and quote the exit code.\n` +
    `     exit 1 or 2 -> FAIL, full stop.\n` +
    `Q4 q4_no_privileged_access_needed - Does it work WITHOUT privileged access? FAIL for "an admin can do X". PASS for\n` +
    `     "a regular user can do X that only an admin should". Name the lowest-privilege identity that reproduces it.\n` +
    `Q5 q5_not_known_behavior - Is it NOT documented/known/intended? Search disclosed reports for this program and class,\n` +
    `     the changelog, and the public API docs. Record the queries you ran and what you found. An intended feature is\n` +
    `     a KILL, not a finding.\n` +
    `Q6 q6_impact_proven - Is the IMPACT proven, not the mechanism? XSS needs the exfiltrated value, not alert(). SSRF\n` +
    `     needs an internal response body, not a DNS hit. IDOR needs the OTHER user's data, not a 200. Open redirect needs\n` +
    `     a victim-reachable sink. If it only proves at a lower severity, set downgrade_to and pass with the lower bar.\n` +
    `Q7 q7_not_never_submit - Is this off the always-rejected list (self-XSS, missing headers with no impact, best-practice\n` +
    `     nits, rate-limit-only, clickjacking on a non-sensitive page, SPF/DMARC, logout CSRF, tabnabbing, autofill,\n` +
    `     CSV injection without a sink, "could be used for phishing", version disclosure alone, open redirect alone)?\n` +
    `     If it IS on that list, it passes ONLY when a CONFIRMED chain makes it valid — set chain_used to that chain and\n` +
    `     point at its hop evidence. No confirmed chain -> FAIL.\n\n` +
    `VERDICT:\n` +
    `  PASS  - all seven pass. Consolidate the proven impact from the CONFIRMED hops only; never quote a HYPOTHESIS hop as\n` +
    `          impact. If Q6 passed only at a lower severity, set downgrade_to to that severity.\n` +
    `  KILL  - the finding is not submittable (intended behavior, always-rejected with no chain, trivial impact, out of\n` +
    `          scope). Set killed_by to the question id and kill_reason to the specific reason. A KILL is a real result,\n` +
    `          not a failure — record it and stop.\n` +
    `  CURE  - the finding IS submittable in principle but a NAMED question fails for a fixable reason (an artifact is\n` +
    `          missing, a policy line must be quoted, the impact needs one more demonstrated step). Put the failing question\n` +
    `          ids in failed_questions[]. ${cycle >= MAX_CURE_CYCLES ? 'NOT ALLOWED this round (cycle budget spent) — PASS or KILL.' : 'The finding goes back to the cure loop and is re-validated BEFORE this gate runs again.'}\n\n` +
    `WRITE ${OUTPUT_DIR}/seven-questions/${cand.id}.json conforming to contracts/seven-questions.schema.json: schema\n` +
    `"bbh/7q/v1", finding_id, asset_tag "${ASSET_TAG}", cycle=${cycle}, answers{} with all seven keys exactly as named above\n` +
    `(each {pass, detail} plus Q1's setup/request/result/impact/cost and Q7's chain_used), verdict, killed_by, kill_reason,\n` +
    `downgrade_to.\n` +
    `Then run: python3 tools/schema_check.py --kind seven-questions ${OUTPUT_DIR}/seven-questions/${cand.id}.json and record\n` +
    `the exit code. A 7-Question result that does not validate is not a completed gate.\n\n` +
    `Return GATE_SCHEMA. blocked_reason is a STRING: '' means no block.`
}

// --- REPRO PACK -------------------------------------------------------------
const REPRO_SCHEMA = {
  type: 'object', additionalProperties: true,
  required: ['built'],
  properties: {
    built: {
      type: 'array',
      items: {
        type: 'object', additionalProperties: true,
        required: ['finding_id', 'runbook_path'],
        properties: {
          finding_id: { type: 'string' },
          runbook_path: { type: 'string' },
          pack_dir: { type: 'string' },
          zip_path: { type: 'string' },
          repro_pack_exit: { type: 'integer' },
          verify_result: { type: 'string' },
        },
      },
    },
    refused: {
      type: 'array',
      items: {
        type: 'object', additionalProperties: true,
        required: ['finding_id', 'reason'],
        properties: { finding_id: { type: 'string' }, reason: { type: 'string' } },
      },
    },
    blocked_reason: { type: 'string' },
  },
}

function reproPrompt(passList) {
  return `${DISCIPLINE}\n\n` +
    `ROLE: REPRO PACK BUILDER (tool runner; no judgment). cwd is ${BUNDLE}.\n` +
    `The deliverable of this pipeline is a runbook a human follows BY HAND, on a clean box, without an agent. Build one\n` +
    `pack per finding that passed the 7-Question Gate.\n\n` +
    `ASSET: ${ASSET_TAG}   OUTPUT_DIR: ${OUTPUT_DIR}   RUN DIR: ${RUN_DIR}\n` +
    `FINDINGS THAT PASSED THE GATE:\n${JSON.stringify(passList, null, 2)}\n\n` +
    `FOR EACH, run the frozen packer:\n` +
    `  python3 tools/repro_pack.py --finding-dir <finding_dir> --verdict <verdict_path> --seven-q <seven_q_path> \\\n` +
    `      --out ${RUN_DIR}/repro/<finding_id>\n` +
    `It emits RUNBOOK.md (rendered from bbh/repro/v1 — every command fenced, install section first, a TROUBLESHOOTING\n` +
    `section built from gotchas + each step's on_failure), pack/ (poc/, evidence/, env/install.sh, verify.sh) and a zip.\n` +
    `It REFUSES to build when the stage-6 verdict is not CONFIRMED or the stage-8 verdict is not PASS (exit 1, printing\n` +
    `REFUSED: with the reason; exit 2 means an input could not be read). Record any refusal verbatim in refused[] and keep\n` +
    `going. NEVER hand-render a runbook to work around it.\n` +
    `Then run the pack's own non-interactive check and record the outcome:\n` +
    `  bash ${RUN_DIR}/repro/<finding_id>/pack/verify.sh\n` +
    `A failing verify.sh is not a blocker — record which step failed and its output; that is the most useful thing the human\n` +
    `will read. Read ${RUN_DIR}/repro/<finding_id>/RUNBOOK.md back and confirm it has non-empty setup, reproduce and verify\n` +
    `sections; if a section is empty, say so in refused[] with the reason (the packer produced an incomplete runbook).\n\n` +
    `Return REPRO_SCHEMA. blocked_reason is a STRING: '' means no block.`
}

// ============================================================================
// PHASE: Loop — think -> (research) -> execute -> integrate -> (skeptic)
// ============================================================================
phase('Loop')

let batch = 0
let exp = Number(boot.exp_count) || 0
let prevExp = exp
let dryStreak = 0
let resetMode = false
let resetGoal = null
let stopped = false
let stopReason = ''
let coveragePending = Infinity
let coverageComplete = false
let coverageRatio = null
let openCells = []
let activeGoal = ''
let goalAttempts = 0
let attackChainLines = null   // reported by THINK/INTEGRATE (the script has no filesystem)
const skepticBriefs = []
const allCandidateIds = new Set()
const terminal = { CONFIRMED: [], REJECTED: [], DROPPED: [] }
const findingsOut = []
let nextFindingNum = 1

// Ingest whatever is already on disk from a previous run of this coordinator, so
// a resumed asset never re-validates a terminal verdict (that would be wasted
// agents) and never forgets a candidate it already produced. `exp > 0` is the
// resume signal: every candidate is materialised by INTEGRATE, and INTEGRATE
// always appends at least one ledger row when it materialises one.
if (exp > 0) {
  const ingest = await agent(
    `ROLE: RESUME INGEST (deterministic read-back; no requests, no judgment). cwd is ${BUNDLE}.\n` +
    `This coordinator is resuming an asset that already has work on disk. Report the EXISTING terminal state so the loop\n` +
    `does not redo it.\n\n` +
    `OUTPUT_DIR: ${OUTPUT_DIR}\nASSET: ${ASSET_TAG}\n\n` +
    `DO:\n` +
    `1. exp_count = grep -c '^| E-' ${OUTPUT_DIR}/experiments.md   (0 if the file is missing)\n` +
    `2. Highest existing finding number: ls -1d ${OUTPUT_DIR}/findings/finding-* 2>/dev/null | tail -1   -> report next_index\n` +
    `   (0 when there are none) so new findings never collide with an old F-NNN.\n` +
    `3. For EVERY json under ${OUTPUT_DIR}/artifacts/validated/, artifacts/false-positives/ and artifacts/dropped/:\n` +
    `   report {finding_id, verdict, class_id, cure_cycles, path}. Read the verdict field from the file; do not infer it\n` +
    `   from the directory name — but note in notes[] if the two disagree, because that is a real bug.\n` +
    `4. For every ${OUTPUT_DIR}/seven-questions/*.json report {finding_id, verdict, cycle, path}.\n` +
    `5. Run BOTH gate modes:\n` +
    `     python3 tools/coverage_gate.py --asset-dir ${OUTPUT_DIR}\n` +
    `     python3 tools/coverage_gate.py --asset-dir ${OUTPUT_DIR} --mode strict\n` +
    `   Report each exit code, the coverage_ratio and the complete flag from ${OUTPUT_DIR}/reports/coverage-matrix.json,\n` +
    `   plus the still-open cell keys. Exit 1 is expected before any work has been done.\n\n` +
    `Return RESUME_SCHEMA. Read only; write nothing.`,
    {
      schema: {
        type: 'object', additionalProperties: true,
        required: ['exp_count'],
        properties: {
          exp_count: { type: 'integer' },
          next_index: { type: 'integer' },
          terminal_verdicts: {
            type: 'array',
            items: {
              type: 'object', additionalProperties: true,
              required: ['finding_id', 'verdict', 'path'],
              properties: {
                finding_id: { type: 'string' },
                verdict: { type: 'string' },
                class_id: { type: 'string' },
                cure_cycles: { type: 'integer' },
                path: { type: 'string' },
              },
            },
          },
          gate_verdicts: {
            type: 'array',
            items: {
              type: 'object', additionalProperties: true,
              required: ['finding_id', 'verdict', 'path'],
              properties: {
                finding_id: { type: 'string' },
                verdict: { type: 'string' },
                cycle: { type: 'integer' },
                path: { type: 'string' },
              },
            },
          },
          gate_exit: { type: 'integer' },
          coverage_ratio: { type: 'number' },
          coverage_complete: { type: 'boolean' },
          open_cells: { type: 'array', items: { type: 'string' } },
          notes: { type: 'array', items: { type: 'string' } },
          blocked_reason: { type: 'string' },
        },
      },
      label: 'resume:ingest', phase: 'Loop',
    }
  )
  if (ingest) {
    exp = Number(ingest.exp_count) || exp
    nextFindingNum = (Number(ingest.next_index) || 0) + 1
    for (const v of (ingest.terminal_verdicts || [])) {
      if (!v || !v.finding_id) continue
      allCandidateIds.add(v.finding_id)
      const key = String(v.verdict).toUpperCase()
      if (terminal[key] && !terminal[key].some((x) => x.finding_id === v.finding_id)) {
        terminal[key].push({ finding_id: v.finding_id, class_id: v.class_id, verdict: key, cure_cycles: v.cure_cycles, verdict_path: v.path, reason: 'restored from disk on resume' })
        findingsOut.push({ finding_id: v.finding_id, class_id: v.class_id, verdict: key, cure_cycles: v.cure_cycles, verdict_path: v.path, seven_q_verdict: 'NOT_RUN', seven_q_path: '', chain_used: '', repro_dir: '' })
      }
    }
    if (ingest.coverage_complete === true) { coverageComplete = true; coveragePending = 0 }
    else if (typeof ingest.gate_exit === 'number' && ingest.gate_exit !== 2) coveragePending = Number.MAX_SAFE_INTEGER
    coverageRatio = typeof ingest.coverage_ratio === 'number' ? ingest.coverage_ratio : null
    openCells = Array.isArray(ingest.open_cells) ? ingest.open_cells : []
    log(`resume: exp=${exp} next_finding=${nextFindingNum} terminal=${terminal.CONFIRMED.length}C/${terminal.REJECTED.length}R/${terminal.DROPPED.length}D complete=${coverageComplete}`)
  }
}

// ---- the blind validator lane (interleaved) --------------------------------
// A candidate reaches this lane from three places (INTEGRATE's new_findings, the
// chain stage's new_candidates, and a 7-Question cure re-validation of an already
// terminal finding). Those carry slightly different keys, so normalise once,
// here, rather than letting an undefined finding_id reach a validator prompt.
function asCandidate(x) {
  const id = x.id || x.finding_id || ''
  return {
    id: id,
    dir: x.dir || x.finding_dir || `${OUTPUT_DIR}/findings/finding-${String(id).replace(/^F-/, '')}`,
    class_id: x.class_id || '',
    endpoint: x.endpoint || '',
    claimed_severity: x.claimed_severity || '',
    claimed_cvss_vector: x.claimed_cvss_vector || '',
    verdict_path: x.verdict_path || '',
  }
}

async function blindValidate(rawCand, cureRound) {
  const cand = asCandidate(rawCand)
  const v = await agent(validatorPrompt(cand, cureRound), {
    schema: VALIDATOR_SCHEMA,
    label: `validate:${cand.id}#r${cureRound}`,
    phase: 'Validate',
  })
  return v
}

async function validateOneCandidate(rawCand) {
  const cand = asCandidate(rawCand)
  let round = 0
  let last = null
  while (true) {
    const v = await blindValidate(cand, round)
    if (!v) {
      // A null validator is an infrastructure failure, never a CONFIRMED. Record
      // it as an unresolved candidate so the next batch can retry it.
      return { finding_id: cand.id, class_id: cand.class_id, verdict: 'UNRESOLVED', failed_checks: ['validator_agent_null'], cure_cycles: round, verdict_path: '', seven_q_verdict: 'NOT_RUN', seven_q_path: '', chain_used: '', repro_dir: '' }
    }
    last = v
    const verdict = String(v.verdict || '').toUpperCase()
    if (verdict === 'CURE' && round < MAX_CURE_CYCLES) {
      log(`cure ${cand.id} round ${round + 1}/${MAX_CURE_CYCLES}: failed=${JSON.stringify(v.failed_checks || [])} missing=${JSON.stringify(v.missing_evidence || [])}`)
      // FRESH cure executor, then a FRESH blind validator — independence survives
      // the cure because neither one is the agent that ran before it.
      await agent(curePrompt(cand, v.failed_checks, v.missing_evidence, round), {
        schema: CURE_SCHEMA, label: `cure:${cand.id}#${round + 1}`, phase: 'Validate',
      })
      round++
      continue
    }
    if (verdict === 'CURE' && round >= MAX_CURE_CYCLES) {
      // The bound is hard: a lingering CURE becomes DROPPED, written by a
      // mechanical demoter so the loop can never spin on a stuck candidate.
      const d = await agent(demotePrompt(cand, v, round), {
        schema: DEMOTE_SCHEMA, label: `demote:${cand.id}`, phase: 'Validate',
      })
      return {
        finding_id: cand.id, class_id: cand.class_id, verdict: 'DROPPED',
        failed_checks: v.failed_checks || [], missing_evidence: v.missing_evidence || [],
        cure_cycles: round, verdict_path: d && d.dropped_path ? d.dropped_path : `${OUTPUT_DIR}/artifacts/dropped/${cand.id}.json`,
        reason: 'cure budget exhausted', seven_q_verdict: 'NOT_RUN', seven_q_path: '', chain_used: '', repro_dir: '',
      }
    }
    return {
      finding_id: cand.id, class_id: cand.class_id, verdict: verdict || 'UNRESOLVED',
      failed_checks: v.failed_checks || [], missing_evidence: v.missing_evidence || [],
      cure_cycles: round, verdict_path: v.verdict_path || '',
      reason: v.reason || '', seven_q_verdict: 'NOT_RUN', seven_q_path: '', chain_used: '', repro_dir: '',
    }
  }
}

// Interleaved: each candidate is validated to a TERMINAL verdict the instant
// INTEGRATE materialises it, BEFORE the next batch runs. Never one downstream
// pass at the end — that is what lets a rejected class feed straight back into
// the search while the run still has budget.
async function validateBatch(newFindings) {
  const fresh = []
  for (const c of (newFindings || [])) {
    if (!c || !c.id || allCandidateIds.has(c.id)) continue
    allCandidateIds.add(c.id)
    fresh.push(c)
  }
  if (!fresh.length) return
  const results = PARALLEL_INLINE_VALIDATE
    ? (await parallel(fresh.map((c) => () => validateOneCandidate(c)))).filter(Boolean)
    : await inChunks(fresh, 1, (c) => validateOneCandidate(c))
  for (const r of (results || [])) {
    if (!r) continue
    const reported = String(r.verdict).toUpperCase()
    const key = terminal[reported] ? reported : 'DROPPED'
    if (key === reported) terminal[key].push(r)
    else terminal.DROPPED.push(Object.assign({}, r, { verdict: 'DROPPED', reason: r.reason || 'validator returned an unrecognised verdict (' + reported + ') — treated as dropped, never as confirmed' }))
    findingsOut.push({
      finding_id: r.finding_id, class_id: r.class_id, title: '', severity: '',
      verdict: key, cure_cycles: r.cure_cycles, verdict_path: r.verdict_path,
      seven_q_verdict: 'NOT_RUN', seven_q_path: '', chain_used: '', repro_dir: '',
    })
    log(`verdict ${r.finding_id}: ${key}${r.reason ? ' — ' + String(r.reason).slice(0, 140) : ''}`)
  }
}

const verdictSignal = () => ({
  confirmed: terminal.CONFIRMED.map((x) => x.finding_id),
  rejected: terminal.REJECTED.map((x) => x.finding_id),
  dropped: terminal.DROPPED.map((x) => x.finding_id),
})

while (!stopped && batch < MAX_BATCHES && batch < ABSOLUTE_MAX_BATCHES && exp < MAX_EXPERIMENTS && !coverageComplete) {
  batch++

  // --- P2 THINK (+ P4b reset folded in) ---
  const think = await agent(thinkPrompt(batch, resetMode, resetGoal, skepticBriefs.slice(-2), openCells, verdictSignal()), {
    schema: THINK_SCHEMA, label: `think:b${batch}`, phase: 'Loop',
  })
  if (!think) { stopped = true; stopReason = 'think agent returned null'; break }

  const wildcards = (think.hypotheses || []).filter((h) => h && h.wildcard)
  if ((think.hypotheses || []).length < 3) {
    log(`think b${batch}: WARNING only ${(think.hypotheses || []).length} hypothesis/hypotheses recorded (3 required) — recorded, not silently accepted`)
  }
  if (!wildcards.length) {
    log(`think b${batch}: WARNING no [wildcard] hypothesis — the invented-angle requirement was not met this batch`)
  }
  if (think.attack_chain_lines && think.attack_chain_lines > 50) {
    log(`think b${batch}: WARNING attack-chain.md is ${think.attack_chain_lines} lines (cap 50)`)
  }
  activeGoal = think.active_goal || activeGoal
  if (Number(think.attack_chain_lines) > 0) attackChainLines = Number(think.attack_chain_lines)
  if (Array.isArray(think.open_cells) && think.open_cells.length) openCells = think.open_cells

  // A terminate request is honoured ONLY when the coverage contract allows it.
  if (think.terminate && !coverageComplete) {
    log(`think b${batch}: ignoring terminate — ${coveragePending === Infinity ? 'the coverage gate has not reported yet' : coveragePending + ' applicable cell(s) still pending'}. Pending cells are the completion contract, not a hypothesis shortage.`)
    think.terminate = false
  }
  if (think.terminate) { stopped = true; stopReason = think.terminate_reason || 'think requested terminate'; break }

  const missions = (think.chosen || []).slice(0, 2)
  if (!missions.length) { stopped = true; stopReason = 'think produced no missions'; break }

  // --- P2b RESEARCH (conditional) ---
  let brief = null
  if (think.research_needed || resetMode) {
    const research = await agent(researchPrompt(think), { schema: RESEARCH_SCHEMA, label: `research:b${batch}`, phase: 'Loop' })
    brief = research ? research.brief : null
    if (research && Array.isArray(research.cves_found) && research.cves_found.length) {
      log(`research b${batch}: CVEs surfaced ${JSON.stringify(research.cves_found)}`)
    }
  }

  // --- P3 EXECUTE 1-2 executors in parallel ---
  const execResults = (await parallel(missions.map((m, i) => () =>
    agent(execPrompt(m, brief, `b${batch}m${i + 1}`, `E-${exp + i + 1}`), {
      schema: EXEC_SCHEMA, label: `exec:b${batch}m${i + 1}`, phase: 'Loop',
    })
  ))).filter(Boolean)

  // --- P4 INTEGRATE (sole writer of the three state files + coverage.json) ---
  const integ = await agent(integratePrompt(batch, execResults, resetMode, verdictSignal()), {
    schema: INTEGRATE_SCHEMA, label: `integrate:b${batch}`, phase: 'Loop',
  })
  resetMode = false
  if (!integ) { stopped = true; stopReason = 'integrate returned null'; break }

  prevExp = exp
  exp = Number(integ.exp_count) > exp ? Number(integ.exp_count) : exp + 1 // never stall the counter
  coverageComplete = integ.coverage_complete === true
  coverageRatio = typeof integ.coverage_ratio === 'number' ? integ.coverage_ratio : coverageRatio
  coveragePending = coverageComplete ? 0 : (typeof integ.applicable_pending === 'number' ? integ.applicable_pending : coveragePending)
  if (Array.isArray(integ.open_cells) && integ.open_cells.length) openCells = integ.open_cells
  goalAttempts = Number(integ.goal_attempts) || 0
  if (Number(integ.attack_chain_lines) > 0) attackChainLines = Number(integ.attack_chain_lines)

  log(`batch ${batch}: exp=${exp} progress=${integ.progress} pending=${coveragePending} ratio=${coverageRatio} ${integ.coverage_complete ? 'COVERAGE_COMPLETE' : ''}${integ.recommend_reset ? ' (reset queued)' : ''}`)

  // --- INTERLEAVED VALIDATION: before the next batch, never after the loop ---
  await validateBatch(integ.new_findings || [])

  if (coverageComplete) { log(`coverage: every applicable cell is covered, corroborated-negative or justified-NA (ratio ${coverageRatio}). Loop complete.`); break }
  if (integ.terminate) {
    if (!coverageComplete) {
      log(`integrate b${batch}: ignoring terminate — ${coveragePending} cell(s) still pending.`)
    } else { stopped = true; stopReason = integ.terminate_reason || 'integrate requested terminate'; break }
  }
  if (integ.recommend_reset) { resetMode = true; resetGoal = integ.stuck_goal || integ.active_goal || activeGoal }
  dryStreak = integ.progress ? 0 : dryStreak + 1
  if (dryStreak >= DRY_LIMIT) { stopped = true; stopReason = `no progress for ${DRY_LIMIT} consecutive batches`; break }

  // --- SKEPTIC: mandatory at experiments 5, 15, 25, then every 25 ---
  const N = skepticDue(prevExp, exp)
  if (N) {
    const sk = await agent(skepticPrompt(N), { schema: SKEPTIC_SCHEMA, label: `skeptic:E${N}`, phase: 'Loop' })
    if (sk && sk.brief_path) {
      skepticBriefs.push(sk.brief_path)
      log(`skeptic at E${N}: objection_found=${sk.objection_found} -> ${sk.brief_path}`)
    } else {
      log(`skeptic at E${N}: agent returned nothing — the mandatory checkpoint did NOT produce a brief`)
    }
  }
}

if (!stopped && !coverageComplete) {
  if (exp >= MAX_EXPERIMENTS) stopReason = `experiment budget (${MAX_EXPERIMENTS}) exhausted with ${coveragePending} cell(s) pending`
  else if (batch >= MAX_BATCHES) stopReason = `batch cap (${MAX_BATCHES}) reached`
  else stopReason = 'loop exited'
}
log(`Loop ended: ${batch} batch(es), ${exp} experiment(s). complete=${coverageComplete} pending=${coveragePending}. ${stopReason}`)

// ============================================================================
// PHASE: Chain — A -> B -> C for every CONFIRMED finding
// ============================================================================
phase('Chain')

const chained = []
for (const c of terminal.CONFIRMED) {
  if (!c || !c.finding_id) continue
  const ch = await agent(chainPrompt(c, nextFindingNum), {
    schema: CHAIN_SCHEMA, label: `chain:${c.finding_id}`, phase: 'Chain',
  })
  if (ch && ch.new_candidates && ch.new_candidates.length) nextFindingNum += ch.new_candidates.length
  chained.push({ finding_id: c.finding_id, chain_path: ch ? ch.chain_path : '', new_candidates: (ch && ch.new_candidates) || [], max_impact_proven: ch ? ch.max_impact_proven : '', reachable_without_privilege: ch ? ch.reachable_without_privilege : null })
  log(`chain ${c.finding_id}: ${ch ? (ch.hops || []).map((h) => `${h.hop}:${h.status}`).join(' -> ') : 'chain agent returned null'}`)
  // New candidates the chain discovered are real candidates: they go through the
  // SAME interleaved blind validation before the gate, never straight to a report.
  if (ch && ch.new_candidates && ch.new_candidates.length) await validateBatch(ch.new_candidates)
}

// ============================================================================
// PHASE: Gate — the 7-Question submission gate
// ============================================================================
phase('Gate')

const gateResults = []
for (const c of terminal.CONFIRMED) {
  if (!c || !c.finding_id) continue
  const chainRec = chained.find((x) => x.finding_id === c.finding_id)
  let cycle = 1
  let verdict = 'CURE'
  let last = null
  while (cycle <= MAX_CURE_CYCLES + 1) {
    const g = await agent(gatePrompt(c, chainRec ? chainRec.chain_path : '', cycle), {
      schema: GATE_SCHEMA, label: `gate:${c.finding_id}#c${cycle}`, phase: 'Gate',
    })
    if (!g) { last = null; verdict = 'BLOCKED'; break }
    last = g
    verdict = String(g.verdict || '').toUpperCase()
    if (verdict === 'CURE' && cycle <= MAX_CURE_CYCLES) {
      log(`gate ${c.finding_id}: CURE at cycle ${cycle}, failed=${JSON.stringify(g.failed_questions || [])} -> back to the cure loop, then re-validate, then re-gate`)
      // A Q-failure is NOT a kill: it is a failed check. Cure ONLY the named
      // questions, then re-validate on a FRESH blind validator BEFORE the gate
      // runs again (the re-validation is what makes the second gate meaningful).
      await agent(curePrompt(asCandidate(c), (g.failed_questions || []).map((q) => `q:${q}`), [], cycle - 1), {
        schema: CURE_SCHEMA, label: `gate-cure:${c.finding_id}#${cycle}`, phase: 'Gate',
      })
      const re = await blindValidate(asCandidate(c), cycle)
      if (re) {
        const rv = String(re.verdict || '').toUpperCase()
        if (rv !== 'CONFIRMED') {
          log(`gate ${c.finding_id}: re-validation after the Q-cure returned ${rv} — the finding is no longer confirmed and is removed from the gate queue`)
          c.verdict = rv
          const key = terminal[rv] ? rv : 'DROPPED'
          terminal.CONFIRMED = terminal.CONFIRMED.filter((x) => x.finding_id !== c.finding_id)
          terminal[key].push(Object.assign({}, c, { verdict: key, reason: 're-validation after a 7-Question cure returned ' + rv }))
          const out = findingsOut.find((f) => f.finding_id === c.finding_id)
          if (out) { out.verdict = key; out.cure_cycles = re.cure_cycles }
          verdict = key
          break
        }
      }
      cycle++
      continue
    }
    if (verdict === 'CURE' && cycle > MAX_CURE_CYCLES) {
      // Cycle budget spent on a gate that still wants a cure: record it as KILL
      // with the honest reason rather than letting it sit in limbo.
      verdict = 'KILL'
      last = Object.assign({}, last, { kill_reason: `7-Question Gate still returned CURE after ${MAX_CURE_CYCLES} cycle(s): ${JSON.stringify(last.failed_questions || [])}` })
    }
    break
  }
  if (!last) verdict = 'BLOCKED'
  gateResults.push({
    finding_id: c.finding_id,
    verdict: verdict,
    cycle: last ? last.cycle : cycle,
    q_path: last ? last.q_path : '',
    killed_by: last ? last.killed_by : '',
    kill_reason: last ? (last.kill_reason || '') : 'gate agent returned null',
    downgrade_to: last ? last.downgrade_to : '',
    chain_used: last ? (last.chain_used || (chainRec ? chainRec.chain_path : '')) : '',
  })
  log(`gate ${c.finding_id}: ${verdict}${last && last.killed_by ? ' (killed by ' + last.killed_by + ')' : ''}`)
}

// ============================================================================
// PHASE: Repro — a runbook per PASS
// ============================================================================
phase('Repro')

const passList = []
for (const c of terminal.CONFIRMED) {
  const g = gateResults.find((x) => x.finding_id === c.finding_id)
  if (!g || g.verdict !== 'PASS') continue
  const out = findingsOut.find((f) => f.finding_id === c.finding_id)
  passList.push({
    finding_id: c.finding_id,
    finding_dir: `${OUTPUT_DIR}/findings/finding-${c.finding_id.replace(/^F-/, '')}`,
    class_id: c.class_id,
    verdict_path: c.verdict_path || `${OUTPUT_DIR}/artifacts/validated/${c.finding_id}.json`,
    seven_q_path: g.q_path || `${OUTPUT_DIR}/seven-questions/${c.finding_id}.json`,
    chain_path: g.chain_used || '',
    downgrade_to: g.downgrade_to || '',
  })
  if (out) { out.seven_q_verdict = 'PASS'; out.seven_q_path = passList[passList.length - 1].seven_q_path; out.chain_used = passList[passList.length - 1].chain_path }
}
for (const g of gateResults) {
  const out = findingsOut.find((f) => f.finding_id === g.finding_id)
  if (out && out.seven_q_verdict !== 'PASS') { out.seven_q_verdict = g.verdict; out.seven_q_path = g.q_path; out.chain_used = g.chain_used || '' }
}

let repro = { built: [], refused: [] }
if (passList.length) {
  const r = await agent(reproPrompt(passList), { schema: REPRO_SCHEMA, label: 'repro:packs', phase: 'Repro' })
  if (r) {
    repro = r
    for (const b of (r.built || [])) {
      const out = findingsOut.find((f) => f.finding_id === b.finding_id)
      if (out) out.repro_dir = b.runbook_path
    }
  }
} else {
  log('repro: no finding passed the 7-Question Gate — no pack to build (the KILL/CURE outcomes are recorded in their verdicts)')
}

// ============================================================================
// PHASE: Report — the asset's closing gate
// ============================================================================
phase('Report')

const CLOSE_SCHEMA = {
  type: 'object', additionalProperties: true,
  required: ['gate_exit'],
  properties: {
    gate_exit: { type: 'integer' },
    coverage_complete: { type: 'boolean' },
    coverage_ratio: { type: 'number' },
    applicable: { type: 'integer' },
    covered: { type: 'integer' },
    pending: { type: 'integer' },
    missing_cells: { type: 'array', items: { type: 'string' } },
    schema_check_exit: { type: 'integer' },
    report_path: { type: 'string' },
    coverage_json_cells_written: { type: 'integer' },
    notes: { type: 'array', items: { type: 'string' } },
    blocked_reason: { type: 'string' },
  },
}

const close = await agent(
  `${DISCIPLINE}\n\n` +
  `ROLE: ASSET CLOSEOUT (deterministic tool runs + one written report; no requests, no judgment about findings). cwd is ${BUNDLE}.\n` +
  `The loop, the chain stage and the 7-Question Gate have all finished for this asset. Record the final state.\n\n` +
  `ASSET: ${ASSET_TAG}   OUTPUT_DIR: ${OUTPUT_DIR}   RUN DIR: ${RUN_DIR}   SCOPE: ${SCOPE_REF}\n` +
  `BUDGET: ${MAX_EXPERIMENTS} experiments, ${MAX_CURE_CYCLES} cure cycles, ${VOTES} refuters. Spent: ${exp} experiments, ${batch} batches.\n` +
  `IN-MEMORY RESULT (this invocation): ${JSON.stringify({ terminal: { confirmed: terminal.CONFIRMED.map((x) => x.finding_id), rejected: terminal.REJECTED.map((x) => x.finding_id), dropped: terminal.DROPPED.map((x) => x.finding_id) }, gates: gateResults.map((g) => ({ finding_id: g.finding_id, verdict: g.verdict, killed_by: g.killed_by })), packs: (repro.built || []).map((b) => b.runbook_path), refused_packs: repro.refused || [] })}\n\n` +
  `${COVERAGE_CONTRACT}\n\n` +
  `DO:\n` +
  `1. If coverage.json does not exist yet, create it now from ${OUTPUT_DIR}/applicability/cells.json — one row per class_id\n` +
  `   with every cell listed under units_tested. Do not invent a status: a cell you cannot justify as covered,\n` +
  `   covered_negative or deferred stays "pending".\n` +
  `2. Run, in this order, and record each exit code verbatim:\n` +
  `     python3 tools/cells_build.py --asset-dir ${OUTPUT_DIR} --catalog catalog/bounty-coverage-matrix.json\n` +
  `     python3 tools/coverage_gate.py --asset-dir ${OUTPUT_DIR}\n` +
  `     python3 tools/coverage_gate.py --asset-dir ${OUTPUT_DIR} --mode strict\n` +
  `     python3 tools/schema_check.py --kind all --run-dir ${RUN_DIR}\n` +
  `   ${SCHEMA_CHECK_GATE}\n` +
  `   Report coverage_complete, coverage_ratio, applicable, covered, pending and the missing cell keys from\n` +
  `   ${OUTPUT_DIR}/reports/coverage-matrix.json.\n` +
  `3. Write ${OUTPUT_DIR}/reports/asset-report.md:\n` +
  `     # Asset report - ${ASSET_TAG}\n` +
  `     ## Status            one line: coverage complete or the exact number of pending cells\n` +
  `     ## Budget            experiments spent / budget, batches, cure cycles used, refuter quorum\n` +
  `     ## Confirmed          one row per CONFIRMED finding: id, class, severity, one-line proven impact, runbook path\n` +
  `     ## Chains            the A->B->C summary per finding from ${OUTPUT_DIR}/chains/, marking which hops are CONFIRMED and\n` +
  `                          which remain HYPOTHESIS (quote "## What is NOT proven" — never promote a hypothesis to impact)\n` +
  `     ## Gate outcomes     one row per finding: PASS / KILL (+ killed_by) / CURE, and any downgrade_to\n` +
  `     ## Rejected & dropped the false positives and the uncured candidates with their failed_checks (audit trail only —\n` +
  `                          none of these may appear in any report body as a finding)\n` +
  `     ## Coverage gaps     every still-pending cell with the concrete next action for it\n` +
  `     ## Dead ends         the top entries from session-memory.md ## Dead Ends, so the next run does not repeat them\n` +
  `   Read every number from the artifacts on disk. Do not transcribe from this prompt.\n\n` +
  `Return CLOSE_SCHEMA. blocked_reason is a STRING: '' means no block; set it only if a tool exited 2 (unreadable inputs).`,
  { schema: CLOSE_SCHEMA, label: 'closeout', phase: 'Report' }
)

const gateExit = close ? Number(close.gate_exit) : 2
const finalCoverage = {
  applicable: close && typeof close.applicable === 'number' ? close.applicable : APPLICABLE.length,
  covered: close && typeof close.covered === 'number' ? close.covered : null,
  pending: close && typeof close.pending === 'number' ? close.pending : (coveragePending === Infinity ? null : coveragePending),
  ratio: close && typeof close.coverage_ratio === 'number' ? close.coverage_ratio : coverageRatio,
  complete: !!(close && close.coverage_complete === true),
  gate_exit: gateExit,
  open_cells: (close && close.missing_cells) || openCells,
}

// Tri-state coverage status. RESUMABLE = the budget ran out with cells still
// open (a re-invocation continues); INCOMPLETE_COVERAGE = the run stopped stuck
// with budget remaining. Neither is ever reported as COMPLETE.
const status = finalCoverage.complete
  ? 'COVERAGE_COMPLETE'
  : (exp >= MAX_EXPERIMENTS || batch >= MAX_BATCHES ? 'INCOMPLETE_RESUMABLE' : 'INCOMPLETE_COVERAGE')

CHECKPOINTS.push({ id: 'ASSET_LOOP', kind: 'bounded-loop', batches: batch, experiments: exp, stop_reason: stopReason })
for (const N of [5, 15, 25]) {
  if (exp >= N) CHECKPOINTS.push({ id: `SKEPTIC_${N}`, kind: 'blind-skeptic', produced: skepticBriefs.some((p) => p.endsWith(`skeptic-brief-${N}.md`)) })
}
CHECKPOINTS.push({ id: 'CHAIN', kind: 'per-confirmed-finding', chained: chained.map((c) => ({ finding_id: c.finding_id, chain_path: c.chain_path, max_impact_proven: c.max_impact_proven })) })
CHECKPOINTS.push({ id: 'SEVEN_QUESTION_GATE', kind: 'submission-gate', outcomes: gateResults.map((g) => ({ finding_id: g.finding_id, verdict: g.verdict, killed_by: g.killed_by })) })
CHECKPOINTS.push({ id: 'REPRO', kind: 'runbook-built', packs: (repro.built || []).map((b) => b.runbook_path) })

const blocks = []
if (stopReason) blocks.push(`loop stop: ${stopReason}`)
if (!finalCoverage.complete) blocks.push(`coverage incomplete: ${finalCoverage.pending} applicable cell(s) pending, gate exit ${gateExit}`)
if (close && close.blocked_reason) blocks.push(`closeout: ${close.blocked_reason}`)
for (const f of (repro.refused || [])) blocks.push(`repro pack refused for ${f.finding_id}: ${f.reason}`)

log(`asset ${ASSET_TAG}: status=${status} confirmed=${terminal.CONFIRMED.length} rejected=${terminal.REJECTED.length} dropped=${terminal.DROPPED.length} passes=${passList.length} coverage=${finalCoverage.covered}/${finalCoverage.applicable}`)

return {
  status: status,
  asset_tag: ASSET_TAG,
  asset_id: boot.asset_id || null,
  output_dir: OUTPUT_DIR,
  run_dir: RUN_DIR,
  experiments_run: exp,
  batches: batch,
  stop_reason: stopReason,
  findings: findingsOut,
  confirmed: terminal.CONFIRMED.map((x) => x.finding_id),
  rejected: terminal.REJECTED.map((x) => x.finding_id),
  dropped: terminal.DROPPED.map((x) => x.finding_id),
  gated_pass: gateResults.filter((g) => g.verdict === 'PASS').map((g) => g.finding_id),
  gated_kill: gateResults.filter((g) => g.verdict === 'KILL').map((g) => ({ finding_id: g.finding_id, killed_by: g.killed_by, kill_reason: g.kill_reason })),
  chains: chained,
  repro_packs: repro.built || [],
  repro_refused: repro.refused || [],
  coverage: finalCoverage,
  skeptic_briefs: skepticBriefs,
  attack_chain_lines: attackChainLines,   // last reported line count of attack-chain.md (cap 50)
  report_path: close ? close.report_path : `${OUTPUT_DIR}/reports/asset-report.md`,
  asset_report: `${OUTPUT_DIR}/reports/asset-report.md`,
  coverage_matrix: `${OUTPUT_DIR}/reports/coverage-matrix.json`,
  experiments_ledger: `${OUTPUT_DIR}/experiments.md`,
  state_files: [`${OUTPUT_DIR}/attack-chain.md`, `${OUTPUT_DIR}/session-memory.md`, `${OUTPUT_DIR}/experiments.md`],
  checkpoints: CHECKPOINTS,
  blocks: blocks,
  notes: [
    `Validation was INTERLEAVED: every candidate was driven to a terminal verdict (with up to ${MAX_CURE_CYCLES} cure cycles on FRESH blind agents) before the next batch.`,
    `Blind-validator contract held: the validator never received attack-chain.md, session-memory.md, another finding, or an executor log.`,
    `Coverage is by VALID only: a class whose candidates were all rejected stays pending and search continues.`,
  ],
}
