# contracts/ — the stage interfaces

Nine JSON Schemas, one per artifact that crosses a stage boundary. A stage is not finished until
its output validates against its contract; `tools/schema_check.py` is the enforcer.

| `--kind` | file | schema `$id` | written by |
|---|---|---|---|
| `scope` | `scope.schema.json` | `bbh/scope/v1` | `bbh_scope.py init` |
| `classification` | `classification.schema.json` | `bbh/classification/v1` | `bbh_classify.py` |
| `surface` | `surface.v2.schema.json` | `surface/v2` | `surface_build.py` |
| `queue` | `surface-queue.schema.json` | `bbh/queue/v1` | `queue_build.py` |
| `slice` | `slice.schema.json` | `bbh/slice/v1` | `slice_build.py` |
| `finding` | `finding.schema.json` | `bbh/finding/v1` | the executor |
| `verdict` | `validation-verdict.schema.json` | `bbh/verdict/v1` | the blind validator |
| `seven-questions` | `seven-questions.schema.json` | `bbh/7q/v1` | the 7-Question Gate |
| `repro` | `repro-runbook.schema.json` | `bbh/repro/v1` | authored, then rendered by `repro_pack.py` |

`surface/v2` is the one contract this bundle did **not** author: it is communitytools' surface
inventory format, kept byte-compatible so the coverage catalogue's `applies_when` predicates can be
evaluated against it. Everything else is this bundle's own.

Run `python3 tools/schema_check.py --list-kinds` for the authoritative table including aliases;
the kind names deliberately do **not** map mechanically onto the filenames (`queue` →
`surface-queue.schema.json`).

---

## Do NOT hand these files to a workflow `agent({schema})` call

This is the single easiest way to kill a workflow script, and the failure is total rather than
partial: a misused `schema` throws, and a throwing hook kills the whole script — not just that
agent's item.

These contracts are **full JSON Schema**, validated with the `jsonschema` library by
`tools/schema_check.py`. The DSH workflow `agent()` hook accepts only a **narrow subset**, and the
two are not the same language:

| Allowed in `contracts/*.json` | Allowed in `agent({schema})` |
|---|---|
| `type: ["string", "null"]` (a type **array**) | ❌ — must be a **single** `type` string |
| `format`, `pattern` | ❌ rejected |
| numeric bounds (`minimum`, `maximum`) | ❌ rejected |
| `$ref`, `$defs` | ❌ rejected |
| `type`, `properties`, `required`, `additionalProperties`, `items`, `enum`, `const`, `oneOf` | ✅ the whole supported set |

Six of the nine contracts use `type: [...]` arrays, so passing one straight into an executor's
output schema would throw on the first call. The workflows therefore declare their **own** inline
subset schemas and use these files only for on-disk artifact validation. If you add a workflow that
wants a structured return, write a fresh inline schema — do not import a contract.

A related invariant: keys named `schema` inside these documents hold the `$id` string (`bbh/verdict/v1`),
which is how `schema_check.py --kind all` recognises a file by content when the path is ambiguous.

---

## The three-file coordinator state contract

Not a JSON Schema, because they are Markdown by design — an agent reads and rewrites them directly,
and a schema would add ceremony without adding a check. But the contract is real and the workflow
depends on it. All three live in the slice's `output_dir`; the INTEGRATE agent is their **sole
writer** so parallel executors never race:

| file | job | discipline |
|---|---|---|
| `attack-chain.md` | current working theory | **rewritten** every batch, ≤50 lines |
| `experiments.md` | append-only ledger of what was tried | one `E-NNN` row per attempt with goal + outcome |
| `session-memory.md` | durable facts that outlive the theory | append-only, ~80 lines: identities (env-var NAMES only), confirmed-live facts, dead ends, environment quirks, confirmed chains |

Upstream communitytools defines the first two. `session-memory.md` is this bundle's addition: a
bounty run spans more sessions than a scoped pentest, and the dead-ends list is what stops a re-run
from repeating yesterday's failures.

One more file matters and is written by the same agent: `coverage.json` (`bbh/coverage/v1`,
described in `tools/README.md` § Stage 3 gate). It is the ledger the coverage gate scores against,
and it is the only artifact where an agent's claim is checked against the filesystem.
